package com.ufoto.request;

import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.NoArgsConstructor;

import java.io.Serializable;
import java.util.List;
import java.util.Map;

/**
 * @author tangyd
 */
@Data
@Builder
@NoArgsConstructor
@AllArgsConstructor
public class ImageCheckRequest implements Serializable {

    private List<ActionData> actionData;
    private String uid;
    private String source;
    private Map<String, Object> data;

}
