package com.ufoto.constants.result;

/**
 * @author tangyd
 */
public class RecognizeFaceResultConstants {

    public static final Integer FEMALE = 0;
    public static final Integer MALE = 1;

}
