package com.ufoto.request;

import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.NoArgsConstructor;

import java.io.Serializable;
import java.util.List;

/**
 * @author tangyd
 */
@Data
@Builder
@NoArgsConstructor
@AllArgsConstructor
public class ActionData implements Serializable {

    private String url;
    private Integer type;
    private List<Integer> action;

}
