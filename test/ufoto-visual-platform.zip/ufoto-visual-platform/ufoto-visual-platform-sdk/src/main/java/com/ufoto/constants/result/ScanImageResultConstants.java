package com.ufoto.constants.result;

/**
 * @author tangyd
 */
public class ScanImageResultConstants {

    public static final Integer LEGAL = 1;
    public static final Integer ILLEGAL = 2;
    public static final Integer REVIEW = 3;
    public static final Integer REPORT = 4;

}
