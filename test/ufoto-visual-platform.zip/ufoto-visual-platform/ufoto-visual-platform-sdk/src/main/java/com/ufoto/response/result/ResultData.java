package com.ufoto.response.result;

import java.io.Serializable;

/**
 * @author tangyd
 */
public interface ResultData extends Serializable {
}
