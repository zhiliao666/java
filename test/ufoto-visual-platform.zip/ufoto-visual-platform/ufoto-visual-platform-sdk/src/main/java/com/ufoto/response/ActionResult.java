package com.ufoto.response;

import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.NoArgsConstructor;
import com.ufoto.response.result.ResultData;

import java.io.Serializable;

/**
 * @author tangyd
 */
@Data
@Builder
@NoArgsConstructor
@AllArgsConstructor
public class ActionResult implements Serializable {

    private Integer type;
    private ResultData result;

}
