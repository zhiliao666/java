package com.ufoto.response;

import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.NoArgsConstructor;

import java.io.Serializable;
import java.util.List;
import java.util.Map;

/**
 * @author tangyd
 */
@Data
@Builder
@NoArgsConstructor
@AllArgsConstructor
public class ImageCheckResponse implements Serializable {

    private List<ResponseResult> result;
    private String uid;
    private String source;
    private Map<String, Object> data;

}
