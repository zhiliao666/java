package com.ufoto.constants;

/**
 * @author tangyd
 */
public class MediaType {

    public static final Integer IMAGE = 1;

    public static final Integer VIDEO = 2;

}
