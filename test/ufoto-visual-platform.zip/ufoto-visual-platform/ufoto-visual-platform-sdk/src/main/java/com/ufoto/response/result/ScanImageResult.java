package com.ufoto.response.result;

import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.NoArgsConstructor;

/**
 * @author tangyd
 */
@Data
@Builder
@NoArgsConstructor
@AllArgsConstructor
public class ScanImageResult implements ResultData {

    private Integer checkState;

}
