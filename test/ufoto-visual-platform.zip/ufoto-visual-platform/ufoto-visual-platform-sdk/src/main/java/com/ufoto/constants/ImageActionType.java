package com.ufoto.constants;

/**
 * @author tangyd
 */
public class ImageActionType {

    public static final Integer SCAN_IMAGE = 1;

    public static final Integer FACE_RECOGNIZE = 2;

}
