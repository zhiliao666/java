package com.ufoto.config.process;

import lombok.Data;

import java.util.ArrayList;
import java.util.LinkedList;
import java.util.List;

/**
 * @author tangyd
 */
@Data
public class ActionProcessConfigDto {

    public ActionProcessConfigDto() {
        this.sum = 0;
        this.processConfigDtoList = new ArrayList<>();
        this.preProcessChain = new LinkedList<>();
    }

    private Integer sum;
    private List<ProcessConfigDto> processConfigDtoList;
    private String defaultProcess;
    private List<String> preProcessChain;

}
