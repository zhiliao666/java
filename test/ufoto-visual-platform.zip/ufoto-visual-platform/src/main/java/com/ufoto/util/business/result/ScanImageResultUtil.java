package com.ufoto.util.business.result;

import com.tencentcloudapi.cms.v20190321.models.ImageData;
import com.tencentcloudapi.cms.v20190321.models.ImageModerationResponse;
import com.tencentcloudapi.cms.v20190321.models.ImagePornDetect;
import com.ufoto.business.constants.TencentImageScanConstants;
import com.ufoto.dto.ResultsDto;
import org.apache.commons.lang3.StringUtils;

import java.util.EnumSet;
import java.util.Optional;

/**
 * @author tangyd
 */
public class ScanImageResultUtil {

    public static Integer parseCheckResult(ImageModerationResponse imageModerationResponse) {
        ImageData imageData = imageModerationResponse.getData();
        Long evilFlag = imageData.getEvilFlag();
        if(evilFlag.equals(TencentImageScanConstants.ILLEGAL_EVIL_TYPE)) {
            Long evilType = imageData.getEvilType();
            if(evilType.equals(TencentImageScanConstants.EVIL_TYPE_PORN)) {
                return 2;
            } else {
                ImagePornDetect imagePornDetect = imageData.getPornDetect();
                if(imagePornDetect != null && imagePornDetect.getHitFlag().equals(TencentImageScanConstants.ILLEGAL_EVIL_TYPE)) {
                    return 2;
                }
            }
        }
        return 1;
    }

    public static Integer parseCheckResult(ResultsDto dto) {
        return parseCheckResult(dto.getLabel(), dto.getSuggestion());
    }

    public static Integer parseCheckResult(String label, String suggestion, Float rate, Float max) {
//        if(rate >= max) return 2;
        return parseCheckResult(label, suggestion);
    }

    public static Integer parseCheckResult(String label, String suggestion) {
        String data = label + "_" + suggestion;
        Optional<CheckEnum> opt = EnumSet.allOf(CheckEnum.class).stream()
                .filter(item -> StringUtils.equalsIgnoreCase(item.data, data))
                .findFirst();
        if (opt.isPresent()) {
            return opt.get().getType();
        }
        return 3;
    }

    enum CheckEnum {

        NORMAL_PASS("normal_pass", 1),
        NORMAL_BLOCK("normal_block", 2),
        NORMAL_REVIEW("normal_review", 3),


        SEXY_PASS("sexy_pass", 1),
        SEXY_BLOCK("sexy_block", 2),
        SEXY_REVIEW("sexy_review", 3),


        PORN_PASS("porn_pass", 2),
        PRON_BLOCK("porn_block", 2),
        PRON_REVIEW("porn_review", 2);

        private String data;

        private Integer type;

        public String getData() {
            return data;
        }

        public Integer getType() {
            return type;
        }

        CheckEnum(String data, Integer type) {
            this.data = data;
            this.type = type;
        }

        @Override
        public String toString() {
            return data;
        }
    }

}
