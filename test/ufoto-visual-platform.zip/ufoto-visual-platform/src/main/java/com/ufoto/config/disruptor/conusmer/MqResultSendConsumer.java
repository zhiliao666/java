package com.ufoto.config.disruptor.conusmer;

import com.ufoto.config.disruptor.event.MqResultEvent;
import com.ufoto.lmax.consumer.Consumer;
import com.ufoto.mq.RabbitProducer;
import com.ufoto.mq.constants.EExchange;
import com.ufoto.util.json.JSONUtil;
import lombok.extern.slf4j.Slf4j;
import org.apache.commons.lang3.StringUtils;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;

/**
 * @author tangyd
 */
@Slf4j
@Component
public class MqResultSendConsumer extends Consumer<MqResultEvent> {

    @Autowired
    RabbitProducer rabbitProducer;

    public MqResultSendConsumer() {
        super(ConsumerId.CONSUMER_MQ_RESOLVE);
    }

    @Override
    public void consume(MqResultEvent event) {
        if(event.getImageCheckResponse() != null) {
            log.debug("prepare to send message to mq: {}", JSONUtil.toJSON(event.getImageCheckResponse()));
            rabbitProducer.produceByJson(EExchange.VISUAL_RESPONSE_TOPIC, event.getImageCheckResponse().getSource(), event.getImageCheckResponse());
            event.setImageCheckResponse(null);
        }
    }
}
