package com.ufoto.business.retry;

import com.github.benmanes.caffeine.cache.Cache;
import com.ufoto.config.disruptor.event.MqResultEvent;
import com.ufoto.dao.read.ReadUfotoFailTaskMapper;
import com.ufoto.dao.write.WriteUfotoFailTaskMapper;
import com.ufoto.dto.RetryTaskDto;
import com.ufoto.entity.UfotoFailTaskEntity;
import com.ufoto.request.ImageCheckRequest;
import com.ufoto.util.json.JSONUtil;
import lombok.extern.slf4j.Slf4j;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;

import java.util.List;
import java.util.stream.Collectors;

/**
 * @author tangyd
 */
@Component
public class FailTaskManager {

    @Autowired
    Cache<String, Integer> failTaskCache;

    @Autowired
    WriteUfotoFailTaskMapper writeUfotoFailTaskMapper;

    @Autowired
    ReadUfotoFailTaskMapper readUfotoFailTaskMapper;

    public List<RetryTaskDto> getFailTasks() {
        return readUfotoFailTaskMapper.getRetryTasks().stream()
                .filter(request -> failTaskCache.getIfPresent(request.getUuid()) == null)
                .map(request -> {
                    failTaskCache.put(request.getUuid(), request.getRetryTimes());
                    return new RetryTaskDto(request.getUuid(), JSONUtil.toObject(request.getRequestBody(), ImageCheckRequest.class));
                })
                .collect(Collectors.toList());
    }

    public void taskCompleted(String uuid) {
        if(failTaskCache.getIfPresent(uuid) != null) {
            failTaskCache.invalidate(uuid);
            writeUfotoFailTaskMapper.delete(uuid);
        }
    }

    public void addFailTask(MqResultEvent event) {
        Integer retryTimes = failTaskCache.getIfPresent(event.getUuid());
        if(retryTimes == null) {
            UfotoFailTaskEntity ufotoFailTaskEntity = new UfotoFailTaskEntity();
            ufotoFailTaskEntity.setUuid(event.getUuid());
            ufotoFailTaskEntity.setRetryTimes(0);
            ufotoFailTaskEntity.setRequestBody(JSONUtil.toJSON(event.getImageCheckRequest()));
            writeUfotoFailTaskMapper.insert(ufotoFailTaskEntity);
        } else {
            failTaskCache.invalidate(event.getUuid());
            writeUfotoFailTaskMapper.update(event.getUuid(), retryTimes + 1);
        }
    }

}
