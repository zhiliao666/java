package com.ufoto.config.mq;

import com.ufoto.mq.constants.EExchange;
import org.springframework.amqp.core.TopicExchange;
import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;

/**
 * @author tangyd
 */
@Configuration
public class MqConfig {

    @Bean(EExchange.VISUAL_RESPONSE_TOPIC)
    public TopicExchange topicExchange() {
        return new TopicExchange(EExchange.VISUAL_RESPONSE_TOPIC);
    }

}
