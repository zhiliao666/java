package com.ufoto.util;

import org.joda.time.DateTime;
import org.joda.time.DateTimeZone;

import java.math.BigInteger;
import java.sql.Timestamp;
import java.text.DateFormat;
import java.text.SimpleDateFormat;
import java.time.DayOfWeek;
import java.time.LocalDate;
import java.time.ZoneId;
import java.time.format.DateTimeFormatter;
import java.util.Calendar;
import java.util.Date;
import java.util.TimeZone;

/**
 * Created by Administrator on 2015/6/30.
 */
public class DateUtil {
    public static final String DEFAULT_TIMEZONE_ID = "Asia/Shanghai";
    public static final TimeZone DEFAULT_TIMEZONE = TimeZone.getTimeZone(DEFAULT_TIMEZONE_ID);
    public static final ZoneId ZONE_ID = ZoneId.of(DateUtil.DEFAULT_TIMEZONE_ID);

    public static String getCurrentDateStr(String format) {
        DateFormat dateFormat = new SimpleDateFormat(format);
        dateFormat.setTimeZone(DEFAULT_TIMEZONE);
        return dateFormat.format(Calendar.getInstance().getTime());
    }

    public static String getYesterdayDateStr(String format) {
        DateFormat dateFormat = new SimpleDateFormat(format);
        dateFormat.setTimeZone(DEFAULT_TIMEZONE);
        return dateFormat.format(DateTime.now(DateTimeZone.forTimeZone(DEFAULT_TIMEZONE)).minusDays(1).toDate());
    }

    private static Integer getSecondFromGMTDateString(String date) {
        SimpleDateFormat simpleDateFormat = new SimpleDateFormat("yyyy-MM-dd");
        simpleDateFormat.setTimeZone(DEFAULT_TIMEZONE);
        try {
            Date d = simpleDateFormat.parse(date);
            return new Long(d.getTime() / 1000).intValue();
        } catch (Exception e) {
            e.printStackTrace();
        }
        return null;
    }

    public static Integer getCurrentSecondIntValue() {
        return new Long(System.currentTimeMillis() / 1000).intValue();
    }

    public static Long getCurrentSecond() {
        return System.currentTimeMillis() / 1000;
    }

    public static Long getCurrentSecondLongValue() {
        return System.currentTimeMillis();
    }

    public static Integer getGMTDayStart(Integer timestamp) {
        Calendar calendar = Calendar.getInstance(DEFAULT_TIMEZONE);
        calendar.setTimeInMillis(timestamp * 1000L);
        DateFormat dateFormat = new SimpleDateFormat("yyyy-MM-dd");
        dateFormat.setTimeZone(DEFAULT_TIMEZONE);
        String dateString = dateFormat.format(calendar.getTime());
        return getSecondFromGMTDateString(dateString);
    }

    /**
     * 获取当前时间与 timestamp之间的小时数 如果当前时间大于timestamp 则返回0
     *
     * @param timestamp 时间戳 秒
     * @return Result
     */
    public static Integer getTimeHour(Integer timestamp) {
        Integer current = getCurrentSecondIntValue();
        if (current >= timestamp) {
            return 0;
        }
        return (timestamp - current) / 3600;
    }

    /**
     * 获取当前时间到凌晨的时间差
     *
     * @return time diff
     */
    public static Long getTodayTimeDiff() {
        Calendar c = Calendar.getInstance();
        long now = c.getTimeInMillis();
        c.add(Calendar.DAY_OF_MONTH, 1);
        c.set(Calendar.HOUR_OF_DAY, 0);
        c.set(Calendar.MINUTE, 0);
        c.set(Calendar.SECOND, 0);
        c.set(Calendar.MILLISECOND, 0);
        return (c.getTimeInMillis() - now) / 1000;
    }

    /**
     * 根据结束时间获取剩余天数
     *
     * @param expireTime
     * @return
     */
    public static Integer getDay(Integer expireTime) {
        if (expireTime != null) {
            int i = (expireTime - DateUtil.getCurrentSecondIntValue()) / 86400;
            return i < 0 ? 0 : i;
        }
        return 0;
    }

    /**
     * 获得当天零时零分零秒
     *
     * @return
     */
    public static Integer initDateByDay() {
        Calendar calendar = Calendar.getInstance();
        calendar.setTime(new Date());
        calendar.set(Calendar.HOUR_OF_DAY, 0);
        calendar.set(Calendar.MINUTE, 0);
        calendar.set(Calendar.SECOND, 0);
        return new Long(calendar.getTime().getTime() / 1000).intValue();
    }

    public static Integer getGMTTodayStart() {
        Calendar calendar = Calendar.getInstance(DEFAULT_TIMEZONE);
        DateFormat dateFormat = new SimpleDateFormat("yyyy-MM-dd");
        dateFormat.setTimeZone(DEFAULT_TIMEZONE);
        String dateString = dateFormat.format(calendar.getTime());
        return getSecondFromGMTDateString(dateString, "yyyy-MM-dd");
    }

    public static Integer getGMTTodayEnd() {
        return getGMTTodayStart() + 60 * 60 * 24;
    }

    public static Integer getSecondFromGMTDateString(String date, String format) {

        SimpleDateFormat simpleDateFormat = new SimpleDateFormat(format);
        simpleDateFormat.setTimeZone(DEFAULT_TIMEZONE);
        try {
            Date d = simpleDateFormat.parse(date);
            return new Long(d.getTime() / 1000).intValue();
        } catch (Exception e) {
            e.printStackTrace();
        }
        return null;
    }

    public static Integer getOneDaySecond() {
        return 86400;
    }

    public static Integer getOneDaySecondSign() {
        return 86400;
    }

    public static Long date2Long(Date date) {
        if (date == null) return null;
        try {
            return date.getTime() / 1000;
        } catch (Exception e) {
            e.printStackTrace();
        }
        return null;
    }

    public static String format(Date date) {
        SimpleDateFormat dateFormat = new SimpleDateFormat("yyyy-MM-dd HH:mm:ss.SSS");
        return dateFormat.format(date);
    }

    public static boolean isInSameDay(Integer time1, Integer time2) {
        SimpleDateFormat dateFormat = new SimpleDateFormat("yyyyMMdd");
        final String day1 = dateFormat.format(new Date(time1 * 1000L));
        final String day2 = dateFormat.format(new Date(time2 * 1000L));
        return day1.equals(day2);
    }

    public static boolean isContinuous(Integer time1, Integer time2) {
        if (time1 < time2) {
            SimpleDateFormat dateFormat = new SimpleDateFormat("yyyyMMdd");
            final String day1 = dateFormat.format(new Date(time1 * 1000L));
            final String day2 = dateFormat.format(new Date(time2 * 1000L));
            BigInteger d1 = new BigInteger(day1);
            BigInteger d2 = new BigInteger(day2);
            return d2.subtract(d1).intValue() == 1;
        }
        return false;
    }

    /**
     * 获取当前时间到中国时间的零点的秒数
     *
     * @return 相对时间
     */
    public static int countdown() {
        final DateTime startTime = DateTime.now(DateTimeZone.forTimeZone(DateUtil.DEFAULT_TIMEZONE));
        final DateTime endTime = startTime.plusDays(1).withHourOfDay(0).withMinuteOfHour(0).withSecondOfMinute(0).withMillisOfSecond(0);
        return (int) ((endTime.toDate().getTime() - startTime.toDate().getTime()) / 1000);
    }

    public static int countdownUTC() {
        final DateTime startTime = DateTime.now();
        final DateTime endTime = startTime.plusDays(1).withHourOfDay(0).withMinuteOfHour(0).withSecondOfMinute(0).withMillisOfSecond(0);
        return (int) ((endTime.toDate().getTime() - startTime.toDate().getTime()) / 1000);
    }

    public static Date chinaZero() {
        final DateTime startTime = DateTime.now(DateTimeZone.forTimeZone(DateUtil.DEFAULT_TIMEZONE));
        return startTime.plusDays(1).withHourOfDay(0).withMinuteOfHour(0).withSecondOfMinute(0).withMillisOfSecond(0).toDate();
    }

    public static Date chinaZeroAfterDays(int day) {
        final DateTime startTime = DateTime.now(DateTimeZone.forTimeZone(DateUtil.DEFAULT_TIMEZONE));
        return startTime.plusDays(day).withHourOfDay(0).withMinuteOfHour(0).withSecondOfMinute(0).withMillisOfSecond(0).toDate();
    }

    public static Date chinaZeroBeforeDays(int day) {
        final DateTime startTime = DateTime.now(DateTimeZone.forTimeZone(DateUtil.DEFAULT_TIMEZONE));
        return startTime.minusDays(day).withHourOfDay(0).withMinuteOfHour(0).withSecondOfMinute(0).withMillisOfSecond(0).toDate();
    }

    public static DateTime zero(DateTime dateTime) {
        return dateTime.withHourOfDay(0).withMinuteOfHour(0).withSecondOfMinute(0).withMillisOfSecond(0);
    }

    public static boolean isToday(Integer timestamp) {
        return DateTime.now().toString("yyyyMMdd").equals(new DateTime(timestamp * 1000L).toString("yyyyMMdd"));
    }

    public static Integer getTimestamp(DateTime dateTime) {
        return (int) (dateTime.getMillis() / 1000);
    }

    /**
     * 获取是当前第几周
     *
     * @return 第几周
     */
    public static String getCurrentWeek() {
        final DateTime now = DateTime.now(DateTimeZone.forTimeZone(DEFAULT_TIMEZONE));
        return getWeek(now);
    }

    public static String getWeek(DateTime now) {
        return now.weekyear().getAsString() + now.weekOfWeekyear().getAsString();
    }

    public static String getBeforeCurrentWeek(int timestamp) {
        DateTime now = new DateTime(timestamp * 1000L, DateTimeZone.forTimeZone(DateUtil.DEFAULT_TIMEZONE)).minusWeeks(1);
        return getWeek(now);
    }

    /**
     * 获取上周
     *
     * @return 上周
     */
    public static String getBeforeCurrentWeek() {
        final DateTime now = DateTime.now(DateTimeZone.forTimeZone(DEFAULT_TIMEZONE)).minusWeeks(1);
        return getWeek(now);
    }


    public static int localDate2Timestamp(LocalDate localDate) {
        return (int) (Timestamp.valueOf(localDate.atStartOfDay()).getTime() / 1000);
    }

    /**
     * 获取当天的零点
     *
     * @return 零点
     */
    public static int getCurrentDayZero() {
        return localDate2Timestamp(LocalDate.now(DateUtil.ZONE_ID));
    }

    /**
     * 获取昨天的零点
     *
     * @return 昨天的零点
     */
    public static int getBeforeCurrentDayZero() {
        return localDate2Timestamp(LocalDate.now(DateUtil.ZONE_ID).minusDays(1));
    }

    /**
     * 获取当前周的星期一的零点
     *
     * @return 星期一零点的时间戳
     */
    public static int getCurrentMondayZero() {
        return localDate2Timestamp(LocalDate.now(DateUtil.ZONE_ID).with(DayOfWeek.MONDAY));
    }

    /**
     * 获取当前周上周的星期一的零点
     *
     * @return 上周星期一零点的时间戳
     */
    public static int getBeforeCurrentMondayZero() {
        return localDate2Timestamp(LocalDate.now(DateUtil.ZONE_ID).with(DayOfWeek.MONDAY).minusWeeks(1));
    }

    /**
     * 获取当前月的第一天的零点
     *
     * @return 当前月的第一天的零点
     */
    public static int getCurrentMonthFirstDayZero() {
        return localDate2Timestamp(LocalDate.now(DateUtil.ZONE_ID).withDayOfMonth(1));
    }

    /**
     * 获取当前月上个月的第一天的零点
     *
     * @return 当前月上个月的第一天的零点
     */
    public static int getBeforeCurrentMonthFirstDayZero() {
        return localDate2Timestamp(LocalDate.now(DateUtil.ZONE_ID).withDayOfMonth(1).minusMonths(1));
    }

    public static void main(String[] args) {
        final LocalDate localDate = LocalDate.parse("2019-03-23 12:12:13", DateTimeFormatter.ofPattern("yyyy-MM-dd HH:mm:ss"));
        System.out.println(localDate);
        System.out.println(localDate.with(DayOfWeek.MONDAY));
        System.out.println(localDate.withDayOfMonth(1));
        System.out.println(localDate.withDayOfMonth(1).minusMonths(1));
        System.out.println("-----------");
        System.out.println(getCurrentMondayZero());
        System.out.println(getBeforeCurrentMondayZero());
        System.out.println(getCurrentMonthFirstDayZero());
        System.out.println(getBeforeCurrentMonthFirstDayZero());

        System.out.println("---");

        System.out.println(getCurrentWeek());
    }

}
