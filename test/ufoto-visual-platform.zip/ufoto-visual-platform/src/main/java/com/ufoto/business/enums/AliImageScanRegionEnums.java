package com.ufoto.business.enums;

/**
 * @author tangyd
 */
public enum AliImageScanRegionEnums {

    SHANGHAI(1, "cn-shanghai"),
    AMERICAN_US(2, "us-west-1")
    ;

    public Integer type;
    public String region;

    AliImageScanRegionEnums(Integer type, String region) {
        this.type = type;
        this.region = region;
    }

    public static String getRegionByType(Integer type) {
        for(AliImageScanRegionEnums aliImageScanRegionEnums : AliImageScanRegionEnums.values()) {
            if(aliImageScanRegionEnums.type.equals(type)) {
                return aliImageScanRegionEnums.region;
            }
        }
        return AMERICAN_US.region;
    }

}
