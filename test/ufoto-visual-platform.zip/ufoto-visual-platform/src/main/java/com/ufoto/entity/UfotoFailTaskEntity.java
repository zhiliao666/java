package com.ufoto.entity;

import java.io.Serializable;

/**
 * @author tangyd
 */
public class UfotoFailTaskEntity implements Serializable {

    private String uuid;

    private String requestBody;

    private Integer createTime;

    private Integer retryTimes;

    public UfotoFailTaskEntity() {
    }

    public UfotoFailTaskEntity(String uuid, String requestBody, Integer createTime, Integer retryTimes) {
        this.uuid = uuid;
        this.requestBody = requestBody;
        this.createTime = createTime;
        this.retryTimes = retryTimes;
    }

    public String getUuid() {
        return uuid;
    }

    public void setUuid(String uuid) {
        this.uuid = uuid;
    }

    public String getRequestBody() {
        return requestBody;
    }

    public void setRequestBody(String requestBody) {
        this.requestBody = requestBody;
    }

    public Integer getCreateTime() {
        return createTime;
    }

    public void setCreateTime(Integer createTime) {
        this.createTime = createTime;
    }

    public Integer getRetryTimes() {
        return retryTimes;
    }

    public void setRetryTimes(Integer retryTimes) {
        this.retryTimes = retryTimes;
    }
}
