package com.ufoto.business.process.scanImage;

import com.github.benmanes.caffeine.cache.Cache;
import com.ufoto.annation.ProcessMetadata;
import com.ufoto.business.enums.AliImageScanRegionEnums;
import com.ufoto.business.process.BaseProcess;
import com.ufoto.business.process.dto.ProcessData;
import com.ufoto.constants.ImageActionType;
import com.ufoto.dto.AliCheckDetailDto;
import com.ufoto.response.ActionResult;
import com.ufoto.response.result.ScanImageResult;
import com.ufoto.util.business.AliCloudImageScanUtil;
import lombok.extern.slf4j.Slf4j;
import org.apache.commons.lang3.time.StopWatch;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.stereotype.Component;

/**
 * @author tangyd
 */
@Slf4j
@Component("aliImageScan")
@ProcessMetadata(actionType = 1, weight = 80
        , name = "阿里云内容安全鉴黄节点"
        , description = "阿里云内容安全提供的鉴黄能力，根据配置选择服务器，默认百分之八十")
public class ScanImageAliCloudImageScanProcess implements BaseProcess {

    public static final Long processId = 10001L;

    @Value("${imageScan.aliImageScan.node:1}")
    Integer nodeSwitch;

    @Value("${visual.platform.slow:2000}")
    Long slowProcess;

    @Autowired
    Cache<String, ActionResult> taskResultCache;

    @Override
    public void process(ProcessData processData) throws Exception {
        log.debug("processID : {}, start to scan image by ali cloud , url : {}, region is: {}"
                , processId, processData.getActionData().getUrl(), AliImageScanRegionEnums.getRegionByType(nodeSwitch));
        if(taskResultCache.getIfPresent(processData.getUuid()) == null) {
            StopWatch watch = new StopWatch();
            watch.start();
            AliCheckDetailDto aliCheckDetailDto;
            try {
                aliCheckDetailDto = AliCloudImageScanUtil.getCheckDetailInfo(processData.getActionData().getUrl(), nodeSwitch);
            } finally {
                watch.stop();
                long cost = watch.getTime();
                if(cost >= slowProcess) {
                    log.warn("get ali image scan result slow, url:{}, cost:{}, region: {}"
                            , processData.getActionData().getUrl(), cost, AliImageScanRegionEnums.getRegionByType(nodeSwitch));
                }
            }
            taskResultCache.put(processData.getUuid(), ActionResult.builder()
                    .type(ImageActionType.SCAN_IMAGE)
                    .result(ScanImageResult.builder().
                            checkState(aliCheckDetailDto.getCheckResult())
                            .build())
                    .build());
        }
    }
}
