package com.ufoto.exception;

/**
 * @author tangyd
 */
public class DecodeFaceException extends Exception {

}
