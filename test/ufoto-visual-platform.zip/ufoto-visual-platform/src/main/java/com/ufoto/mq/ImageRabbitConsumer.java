package com.ufoto.mq;

import com.github.benmanes.caffeine.cache.Cache;
import com.rabbitmq.client.Channel;
import com.ufoto.business.process.BaseProcess;
import com.ufoto.business.process.dto.ProcessData;
import com.ufoto.config.disruptor.event.MqResultEvent;
import com.ufoto.config.process.ProcessConfigManager;
import com.ufoto.constants.ImageActionType;
import com.ufoto.exception.DecodeFaceException;
import com.ufoto.lmax.LMaxDisruptor;
import com.ufoto.mq.constants.EExchange;
import com.ufoto.mq.constants.EQueue;
import com.ufoto.request.ActionData;
import com.ufoto.request.ImageCheckRequest;
import com.ufoto.response.ActionResult;
import com.ufoto.response.result.RecognizeFaceResult;
import com.ufoto.util.json.JSONUtil;
import lombok.extern.slf4j.Slf4j;
import org.apache.commons.collections.CollectionUtils;
import org.springframework.amqp.core.ExchangeTypes;
import org.springframework.amqp.rabbit.annotation.Exchange;
import org.springframework.amqp.rabbit.annotation.Queue;
import org.springframework.amqp.rabbit.annotation.QueueBinding;
import org.springframework.amqp.rabbit.annotation.RabbitListener;
import org.springframework.amqp.support.AmqpHeaders;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.messaging.handler.annotation.Header;
import org.springframework.messaging.handler.annotation.Payload;
import org.springframework.stereotype.Component;

import java.util.Collections;
import java.util.UUID;
import java.util.concurrent.CountDownLatch;
import java.util.concurrent.Executor;
import java.util.concurrent.Executors;
import java.util.concurrent.TimeUnit;

/**
 * @author tangyd
 */
@Slf4j
@Component
public class ImageRabbitConsumer {

    @Autowired
    Cache<String, ActionResult> taskResultCache;

    @Autowired
    ProcessConfigManager processConfigManager;

    @Autowired
    LMaxDisruptor<MqResultEvent> mqResultEventLMaxDisruptor;

    private static final Integer DEFAULT_MESSAGE_NUM = 15;

    private static final Integer DEFAULT_ACTION_PER_URL = 2;

    private final Executor threadPoolExecutor =
            Executors.newFixedThreadPool(DEFAULT_MESSAGE_NUM * DEFAULT_ACTION_PER_URL);

    @RabbitListener(
            bindings = {
                    @QueueBinding(
                            exchange = @Exchange(name = EExchange.IMAGE_FANOUT_CHECK,
                                    type = ExchangeTypes.FANOUT),
                            value = @Queue(name = EQueue.QUEUE_IMAGE_CHECK, durable = "true", exclusive = "false", autoDelete = "false")
                    )
            }, concurrency = "15"
    )
    public void checkImage(@Payload ImageCheckRequest imageCheckRequest, Channel channel, @Header(AmqpHeaders.DELIVERY_TAG) long tag) {
        RabbitConsumerExecutor.execute(channel, tag, () -> {
            processImage(imageCheckRequest,  UUID.randomUUID().toString());
        });
    }

    public void processImage(ImageCheckRequest imageCheckRequest, String uuid) {
        if(!CollectionUtils.isEmpty(imageCheckRequest.getActionData())) {
            log.debug("start to check uid: {}", imageCheckRequest.getUid());

            int taskNum = 0;
            for(ActionData actionData : imageCheckRequest.getActionData()) {
                taskNum += actionData.getAction().size();
            }

            CountDownLatch countDownLatch = new CountDownLatch(taskNum);
            createTasks(countDownLatch, imageCheckRequest, uuid);
            try {
                countDownLatch.await(1, TimeUnit.MINUTES);
            } catch (InterruptedException e) {
                log.error("something has wrong during visual process, request: {}"
                        , JSONUtil.toJSON(imageCheckRequest));
            }
            mqResultEventLMaxDisruptor.send(MqResultEvent.builder()
                    .imageCheckRequest(imageCheckRequest)
                    .taskNum(taskNum)
                    .uuid(uuid)
                    .build());
        }
    }

    private void createTasks(CountDownLatch countDownLatch, ImageCheckRequest imageCheckRequest, String uuid) {
        int index = 0;
        for(ActionData actionData : imageCheckRequest.getActionData()) {
            for(Integer action : actionData.getAction()) {
                BaseProcess baseProcess = processConfigManager.getActionProcess(action, actionData, imageCheckRequest);
                BaseProcess defaultProcess = processConfigManager.getActionDefaultProcess(action);
                String taskId = uuid + "_" + index++;
                ProcessData processData = new ProcessData(taskId, actionData);
                threadPoolExecutor.execute(() -> {
                    try {
                        baseProcess.process(processData);
                    } catch (Exception e) {
                        if(e instanceof DecodeFaceException) {
                            log.warn("visual process error, url: {}, visual process: {}, decode face fail",
                                    processData.getActionData().getUrl(), baseProcess);
                            taskResultCache.put(taskId, ActionResult.builder()
                                    .type(ImageActionType.FACE_RECOGNIZE)
                                    .result(RecognizeFaceResult.builder()
                                            .ageList(Collections.emptyList()).genderList(Collections.emptyList())
                                            .checkState(1).build())
                                    .build());
                        } else {
                            log.warn("visual process error, url: {}, visual process: {}, exception: {}",
                                    processData.getActionData().getUrl(), baseProcess, e.getMessage());
                            try {
                                defaultProcess.process(processData);
                            } catch (Exception exception) {
                                if(exception instanceof DecodeFaceException) {
                                    log.warn("visual default process error, url: {}, visual process: {}, decode face fail",
                                            processData.getActionData().getUrl(), defaultProcess);
                                    taskResultCache.put(taskId, ActionResult.builder()
                                            .type(ImageActionType.FACE_RECOGNIZE)
                                            .result(RecognizeFaceResult.builder()
                                                    .ageList(Collections.emptyList()).genderList(Collections.emptyList())
                                                    .checkState(1).build())
                                            .build());
                                } else {
                                    log.warn("[defaultProcessError]visual default process error! url: {}, visual process: {}, exception: {}",
                                            processData.getActionData().getUrl(), defaultProcess, exception.getMessage());
                                }
                            }
                        }
                    } finally {
                        countDownLatch.countDown();
                    }
                });
            }
        }
    }

}
