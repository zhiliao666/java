package com.ufoto.dto;

import lombok.Data;

/**
 * @author luozq
 * @date 2019/11/29 11:34
 */
@Data
public class ResultsDto {
    /**
     * rate : 99.99
     * suggestion : block
     * label : porn
     * scene : porn
     */

    private Double rate;
    private String suggestion;
    private String label;
    private String scene;
}
