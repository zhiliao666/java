package com.ufoto.util;

import java.util.List;

import com.google.common.collect.Lists;
import org.springframework.util.CollectionUtils;
import org.springframework.util.StringUtils;

import java.util.Optional;

/**
 * @author tangyd
 */
public class ZoomUtil {

    private static final String IMG_ZOOM_SUFFIX = "_s50.webp";
    private static final String IMG_FACE_ZOOM_SUFFIX = "_s50.jpg";


    private static List<String> s3BucketList = Lists.newArrayList("social.ufotosoft.com",
            "res.ufotosoft.com",
            "test.ufotosoft.com");

    /**
     * 图片缩放
     * @param imageList image list
     * @return zoom image list
     */
    public static List<String> zoomImageList(List<String> imageList) {
        if (CollectionUtils.isEmpty(imageList)) {
            return Lists.newArrayList();
        }
        List<String> list = Lists.newArrayList();
        for (String item : imageList) {
            list.add(zoomImage(item));
        }
        return list;
    }

    /**
     * 图片缩放
     * @param image image
     * @return zoom image
     */
    public static String zoomImage(String image) {

        if (StringUtils.isEmpty(image)) {
            return image;
        }
        Optional<String> opt = s3BucketList.stream().filter(image::contains).findAny();
        if (opt.isPresent()) {
            return image + IMG_ZOOM_SUFFIX;
        }
        return image;
    }

    public static String zoomFaceImage(String image) {

        if (StringUtils.isEmpty(image)) {
            return image;
        }
        Optional<String> opt = s3BucketList.stream().filter(image::contains).findAny();
        if (opt.isPresent()) {
            return image + IMG_FACE_ZOOM_SUFFIX;
        }
        return image;
    }

}
