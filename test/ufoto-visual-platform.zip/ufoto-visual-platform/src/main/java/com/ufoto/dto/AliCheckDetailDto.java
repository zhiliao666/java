package com.ufoto.dto;

import lombok.Data;

import java.util.List;
import java.util.Map;

/**
 * @author luozq
 * @date 2019/11/29 11:32
 */
@Data
public class AliCheckDetailDto {


    /**
     * msg : OK
     * code : 200
     * dataId : 5f38943d-081c-483f-b778-631e888b451b
     * extras : {}
     * results : [{"rate":99.99,"suggestion":"block","label":"porn","scene":"porn"}]
     * taskId : img3vKAto7GQYs7A3uJGwxvzG-1rGMjl
     * url : http://social.ufotosoft.com/chat/feed/191125/397918128723460160_1574624138748_UF191124855d1817-32d0-4931-a055-8db557675840.jpg
     */

    private String msg;
    private int code;
    private String dataId;
    private Map<String, String> extras;
    private String taskId;
    private String url;
    private List<ResultsDto> results;

    private Double defaultRate;

    private Integer checkResult;

}
