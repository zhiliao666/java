package com.ufoto.business.process.dto;

import com.ufoto.request.ActionData;
import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;

/**
 * @author tangyd
 */
@Data
@AllArgsConstructor
@NoArgsConstructor
public class ProcessData {

    private String uuid;
    private ActionData actionData;

}
