package com.ufoto.api;

import com.fasterxml.jackson.databind.JsonNode;
import com.ufoto.mq.ImageRabbitConsumer;
import com.ufoto.mq.RabbitProducer;
import com.ufoto.mq.constants.EExchange;
import com.ufoto.request.ImageCheckRequest;
import com.ufoto.util.ApiResult;
import lombok.RequiredArgsConstructor;
import lombok.extern.slf4j.Slf4j;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.*;

import java.util.UUID;

/**
 * @author tangyd
 */
@Slf4j
@RestController
@RequiredArgsConstructor
public class VisualPlatformToolController {

    @Autowired
    RabbitProducer rabbitProducer;

    @Autowired
    ImageRabbitConsumer imageRabbitConsumer;

    @RequestMapping(path = "/v1/result", method = RequestMethod.POST)
    public ApiResult<Boolean> sendResult(@RequestBody JsonNode imageCheckResponse) {
        log.debug("prepare to send message to mq from api: {}", imageCheckResponse);
        rabbitProducer.produceByJson(EExchange.VISUAL_RESPONSE_TOPIC,imageCheckResponse.get("source").textValue() , imageCheckResponse);
        return new ApiResult<Boolean>().setResult(true);
    }

    @RequestMapping(path = "/v1/process", method = RequestMethod.POST)
    public ApiResult<Boolean> process(@RequestBody ImageCheckRequest imageCheckRequest) {
        imageRabbitConsumer.processImage(imageCheckRequest, UUID.randomUUID().toString());
        return new ApiResult<Boolean>().setResult(true);
    }

}
