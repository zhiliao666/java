package com.ufoto.business.constants;

/**
 * @author tangyd
 */
public interface TencentImageScanConstants {

    Long NORMAL_EVIL_TYPE = 0L;
    Long ILLEGAL_EVIL_TYPE = 1L;

    Long EVIL_TYPE_PORN = 20002L;

}
