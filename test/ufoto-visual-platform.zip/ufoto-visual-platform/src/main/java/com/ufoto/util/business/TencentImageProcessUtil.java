package com.ufoto.util.business;

import com.tencentcloudapi.cms.v20190321.CmsClient;
import com.tencentcloudapi.cms.v20190321.models.ImageModerationRequest;
import com.tencentcloudapi.cms.v20190321.models.ImageModerationResponse;
import com.tencentcloudapi.common.Credential;
import com.tencentcloudapi.common.exception.TencentCloudSDKException;
import com.tencentcloudapi.common.profile.ClientProfile;
import com.tencentcloudapi.common.profile.HttpProfile;
import com.tencentcloudapi.iai.v20180301.IaiClient;
import com.tencentcloudapi.iai.v20180301.models.DetectFaceRequest;
import com.tencentcloudapi.iai.v20180301.models.DetectFaceResponse;
import com.ufoto.exception.DecodeFaceException;

/**
 * 腾讯人脸识别
 * 文档：https://cloud.tencent.com/document/product/867/32800
 * https://console.cloud.tencent.com/api/explorer?Product=iai&Version=2018-03-01&Action=DetectFace&SignVersion=
 * @author zhangqh
 *
 */
public class TencentImageProcessUtil {

    public static DetectFaceResponse txFaceRecognize(String url) throws Exception {
        Credential cred = new Credential("AKIDDJBtMZjLtZ4JI0BjjYCgv1u45rNhpIjx", "8080fARTHY8C6TbYbifMn01rTzAAyWpx");

        HttpProfile httpProfile = new HttpProfile();
        httpProfile.setEndpoint("iai.tencentcloudapi.com");

        ClientProfile clientProfile = new ClientProfile();
        clientProfile.setHttpProfile(httpProfile);

        IaiClient client = new IaiClient(cred, "", clientProfile);

        DetectFaceRequest req = new DetectFaceRequest();
        req.setUrl(url);
        req.setMaxFaceNum(3L);
        req.setNeedFaceAttributes(1L);

        try {
            return client.DetectFace(req);
        } catch (Exception e) {
            if(e.getMessage().startsWith("InvalidParameterValue.NoFaceInPhoto")
                || e.getMessage().startsWith("FailedOperation.FaceSizeTooSmall")
                || e.getMessage().startsWith("FailedOperation.ImageResolutionTooSmall")) {
                throw new DecodeFaceException();
            } else {
                throw e;
            }
        }
    }

    public static ImageModerationResponse imageModeration(String url) throws TencentCloudSDKException {
        Credential cred = new Credential("AKIDDJBtMZjLtZ4JI0BjjYCgv1u45rNhpIjx", "8080fARTHY8C6TbYbifMn01rTzAAyWpx");

        HttpProfile httpProfile = new HttpProfile();
        httpProfile.setEndpoint("cms.tencentcloudapi.com");

        ClientProfile clientProfile = new ClientProfile();
        clientProfile.setHttpProfile(httpProfile);

        CmsClient client = new CmsClient(cred, "", clientProfile);
        // 支持区域文档https://cloud.tencent.com/document/product/669/34494
        client.setRegion("na-siliconvalley");

        ImageModerationRequest req = new ImageModerationRequest();
        req.setFileUrl(url);

        return client.ImageModeration(req);
    }
//    public static void main(String [] args) throws Exception {
//
//        String url ="https://i3.sinaimg.cn/ent/cr/2014/0405/3164492163.jpg";
//        imageModeration(url);
//
//    }

}
