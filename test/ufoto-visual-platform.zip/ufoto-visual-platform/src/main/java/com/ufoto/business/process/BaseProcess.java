package com.ufoto.business.process;

import com.ufoto.business.process.dto.ProcessData;

/**
 * @author tangyd
 */
public interface BaseProcess {

    void process(ProcessData processData) throws Exception;

}