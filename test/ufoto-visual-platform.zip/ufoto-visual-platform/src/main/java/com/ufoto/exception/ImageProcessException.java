package com.ufoto.exception;

/**
 * @author tangyd
 */
public class ImageProcessException extends Exception {
}
