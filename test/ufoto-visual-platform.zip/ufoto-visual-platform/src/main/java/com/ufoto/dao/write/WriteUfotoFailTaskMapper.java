package com.ufoto.dao.write;

import com.ufoto.entity.UfotoFailTaskEntity;
import org.apache.ibatis.annotations.Mapper;

/**
 * @author tangyd
 */
@Mapper
public interface WriteUfotoFailTaskMapper {

    int insert(UfotoFailTaskEntity ufotoFailTaskEntity);

    void delete(String uuid);

    int update(String uuid, Integer retryTimes);

}
