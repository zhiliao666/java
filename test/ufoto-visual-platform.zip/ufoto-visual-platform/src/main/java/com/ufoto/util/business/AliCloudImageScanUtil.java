package com.ufoto.util.business;

import com.aliyuncs.DefaultAcsClient;
import com.aliyuncs.IAcsClient;
import com.aliyuncs.exceptions.ClientException;
import com.aliyuncs.green.model.v20170825.ImageSyncScanRequest;
import com.aliyuncs.http.FormatType;
import com.aliyuncs.http.HttpResponse;
import com.aliyuncs.http.ProtocolType;
import com.aliyuncs.profile.DefaultProfile;
import com.aliyuncs.profile.IClientProfile;
import com.fasterxml.jackson.databind.JsonNode;
import com.fasterxml.jackson.databind.node.ArrayNode;
import com.fasterxml.jackson.databind.node.ObjectNode;
import com.ufoto.business.enums.AliImageScanRegionEnums;
import com.ufoto.dto.AliCheckDetailDto;
import com.ufoto.dto.ResultsDto;
import com.ufoto.util.business.result.ScanImageResultUtil;
import com.ufoto.util.json.JSONUtil;
import lombok.extern.slf4j.Slf4j;
import org.apache.commons.collections.CollectionUtils;
import org.apache.commons.lang3.RandomUtils;
import org.apache.commons.lang3.StringUtils;
import org.apache.commons.lang3.time.StopWatch;

import java.nio.charset.Charset;
import java.nio.charset.StandardCharsets;
import java.util.*;
import java.util.concurrent.TimeUnit;

/**
 * 鉴黄
 * 文档地址:
 *  https://help.aliyun.com/document_detail/70292.html?spm=a2c4g.11186623.2.54.12f85fc2LIHQwt#reference-fzy-ztm-v2b
 * @author luozq
 * @date 2019/3/28/028
 *
 */
@Slf4j
public class AliCloudImageScanUtil {

    private static final Charset DEFAULT_ENCODE = StandardCharsets.UTF_8;

    public static final Map<Integer, IAcsClient> clientMap = new HashMap<>();

    static {
        for(AliImageScanRegionEnums aliImageScanRegionEnums : AliImageScanRegionEnums.values()) {
            clientMap.put(aliImageScanRegionEnums.type, getAliClient(aliImageScanRegionEnums.region));
        }
    }

    private AliCloudImageScanUtil() {

    }

    /**
     * 定义阿里上海鉴黄节点
     * @return 鉴黄client
     */
    private static IAcsClient getAliClient(String region) {
        String prefixUri = String.format("green.%s.aliyuncs.com", region);
        IClientProfile profile = DefaultProfile.getProfile(region,
                "LTAIJWwKP6gIV9cq",
                "HpVwzVulzSVMHAUbdnynC2y998mElD");
        try {
            // us-west-1, cn-shanghai
            DefaultProfile.addEndpoint(region,
                    region,
                    "Green",
                    prefixUri);
        } catch (ClientException e) {
            log.error("getAliClient task occurs error, region:{}", region, e);
        }
        return new DefaultAcsClient(profile);
    }


    /**
     * 鉴黄
     * @param url url
     * @return 鉴黄结果详情
     */
    public static AliCheckDetailDto getCheckDetailInfo(String url, Integer nodeRegion) {
        ImageSyncScanRequest request = buildRequest(url);
        return sendCheckRequest(url, request, nodeRegion);
    }

    private static AliCheckDetailDto sendCheckRequest(String url,
                                                      ImageSyncScanRequest imageSyncScanRequest,
                                                      Integer nodeRegion) {
        HttpResponse httpResponse;
        AliCheckDetailDto detailDto;
        try {
            IAcsClient client = clientMap.get(nodeRegion);
            if(client == null) {
                log.error("ali cloud image scan client config error, nodeRegion is: {}", nodeRegion);
                client = clientMap.get(AliImageScanRegionEnums.AMERICAN_US.type);
            }
            httpResponse = client.doAction(imageSyncScanRequest);
            detailDto = buildDetailDto(httpResponse);
            // 重试
            if (Objects.isNull(detailDto)) {
                imageSyncScanRequest.setRegionId(AliImageScanRegionEnums.AMERICAN_US.region);
                log.warn("ALI_REQUEST_RETRY, detailDto is null, region:{}, url:{}",
                        imageSyncScanRequest.getRegionId(), url);
                httpResponse = client.doAction(imageSyncScanRequest);
                detailDto = buildDetailDto(httpResponse);
            }
            return detailDto;
        } catch (Exception e) {
            try {
                log.warn("ALI_REQUEST_RETRY, region:{}, url:{}", imageSyncScanRequest.getRegionId(), url);
                int waitCount = RandomUtils.nextInt(200, 1000);
                TimeUnit.MILLISECONDS.sleep(waitCount);
                imageSyncScanRequest.setRegionId(AliImageScanRegionEnums.AMERICAN_US.region);
                httpResponse = clientMap.get(AliImageScanRegionEnums.AMERICAN_US.type).doAction(imageSyncScanRequest);
                detailDto = buildDetailDto(httpResponse);
                // 重试
                if (Objects.isNull(detailDto)) {
                    log.warn("ALI_REQUEST_RETRY, detailDto is null, region:{}, url:{}",
                            imageSyncScanRequest.getRegionId(), url);
                    httpResponse = clientMap.get(AliImageScanRegionEnums.AMERICAN_US.type).doAction(imageSyncScanRequest);
                    detailDto = buildDetailDto(httpResponse);
                }
                return detailDto;
            } catch (Exception ex) {
                log.error("ALI_CHECK_ERROR_LOG, url:{}", url, e);
                return null;
            }
        }
    }


    private static ImageSyncScanRequest buildRequest(String url) {
        ImageSyncScanRequest imageSyncScanRequest = new ImageSyncScanRequest();
        // 指定api返回格式
        imageSyncScanRequest.setAcceptFormat(FormatType.JSON);
        imageSyncScanRequest.setHttpContentType(FormatType.JSON);
        imageSyncScanRequest.setProtocol(ProtocolType.HTTP);
        // 指定请求方法
        imageSyncScanRequest.setMethod(com.aliyuncs.http.MethodType.POST);
        imageSyncScanRequest.setEncoding("utf-8");
        imageSyncScanRequest.setRegionId(AliImageScanRegionEnums.AMERICAN_US.region);
        List<Map<String, Object>> tasks = new ArrayList<>();
        Map<String, Object> task = new LinkedHashMap<>();
        task.put("dataId", UUID.randomUUID().toString());
        task.put("url", url);
        task.put("time", new Date());
        if (ifGifType(url)) {
            task.put("interval", 10);
            task.put("maxFrames", 5);
        }
        tasks.add(task);
        ObjectNode data = JSONUtil.createObjectNode();
        // porn: 色情, terrorism: 暴恐, qrcode: 二维码, ad: 图片广告, ocr: 文字识别
        ArrayNode busArray = data.putArray("scenes");
        busArray.add("porn");

        ArrayNode taskArray = data.putArray("tasks");
        tasks.forEach(taskArray::addPOJO);

        imageSyncScanRequest.setHttpContent(JSONUtil.toJSON(data).getBytes(DEFAULT_ENCODE), "UTF-8", FormatType.JSON);
        // 请务必设置超时时间
        imageSyncScanRequest.setConnectTimeout(3000);
        imageSyncScanRequest.setReadTimeout(6000);
        return imageSyncScanRequest;
    }

    private static boolean ifGifType(String url) {
        if (StringUtils.isEmpty(url)) {
            return false;
        }
        return url.contains(".gif");
    }

    private static AliCheckDetailDto buildDetailDto(HttpResponse httpResponse) {
        if (!httpResponse.isSuccess()) {
            log.warn("ALI_REQUEST_FAIL, msg:{}", JSONUtil.toJSON(httpResponse));
            return null;
        }

        JsonNode jsonObject = JSONUtil.toJsonObjectNode(new String(httpResponse.getHttpContent(), DEFAULT_ENCODE));
        ArrayNode taskResults = (ArrayNode) jsonObject.get("data");
        if (taskResults == null || taskResults.size() == 0) {
            return null;
        }
        String dataStr = taskResults.get(0).toString();
        AliCheckDetailDto detailDto = JSONUtil.toObject(dataStr, AliCheckDetailDto.class);
        List<ResultsDto> resultList = detailDto.getResults();
        if (CollectionUtils.isEmpty(resultList)) {
            // 阿里返回图片下载超时会返回空
            log.warn("ALI_REQUEST_TIME_OUT_FAIL, msg:{}", dataStr);
            return null;
        }
        List<Integer> checkDataList = new ArrayList<>();
        for (ResultsDto result : resultList) {
            checkDataList.add(ScanImageResultUtil.parseCheckResult(result));
        }
        if (checkDataList.contains(3)) {
            detailDto.setCheckResult(3);
        } else if (checkDataList.contains(2)) {
            detailDto.setCheckResult(2);
        }  else {
            detailDto.setCheckResult(1);
        }
        return detailDto;
    }

    public static void main(String[] args) {
        String url = "http://social.ufotosoft.com/chat/img/200309/442964109764329629_1583737900396_UF200309e638c729-1181-431b-89ed-3d7328ad1805.gif";
        log.info("msg:{}", JSONUtil.toJSON(getCheckDetailInfo(url, 2)));
    }

}
