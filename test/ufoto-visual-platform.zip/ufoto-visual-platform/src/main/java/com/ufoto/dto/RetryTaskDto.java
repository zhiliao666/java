package com.ufoto.dto;

import com.ufoto.request.ImageCheckRequest;

/**
 * @author tangyd
 */
public class RetryTaskDto {

    private String uuid;

    private ImageCheckRequest imageCheckRequest;

    public RetryTaskDto(String uuid, ImageCheckRequest imageCheckRequest) {
        this.uuid = uuid;
        this.imageCheckRequest = imageCheckRequest;
    }

    public String getUuid() {
        return uuid;
    }

    public void setUuid(String uuid) {
        this.uuid = uuid;
    }

    public ImageCheckRequest getImageCheckRequest() {
        return imageCheckRequest;
    }

    public void setImageCheckRequest(ImageCheckRequest imageCheckRequest) {
        this.imageCheckRequest = imageCheckRequest;
    }
}
