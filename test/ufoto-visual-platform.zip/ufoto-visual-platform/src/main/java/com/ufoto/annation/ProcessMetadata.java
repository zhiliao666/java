package com.ufoto.annation;

import java.lang.annotation.*;

/**
 * @author tangyd
 */
@Target(ElementType.TYPE)
@Retention(RetentionPolicy.RUNTIME)
@Documented
public @interface ProcessMetadata {

    boolean available() default true;

    int actionType();

    int weight() default 50;

    boolean isDefault() default false;

    String name() default "";

    String description() default "";

}
