package com.ufoto.business.schedule;

import com.ufoto.business.retry.FailTaskManager;
import com.ufoto.mq.ImageRabbitConsumer;
import com.ufoto.request.ImageCheckRequest;
import com.xxl.job.core.biz.model.ReturnT;
import com.xxl.job.core.handler.IJobHandler;
import com.xxl.job.core.handler.annotation.JobHandler;
import lombok.extern.slf4j.Slf4j;
import org.quartz.DisallowConcurrentExecution;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;

import java.util.List;

/**
 * @author tangyd
 */
@Slf4j
@DisallowConcurrentExecution
@JobHandler(value = "failTaskRetry")
@Component
public class FailTaskRetryJob extends IJobHandler {

    @Autowired
    FailTaskManager failTaskManager;

    @Autowired
    ImageRabbitConsumer imageRabbitConsumer;

    @Override
    public ReturnT<String> execute(String s) throws Exception {
        log.debug("start to retry fail tasks");
        failTaskManager.getFailTasks().forEach(retryTaskDto -> {
            imageRabbitConsumer.processImage(retryTaskDto.getImageCheckRequest(), retryTaskDto.getUuid());
        });
        return new ReturnT<>(200, "success");
    }
}
