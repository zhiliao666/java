package com.ufoto.config.disruptor.exception;

import com.lmax.disruptor.ExceptionHandler;
import com.ufoto.config.disruptor.event.MqResultEvent;
import com.ufoto.lmax.ContextEvent;
import lombok.extern.slf4j.Slf4j;

/**
 * @author tangyd
 */
@Slf4j
public class VisualPlatformExceptionHandler implements ExceptionHandler<ContextEvent<MqResultEvent>> {
    @Override
    public void handleEventException(Throwable ex, long sequence, ContextEvent<MqResultEvent> event) {
        log.error(String.format("sequence=%d,event=%s", sequence, event), ex);
    }

    @Override
    public void handleOnStartException(Throwable ex) {
        log.error(ex.getMessage(), ex);
    }

    @Override
    public void handleOnShutdownException(Throwable ex) {
        log.error(ex.getMessage(), ex);
    }
}
