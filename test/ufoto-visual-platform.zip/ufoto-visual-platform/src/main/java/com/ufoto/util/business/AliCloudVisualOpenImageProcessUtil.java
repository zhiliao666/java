package com.ufoto.util.business;

import com.aliyuncs.AcsResponse;
import com.aliyuncs.DefaultAcsClient;
import com.aliyuncs.IAcsClient;
import com.aliyuncs.RpcAcsRequest;
import com.aliyuncs.exceptions.ClientException;
import com.aliyuncs.exceptions.ServerException;
import com.aliyuncs.facebody.model.v20191230.RecognizeFaceRequest;
import com.aliyuncs.facebody.model.v20191230.RecognizeFaceResponse;
import com.aliyuncs.imageaudit.model.v20191230.ScanImageRequest;
import com.aliyuncs.imageaudit.model.v20191230.ScanImageRequest.Task;
import com.aliyuncs.imageaudit.model.v20191230.ScanImageResponse;
import com.aliyuncs.profile.DefaultProfile;
import com.ufoto.exception.DecodeFaceException;
import com.ufoto.util.OSSFileUtils;
import com.ufoto.util.business.result.ScanImageResultUtil;
import com.ufoto.util.json.JSONUtil;
import lombok.extern.slf4j.Slf4j;

import java.util.ArrayList;
import java.util.List;
import java.util.UUID;
import java.util.concurrent.ExecutorService;
import java.util.concurrent.Executors;

import static com.ufoto.util.business.oss.OssUtil.getFileUtils;

/**
 * 阿里云视觉智能开放平台
 * 文档地址：https://help.aliyun.com/document_detail/151968.html?spm=a2c4g.11186623.6.567.3d9f6c23rdHwM4
 * 
 * @author zhangqh
 *
 */
@Slf4j
public class AliCloudVisualOpenImageProcessUtil {

	private static final IAcsClient client = getAliClient();

	private static final OSSFileUtils fileUtils = getFileUtils();

	private static final String THROTTLING_USER = "Throttling.User";
	private static final String INVALID_IMAGE_DECODE = "InvalidImage.Decode";

	/**
	 * 定义阿里阿里云视觉智能开放平台节点
	 * 
	 * @return 阿里云视觉智能开放平台client
	 */
	private static IAcsClient getAliClient() {
		DefaultProfile profile = DefaultProfile.getProfile("cn-shanghai", // 默认
				"LTAIJWwKP6gIV9cq", "HpVwzVulzSVMHAUbdnynC2y998mElD"); // 您的Access Key Secret
		return new DefaultAcsClient(profile);
	}

	private static <R extends RpcAcsRequest<T>, T extends AcsResponse> T getAcsResponse(R req) throws Exception {
		try {
			return client.getAcsResponse(req);
		} catch (ServerException e) {
			log.warn(String.format("ServerException: errCode=%s, errMsg=%s", e.getErrCode(), e.getErrMsg()));
			if(e.getErrCode().equalsIgnoreCase(THROTTLING_USER)) {
				log.warn("[Throttling.User] now time : {}, ali open visual limiting is triggered!", System.currentTimeMillis());
			}
			throw e;
		} catch (ClientException e) {
			// 客户端错误
			log.warn(String.format("ClientException: errCode=%s, errMsg=%s", e.getErrCode(), e.getErrMsg()));
			if(e.getErrCode().equalsIgnoreCase(THROTTLING_USER)) {
				log.warn("[Throttling.User] now time : {}, ali open visual limiting is triggered!", System.currentTimeMillis());
			} else if (e.getErrCode().equalsIgnoreCase(INVALID_IMAGE_DECODE)) {
				throw new DecodeFaceException();
			}
			throw e;
		} catch (Exception e) {
			log.warn("Exception:" + e.getMessage());
			throw e;
		}
	}

	public static void printResponse(String actionName, String requestId, AcsResponse data) {
		System.out.println(
				String.format("actionName=%s, requestId=%s, data=%s", actionName, requestId, JSONUtil.toJSON(data)));
	}

	public static Integer aliAIScanImage(String ossurl, Float rate) throws Exception {
		ScanImageRequest req = new ScanImageRequest();
		List<String> scenes = new ArrayList<String>();
		scenes.add("porn");
		req.setScenes(scenes);
		List<Task> tasks = new ArrayList<Task>();
		com.aliyuncs.imageaudit.model.v20191230.ScanImageRequest.Task task = new Task();
		task.setDataId(UUID.randomUUID().toString());
		task.setImageURL(ossurl);
		if(ossurl.contains(".gif")) {
			task.setInterval(10);
			task.setMaxFrames(5);
		}
		tasks.add(task);
		req.setTasks(tasks);
		ScanImageResponse resp = getAcsResponse(req);
		return ScanImageResultUtil.parseCheckResult(resp.getData().getResults().get(0).getSubResults().get(0).getLabel(),
				resp.getData().getResults().get(0).getSubResults().get(0).getSuggestion(),
				resp.getData().getResults().get(0).getSubResults().get(0).getRate(),
				rate);
	}

	// 人脸属性识别
	public static RecognizeFaceResponse aliAIRecognizeFace(String ossurl) throws Exception {
		RecognizeFaceRequest req = new RecognizeFaceRequest();
		req.setImageURL(ossurl);
		return getAcsResponse(req);
	}

//	public static void main(String[] args) {
//		ExecutorService pool = Executors.newFixedThreadPool(1);
//		for (int i = 0; i<1;i++) {
//			pool.execute(() -> {
//				String url = "http://social.ufotosoft.com/head/img/180201/1517443261799_UF180201db40de13-6fe1-482d-ab74-60046ef9019a.jpg";
//				Long startTime2 = System.currentTimeMillis();
//				try {
//					aliAIRecognizeFace(url);
//				} catch (Exception e) {
//					e.printStackTrace();
//				}
//				Long endTime2 = System.currentTimeMillis();
//				log.info( "处理时间：" + (endTime2 - startTime2));
//			});
//		}
//
//	}

//	public static void main(String[] args) {
//		ExecutorService pool = Executors.newFixedThreadPool(1);
//		for (int i = 0; i<1;i++) {
//			pool.execute(() -> {
//				String url = "http://social.ufotosoft.com/chat/img/200309/442964109764329629_1583737900396_UF200309e638c729-1181-431b-89ed-3d7328ad1805.gif";
//				Long startTime2 = System.currentTimeMillis();
//				try {
//					String ossUrl = fileUtils.upload(url);
//					aliAIScanImage(ossUrl);
//				} catch (Exception e) {
//					e.printStackTrace();
//				}
//				Long endTime2 = System.currentTimeMillis();
//				log.info( "处理时间：" + (endTime2 - startTime2));
//			});
//		}
//
//	}
}
