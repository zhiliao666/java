package com.ufoto.util.business.oss;

import com.aliyuncs.exceptions.ClientException;
import com.ufoto.util.OSSFileUtils;

/**
 * @author tangyd
 */
public class OssUtil {

    public static OSSFileUtils getFileUtils() {
        try {
            return OSSFileUtils.getInstance("LTAIJWwKP6gIV9cq", "HpVwzVulzSVMHAUbdnynC2y998mElD");
        } catch (ClientException e) {
            e.printStackTrace();
        }
        return null;
    }

}
