package com.ufoto.util.json;

import com.fasterxml.jackson.core.type.TypeReference;
import com.fasterxml.jackson.databind.JsonNode;
import com.fasterxml.jackson.databind.ObjectMapper;
import com.fasterxml.jackson.databind.node.ObjectNode;
import com.fasterxml.jackson.databind.type.TypeFactory;

import java.io.IOException;
import java.util.List;
import java.util.Map;
import java.util.Set;

public class JSONUtil {
    private static ObjectMapper mapper = ObjectMapperFactory.getInstance();
    private final static TypeFactory typeFactory = mapper.getTypeFactory();

    /**
     * 对象转json字符串
     *
     * @param object 目标对象
     * @return json string
     */
    public static String toJSON(Object object) {
        try {
            return mapper.writeValueAsString(object);
        } catch (Exception e) {
            e.printStackTrace();
            throw new RuntimeException("JSON转换异常");
        }
    }

    /**
     * json字符串转对象
     * 一般用于没有泛型的对象 例如ObjectBean
     *
     * @param json  json字符串
     * @param clazz 对象的class对象
     * @param <T>   实际对象类型,ObjectBean
     * @return 对象ObjectBean
     */
    public static <T> T toObject(String json, Class<T> clazz) {
        try {
            return mapper.readValue(json, clazz);
        } catch (IOException e) {
            throw new RuntimeException("解析json异常");
        }
    }

    /**
     * 当返回的是 List、Set、map等复杂对象的时候，需要传一个TypeReference
     *
     * @param json
     * @param type example: new TypeReference<Map<String,Object>>{}
     * @return
     */
    public static <T> T toObject(String json, TypeReference<T> type) {
        try {
            return mapper.readValue(json, type);
        } catch (Exception e) {
            e.printStackTrace();
            throw new RuntimeException("解析JSON异常");
        }
    }

    /**
     * json字符串转list
     *
     * @param json         json字符串
     * @param genericClass list的泛型对象class，一般泛型对象不再具有泛型，例如List<ObjectBean>
     * @param <T>          泛型对象类型,ObjectBean
     * @return List<ObjectBean>
     */
    public static <T> List<T> toList(String json, Class<T> genericClass) {
        try {
            return mapper.readValue(json, typeFactory.constructCollectionType(List.class, genericClass));
        } catch (IOException e) {
            throw new RuntimeException("解析json异常");
        }
    }

    /**
     * json字符串转set
     *
     * @param json         json字符串
     * @param genericClass set的泛型对象class，一般泛型对象不再具有泛型，例如Set<ObjectBean>
     * @param <T>          泛型对象类型,ObjectBean
     * @return Set<ObjectBean>
     */
    public static <T> Set<T> toSet(String json, Class<T> genericClass) {
        try {
            return mapper.readValue(json, typeFactory.constructCollectionType(Set.class, genericClass));
        } catch (IOException e) {
            throw new RuntimeException("解析json异常");
        }
    }

    /**
     * json字符串转map
     *
     * @param json       json字符串
     * @param keyClass   key的class对象
     * @param valueClass value的class对象
     * @param <K>        key的实际类型
     * @param <V>        value的实际类型，一般不再具有泛型
     * @return Map<K, V>
     */
    public static <K, V> Map<K, V> toMap(String json, Class<K> keyClass, Class<V> valueClass) {
        try {
            return mapper.readValue(json, typeFactory.constructMapType(Map.class, keyClass, valueClass));
        } catch (IOException e) {
            throw new RuntimeException("解析json异常");
        }
    }

    public static ObjectNode createObjectNode() {
        return mapper.createObjectNode();
    }

    public static JsonNode toJsonObjectNode(String data) {
        try {
            return mapper.readTree(data);
        } catch (IOException e) {
            throw new RuntimeException("解析json异常");
        }
    }

}
