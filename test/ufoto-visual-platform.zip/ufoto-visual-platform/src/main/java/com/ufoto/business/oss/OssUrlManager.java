package com.ufoto.business.oss;

import com.github.benmanes.caffeine.cache.Cache;
import com.ufoto.util.OSSFileUtils;
import com.ufoto.util.business.oss.OssUtil;
import lombok.extern.slf4j.Slf4j;
import org.apache.commons.lang3.StringUtils;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;

import java.io.IOException;
import java.util.concurrent.ConcurrentHashMap;
import java.util.concurrent.atomic.AtomicInteger;

/**
 * @author tangyd
 */
@Slf4j
@Component
public class OssUrlManager {

    @Autowired
    private Cache<String, String> ossUrlCache;

    private final static ConcurrentHashMap<String, AtomicInteger> uploadingUrlMap = new ConcurrentHashMap<>();

    private static final OSSFileUtils fileUtils = OssUtil.getFileUtils();

    public String getOssUrl(String url) throws Exception {
        String ossUrl = ossUrlCache.getIfPresent(url);
        if(StringUtils.isEmpty(ossUrl)) {
            Integer loop = 0;
            while (loop <= 40) {
                ossUrl = ossUrlCache.getIfPresent(url);
                if(!StringUtils.isEmpty(ossUrl)) {
                    return ossUrl;
                }
                if(getLock(url)) {
                    try {
                        ossUrl = fileUtils.upload(url);
                        ossUrlCache.put(url, ossUrl);
                        return ossUrl;
                    } finally {
                        releaseLock(url);
                    }
                } else {
                    Thread.sleep(500L);
                    loop++;
                }
            }
        }
        return ossUrl;
    }

    public boolean getLock(String url) {
        if(uploadingUrlMap.get(url) == null) {
            uploadingUrlMap.putIfAbsent(url, new AtomicInteger(0));
        }
        return uploadingUrlMap.get(url).compareAndSet(0, 1);
    }

    public void releaseLock(String url) {
        if(uploadingUrlMap.get(url) != null) uploadingUrlMap.remove(url);
    }

}
