package com.ufoto.util.business.result;

import com.aliyuncs.facebody.model.v20191230.RecognizeFaceResponse;
import com.tencentcloudapi.iai.v20180301.models.DetectFaceResponse;
import com.tencentcloudapi.iai.v20180301.models.FaceInfo;
import com.ufoto.response.result.RecognizeFaceResult;

import java.util.ArrayList;
import java.util.List;
import java.util.stream.Collectors;

/**
 * @author tangyd
 */
public class FaceRecognizeResultUtil {

    public static RecognizeFaceResult getRecognizeFaceResult(RecognizeFaceResponse recognizeFaceResponse) {
        return new RecognizeFaceResult(recognizeFaceResponse.getData().getGenderList().stream().map(i -> {
            if(i == 0) {
                return 2;
            } else {
                return i;
            }
        } ).collect(Collectors.toList()), recognizeFaceResponse.getData().getAgeList(), 1);
    }

    public static RecognizeFaceResult getRecognizeFaceResult(DetectFaceResponse detectFaceResponse) {
        List<Integer> ageList = new ArrayList<>();
        List<Integer> genderList = new ArrayList<>();
        for(FaceInfo faceInfo : detectFaceResponse.getFaceInfos()) {
            ageList.add(faceInfo.getFaceAttributesInfo().getAge().intValue());
            genderList.add(txGenderTrans(faceInfo.getFaceAttributesInfo().getGender().intValue()));
        }
        return new RecognizeFaceResult(genderList, ageList, 1);
    }

    public static Integer txGenderTrans(Integer data) {
        if(data >= 0 && data <= 49) {
            return 2;
        } else if (data >= 50 && data <=99) {
            return 1;
        } else {
            return 0;
        }
    }

}
