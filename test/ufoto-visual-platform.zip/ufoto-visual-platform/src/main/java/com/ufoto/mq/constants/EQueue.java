package com.ufoto.mq.constants;

/**
 * @author tangyd
 */
public interface EQueue {

    String QUEUE_IMAGE_CHECK = "Q-imageCheck";

}
