package com.ufoto.mq;

import lombok.extern.slf4j.Slf4j;
import org.springframework.amqp.core.Message;
import org.springframework.amqp.core.MessageProperties;
import org.springframework.amqp.core.MessagePropertiesBuilder;
import org.springframework.amqp.rabbit.core.RabbitTemplate;
import org.springframework.amqp.support.converter.MessageConverter;
import org.springframework.stereotype.Component;

/**
 * <p>
 * Author     : Chan
 * CreateDate : 2019-05-17 09:58
 * Description:
 * </p>
 */
@Slf4j
@Component
public class RabbitProducer {

    private final RabbitTemplate rabbitTemplate;

    public RabbitProducer(RabbitTemplate rabbitTemplate) {
        this.rabbitTemplate = rabbitTemplate;
    }

    public void produceByJson(String exchange, String routingKey, Object payload) {
        try {
            MessageConverter messageConverter = rabbitTemplate.getMessageConverter();
            Message message = messageConverter.toMessage(payload, MessagePropertiesBuilder
                    .fromProperties(new MessageProperties())
                    .setContentType(MessageProperties.CONTENT_TYPE_JSON)
                    .build());
            rabbitTemplate.send(exchange, routingKey, message);
        } catch (Exception e) {
            log.error(e.getMessage(), e);
        }
    }
}
