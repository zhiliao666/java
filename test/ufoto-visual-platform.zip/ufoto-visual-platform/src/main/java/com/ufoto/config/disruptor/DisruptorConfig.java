package com.ufoto.config.disruptor;

import com.lmax.disruptor.TimeoutBlockingWaitStrategy;
import com.ufoto.config.disruptor.conusmer.MqResultAssembleConsumer;
import com.ufoto.config.disruptor.conusmer.MqResultSendConsumer;
import com.ufoto.config.disruptor.event.MqResultEvent;
import com.ufoto.config.disruptor.exception.VisualPlatformExceptionHandler;
import com.ufoto.lmax.LMaxDisruptor;
import com.ufoto.lmax.consumers.CustomizerExecuteConsumer;
import com.ufoto.lmax.thread.DefaultThreadFactory;
import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;

import java.util.concurrent.TimeUnit;

/**
 * @author tangyd
 */
@Configuration
public class DisruptorConfig {

    @Bean(initMethod = "startDisruptor", destroyMethod = "shutdown")
    public LMaxDisruptor<MqResultEvent> mqResultEventLMaxDisruptor(MqResultAssembleConsumer mqResultAssembleConsumer,
                                                                   MqResultSendConsumer mqResultSendConsumer) {
        LMaxDisruptor<MqResultEvent> disruptor = LMaxDisruptor.<MqResultEvent>builder()
                .waitStrategy(new TimeoutBlockingWaitStrategy(3, TimeUnit.SECONDS))
                .bufferSize(16)
                .consumer(CustomizerExecuteConsumer.class)
                .exceptionHandler(new VisualPlatformExceptionHandler())
                .threadFactory(new DefaultThreadFactory())
                .build();
        disruptor.subscribeCustomizer(
                dis -> dis
                        .handleEventsWithWorkerPool(
                                mqResultAssembleConsumer,
                                mqResultAssembleConsumer,
                                mqResultAssembleConsumer)
                        .thenHandleEventsWithWorkerPool(
                                mqResultSendConsumer,
                                mqResultSendConsumer,
                                mqResultSendConsumer)
        );
        return disruptor;
    }

}
