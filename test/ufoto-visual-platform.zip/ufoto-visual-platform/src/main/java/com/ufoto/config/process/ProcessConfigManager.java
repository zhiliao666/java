package com.ufoto.config.process;

import com.ctrip.framework.apollo.model.ConfigChangeEvent;
import com.ctrip.framework.apollo.spring.annotation.ApolloConfigChangeListener;
import com.fasterxml.jackson.core.type.TypeReference;
import com.ufoto.annation.ProcessMetadata;
import com.ufoto.business.chain.BaseChainDealer;
import com.ufoto.business.process.BaseProcess;
import com.ufoto.constants.ImageActionType;
import com.ufoto.request.ActionData;
import com.ufoto.request.ImageCheckRequest;
import com.ufoto.util.SpringContextUtil;
import com.ufoto.util.json.JSONUtil;
import lombok.extern.slf4j.Slf4j;
import org.apache.commons.collections.CollectionUtils;
import org.apache.commons.lang3.RandomUtils;
import org.apache.commons.lang3.StringUtils;
import org.springframework.aop.support.AopUtils;
import org.springframework.beans.BeansException;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.beans.factory.config.BeanPostProcessor;
import org.springframework.stereotype.Component;

import javax.annotation.PostConstruct;
import java.util.*;
import java.util.concurrent.ConcurrentHashMap;

/**
 * @author tangyd
 */
@Slf4j
@Component
public class ProcessConfigManager implements BeanPostProcessor {

    private Map<Integer, ActionProcessConfigDto> processMap = new ConcurrentHashMap<>();
    private Boolean processByConfig = false;

    @Value("${visual.platform.process.config:}")
    String processConfig;

    @PostConstruct
    public void initProcessMap() {
        try {
            if(StringUtils.isNotEmpty(processConfig)) {
                processMap = JSONUtil.toObject(processConfig
                        , new TypeReference<Map<Integer, ActionProcessConfigDto>>(){});
                processMap.forEach((key, value) -> Collections.sort(value.getProcessConfigDtoList()));
                processByConfig = true;
            }
        } catch (Exception e) {
            log.error("visual process assemble error , error is: {}", e.getMessage());
        }
    }

    public void initProcessMap(String config) {
        processConfig = config;
        initProcessMap();
    }

    @ApolloConfigChangeListener
    private void configChanged(ConfigChangeEvent configChangeEvent) {
        if(configChangeEvent.isChanged("visual.platform.process.config")) {
            initProcessMap(configChangeEvent.getChange("visual.platform.process.config").getNewValue());
        }
    }

    @Override
    public Object postProcessAfterInitialization(Object bean, String beanName) throws BeansException {
        if(StringUtils.isEmpty(processConfig) || !processByConfig) {
            final Class<?> targetClass = AopUtils.getTargetClass(bean);
            ProcessMetadata processMetadata = targetClass.getAnnotation(ProcessMetadata.class);
            if(processMetadata != null && processMetadata.available() && bean instanceof BaseProcess) {
                if(!processMap.containsKey(processMetadata.actionType())) {
                    processMap.put(processMetadata.actionType(), new ActionProcessConfigDto());
                }
                ActionProcessConfigDto actionProcessConfigDto = processMap.get(processMetadata.actionType());
                actionProcessConfigDto.getProcessConfigDtoList().add(new ProcessConfigDto(beanName, processMetadata.weight()));
                actionProcessConfigDto.setSum(actionProcessConfigDto.getSum() + processMetadata.weight());
                if(processMetadata.isDefault()) {
                    actionProcessConfigDto.setDefaultProcess(beanName);
                }
                Collections.sort(actionProcessConfigDto.getProcessConfigDtoList());
            }
        }
        return bean;
    }

    public BaseProcess getActionProcess(Integer actionType, ActionData actionData,
                                        ImageCheckRequest imageCheckRequest) {
        if(!processMap.containsKey(actionType)) {
            actionType = ImageActionType.SCAN_IMAGE;
        }
        ActionProcessConfigDto actionProcessConfigDto = processMap.get(actionType);

        if(CollectionUtils.isNotEmpty(actionProcessConfigDto.getPreProcessChain())) {
            BaseProcess targetProcess;
            for(String baseChainName : actionProcessConfigDto.getPreProcessChain()) {
                targetProcess = ((BaseChainDealer) SpringContextUtil.getBean(baseChainName)).deal(actionData, imageCheckRequest);
                if(targetProcess != null) {
                    return targetProcess;
                }
            }
        }

        int random = RandomUtils.nextInt(0, actionProcessConfigDto.getSum());
        int temp = 0;
        for(int i = 0; i < actionProcessConfigDto.getProcessConfigDtoList().size(); i++) {
            temp += actionProcessConfigDto.getProcessConfigDtoList().get(i).getWeight();
            if(temp > random) {
                return (BaseProcess) SpringContextUtil.getBean(actionProcessConfigDto.getProcessConfigDtoList().get(i).getBaseProcess());
            }
        }
        return  (BaseProcess) SpringContextUtil.getBean(actionProcessConfigDto.getDefaultProcess());
    }

    public BaseProcess getActionDefaultProcess(Integer actionType) {
        if(!processMap.containsKey(actionType)) {
            actionType = ImageActionType.SCAN_IMAGE;
        }
        ActionProcessConfigDto actionProcessConfigDto = processMap.get(actionType);
        return (BaseProcess) SpringContextUtil.getBean(actionProcessConfigDto.getDefaultProcess());
    }

}
