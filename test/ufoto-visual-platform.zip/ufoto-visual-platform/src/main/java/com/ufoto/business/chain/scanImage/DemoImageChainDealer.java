package com.ufoto.business.chain.scanImage;

import com.ufoto.business.chain.BaseChainDealer;
import com.ufoto.business.process.BaseProcess;
import com.ufoto.request.ActionData;
import com.ufoto.request.ImageCheckRequest;
import com.ufoto.util.SpringContextUtil;
import org.springframework.stereotype.Component;

/**
 * @author tangyd
 */
@Component("testEcho")
public class DemoImageChainDealer implements BaseChainDealer {

    @Override
    public BaseProcess deal(ActionData actionData, ImageCheckRequest imageCheckRequest) {
        if(imageCheckRequest.getSource().contains("echo")) {
            return (BaseProcess) SpringContextUtil.getBean("aliImageScan");
        }
        return null;
    }
}
