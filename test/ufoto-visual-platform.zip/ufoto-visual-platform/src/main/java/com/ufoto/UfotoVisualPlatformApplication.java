package com.ufoto;

import com.ufoto.logging.proxy.UfotoLogFactory;
import io.micrometer.core.instrument.Metrics;
import io.micrometer.core.instrument.simple.SimpleMeterRegistry;
import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

/**
 * @author tangyd
 */
@SpringBootApplication
public class UfotoVisualPlatformApplication {

    public static void main(String[] args) {
        UfotoLogFactory.enableDefaultLogFormat();
        Metrics.addRegistry(new SimpleMeterRegistry());
        SpringApplication.run(UfotoVisualPlatformApplication.class, args);
    }

}
