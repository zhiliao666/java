package com.ufoto.business.process.scanImage;

import com.github.benmanes.caffeine.cache.Cache;
import com.ufoto.annation.ProcessMetadata;
import com.ufoto.business.process.BaseProcess;
import com.ufoto.business.process.dto.ProcessData;
import com.ufoto.constants.ImageActionType;
import com.ufoto.response.ActionResult;
import com.ufoto.response.result.ScanImageResult;
import com.ufoto.util.business.TencentImageProcessUtil;
import com.ufoto.util.business.result.ScanImageResultUtil;
import lombok.extern.slf4j.Slf4j;
import org.apache.commons.lang3.time.StopWatch;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.stereotype.Component;

/**
 * @author tangyd
 */
@Slf4j
@Component("tencentImageScan")
@ProcessMetadata(actionType = 1, weight = 0
        , name = "腾讯云鉴黄节点"
        , description = "腾讯云提供的鉴黄能力，默认暂时不启用")
public class ScanImageTencentProcess implements BaseProcess {

    public static final Long processId = 10004L;

    @Autowired
    private Cache<String, ActionResult> taskResultCache;

    @Value("${visual.platform.slow:2000}")
    Long slowProcess;

    @Override
    public void process(ProcessData processData) throws Exception {
        log.debug("processID : {}, start to scan image by tencent cloud, url : {}"
                , processId, processData.getActionData().getUrl());
        if(taskResultCache.getIfPresent(processData.getUuid()) == null) {
            StopWatch watch = new StopWatch();
            watch.start();
            ScanImageResult scanImageResult;
            try {
                scanImageResult = new ScanImageResult(ScanImageResultUtil.parseCheckResult(
                        TencentImageProcessUtil.imageModeration(processData.getActionData().getUrl())
                ));
            } finally {
                watch.stop();
                long cost = watch.getTime();
                if(cost >= slowProcess) {
                    log.warn("get tencent image scan result slow, url:{}, cost:{}"
                            , processData.getActionData().getUrl(), cost);
                }
            }
            taskResultCache.put(processData.getUuid(), ActionResult.builder()
                    .type(ImageActionType.SCAN_IMAGE)
                    .result(scanImageResult)
                    .build());
        }
    }

}
