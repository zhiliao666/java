package com.ufoto.business.process.faceRecognize;

import com.github.benmanes.caffeine.cache.Cache;
import com.ufoto.annation.ProcessMetadata;
import com.ufoto.business.oss.OssUrlManager;
import com.ufoto.business.process.BaseProcess;
import com.ufoto.business.process.dto.ProcessData;
import com.ufoto.constants.ImageActionType;
import com.ufoto.response.ActionResult;
import com.ufoto.response.result.RecognizeFaceResult;
import com.ufoto.util.ZoomUtil;
import com.ufoto.util.business.AliCloudVisualOpenImageProcessUtil;
import com.ufoto.util.business.result.FaceRecognizeResultUtil;
import lombok.extern.slf4j.Slf4j;
import org.apache.commons.lang3.time.StopWatch;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.stereotype.Component;

/**
 * @author tangyd
 */
@Slf4j
@Component("aliVisualDefaultOpenFaceRecognize")
@ProcessMetadata(actionType = 2, weight = 0, isDefault = true
        , name = "阿里云人脸兜底识别"
        , description = "阿里云视觉平台提供的人脸识别，兜底压缩鉴别")
public class FaceRecognizeAliCloudDefaultProcess implements BaseProcess {
    public static final Long processId = 20004L;

    @Autowired
    private Cache<String, ActionResult> taskResultCache;

    @Autowired
    private OssUrlManager ossUrlManager;

    @Value("${visual.platform.slow:2000}")
    Long slowProcess;

    @Override
    public void process(ProcessData processData) throws Exception {
        log.debug("processID : {}, start to face recognize by ali cloud, url : {}"
                , processId, processData.getActionData().getUrl());
        if(taskResultCache.getIfPresent(processData.getUuid()) == null) {
            StopWatch watch = new StopWatch();
            watch.start();
            RecognizeFaceResult recognizeFaceResult;
            try {
                String ossUrl = ossUrlManager.getOssUrl(ZoomUtil.zoomFaceImage(processData.getActionData().getUrl()));
                recognizeFaceResult = FaceRecognizeResultUtil.getRecognizeFaceResult(
                        AliCloudVisualOpenImageProcessUtil.aliAIRecognizeFace(ossUrl));
            } finally {
                watch.stop();
                long cost = watch.getTime();
                if(cost >= slowProcess) {
                    log.warn("get default ali open visual face recognize result slow, url:{}, cost:{}"
                            , processData.getActionData().getUrl(), cost);
                }
            }
            taskResultCache.put(processData.getUuid(), ActionResult.builder()
                    .type(ImageActionType.FACE_RECOGNIZE)
                    .result(recognizeFaceResult)
                    .build());
        }
    }
}
