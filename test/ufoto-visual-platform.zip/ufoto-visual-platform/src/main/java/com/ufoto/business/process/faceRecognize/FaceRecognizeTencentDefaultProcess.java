package com.ufoto.business.process.faceRecognize;

import com.github.benmanes.caffeine.cache.Cache;
import com.ufoto.annation.ProcessMetadata;
import com.ufoto.business.process.BaseProcess;
import com.ufoto.business.process.dto.ProcessData;
import com.ufoto.constants.ImageActionType;
import com.ufoto.response.ActionResult;
import com.ufoto.response.result.RecognizeFaceResult;
import com.ufoto.util.ZoomUtil;
import com.ufoto.util.business.TencentImageProcessUtil;
import com.ufoto.util.business.result.FaceRecognizeResultUtil;
import lombok.extern.slf4j.Slf4j;
import org.apache.commons.lang3.time.StopWatch;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.stereotype.Component;

/**
 * @author tangyd
 */
@Slf4j
@Component("tencentFaceDefaultRecognize")
@ProcessMetadata(actionType = 2, weight = 0
        , name = "腾讯云人脸兜底识别"
        , description = "腾讯云提供的人脸识别，图片进行压缩，人脸识别兜底逻辑")
public class FaceRecognizeTencentDefaultProcess implements BaseProcess {

    public static final Long processId = 20003L;

    @Autowired
    private Cache<String, ActionResult> taskResultCache;

    @Value("${visual.platform.slow:2000}")
    Long slowProcess;

    @Override
    public void process(ProcessData processData) throws Exception {
        log.debug("processID : {}, start to default face recognize by tencent cloud, url : {}"
                , processId, processData.getActionData().getUrl());
        if(taskResultCache.getIfPresent(processData.getUuid()) == null) {
            StopWatch watch = new StopWatch();
            watch.start();
            RecognizeFaceResult recognizeFaceResult;
            try {
                recognizeFaceResult = FaceRecognizeResultUtil.getRecognizeFaceResult(TencentImageProcessUtil.txFaceRecognize(ZoomUtil.zoomFaceImage(processData.getActionData().getUrl())));
            } finally {
                watch.stop();
                long cost = watch.getTime();
                if(cost >= slowProcess) {
                    log.warn("get default tencent face recognize result slow, url:{}, cost:{}"
                            , processData.getActionData().getUrl(), cost);
                }
            }
            taskResultCache.put(processData.getUuid(), ActionResult.builder()
                    .type(ImageActionType.FACE_RECOGNIZE)
                    .result(recognizeFaceResult)
                    .build());
        }
    }
}
