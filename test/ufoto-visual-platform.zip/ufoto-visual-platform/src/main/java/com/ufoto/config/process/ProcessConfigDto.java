package com.ufoto.config.process;

import com.ufoto.business.process.BaseProcess;
import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;

/**
 * @author tangyd
 */
@Data
@AllArgsConstructor
@NoArgsConstructor
public class ProcessConfigDto implements Comparable<ProcessConfigDto> {

    private String baseProcess;
    private Integer weight;

    @Override
    public int compareTo(ProcessConfigDto processConfigDto) {
        return this.weight - processConfigDto.weight;
    }

}
