package com.ufoto.config.disruptor.conusmer;

import com.github.benmanes.caffeine.cache.Cache;
import com.ufoto.business.retry.FailTaskManager;
import com.ufoto.config.disruptor.event.MqResultEvent;
import com.ufoto.constants.ImageActionType;
import com.ufoto.dao.write.WriteUfotoFailTaskMapper;
import com.ufoto.entity.UfotoFailTaskEntity;
import com.ufoto.exception.ImageProcessException;
import com.ufoto.lmax.consumer.Consumer;
import com.ufoto.request.ActionData;
import com.ufoto.request.ImageCheckRequest;
import com.ufoto.response.ActionResult;
import com.ufoto.response.ImageCheckResponse;
import com.ufoto.response.ResponseResult;
import com.ufoto.response.result.RecognizeFaceResult;
import com.ufoto.response.result.ScanImageResult;
import com.ufoto.util.json.JSONUtil;
import lombok.extern.slf4j.Slf4j;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;

import java.util.ArrayList;
import java.util.Collections;
import java.util.List;

/**
 * @author tangyd
 */
@Slf4j
@Component
public class MqResultAssembleConsumer extends Consumer<MqResultEvent> {

    @Autowired
    Cache<String, ActionResult> taskResultCache;

    @Autowired
    FailTaskManager failTaskManager;

    public MqResultAssembleConsumer() {
        super(ConsumerId.CONSUMER_RESULT_RESOLVE);
    }

    @Override
    public void consume(MqResultEvent event) {
        ImageCheckRequest imageCheckRequest = event.getImageCheckRequest();
        log.debug("start to assemble uid :{}'s visual response", imageCheckRequest.getUid());

        String uuid = event.getUuid();

        List<ResponseResult> responseResults = new ArrayList<>();
        int index = 0;
        try {
            for (ActionData actionData : imageCheckRequest.getActionData()) {
                List<ActionResult> actionResults = new ArrayList<>();
                for (Integer action : actionData.getAction()) {
                    ActionResult actionResult = taskResultCache.getIfPresent(uuid + "_" + index++);

                    if (actionResult == null) {
                        log.warn("[errorProcess] uid: {}'s visual request, request: {}",
                                imageCheckRequest.getUid(), JSONUtil.toJSON(event.getImageCheckRequest()));
                        throw new ImageProcessException();
                    }

                    actionResults.add(actionResult);
                }

                responseResults.add(ResponseResult.builder()
                        .url(actionData.getUrl())
                        .actionResult(actionResults).build());
            }

            for(int i = 0; i < index; i++) {
                taskResultCache.invalidate(uuid + "_" + i);
            }
        } catch (ImageProcessException e) {
            failTaskManager.addFailTask(event);
            return;
        }

        event.setImageCheckResponse(ImageCheckResponse.builder()
                .data(imageCheckRequest.getData())
                .source(imageCheckRequest.getSource())
                .uid(imageCheckRequest.getUid())
                .result(responseResults)
                .build());
        event.setImageCheckRequest(null);
        event.setTaskNum(null);
        event.setUuid(null);
        failTaskManager.taskCompleted(uuid);
    }
}
