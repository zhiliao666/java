package com.ufoto.mq;

import com.rabbitmq.client.Channel;
import lombok.extern.slf4j.Slf4j;

@Slf4j
public class RabbitConsumerExecutor {

    public static void execute(Channel channel, long deliveryTag, Command command) {
        execute(channel, deliveryTag, command, e -> log.error(e.getMessage(), e));
    }

    public static void execute(Channel channel, long deliveryTag, Command command, FailCallback callback) {
        try {
            command.cmd();
        } catch (Exception e) {
            callback.callback(e);
        } finally {
            try {
                channel.basicAck(deliveryTag, false);
            } catch (Exception e) {
                log.error(e.getMessage(), e);
            }
        }
    }

    //发送命令
    public interface Command {
        void cmd();
    }

    //发送失败的处理策略
    public interface FailCallback {
        void callback(Exception e);
    }

}
