package com.ufoto.mq.constants;

/**
 * @author tangyd
 */
public interface EExchange {

    String IMAGE_FANOUT_CHECK = "visual.platform.fanout.process";

    String VISUAL_RESPONSE_TOPIC = "visual.platform.topic.result";

}
