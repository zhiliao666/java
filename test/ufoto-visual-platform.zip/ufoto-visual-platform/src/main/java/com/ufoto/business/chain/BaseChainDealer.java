package com.ufoto.business.chain;

import com.ufoto.business.process.BaseProcess;
import com.ufoto.request.ActionData;
import com.ufoto.request.ImageCheckRequest;

/**
 * @author tangyd
 */
public interface BaseChainDealer {

    BaseProcess deal(ActionData actionData, ImageCheckRequest imageCheckRequest);

}
