package com.ufoto.dao.read;

import com.ufoto.dto.UfotoFailTaskDto;
import org.apache.ibatis.annotations.Mapper;

import java.util.List;

/**
 * @author tangyd
 */
@Mapper
public interface ReadUfotoFailTaskMapper {

    List<UfotoFailTaskDto> getRetryTasks();

}
