package com.ufoto.config.disruptor.event;

import com.ufoto.lmax.event.Event;
import com.ufoto.request.ImageCheckRequest;
import com.ufoto.response.ImageCheckResponse;
import lombok.*;

/**
 * @author tangyd
 */
@EqualsAndHashCode(callSuper = true)
@Data
@Builder
public class MqResultEvent extends Event {

    String uuid;
    Integer taskNum;
    ImageCheckRequest imageCheckRequest;
    ImageCheckResponse imageCheckResponse;

}
