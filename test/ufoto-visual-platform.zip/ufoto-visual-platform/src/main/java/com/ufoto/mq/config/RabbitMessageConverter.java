package com.ufoto.mq.config;

import com.ufoto.request.ImageCheckRequest;
import org.springframework.amqp.core.Message;
import org.springframework.amqp.core.MessageProperties;
import org.springframework.amqp.support.converter.Jackson2JsonMessageConverter;
import org.springframework.amqp.support.converter.MessageConversionException;
import org.springframework.amqp.support.converter.MessageConverter;
import org.springframework.amqp.support.converter.SimpleMessageConverter;
import org.springframework.stereotype.Component;

/**
 * <p>
 * Author     : Chan
 * CreateDate : 2019-04-18 11:21
 * Description: 自定义rabbit消息转换器
 * 1.SimpleMessageConverter  默认application/octet-stream
 * 2.Jackson2JsonMessageConverter 默认application/json
 * 3.object->message convert by contentType
 * 4.message->object convert by contentType
 * 如果是application/octet-stream 默认走Simple
 * 如果是application/json 默认走Jackson
 * 其他 直接返回字节数组
 * </p>
 */
@Component
public class RabbitMessageConverter implements MessageConverter {

    private final Jackson2JsonMessageConverter jackson2JsonMessageConverter = new Jackson2JsonMessageConverter();
    private final SimpleMessageConverter simpleMessageConverter = new SimpleMessageConverter();

    @Override
    public Message toMessage(Object object, MessageProperties messageProperties) throws MessageConversionException {
        String contentType = messageProperties.getContentType();
        if (MessageProperties.CONTENT_TYPE_JSON.equals(contentType)) {
            return jackson2JsonMessageConverter.toMessage(object, messageProperties);
        } else {
            return simpleMessageConverter.toMessage(object, messageProperties);
        }
    }

    @Override
    public Object fromMessage(Message message) throws MessageConversionException {
        final MessageProperties properties = message.getMessageProperties();
        if (properties != null) {
            String contentType = properties.getContentType();
            try {
                if (contentType.equals(MessageProperties.CONTENT_TYPE_JSON)) {
                    return jackson2JsonMessageConverter.fromMessage(message);
                } else {
                    return simpleMessageConverter.fromMessage(message);
                }
            } catch (Exception e) {
                return ImageCheckRequest.builder().build();
            }
        }
        return message.getBody();
    }
}
