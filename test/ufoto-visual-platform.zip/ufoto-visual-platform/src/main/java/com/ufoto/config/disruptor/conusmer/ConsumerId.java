package com.ufoto.config.disruptor.conusmer;

/**
 * @author tangyd
 */
public interface ConsumerId {

    String CONSUMER_RESULT_RESOLVE = "C:result_resolve";

    String CONSUMER_MQ_RESOLVE = "C:mq_resolve";

}
