package com.ufoto.config.mysql.interceptor;

import com.ufoto.util.DateUtil;
import org.apache.ibatis.executor.Executor;
import org.apache.ibatis.mapping.MappedStatement;
import org.apache.ibatis.mapping.SqlCommandType;
import org.apache.ibatis.plugin.*;
import org.springframework.util.ReflectionUtils;

import java.lang.reflect.Method;
import java.util.Date;
import java.util.Properties;

/**
 * <p>
 * MyBatis 拦截器  统一设置domain中的时间
 * </p>
 *
 * @author created by chenzhou at 2018-05-23 13:49
 */
@Intercepts({
        @Signature(type = Executor.class, method = "update", args = {MappedStatement.class, Object.class})
})
public class CRUDInterceptor implements Interceptor {
    @Override
    public Object intercept(Invocation invocation) throws Throwable {
        try {
            MappedStatement mappedStatement = (MappedStatement) invocation.getArgs()[0];
            if (mappedStatement.getSqlCommandType() == SqlCommandType.DELETE) {
                return invocation.proceed();
            }
            final Object entity = invocation.getArgs()[1];
            if (mappedStatement.getSqlCommandType() == SqlCommandType.INSERT) {
                Method createDateMethod = ReflectionUtils.findMethod(entity.getClass(), "setCreateDate", Date.class);
                if (createDateMethod != null) {
                    Method readCreateDateMethod = ReflectionUtils.findMethod(entity.getClass(), "getCreateDate");
                    if (readCreateDateMethod != null && readCreateDateMethod.invoke(entity) == null) {
                        createDateMethod.invoke(entity, new Date());
                    }
                } else {
                    createDateMethod = ReflectionUtils.findMethod(entity.getClass(), "setCreateTime", Integer.class);
                    if (createDateMethod != null) {
                        Method readCreateDateMethod = ReflectionUtils.findMethod(entity.getClass(), "getCreateTime");
                        if (readCreateDateMethod != null && readCreateDateMethod.invoke(entity) == null) {
                            createDateMethod.invoke(entity, DateUtil.getCurrentSecondIntValue());
                        }
                    }
                }
            }
            Method modifyDateMethod = ReflectionUtils.findMethod(entity.getClass(), "setUpdateDate", Date.class);
            if (modifyDateMethod != null) {
                Method readUpdateDateMethod = ReflectionUtils.findMethod(entity.getClass(), "getUpdateDate");
                if (readUpdateDateMethod != null && readUpdateDateMethod.invoke(entity) == null)
                    modifyDateMethod.invoke(entity, new Date());
            } else {
                modifyDateMethod = ReflectionUtils.findMethod(entity.getClass(), "setUpdateTime", Integer.class);
                if (modifyDateMethod != null) {
                    Method readUpdateDateMethod = ReflectionUtils.findMethod(entity.getClass(), "getUpdateTime");
                    if (readUpdateDateMethod != null && readUpdateDateMethod.invoke(entity) == null)
                        modifyDateMethod.invoke(entity, DateUtil.getCurrentSecondIntValue());
                }
            }
        } catch (Exception e) {
            e.printStackTrace();
        }
        return invocation.proceed();
    }

    @Override
    public Object plugin(Object target) {
        return Plugin.wrap(target, this);
    }

    @Override
    public void setProperties(Properties properties) {

    }
}
