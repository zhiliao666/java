package com.ufoto.business.process.scanImage;

import com.github.benmanes.caffeine.cache.Cache;
import com.ufoto.annation.ProcessMetadata;
import com.ufoto.business.oss.OssUrlManager;
import com.ufoto.business.process.BaseProcess;
import com.ufoto.business.process.dto.ProcessData;
import com.ufoto.constants.ImageActionType;
import com.ufoto.response.ActionResult;
import com.ufoto.response.result.ScanImageResult;
import com.ufoto.util.business.AliCloudVisualOpenImageProcessUtil;
import lombok.extern.slf4j.Slf4j;
import org.apache.commons.lang3.time.StopWatch;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.stereotype.Component;

/**
 * @author tangyd
 */
@Slf4j
@Component("aliVisualOpenImageScan")
@ProcessMetadata(actionType = 1, weight = 20
        , name = "阿里云视觉平台鉴黄节点"
        , description = "阿里云视觉平台提供的鉴黄能力，默认百分之二十，对于gif鉴别能力不行")
public class ScanImageAliCloudOpenVisualProcess implements BaseProcess {

    public static final Long processId = 10002L;

    @Autowired
    private Cache<String, ActionResult> taskResultCache;

    @Autowired
    private OssUrlManager ossUrlManager;

    @Value("${visual.platform.slow:2000}")
    Long slowProcess;

    @Value("${visual.platform.image.rate:90}")
    Float rate;

    @Override
    public void process(ProcessData processData) throws Exception {
        log.debug("processID : {}, start to scan image by ali cloud visual open platform , url : {}"
                , processId, processData.getActionData().getUrl());
        if(taskResultCache.getIfPresent(processData.getUuid()) == null) {
            StopWatch watch = new StopWatch();
            watch.start();
            ScanImageResult scanImageResult;
            try {
                String ossUrl = ossUrlManager.getOssUrl(processData.getActionData().getUrl());
                scanImageResult = new ScanImageResult(AliCloudVisualOpenImageProcessUtil.aliAIScanImage(ossUrl, rate));
            } finally {
                watch.stop();
                long cost = watch.getTime();
                if(cost >= slowProcess) {
                    log.warn("get ali open visual image scan result slow, url:{}, cost:{}"
                            , processData.getActionData().getUrl(), cost);
                }
            }
            taskResultCache.put(processData.getUuid(), ActionResult.builder()
                    .type(ImageActionType.SCAN_IMAGE)
                    .result(scanImageResult)
                    .build());
        }
    }

}
