package com.ufoto.business;

import com.aliyuncs.facebody.model.v20191230.RecognizeFaceResponse;
import com.tencentcloudapi.cms.v20190321.models.ImageModerationResponse;
import com.tencentcloudapi.iai.v20180301.models.DetectFaceResponse;
import com.ufoto.business.oss.OssUrlManager;
import com.ufoto.util.OSSFileUtils;
import com.ufoto.util.ZoomUtil;
import com.ufoto.util.business.AliCloudImageScanUtil;
import com.ufoto.util.business.AliCloudVisualOpenImageProcessUtil;
import com.ufoto.util.business.TencentImageProcessUtil;
import com.ufoto.util.business.oss.OssUtil;
import com.ufoto.util.business.result.FaceRecognizeResultUtil;
import com.ufoto.util.business.result.ScanImageResultUtil;
import com.ufoto.util.json.JSONUtil;
import org.junit.Test;
import org.junit.runner.RunWith;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.context.SpringBootTest;
import org.springframework.test.context.ActiveProfiles;
import org.springframework.test.context.junit4.SpringRunner;

/**
 * @author tangyd
 */
@RunWith(SpringRunner.class)
@ActiveProfiles("dev")
@SpringBootTest
public class VisualBusinessTest {

    @Autowired
    private OssUrlManager ossUrlManager;

    private static final OSSFileUtils fileUtils = OssUtil.getFileUtils();

    @Test
    public void AliImageScanTest() {
        String url = "http://social.ufotosoft.com/chat/img/200602/474427342714830925_1591090223389_UF200602f44f02ad-2e43-4774-a700-e3360c257c04.jpg";
        System.out.println(JSONUtil.toJSON(AliCloudImageScanUtil.getCheckDetailInfo(url, 1)));
    }

    @Test
    public void AliOpenVisualImageScanTest() throws Exception {
        String url = "http://social.ufotosoft.com/chat/img/200602/474427342714830925_1591090223389_UF200602f44f02ad-2e43-4774-a700-e3360c257c04.jpg";
        String ossUrl = fileUtils.upload(url);
        System.out.println(JSONUtil.toJSON(AliCloudVisualOpenImageProcessUtil.aliAIScanImage(ossUrl, 90F)));
    }

    @Test
    public void tencentImageScanTest() throws Exception {
        String url = "http://social.ufotosoft.com/head/img/180201/1517443261799_UF180201db40de13-6fe1-482d-ab74-60046ef9019a.jpg";
        ImageModerationResponse imageCheckResponse = TencentImageProcessUtil.imageModeration(url);
        System.out.println(JSONUtil.toJSON(imageCheckResponse));
        System.out.println(JSONUtil.toJSON(ScanImageResultUtil.parseCheckResult(imageCheckResponse)));
    }

    @Test
    public void aliFaceRecognizeTest() throws Exception {
        String url = "http://social.ufotosoft.com/chat/img/200602/474272629499363468_1591084494584_UF200602788d2345-b96e-40c8-9001-d76fd60cfcfa.jpg";
        String ossUrl = fileUtils.upload(ZoomUtil.zoomFaceImage(url));
        RecognizeFaceResponse recognizeFaceResponse = AliCloudVisualOpenImageProcessUtil.aliAIRecognizeFace(ossUrl);
        System.out.println("*************remote response is :" + JSONUtil.toJSON(recognizeFaceResponse));
        System.out.println("*************mq response is :" + JSONUtil.toJSON(FaceRecognizeResultUtil.getRecognizeFaceResult(recognizeFaceResponse)));
    }

    @Test
    public void tencentFaceRecognizeTest() throws Exception {
        String url = "http://social.ufotosoft.com/chat/img/200602/474289866591436915_1591040755935_UF200601ba581f4b-db54-4f78-8d90-8511e507a7ee.png";
        DetectFaceResponse detectFaceResponse = TencentImageProcessUtil.txFaceRecognize(ZoomUtil.zoomFaceImage(url));
        System.out.println("*************remote response is :" + JSONUtil.toJSON(detectFaceResponse));
        System.out.println("*************mq response is :" + JSONUtil.toJSON(FaceRecognizeResultUtil.getRecognizeFaceResult(detectFaceResponse)));
    }

}
