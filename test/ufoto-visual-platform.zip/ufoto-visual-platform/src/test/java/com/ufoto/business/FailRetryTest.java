package com.ufoto.business;

import com.ufoto.business.schedule.FailTaskRetryJob;
import com.ufoto.dao.write.WriteUfotoFailTaskMapper;
import com.ufoto.entity.UfotoFailTaskEntity;
import org.junit.Test;
import org.junit.runner.RunWith;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.context.SpringBootTest;
import org.springframework.test.context.ActiveProfiles;
import org.springframework.test.context.junit4.SpringRunner;

/**
 * @author tangyd
 */
@RunWith(SpringRunner.class)
@ActiveProfiles("dev")
@SpringBootTest
public class FailRetryTest {

    @Autowired
    FailTaskRetryJob failTaskRetryJob;

    @Autowired
    private WriteUfotoFailTaskMapper writeUfotoFailTaskMapper;

    @Test
    public void testRetry() throws Exception {
        UfotoFailTaskEntity ufotoFailTaskEntity = new UfotoFailTaskEntity();
        ufotoFailTaskEntity.setRequestBody("{\n" +
                "    \"actionData\":[\n" +
                "        {\n" +
                "            \"url\":\"http://social.ufotosoft.com/chat/img/200309/442964109764329629_1583737900396_UF200309e638c729-1181-431b-89ed-3d7328ad1805.gif\",\n" +
                "            \"type\":1,\n" +
                "            \"action\":[\n" +
                "                1\n" +
                "            ]\n" +
                "        }\n" +
                "    ],\n" +
                "    \"source\":\"feed\",\n" +
                "    \"uid\":1313131,\n" +
                "    \"data\":{\n" +
                "        \"picId\":1\n" +
                "    }\n" +
                "}");
        ufotoFailTaskEntity.setRetryTimes(0);
        ufotoFailTaskEntity.setUuid("313123123123214");
        writeUfotoFailTaskMapper.insert(ufotoFailTaskEntity);
        failTaskRetryJob.execute("");
        Thread.sleep(20000L);
        System.out.println();
    }
}
