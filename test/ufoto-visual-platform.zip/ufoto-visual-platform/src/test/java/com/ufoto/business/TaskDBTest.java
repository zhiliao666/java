package com.ufoto.business;

import com.ufoto.dao.read.ReadUfotoFailTaskMapper;
import com.ufoto.dao.write.WriteUfotoFailTaskMapper;
import com.ufoto.dto.UfotoFailTaskDto;
import com.ufoto.entity.UfotoFailTaskEntity;
import org.junit.Test;
import org.junit.runner.RunWith;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.context.SpringBootTest;
import org.springframework.test.context.ActiveProfiles;
import org.springframework.test.context.junit4.SpringRunner;

import java.util.List;

/**
 * @author tangyd
 */
@RunWith(SpringRunner.class)
@ActiveProfiles("dev")
@SpringBootTest
public class TaskDBTest {

    @Autowired
    private ReadUfotoFailTaskMapper readUfotoFailTaskMapper;

    @Autowired
    private WriteUfotoFailTaskMapper writeUfotoFailTaskMapper;

    @Test
    public void testTaskGet() {
        List<UfotoFailTaskDto> list = readUfotoFailTaskMapper.getRetryTasks();
        System.out.println(list.size());
    }

    @Test
    public void testTaskInsert() {
        UfotoFailTaskEntity ufotoFailTaskEntity = new UfotoFailTaskEntity();
        ufotoFailTaskEntity.setRequestBody("{\n" +
                "    \"actionData\":[\n" +
                "        {\n" +
                "            \"url\":\"http://social.ufotosoft.com/chat/img/200309/442964109764329629_1583737900396_UF200309e638c729-1181-431b-89ed-3d7328ad1805.gif\",\n" +
                "            \"type\":1,\n" +
                "            \"action\":[\n" +
                "                1\n" +
                "            ]\n" +
                "        }\n" +
                "    ],\n" +
                "    \"source\":\"feed\",\n" +
                "    \"uid\":1313131,\n" +
                "    \"data\":{\n" +
                "        \"picId\":1\n" +
                "    }\n" +
                "}");
        ufotoFailTaskEntity.setRetryTimes(0);
        ufotoFailTaskEntity.setUuid("313123123123214");
        writeUfotoFailTaskMapper.insert(ufotoFailTaskEntity);
    }

    @Test
    public void testTaskUpdate() {
        writeUfotoFailTaskMapper.update("313123123123214", 1);
    }

    @Test
    public void testTaskDelete() {
        writeUfotoFailTaskMapper.delete("313123123123214");
    }
}
