package com.ufoto.metric.config.semaphore;

import com.codahale.metrics.MetricFilter;
import com.codahale.metrics.MetricRegistry;
import com.netflix.hystrix.HystrixCommand;
import com.ufoto.metric.config.MetricsReporterAutoConfiguration;
import com.ufoto.metric.config.MetricsReporterProperties;
import com.ufoto.metric.process.SemaphoreMetricProducer;
import com.ufoto.metric.process.Slf4jToJsonReporter;
import io.micrometer.core.instrument.MeterRegistry;
import org.assertj.core.api.Assertions;
import org.junit.Test;
import org.springframework.boot.autoconfigure.AutoConfigurations;
import org.springframework.boot.autoconfigure.logging.ConditionEvaluationReportLoggingListener;
import org.springframework.boot.test.context.FilteredClassLoader;
import org.springframework.boot.test.context.assertj.AssertableApplicationContext;
import org.springframework.boot.test.context.runner.ApplicationContextRunner;
import org.springframework.util.Assert;
import org.springframework.util.ReflectionUtils;

import java.lang.reflect.Field;

/**
 * @author Luo Bao Ding
 * @since 2018/12/11
 */
public class SemaphoreMetricConfigurationTest {
    private final ConditionEvaluationReportLoggingListener loggingListener = new ConditionEvaluationReportLoggingListener();
    private final ApplicationContextRunner contextRunner = new ApplicationContextRunner()
            .withConfiguration(AutoConfigurations.of(MetricsReporterAutoConfiguration.class)).withInitializer(loggingListener);


    @Test
    public void defaultServiceBacksOff() {
        this.contextRunner.run(context -> {
            Assertions.assertThat(context).hasSingleBean(SemaphoreMetricProducer.class);
            Assertions.assertThat(context).hasSingleBean(MetricFilter.class);
            assertReporterBeanExistence(context);
            Slf4jToJsonReporter reporter = context.getBean(Slf4jToJsonReporter.class);
            Field fieldMetricProducers = ReflectionUtils.findField(Slf4jToJsonReporter.class, "metricProducers");
            Assert.notNull(fieldMetricProducers, "Slf4jToJsonReporter's field metricProducers must exist");
            fieldMetricProducers.setAccessible(true);
            Object objMetricProducers = fieldMetricProducers.get(reporter);
            Assert.notNull(objMetricProducers, "Slf4jToJsonReporter.metricProducers should not be  null");
        });

    }

    @Test
    public void serviceIsIgnoredIfDisabled() {
        this.contextRunner.withPropertyValues("ufoto.metrics.log.semaphore.enabled=false").run((context) -> {
            Assertions.assertThat(context).doesNotHaveBean(SemaphoreMetricProducer.class);
            assertReporterBeanExistence(context);

        });
    }

    @Test
    public void metricFilterDisabled() {
        this.contextRunner.withPropertyValues("ufoto.metrics.log.filter.enabled=false").run(context -> {
            Assertions.assertThat(context).doesNotHaveBean(MetricFilter.class);
            assertReporterBeanExistence(context);

        });
    }

    @Test
    public void serviceIsIgnoredIfLibraryIsNotPresent() {
        this.contextRunner.withClassLoader(new FilteredClassLoader(HystrixCommand.class))
                .run(context -> {
                    Assertions.assertThat(context).doesNotHaveBean(SemaphoreMetricProducer.class);
                    assertReporterBeanExistence(context);

                });
    }

    private void assertReporterBeanExistence(AssertableApplicationContext context) {
        Assertions.assertThat(context).hasSingleBean(MetricRegistry.class);
        Assertions.assertThat(context).hasSingleBean(Slf4jToJsonReporter.class);
        Assertions.assertThat(context).hasSingleBean(MeterRegistry.class);
        Assertions.assertThat(context).hasSingleBean(MetricsReporterProperties.class);
    }
}