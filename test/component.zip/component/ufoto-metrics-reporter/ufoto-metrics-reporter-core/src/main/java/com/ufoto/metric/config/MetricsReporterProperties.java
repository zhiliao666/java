package com.ufoto.metric.config;

import org.springframework.boot.context.properties.ConfigurationProperties;

import java.util.ArrayList;
import java.util.List;

/**
 * 指标上报配置类
 *
 * @author zhangqh
 * @date 2018年11月20日
 */
@ConfigurationProperties(prefix = "ufoto.metrics.log")
public class MetricsReporterProperties {

    private final static int DEFAULT_PERIOD = 1;
    private final static String DEFAULT_NAME = "tomcat_metrics";
    private final static String DEFAULT_BASEPATH = "logs";
    private final static int DEFAULT_MAXHISTORY = 7;

    private boolean enabled = true;
    /**
     * 默认true为开启 关闭告警邮件发送设为false
     */
    private Boolean status = true;

    /**
     * 日志存放跟路径 可以是相对路径 如当前项目目录的logs目录下 则配置为：/logs
     */
    private String basePath = DEFAULT_BASEPATH;


    /**
     * 日志保留天数
     */
    private int maxHistory = DEFAULT_MAXHISTORY;

    /**
     * 文件名字
     */
    private String fileName = DEFAULT_NAME;

    /**
     * 日志打印间隔
     */
    private int period = DEFAULT_PERIOD;

    private Semaphore semaphore;

    private Filter filter = new Filter();

    public boolean isEnabled() {
        return enabled;
    }

    public void setEnabled(boolean enabled) {
        this.enabled = enabled;
    }

    /**
     * @return the period
     */
    public int getPeriod() {
        return period;
    }

    /**
     * @param period the period to set
     */
    public void setPeriod(int period) {
        this.period = period;
    }

    /**
     * @return the status
     */
    public Boolean getStatus() {
        return status;
    }

    /**
     * @param status the status to set
     */
    public void setStatus(Boolean status) {
        this.status = status;
    }

    /**
     * @return the basePath
     */
    public String getBasePath() {
        return basePath;
    }

    /**
     * @param basePath the basePath to set
     */
    public void setBasePath(String basePath) {
        this.basePath = basePath;
    }


    /**
     * @return the maxHistory
     */
    public int getMaxHistory() {
        return maxHistory;
    }

    /**
     * @param maxHistory the maxHistory to set
     */
    public void setMaxHistory(int maxHistory) {
        this.maxHistory = maxHistory;
    }

    /**
     * @return the fileName
     */
    public String getFileName() {
        return fileName;
    }

    /**
     * @param fileName the fileName to set
     */
    public void setFileName(String fileName) {
        this.fileName = fileName;
    }

    public Semaphore getSemaphore() {
        return semaphore;
    }

    public void setSemaphore(Semaphore semaphore) {
        this.semaphore = semaphore;
    }


    public Filter getFilter() {
        return filter;
    }

    public void setFilter(Filter filter) {
        this.filter = filter;
    }

    public static class Semaphore {
        private boolean enabled = true;

        public boolean isEnabled() {
            return enabled;
        }

        public void setEnabled(boolean enabled) {
            this.enabled = enabled;
        }
    }

    public static class Filter {
        private List<String> includedPrefixes;
        private List<String> excludedPrefixes;
        private boolean enabled = true;

        public Filter() {
            includedPrefixes = new ArrayList<>(8);
            includedPrefixes.add("tomcatThreadsBusy");
            includedPrefixes.add("tomcatThreadsCurrent");
            includedPrefixes.add("tomcatThreadsConnectionCount");
        }

        public List<String> getIncludedPrefixes() {
            return includedPrefixes;
        }

        public void setIncludedPrefixes(List<String> includedPrefixes) {
            this.includedPrefixes = includedPrefixes;
        }

        public List<String> getExcludedPrefixes() {
            return excludedPrefixes;
        }

        public void setExcludedPrefixes(List<String> excludedPrefixes) {
            this.excludedPrefixes = excludedPrefixes;
        }

        public boolean isEnabled() {
            return enabled;
        }

        public void setEnabled(boolean enabled) {
            this.enabled = enabled;
        }
    }

}
