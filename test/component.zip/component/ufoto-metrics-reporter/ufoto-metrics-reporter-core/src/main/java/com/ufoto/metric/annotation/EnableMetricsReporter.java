package com.ufoto.metric.annotation;

import com.ufoto.metric.config.MetricsReporterAutoConfiguration;
import org.springframework.context.annotation.Import;

import java.lang.annotation.*;



/**
 * 启用基于Actuator metrics监控日志打印
 * 
 * <p>在Spring Boot启动类上加上此注解<p>
 * 
 * <pre class="code">
 * &#064;SpringBootApplication
 * &#064;EnableMetricsReporter
 * public class App {
 *     public static void main(String[] args) {
 *         SpringApplication.run(App.class, args);
 *     }
 * }
 * <pre>
 *
 * @author zhangqh
 * @date 2018年11月15日
 */
@Target({ElementType.TYPE})
@Retention(RetentionPolicy.RUNTIME)
@Documented
@Inherited
@Import({MetricsReporterAutoConfiguration.class})
public @interface EnableMetricsReporter {

}
