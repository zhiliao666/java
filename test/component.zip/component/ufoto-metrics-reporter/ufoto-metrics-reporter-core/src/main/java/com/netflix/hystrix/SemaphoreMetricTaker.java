package com.netflix.hystrix;

import org.springframework.util.Assert;

import java.util.concurrent.ConcurrentHashMap;

/**
 * @author Luo Bao Ding
 * @since 2018/12/13
 */
public class SemaphoreMetricTaker extends HystrixCommand {
    private SemaphoreMetricTaker() {
        super(HystrixCommandGroupKey.Factory.asKey(SemaphoreMetricTaker.class.getSimpleName()));
    }

    @Override
    protected Object run() throws Exception {
        return null;
    }


    public static int getBusySemaphore(String key) {
        return getTryableSemaphore(key).getNumberOfPermitsUsed();
    }

    public static int getMaxSemaphore(String key) {
        return getTryableSemaphore(key).numberOfPermits.get();
    }

    public static TryableSemaphoreActual getTryableSemaphore(String key) {
        TryableSemaphore tryableSemaphore = getExecutionSemaphorePerCircuit().get(key);
        Assert.isTrue(tryableSemaphore instanceof TryableSemaphoreActual, "tryableSemaphore must be instance of TryableSemaphoreActual");
        return (TryableSemaphoreActual) tryableSemaphore;

    }

    public static ConcurrentHashMap<String, TryableSemaphore> getExecutionSemaphorePerCircuit() {
        return executionSemaphorePerCircuit;
    }
}
