package com.ufoto.metric.process;

import ch.qos.logback.core.util.CachingDateFormatter;
import com.codahale.metrics.*;
import com.ufoto.metric.util.IpUtil;
import org.slf4j.Logger;
import org.slf4j.Marker;

import java.util.Map.Entry;
import java.util.SortedMap;
import java.util.concurrent.ScheduledExecutorService;
import java.util.concurrent.TimeUnit;


public class Slf4jToJsonReporter extends ScheduledReporter {
    private final CachingDateFormatter cachingDateFormatter = new CachingDateFormatter("yyyy-MM-dd HH:mm:ss");

    private final LoggerProxy loggerProxy;
    private final Marker marker;
    private final String prefix;
    private final Iterable<MetricProducer> metricProducers;

    public Slf4jToJsonReporter(MetricRegistry registry,
                               LoggerProxy loggerProxy,
                               Marker marker,
                               String prefix,
                               TimeUnit rateUnit,
                               TimeUnit durationUnit,
                               MetricFilter filter,
                               ScheduledExecutorService executor,
                               boolean shutdownExecutorOnStop, Iterable<MetricProducer> metricProducers) {
        super(registry, "logger-reporter", filter, rateUnit, durationUnit, executor, shutdownExecutorOnStop);
        this.loggerProxy = loggerProxy;
        this.marker = marker;
        this.prefix = prefix;
        this.metricProducers = metricProducers;
    }


    @Override
    public void report(SortedMap<String, Gauge> gauges,
                       SortedMap<String, Counter> counters,
                       SortedMap<String, Histogram> histograms,
                       SortedMap<String, Meter> meters,
                       SortedMap<String, Timer> timers) {
        logGauge(gauges);

        logMetricIfAvailable();

    }

    private void logGauge(SortedMap<String, Gauge> gauges) {
        if (loggerProxy.isEnabled(marker)) {
            StringBuilder sbuf = new StringBuilder("{\"time\":\"");
            sbuf.append(cachingDateFormatter.format(System.currentTimeMillis())).append("\",");
            sbuf.append("\"ip\":\"").append(IpUtil.getHostIpOrName()).append("\",");
            for (Entry<String, Gauge> entry : gauges.entrySet()) {
                sbuf.append("\"").append(getFirstBySeparator(prefix(entry.getKey()), "\\.")).append("\"").append(":")
                        .append(entry.getValue().getValue()).append(",");
            }
            loggerProxy.log(marker, sbuf.toString().substring(0, sbuf.length() - 1) + "}");
        }
    }

    private void logMetricIfAvailable() {
        if (metricProducers == null) {
            return;
        }
        for (MetricProducer producer : metricProducers) {
            producer.produce();
        }
    }

    public static JsonReporterBuilder forRegistry(MetricRegistry registry, Logger logger) {
        return new JsonReporterBuilder(registry, logger);
    }

    private String getFirstBySeparator(String value, String separator) {
        if (value == null)
            return "";
        if (!value.contains("tomcat"))
            return value;
        return value.split(separator)[0];
    }

    @Override
    protected String getRateUnit() {
        return "events/" + super.getRateUnit();
    }

    private String prefix(String... components) {
        return MetricRegistry.name(prefix, components);
    }


    public static class JsonReporterBuilder {

        private final MetricRegistry registry;
        private Logger logger;
        private Marker marker;
        private String prefix;
        private TimeUnit rateUnit;
        private TimeUnit durationUnit;
        private MetricFilter filter;
        private ScheduledExecutorService executor;
        private boolean shutdownExecutorOnStop;
        private Iterable<MetricProducer> metricProducers;

        private JsonReporterBuilder(MetricRegistry registry, Logger logger) {
            this.registry = registry;
            this.logger = logger;
            this.marker = null;
            this.prefix = "";
            this.rateUnit = TimeUnit.SECONDS;
            this.durationUnit = TimeUnit.MILLISECONDS;
            this.filter = MetricFilter.ALL;
            this.executor = null;
            this.shutdownExecutorOnStop = true;
        }

        public JsonReporterBuilder shutdownExecutorOnStop(boolean shutdownExecutorOnStop) {
            this.shutdownExecutorOnStop = shutdownExecutorOnStop;
            return this;
        }

        public JsonReporterBuilder scheduleOn(ScheduledExecutorService executor) {
            this.executor = executor;
            return this;
        }

        public JsonReporterBuilder outputTo(Logger logger) {
            this.logger = logger;
            return this;
        }

        public JsonReporterBuilder markWith(Marker marker) {
            this.marker = marker;
            return this;
        }

        public JsonReporterBuilder prefixedWith(String prefix) {
            this.prefix = prefix;
            return this;
        }

        /**
         * 时间单位转换
         */
        public JsonReporterBuilder convertRatesTo(TimeUnit rateUnit) {
            this.rateUnit = rateUnit;
            return this;
        }

        public JsonReporterBuilder convertDurationsTo(TimeUnit durationUnit) {
            this.durationUnit = durationUnit;
            return this;
        }

        public JsonReporterBuilder filter(MetricFilter filter) {
            this.filter = filter;
            return this;
        }

        public JsonReporterBuilder metricProducers(Iterable<MetricProducer> metricProducers) {
            this.metricProducers = metricProducers;
            return this;
        }


        public Slf4jToJsonReporter build() {
            MetricsLoggerProxy loggerProxy = new MetricsLoggerProxy(logger);
            return new Slf4jToJsonReporter(registry, loggerProxy, marker,
                    prefix, rateUnit, durationUnit, filter, executor,
                    shutdownExecutorOnStop, metricProducers);
        }


    }
}
