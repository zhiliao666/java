package com.ufoto.metric.config;

import com.netflix.hystrix.HystrixCommand;
import com.ufoto.metric.process.SemaphoreMetricProducer;
import org.springframework.boot.autoconfigure.condition.ConditionalOnClass;
import org.springframework.boot.autoconfigure.condition.ConditionalOnProperty;
import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;

/**
 * @author Luo Bao Ding
 * @since 2018/12/10
 */
@Configuration
@ConditionalOnClass(HystrixCommand.class)
@ConditionalOnProperty(name = "ufoto.metrics.log.semaphore.enabled", havingValue = "true", matchIfMissing = true)
public class SemaphoreMetricConfiguration {

    @Bean
    public SemaphoreMetricProducer semaphoreMetricProducer() {
        return new SemaphoreMetricProducer();
    }
}
