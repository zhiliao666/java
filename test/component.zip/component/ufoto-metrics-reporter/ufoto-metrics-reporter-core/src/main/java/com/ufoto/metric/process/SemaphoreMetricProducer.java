package com.ufoto.metric.process;

import com.netflix.hystrix.SemaphoreMetricTaker;
import com.ufoto.metric.constants.MetricLogTopicConstants;
import org.slf4j.Logger;

import java.util.Enumeration;
import java.util.StringJoiner;

/**
 * @author Luo Bao Ding
 * @since 2018/12/8
 */
public class SemaphoreMetricProducer implements MetricProducer {
    private static final Logger LOGGER = MetricLogTopicConstants.metric_semaphore;

    @Override
    public void produce() {
        Enumeration<String> keys = SemaphoreMetricTaker.getExecutionSemaphorePerCircuit().keys();
        while (keys.hasMoreElements()) {
            String commandName = keys.nextElement();

            //get maxSemaphore
            int maxSemaphore = SemaphoreMetricTaker.getMaxSemaphore(commandName);

            //get busySemaphore
            Object busySemaphore = SemaphoreMetricTaker.getBusySemaphore(commandName);

            //log
            log(commandName, maxSemaphore, busySemaphore);

        }

    }

    private void log(String commandName, int maxSemaphore, Object busySemaphore) {
        String jsonLine = new StringJoiner(",")
                .add("\"c\":" + "\"" + commandName + "\"")
                .add("\"b\":" + busySemaphore)
                .add("\"m\":" + maxSemaphore)
                .toString();
        LOGGER.info(jsonLine);
    }

}
