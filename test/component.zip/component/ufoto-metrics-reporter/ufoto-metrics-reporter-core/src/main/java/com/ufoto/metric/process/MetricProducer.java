package com.ufoto.metric.process;

/**
 * @author Luo Bao Ding
 * @since 2018/12/14
 */
public interface MetricProducer {

    void produce();
}
