package com.ufoto.metric.process;

import org.slf4j.Logger;
import org.slf4j.Marker;

public class MetricsLoggerProxy extends LoggerProxy{
	public MetricsLoggerProxy(Logger logger) {
        super(logger);
    }

    @Override
    public void log(Marker marker, String format, Object... arguments) {
        logger.info(marker, format, arguments);
    }

    @Override
    public boolean isEnabled(Marker marker) {
        return logger.isInfoEnabled(marker);
    }
}
