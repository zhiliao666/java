package com.ufoto.metric.process;

import org.slf4j.Logger;
import org.slf4j.Marker;

public abstract class LoggerProxy {
	protected final Logger logger;

    public LoggerProxy(Logger logger) {
        this.logger = logger;
    }

    abstract void log(Marker marker, String format, Object... arguments);

    abstract boolean isEnabled(Marker marker);
}
