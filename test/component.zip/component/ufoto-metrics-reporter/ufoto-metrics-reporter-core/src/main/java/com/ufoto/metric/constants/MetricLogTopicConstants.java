package com.ufoto.metric.constants;

import com.ufoto.logging.proxy.UfotoLogFactory;
import org.slf4j.Logger;

/**
 * @author Luo Bao Ding
 * @since 2018/12/11
 */
public class MetricLogTopicConstants {
    private static final String LAYOUT = "{\"t\":\"%d{yyyy-MM-dd HH:mm:ss.SSS}\",%msg}%n";
    public static final Logger metric_semaphore = UfotoLogFactory.getLogger("metric_semaphore")
            .enableCustomStatus()
            .enablePatternLayout()
            .withEncoderPattern(LAYOUT)
            .withFileName("metric_semaphore")
            .build();

}
