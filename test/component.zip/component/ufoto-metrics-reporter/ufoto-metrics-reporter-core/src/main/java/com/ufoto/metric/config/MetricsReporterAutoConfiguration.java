package com.ufoto.metric.config;

import com.codahale.metrics.MetricFilter;
import com.codahale.metrics.MetricRegistry;
import com.ufoto.logging.proxy.UfotoLogFactory;
import com.ufoto.metric.process.MetricProducer;
import com.ufoto.metric.process.Slf4jToJsonMetricFilter;
import com.ufoto.metric.process.Slf4jToJsonReporter;
import io.micrometer.core.instrument.Clock;
import io.micrometer.core.instrument.MeterRegistry;
import io.micrometer.core.instrument.dropwizard.DropwizardConfig;
import io.micrometer.core.instrument.dropwizard.DropwizardMeterRegistry;
import io.micrometer.core.instrument.util.HierarchicalNameMapper;
import org.slf4j.Logger;
import org.springframework.beans.factory.ObjectProvider;
import org.springframework.boot.autoconfigure.condition.ConditionalOnProperty;
import org.springframework.boot.context.properties.EnableConfigurationProperties;
import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;
import org.springframework.context.annotation.Import;

import java.util.Collections;
import java.util.List;
import java.util.concurrent.TimeUnit;

@Configuration
@ConditionalOnProperty(name = "ufoto.metrics.log.enabled", havingValue = "true", matchIfMissing = true)
@EnableConfigurationProperties(MetricsReporterProperties.class)
@Import({SemaphoreMetricConfiguration.class,
        AdditionalTomcatMetricsConfiguration.class
})
public class MetricsReporterAutoConfiguration {

    @Bean
    public MetricRegistry dropwizardRegistry() {
        return new MetricRegistry();
    }

    @Bean
    @ConditionalOnProperty(name = "ufoto.metrics.log.filter.enabled", havingValue = "true", matchIfMissing = true)
    public Slf4jToJsonMetricFilter slf4jToJsonMetricFilter(MetricsReporterProperties metricsReporterProperties) {
        return new Slf4jToJsonMetricFilter(metricsReporterProperties);
    }

    @Bean
    public Slf4jToJsonReporter slf4jReporter(MetricRegistry dropwizardRegistry, MetricsReporterProperties metricsReporterProperties,
                                             ObjectProvider<List<MetricProducer>> metricProducers,
                                             ObjectProvider<MetricFilter> slf4jToJsonMetricFilter) {
        if (metricsReporterProperties.getStatus()) {
            Logger logger = UfotoLogFactory.getLogger("metrics")
                    .enableCustomStatus()
                    .withFileName(metricsReporterProperties.getFileName())
                    .withBasePath(metricsReporterProperties.getBasePath())
                    .withMaxHistory(metricsReporterProperties.getMaxHistory())
                    .build();
            Slf4jToJsonReporter reporter = Slf4jToJsonReporter.forRegistry(dropwizardRegistry, logger).convertRatesTo(TimeUnit.SECONDS)
                    .convertDurationsTo(TimeUnit.MILLISECONDS)
                    .filter(slf4jToJsonMetricFilter.getIfAvailable(() -> MetricFilter.ALL))
                    .metricProducers(metricProducers.getIfAvailable(Collections::emptyList))
                    .build();
            reporter.start(metricsReporterProperties.getPeriod(), TimeUnit.SECONDS);
            return reporter;
        }
        return null;
    }

    @Bean
    public MeterRegistry consoleLoggingRegistry(MetricRegistry dropwizardRegistry) {
        DropwizardConfig consoleConfig = new DropwizardConfig() {
            @Override
            public String prefix() {
                return "console";
            }

            @Override
            public String get(String key) {
                return null;
            }

        };
        MeterRegistry meterRegistry = new DropwizardMeterRegistry(consoleConfig, dropwizardRegistry, HierarchicalNameMapper.DEFAULT, Clock.SYSTEM) {
            @Override
            protected Double nullGaugeValue() {
                return null;
            }
        };
        return meterRegistry;

    }
}
