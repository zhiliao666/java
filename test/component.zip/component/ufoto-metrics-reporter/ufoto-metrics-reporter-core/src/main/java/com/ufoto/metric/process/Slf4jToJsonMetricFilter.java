package com.ufoto.metric.process;

import com.codahale.metrics.Metric;
import com.codahale.metrics.MetricFilter;
import com.ufoto.metric.config.MetricsReporterProperties;

import java.util.List;

/**
 * @author Luo Bao Ding
 * @since 2018/12/14
 */
public class Slf4jToJsonMetricFilter implements MetricFilter {
    private final MetricsReporterProperties metricsReporterProperties;

    public Slf4jToJsonMetricFilter(MetricsReporterProperties metricsReporterProperties) {
        this.metricsReporterProperties = metricsReporterProperties;
    }

    @Override
    public boolean matches(String name, Metric metric) {
        MetricsReporterProperties.Filter filter = metricsReporterProperties.getFilter();

        List<String> includedPrefixes = filter.getIncludedPrefixes();
        List<String> excludedPrefixes = filter.getExcludedPrefixes();

        if (!isEmpty(excludedPrefixes)) {
            for (String prefix : excludedPrefixes) {
                boolean yes = name.startsWith(prefix);
                if (yes) {
                    return false;
                }
            }
        }

        if (isEmpty(includedPrefixes)) {
            return true;
        } else {
            for (String prefix : includedPrefixes) {
                boolean yes = name.startsWith(prefix);
                if (yes) {
                    return true;
                }
            }
        }

        return false;
    }

    private boolean isEmpty(List<String> list) {
        return list == null || list.isEmpty();
    }
}
