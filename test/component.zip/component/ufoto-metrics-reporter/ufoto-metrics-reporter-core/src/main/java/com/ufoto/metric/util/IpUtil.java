package com.ufoto.metric.util;
import java.net.InetAddress;
import java.net.UnknownHostException;
/**
 * ip工具类
 *
 * @author zhangqh
 * @date 2018年11月19日
 */
public class IpUtil {

	private static String HOSTIPORNAME = null;
	
	private static String DEFAULTHOSTIP = "127.0.0.1";

	public static String getHostAddress() {
		try {
			return InetAddress.getLocalHost().getHostAddress();
		} catch (UnknownHostException e) {
			e.printStackTrace();
			return "";
		}
	}

	public static String getHostName() {
		return System.getenv("COMPUTERNAME");
	}
	
	public static String getHostIpOrName() {
		if (HOSTIPORNAME != null) {
			return HOSTIPORNAME;
		}
		HOSTIPORNAME = getHostAddress();
		if (HOSTIPORNAME == null || "".equals(HOSTIPORNAME) || DEFAULTHOSTIP.equals(HOSTIPORNAME)) {
			HOSTIPORNAME = getHostName();
		}
		return HOSTIPORNAME;
	}

}
