package com.ufoto.infrastructure.rabbitmq.consumer.concurrency;

import org.assertj.core.api.Assertions;
import org.junit.Test;
import org.springframework.boot.autoconfigure.AutoConfigurations;
import org.springframework.boot.autoconfigure.amqp.RabbitAutoConfiguration;
import org.springframework.boot.autoconfigure.logging.ConditionEvaluationReportLoggingListener;
import org.springframework.boot.env.YamlPropertySourceLoader;
import org.springframework.boot.logging.LogLevel;
import org.springframework.boot.origin.OriginTrackedValue;
import org.springframework.boot.test.context.runner.ApplicationContextRunner;
import org.springframework.core.env.PropertySource;
import org.springframework.core.io.ClassPathResource;

import java.io.IOException;
import java.util.List;
import java.util.Map;

/**
 * @author Luo Bao Ding
 * @since 2019/4/12
 */
public class RabbitmqConsumerConcurrencyAutoConfigurationTest {

    private ConditionEvaluationReportLoggingListener listener = new ConditionEvaluationReportLoggingListener(LogLevel.INFO);
    private ApplicationContextRunner contextRunner = new ApplicationContextRunner().withInitializer(listener)
            .withConfiguration(AutoConfigurations.of(RabbitmqConsumerConcurrencyAutoConfiguration.class));


    @Test
    public void normal() throws IOException {
        String propertiesYaml = "LCFProperties.yaml";
        ClassPathResource resource = new ClassPathResource(propertiesYaml);
        YamlPropertySourceLoader loader = new YamlPropertySourceLoader();
        List<PropertySource<?>> sourceList = loader.load(propertiesYaml, resource);

        String[] objects = ((Map<String, OriginTrackedValue>) sourceList.get(0).getSource()).entrySet().stream()
                .map(entry -> entry.getKey() + "=" + entry.getValue().getValue()).toArray(String[]::new);

        contextRunner.withConfiguration(AutoConfigurations.of(RabbitAutoConfiguration.class))
                .withPropertyValues(objects).run(context -> {
            Assertions.assertThat(context).hasSingleBean(SimpleLCFConfigurer.class);
            Assertions.assertThat(context).hasSingleBean(DirectLCFConfigurer.class);
            Assertions.assertThat(context).hasSingleBean(ListenerBeansRegistrar.class);
            Assertions.assertThat(context).hasBean("lowCon");
            Assertions.assertThat(context).hasBean("highCon");
        });

    }

    @Test
    public void abnormalWithoutConnectionFactory() {
        contextRunner.run(context -> {
            Assertions.assertThat(context).doesNotHaveBean(SimpleLCFConfigurer.class);
            Assertions.assertThat(context).doesNotHaveBean(DirectLCFConfigurer.class);
            Assertions.assertThat(context).doesNotHaveBean(ListenerBeansRegistrar.class);

        });
    }
}