package com.ufoto.infrastructure.rabbitmq.consumer.concurrency;

import org.springframework.amqp.rabbit.connection.ConnectionFactory;
import org.springframework.amqp.rabbit.retry.MessageRecoverer;
import org.springframework.amqp.support.converter.MessageConverter;
import org.springframework.beans.factory.ObjectProvider;
import org.springframework.beans.factory.annotation.Qualifier;
import org.springframework.boot.autoconfigure.AutoConfigureAfter;
import org.springframework.boot.autoconfigure.amqp.RabbitAutoConfiguration;
import org.springframework.boot.autoconfigure.amqp.RabbitRetryTemplateCustomizer;
import org.springframework.boot.autoconfigure.condition.ConditionalOnBean;
import org.springframework.boot.context.properties.EnableConfigurationProperties;
import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;

/**
 * @author Luo Bao Ding
 * @since 2019/4/9
 */
@Configuration
@EnableConfigurationProperties(LCFProperties.class)
@AutoConfigureAfter(RabbitAutoConfiguration.class)
@ConditionalOnBean(ConnectionFactory.class)
public class RabbitmqConsumerConcurrencyAutoConfiguration {

    @Bean
    public SimpleLCFConfigurer simpleLCFConfigurer(ObjectProvider<MessageConverter> messageConverter,
                                                   ObjectProvider<MessageRecoverer> messageRecoverer,
                                                   ObjectProvider<RabbitRetryTemplateCustomizer> retryTemplateCustomizers) {
        return new SimpleLCFConfigurer(messageConverter, messageRecoverer, retryTemplateCustomizers);
    }

    @Bean
    public DirectLCFConfigurer directLCFConfigurer(ObjectProvider<MessageConverter> messageConverter,
                                                   ObjectProvider<MessageRecoverer> messageRecoverer,
                                                   ObjectProvider<RabbitRetryTemplateCustomizer> retryTemplateCustomizers) {

        return new DirectLCFConfigurer(messageConverter, messageRecoverer, retryTemplateCustomizers);
    }

    @Bean
    @Qualifier(Constants.BEAN_NAME_LISTENER_BEANS_REGISTRAR)
    public ListenerBeansRegistrar listenerBeansRegistrar(LCFProperties properties, ConnectionFactory connectionFactory,
                                                         SimpleLCFConfigurer simpleLCFConfigurer, DirectLCFConfigurer directLCFConfigurer) {
        return new ListenerBeansRegistrar(properties, connectionFactory, simpleLCFConfigurer, directLCFConfigurer);
    }


}
