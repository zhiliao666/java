package com.ufoto.infrastructure.rabbitmq.consumer.concurrency;

/**
 * @author Luo Bao Ding
 * @since 2019/4/13
 */
public class Constants {
    public static final String BEAN_NAME_LISTENER_BEANS_REGISTRAR = "listenerBeansRegistrar";

}
