package com.ufoto.infrastructure.transmission.test;

import com.github.tomakehurst.wiremock.core.WireMockConfiguration;
import com.github.tomakehurst.wiremock.extension.responsetemplating.ResponseTemplateTransformer;
import com.github.tomakehurst.wiremock.junit.WireMockRule;
import com.ufoto.infrastructure.transmission.TransmissionAutoConfiguration;
import org.junit.Rule;
import org.junit.Test;
import org.junit.runner.RunWith;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.SpringBootConfiguration;
import org.springframework.boot.autoconfigure.EnableAutoConfiguration;
import org.springframework.boot.test.autoconfigure.web.servlet.AutoConfigureMockMvc;
import org.springframework.boot.test.context.SpringBootTest;
import org.springframework.cloud.openfeign.EnableFeignClients;
import org.springframework.cloud.openfeign.FeignClient;
import org.springframework.context.annotation.ComponentScan;
import org.springframework.context.annotation.Import;
import org.springframework.http.HttpHeaders;
import org.springframework.mock.web.MockHttpServletResponse;
import org.springframework.stereotype.Component;
import org.springframework.test.context.junit4.SpringRunner;
import org.springframework.test.web.servlet.MockMvc;
import org.springframework.test.web.servlet.MvcResult;
import org.springframework.test.web.servlet.request.MockHttpServletRequestBuilder;
import org.springframework.test.web.servlet.request.MockMvcRequestBuilders;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.RestController;

import java.net.URI;

import static com.github.tomakehurst.wiremock.client.WireMock.*;
import static org.assertj.core.api.Assertions.assertThat;

/**
 * @author Luo Bao Ding
 * @since 2019/6/3
 */
@RunWith(SpringRunner.class)
@SpringBootTest
@EnableAutoConfiguration
@EnableFeignClients
@AutoConfigureMockMvc
public class IntegrationTest {

    @Autowired
    private MockMvc mockMvc;

    @Rule
    public WireMockRule wireMockRule = new WireMockRule(new WireMockConfiguration()
            .port(TestConfiguration.TestFeignClient.PORT)
            .extensions(new ResponseTemplateTransformer(false)));

    @Test
    public void testNormal() throws Exception {
        stubFor(get(urlEqualTo("/get?planet=Earth"))
                .withHeader("c", equalTo("1.2.3"))
                .withHeader("uid", equalTo("111232"))
                .willReturn(aResponse().withStatus(200).withBody("ok")));

        MockHttpServletRequestBuilder requestBuilder = getRequestBuilder();
        MvcResult mvcResult = mockMvc.perform(requestBuilder).andReturn();
        MockHttpServletResponse response = mvcResult.getResponse();
        assertThat(response.getStatus()).isEqualTo(200);
    }

    @Test
    public void testContrary() throws Exception {
        stubFor(get(urlEqualTo("/get?planet=Earth"))
                .withHeader("c", equalTo("1.2.3"))
                .withHeader("uid", equalTo("111232"))
                .willReturn(aResponse()
                        .withTransformers(ResponseTemplateTransformer.NAME)
                        .withBody("{{request.headers.uid}},{{request.headers.username}}")
                        .withStatus(200)
                ));

        MockHttpServletRequestBuilder requestBuilder = getRequestBuilder();

        MvcResult mvcResult = mockMvc.perform(requestBuilder).andReturn();
        MockHttpServletResponse response = mvcResult.getResponse();
        String contentAsString = response.getContentAsString();
        assertThat(contentAsString).contains("111232");
        assertThat(contentAsString).doesNotContain("Foo");


    }


    private MockHttpServletRequestBuilder getRequestBuilder() {
        HttpHeaders headers = new HttpHeaders();
        headers.set("username", "Foo");
        headers.set("age", "18");
        headers.set("c", "1.2.3");
        headers.set("uid", "111232");

        return MockMvcRequestBuilders.get(URI.create("/invokeGet")).headers(headers)
                .param("planet", "Earth");
    }

    @SpringBootConfiguration
    @Import(TransmissionAutoConfiguration.class)
    @ComponentScan
    public static class TestConfiguration {

        @RestController
        public static class InvokerController {
            @Autowired
            private TestConfiguration.TestFeignClient testFeignClient;

            @RequestMapping("/invokeGet")
            public String invokeGet(@RequestParam("planet") String planet) {
                return testFeignClient.get(planet);
            }

        }

        @FeignClient(name = "TEST", url = "http://localhost:" + TestFeignClient.PORT)
        @Component
        public interface TestFeignClient {

            int PORT = 9001;

            @RequestMapping(path = "/get")
            String get(@RequestParam("planet") String planet);

        }


    }
}
