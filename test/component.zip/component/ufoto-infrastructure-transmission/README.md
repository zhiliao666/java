# 快速开始
## 加依赖
```xml
        <dependency>
            <groupId>com.ufoto.infrastructure.transmission</groupId>
            <artifactId>ufoto-infrastructure-transmission</artifactId>
            <version>1.1.0.RELEASE</version>
        </dependency>
```

## 加配置
把需要透传的header配上即可  
若为prod或beta环境, 则有全局配置, 不需要加.
```text
ufoto.app.transmission.headers[0]=c
ufoto.app.transmission.headers[1]=uid
ufoto.app.transmission.headers[1]=request-id
```