package com.ufoto.cache;

import org.springframework.amqp.rabbit.core.RabbitTemplate;
import org.springframework.beans.factory.ObjectProvider;
import org.springframework.beans.factory.annotation.Qualifier;
import org.springframework.boot.autoconfigure.cache.CacheManagerCustomizer;
import org.springframework.boot.autoconfigure.cache.CacheManagerCustomizers;
import org.springframework.boot.autoconfigure.cache.CacheProperties;
import org.springframework.boot.autoconfigure.condition.ConditionalOnMissingBean;
import org.springframework.boot.context.properties.EnableConfigurationProperties;
import org.springframework.cache.CacheManager;
import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;
import org.springframework.context.annotation.Primary;
import org.springframework.core.env.Environment;
import org.springframework.core.io.ResourceLoader;
import org.springframework.data.redis.cache.RedisCacheConfiguration;
import org.springframework.data.redis.cache.RedisCacheManager;
import org.springframework.data.redis.connection.RedisConnectionFactory;
import org.springframework.data.redis.core.RedisTemplate;
import org.springframework.data.redis.serializer.JdkSerializationRedisSerializer;
import org.springframework.data.redis.serializer.RedisSerializationContext;
import org.springframework.data.redis.serializer.StringRedisSerializer;

import java.util.LinkedHashSet;
import java.util.List;

/**
 * <p>
 * Author     : Chan
 * CreateDate : 2019-05-11 01:04
 * Description:
 * </p>
 */
@Configuration
@EnableConfigurationProperties(UfotoCacheProperties.class)
public class UfotoAutoCacheConfig {

    @Bean
    @ConditionalOnMissingBean(UfotoCacheDistributedProducer.class)
    public UfotoCacheDistributedProducer ufotoCacheDistributedProducer(UfotoCacheProperties ufotoCacheProperties,
                                                                       @Qualifier("cacheRedisTemplate") RedisTemplate<Object, Object> redisTemplate,
                                                                       RabbitTemplate rabbitTemplate,
                                                                       Environment env) {
        return new UfotoCacheDistributedProducer(redisTemplate, rabbitTemplate, ufotoCacheProperties, env);
    }

    @Bean("ufotoCacheManager")
    @ConditionalOnMissingBean(UfotoCacheManager.class)
    public UfotoCacheManager ufotoCacheManager(UfotoCacheProperties ufotoCacheProperties,
                                               @Qualifier("cacheRedisTemplate") RedisTemplate<Object, Object> redisTemplate,
                                               UfotoCacheDistributedProducer ufotoCacheDistributedProducer) {
        return new UfotoCacheManager(ufotoCacheDistributedProducer, ufotoCacheProperties, redisTemplate);
    }

    @Bean("cacheRedisTemplate")
    @ConditionalOnMissingBean(name = "cacheRedisTemplate")
    public RedisTemplate<Object, Object> redisTemplate(RedisConnectionFactory redisConnectionFactory) {
        RedisTemplate<Object, Object> template = new RedisTemplate<>();
        template.setConnectionFactory(redisConnectionFactory);
        template.setKeySerializer(new StringRedisSerializer());
        template.setValueSerializer(new JdkSerializationRedisSerializer());
        template.afterPropertiesSet();
        return template;
    }

    @Bean
    @ConditionalOnMissingBean(CacheProperties.class)
    public CacheProperties cacheProperties() {
        return new CacheProperties();
    }

    @Bean
    public CacheController cacheController(@Qualifier("ufotoCacheManager") UfotoCacheManager ufotoCacheManager,
                                           UfotoCacheProperties ufotoCacheProperties,
                                           UfotoCacheDistributedProducer ufotoCacheDistributedProducer) {
        return new CacheController(ufotoCacheManager, ufotoCacheProperties, ufotoCacheDistributedProducer);
    }

    @Bean
    @ConditionalOnMissingBean
    public CacheManagerCustomizers cacheManagerCustomizers(
            ObjectProvider<List<CacheManagerCustomizer<?>>> customizers) {
        return new CacheManagerCustomizers(customizers.getIfAvailable());
    }

    @Primary
    @ConditionalOnMissingBean(RedisCacheManager.class)
    @Bean("redisCacheManager")
    public CacheManager redisCacheManager(RedisConnectionFactory factory,
                                          CacheProperties cacheProperties,
                                          ResourceLoader resourceLoader,
                                          CacheManagerCustomizers customizerInvoker) {
        RedisCacheManager.RedisCacheManagerBuilder builder = RedisCacheManager.builder(factory);
        // 配置序列化
        RedisCacheConfiguration config = RedisCacheConfiguration.defaultCacheConfig();
        config = config.serializeValuesWith(RedisSerializationContext.SerializationPair
                .fromSerializer(new JdkSerializationRedisSerializer(resourceLoader.getClassLoader())));
        CacheProperties.Redis redisProperties = cacheProperties.getRedis();
        if (redisProperties.getTimeToLive() != null) {
            config = config.entryTtl(redisProperties.getTimeToLive());
        }
        if (redisProperties.getKeyPrefix() != null) {
            config = config.prefixKeysWith(redisProperties.getKeyPrefix());
        }
        if (!redisProperties.isCacheNullValues()) {
            config = config.disableCachingNullValues();
        }
        if (!redisProperties.isUseKeyPrefix()) {
            config = config.disableKeyPrefix();
        }
        List<String> cacheNames = cacheProperties.getCacheNames();
        if (!cacheNames.isEmpty()) {
            builder.initialCacheNames(new LinkedHashSet<>(cacheNames));
        }
        return customizerInvoker.customize(RedisCacheManager.builder(factory).cacheDefaults(config).build());
    }
}
