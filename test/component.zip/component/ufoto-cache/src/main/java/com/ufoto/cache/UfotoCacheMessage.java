package com.ufoto.cache;

import lombok.Builder;
import lombok.Data;

import java.io.Serializable;

/**
 * <p>
 * Author     : Chan
 * CreateDate : 2019-05-15 13:06
 * Description:
 * </p>
 */
@Data
@Builder
public class UfotoCacheMessage implements Serializable {

    private String name;//prefix
    private Object key;//key
    private Object value;

    private CacheOperateType cacheOperateType;//CacheOperateType.EVICT;

    enum CacheOperateType {
        EVICT,
        PUT
    }

}
