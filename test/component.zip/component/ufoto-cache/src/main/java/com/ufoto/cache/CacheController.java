package com.ufoto.cache;

import org.springframework.cache.Cache;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.util.CollectionUtils;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.RestController;

import java.util.ArrayList;
import java.util.Collections;
import java.util.HashMap;
import java.util.Map;
import java.util.concurrent.ConcurrentHashMap;
import java.util.stream.Collectors;

@RestController
@RequestMapping("/cache")
public class CacheController {

    private final UfotoCacheManager ufotoCacheManager;
    private final UfotoCacheProperties ufotoCacheProperties;
    private final UfotoCacheDistributedProducer ufotoCacheDistributedProducer;

    public CacheController(UfotoCacheManager ufotoCacheManager,
                           UfotoCacheProperties ufotoCacheProperties,
                           UfotoCacheDistributedProducer ufotoCacheDistributedProducer) {
        this.ufotoCacheManager = ufotoCacheManager;
        this.ufotoCacheProperties = ufotoCacheProperties;
        this.ufotoCacheDistributedProducer = ufotoCacheDistributedProducer;
    }

    @RequestMapping("/stats")
    public ResponseEntity<Object> cacheStats(@RequestParam(required = false) String name) {
        final ConcurrentHashMap<String, Cache> cacheMap = ufotoCacheManager.getCacheMap();
        if (CollectionUtils.isEmpty(cacheMap)) {
            return new ResponseEntity<>(new HashMap<>(), HttpStatus.OK);
        }

        if (!org.springframework.util.StringUtils.isEmpty(name)) {
            final Cache cache = cacheMap.get(name);
            if (cache == null) {
                return new ResponseEntity<>(null, HttpStatus.OK);
            }
            ArrayList<CacheStatDto> list = new ArrayList<>();
            Collections.addAll(list, ufotoCache2Stats(cache));
            return new ResponseEntity<>(list, HttpStatus.OK);
        }
        return new ResponseEntity<>(cacheMap.values().stream().map(this::ufotoCache2Stats).collect(Collectors.toList()), HttpStatus.OK);
    }

    public CacheStatDto ufotoCache2Stats(Cache cache) {
        UfotoCache ufotoCache = (UfotoCache) cache;
        final com.github.benmanes.caffeine.cache.Cache<Object, Object> caffeineCache = ufotoCache.getCaffeineCache();
        return CacheStatDto.builder().key(ufotoCache.getName())
                .caffeineStats(CacheStatDto.UfotoCacheStats.builder().cacheStats(caffeineCache.stats()).estimatedSize(caffeineCache.estimatedSize()).build())
                .redisStats(CacheStatDto.UfotoCacheStats.builder().cacheStats(ufotoCache.getRedisStats()).estimatedSize(ufotoCache.estimatedSize()).build())
                .build();
    }

    /**
     * @param key    cache key
     * @param status 状态 0 获取value 1 清除cache 2 清除所有cache 3 清除local cache 和redis cache
     * @return
     */
    @RequestMapping("/operate")
    public ResponseEntity<Object> getCache(@RequestParam(required = false) String key,
                                           @RequestParam(defaultValue = "0", required = false) int status) {
        final ConcurrentHashMap<String, Cache> cacheMap = ufotoCacheManager.getCacheMap();
        if (CollectionUtils.isEmpty(cacheMap)) {
            return new ResponseEntity<>(null, HttpStatus.OK);
        }
        if (2 == status) {
            cacheMap.forEach((k, v) -> v.clear());
            return new ResponseEntity<>(true, HttpStatus.OK);
        }
        if (org.springframework.util.StringUtils.isEmpty(key)) return new ResponseEntity<>(null, HttpStatus.OK);
        Object result = null;
        for (Map.Entry<String, Cache> entry : cacheMap.entrySet()) {
            final String entryKey = entry.getKey();
            final Cache cache = entry.getValue();
            final String prefix = getPrefix(entryKey);
            if (key.startsWith(prefix)) {
                UfotoCache ufotoCache = (UfotoCache) cache;
                result = ufotoCache.get(key.replace(prefix, ""), () -> null);
                if (status == 1) {
                    ufotoCache.clearLocal(key.replace(prefix, ""));
                }
                if (status == 3) {
                    ufotoCache.evict(key.replace(prefix, ""));
                }
                break;
            }
        }
        return new ResponseEntity<>(result, HttpStatus.OK);
    }

    private String getPrefix(String cacheName) {
        final String cachePrefix = ufotoCacheProperties.getCachePrefix();
        if (!org.springframework.util.StringUtils.isEmpty(cachePrefix)) {
            return cachePrefix.concat(":").concat(cacheName).concat(":");
        }
        return cacheName;
    }

    @RequestMapping("/testProducer")
    public ResponseEntity<Boolean> testProducer(UfotoCacheMessage cacheMessage) {
        ufotoCacheDistributedProducer.publish(cacheMessage);
        return new ResponseEntity<>(true, HttpStatus.OK);
    }

}
