package com.ufoto.cache;

import com.github.benmanes.caffeine.cache.Caffeine;
import lombok.Data;
import org.springframework.boot.context.properties.ConfigurationProperties;

import java.util.HashMap;
import java.util.Map;

/**
 * <p>
 * Author     : Chan
 * CreateDate : 2019-05-14 19:48
 * Description:
 * </p>
 */
@Data
@ConfigurationProperties(prefix = "ufoto.cache")
public class UfotoCacheProperties {
    private static final int DEFAULT_INITIAL_CAPACITY = 16;
    private static final int DEFAULT_EXPIRATION = 60;//SECOND
    private static final int DEFAULT_REFRESH = 30;//SECOND
    private static final int DEFAULT_MAXIMUM_SIZE = 8000;
    private static final int DEFAULT_MAXIMUM_WEIGHT = 0;
    private static final LocalDistributed DEFAULT_LOCAL_DISTRIBUTED = LocalDistributed.rabbit;

    //本地缓存通信类型
    private LocalDistributed localDistributed = DEFAULT_LOCAL_DISTRIBUTED;
    private long rabbitExpire = 60000;

    //默认缓存时间
    private long defaultExpiration = DEFAULT_EXPIRATION;
    //可配置每个缓存的时间
    private Map<String, Long> expires = new HashMap<>();
    //是否允许二级缓存 默认为true. 如果使用[secondary]单独指定,只要有true则开启
    private boolean allowSecondary = true;
    //是否开始二级缓存--针对每个key设置
    private Map<String, Boolean> secondary = new HashMap<>();
    //redis pub/sub topic
    private String topic = "ufoto:cache:topic";
    //rabbit fanout exchange
    private String exchange = "sweetchat.fanout.local.cache";
    //统一前缀
    private String cachePrefix;
    //是否允许缓存空值
    private boolean allowNullValues = false;
    //是否允许统计信息
    private boolean allowStats = true;

    /**
     * 以下配置可参考{@link Caffeine}
     */
    //caffeine 缓存最大的key
    private long maximumSize = DEFAULT_MAXIMUM_SIZE;
    private long maximumWeight = DEFAULT_MAXIMUM_WEIGHT;
    //caffeine 初始化容量
    private int initialCapacity = DEFAULT_INITIAL_CAPACITY;
    //缓存刷新时间
    private long refresh = DEFAULT_REFRESH;
    //写入多久后失效
    private long expireAfterWrite = defaultExpiration;

    enum LocalDistributed {
        redis,
        rabbit
    }
}
