package com.ufoto.cache;

import lombok.extern.slf4j.Slf4j;
import org.springframework.amqp.core.*;
import org.springframework.beans.factory.annotation.Qualifier;
import org.springframework.boot.autoconfigure.AutoConfigureAfter;
import org.springframework.boot.autoconfigure.condition.ConditionalOnMissingBean;
import org.springframework.boot.autoconfigure.condition.ConditionalOnProperty;
import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;
import org.springframework.messaging.converter.MessageConverter;

import java.net.InetAddress;
import java.net.UnknownHostException;
import java.util.HashMap;
import java.util.Map;
import java.util.UUID;

/**
 * <p>
 * Author     : Chan
 * CreateDate : 2019-05-18 14:31
 * Description:
 * </p>
 */
@Slf4j
@Configuration
@ConditionalOnProperty(prefix = "ufoto.cache", name = "local-distributed", havingValue = "rabbit")
@AutoConfigureAfter(UfotoAutoCacheConfig.class)
public class UfotoCacheRabbitConfig {

    @Bean
    @ConditionalOnMissingBean(MessageConverter.class)
    public RabbitMessageConverter messageConverter() {
        return new RabbitMessageConverter();
    }

    @Bean("ufotoCacheFanoutExchange")
    public FanoutExchange ufotoCacheFanoutExchange(UfotoCacheProperties ufotoCacheProperties) {
        return new FanoutExchange(ufotoCacheProperties.getExchange());
    }

    @Bean("ufotoCacheQueue")
    public Queue ufotoCacheQueue(UfotoCacheProperties ufotoCacheProperties) {
        Map<String, Object> params = new HashMap<>();
        params.put("x-expires", ufotoCacheProperties.getRabbitExpire());
        return new Queue(getQueueNameByIp(), true, false, false, params);
    }

    @Bean
    public Binding ufotoCacheBinding(@Qualifier("ufotoCacheQueue") Queue queue,
                                     @Qualifier("ufotoCacheFanoutExchange") FanoutExchange exchange) {
        return BindingBuilder.bind(queue).to(exchange);
    }

    @Bean
    public UfotoCacheRabbitLister ufotoCacheRabbitLister(UfotoCacheManager ufotoCacheManager) {
        return new UfotoCacheRabbitLister(ufotoCacheManager);
    }

    private String getQueueNameByIp() {
        String queueName;
        try {
            InetAddress addr = InetAddress.getLocalHost();
            String hostname = addr.getHostName();
            String hostAddress = addr.getHostAddress();
            queueName = hostname + "_" + hostAddress;
        } catch (UnknownHostException e) {
            log.error("获取主机ip异常", e);
            queueName = UUID.randomUUID().toString();
        }
        queueName = "Q_ufoto_cache" + queueName;
        return queueName;
    }

}
