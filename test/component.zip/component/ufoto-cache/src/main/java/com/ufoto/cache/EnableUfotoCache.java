package com.ufoto.cache;

import org.springframework.cache.annotation.EnableCaching;
import org.springframework.context.annotation.Import;

import java.lang.annotation.*;

/**
 * <p>
 * Author     : Chan
 * CreateDate : 2019-06-01 10:25
 * Description: Ufoto Cache 入口
 * </p>
 */
@Target(ElementType.TYPE)
@Retention(RetentionPolicy.RUNTIME)
@Documented
@EnableCaching
@Import({
        UfotoAutoCacheConfig.class,
        UfotoCacheRabbitConfig.class,
        UfotoCacheRedisConfig.class
})
public @interface EnableUfotoCache {

}
