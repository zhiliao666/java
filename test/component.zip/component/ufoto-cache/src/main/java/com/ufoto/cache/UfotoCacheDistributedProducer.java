package com.ufoto.cache;

import lombok.extern.slf4j.Slf4j;
import org.springframework.amqp.core.MessageProperties;
import org.springframework.amqp.core.MessagePropertiesBuilder;
import org.springframework.amqp.rabbit.core.RabbitTemplate;
import org.springframework.core.env.Environment;
import org.springframework.data.redis.core.RedisTemplate;

/**
 * <p>
 * Author     : Chan
 * CreateDate : 2019-05-18 13:50
 * Description: 本地缓存分布式 通知其他机器本地缓存
 * </p>
 */
@Slf4j
public class UfotoCacheDistributedProducer {
    private final RedisTemplate<Object, Object> redisTemplate;
    private final RabbitTemplate rabbitTemplate;
    private final UfotoCacheProperties ufotoCacheProperties;
    private final Environment env;

    public UfotoCacheDistributedProducer(RedisTemplate<Object, Object> redisTemplate,
                                         RabbitTemplate rabbitTemplate,
                                         UfotoCacheProperties ufotoCacheProperties,
                                         Environment env) {
        this.redisTemplate = redisTemplate;
        this.rabbitTemplate = rabbitTemplate;
        this.ufotoCacheProperties = ufotoCacheProperties;
        this.env = env;
    }


    /**
     * 发布消息
     *
     * @param cacheMessage
     */
    public void publish(UfotoCacheMessage cacheMessage) {
        try {
            log.debug("publishMsg: {}", cacheMessage);
            if (!env.getProperty("sync.local.cache", Boolean.class, true)) {
                return;
            }
            final UfotoCacheProperties.LocalDistributed localDistributed = ufotoCacheProperties.getLocalDistributed();
            switch (localDistributed) {
                case rabbit:
                    rabbitTemplate.send(ufotoCacheProperties.getExchange(), "",
                            rabbitTemplate.getMessageConverter().toMessage(
                                    cacheMessage,
                                    MessagePropertiesBuilder.fromProperties(new MessageProperties()).setContentType(MessageProperties.CONTENT_TYPE_SERIALIZED_OBJECT).build()
                            )
                    );
                    break;
                case redis:
                    redisTemplate.convertAndSend(ufotoCacheProperties.getTopic(), cacheMessage);
                    break;
                default:
                    log.warn("localDistributed wrong type...,msg:{}", cacheMessage);
            }
        } catch (Exception e) {
            log.error(e.getMessage(), e);
        }
    }
}
