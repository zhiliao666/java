package com.ufoto.cache;

import com.github.benmanes.caffeine.cache.Cache;
import com.github.benmanes.caffeine.cache.Caffeine;
import com.github.benmanes.caffeine.cache.stats.CacheStats;
import com.github.benmanes.caffeine.cache.stats.ConcurrentStatsCounter;
import lombok.extern.slf4j.Slf4j;
import org.springframework.cache.support.AbstractValueAdaptingCache;
import org.springframework.cache.support.NullValue;
import org.springframework.data.redis.core.RedisTemplate;
import org.springframework.util.CollectionUtils;
import org.springframework.util.SerializationUtils;
import org.springframework.util.StringUtils;

import java.time.Duration;
import java.util.Map;
import java.util.Objects;
import java.util.Set;
import java.util.concurrent.Callable;
import java.util.concurrent.TimeUnit;
import java.util.function.Function;

/**
 * <p>
 * Author     : Chan
 * CreateDate : 2019-05-14 19:42
 * Description:
 * </p>
 */
@Slf4j
@SuppressWarnings("all")
public class UfotoCache extends AbstractValueAdaptingCache {

    private final Cache<Object, Object> caffeineCache;
    private final RedisTemplate<Object, Object> redisTemplate;
    private final String name;
    private final UfotoCacheProperties ufotoCacheProperties;
    private final UfotoCacheDistributedProducer ufotoCacheDistributedProducer;
    private ConcurrentStatsCounter redisStatsCounter;
    private boolean isSecondary = false;

    protected UfotoCache(
            RedisTemplate<Object, Object> redisTemplate,
            String name,
            UfotoCacheProperties ufotoCacheProperties,
            UfotoCacheDistributedProducer ufotoCacheDistributedProducer,
            Caffeine<Object, Object> caffeine) {
        super(ufotoCacheProperties.isAllowNullValues());
        this.redisTemplate = redisTemplate;
        this.name = name;
        this.ufotoCacheProperties = ufotoCacheProperties;
        this.ufotoCacheDistributedProducer = ufotoCacheDistributedProducer;
        if (caffeine == null) {
            this.caffeineCache = createCaffeineCache(name);
        } else {
            this.caffeineCache = caffeine.build();
        }
        final Map<String, Boolean> secondary = ufotoCacheProperties.getSecondary();
        //是否开启二级缓存
        isSecondary = ufotoCacheProperties.isAllowSecondary();
        if (!CollectionUtils.isEmpty(secondary)) {
            final Boolean isSecondary = secondary.get(name);
            this.isSecondary = isSecondary == null || isSecondary;
        }
        if (ufotoCacheProperties.isAllowStats()) {
            //开启redis的统计
            redisStatsCounter = new ConcurrentStatsCounter();
        }
    }

    @Override
    protected Object lookup(Object key) {
        final Object cacheKey = getKey(key);
        Object value = caffeineCache.getIfPresent(cacheKey);
        if (value != null || !isSecondary) {//如果为空 并且[isSecondary] 为false  那么直接返回
            return value;
        }
        try {
            value = redisTemplate.opsForValue().get(cacheKey);
            if (value != null) {
                if (ufotoCacheProperties.isAllowStats()) {
                    redisStatsCounter.recordHits(1);
                }
                caffeineCache.put(cacheKey, value);
            } else {
                if (ufotoCacheProperties.isAllowStats()) {
                    redisStatsCounter.recordMisses(1);
                }
            }
            return SerializationUtils.deserialize(SerializationUtils.serialize(value));
        } catch (Exception e) {
            log.error(e.getMessage(), e);
            return null;
        }
    }

    @Override
    public String getName() {
        return this.name;
    }

    @Override
    public Object getNativeCache() {
        return this;
    }

    @Override
    public <T> T get(Object key, Callable<T> valueLoader) {
        Object value = lookup(key);
        if (value != null) {
            return (T) value;
        }
        try {
            return valueLoader.call();
        } catch (Exception e) {
            throw new ValueRetrievalException(getKey(key), valueLoader, e);
        }
    }

    @Override
    public void put(Object key, Object value) {
        if (!isAllowNullValues() && value == null) {
            log.warn(String.format(
                    "Cache '%s' does not allow 'null' values. Avoid storing null via '@Cacheable(unless=\"#result == null\")' or configure UfotoCache to allow 'null'.",
                    name));
            return;
        }
        final Object cacheKey = getKey(key);
        value = wrapValue(value);
        if (isSecondary) {
            final long expire = getExpire();
            try {
                if (expire > 0) {
                    redisTemplate.opsForValue().set(cacheKey, value, expire, TimeUnit.SECONDS);
                } else {
                    redisTemplate.opsForValue().set(cacheKey, value);
                }
            } catch (Exception e) {
                log.error(e.getMessage(), e);
            }
        }
        caffeineCache.put(cacheKey, value);
        publish(UfotoCacheMessage.builder().cacheOperateType(UfotoCacheMessage.CacheOperateType.PUT).key(key).name(this.name).value(value).build());
    }

    @Override
    public ValueWrapper putIfAbsent(Object key, Object value) {
        if (!isAllowNullValues() && value == null) {
            return get(key);
        }
        final Object cacheKey = getKey(key);
        value = wrapValue(value);
        if (isSecondary) {
            final long expire = getExpire();
            Boolean ifAbsent = false;
            try {
                if (expire > 0) {
                    ifAbsent = redisTemplate.opsForValue().setIfAbsent(cacheKey, value, getExpire(), TimeUnit.SECONDS);
                } else {
                    ifAbsent = redisTemplate.opsForValue().setIfAbsent(cacheKey, value);
                }
            } catch (Exception e) {
                log.error(e.getMessage(), e);
            }

            if (ifAbsent != null && ifAbsent) {
                //redis设置成功
                caffeineCache.put(cacheKey, value);
                publish(UfotoCacheMessage.builder().cacheOperateType(UfotoCacheMessage.CacheOperateType.PUT).key(key).name(this.name).value(value).build());
            } else {
                return null;
            }
        } else {
            Object finalValue = value;
            Object o = caffeineCache.get(cacheKey, new Function<Object, Object>() {
                @Override
                public Object apply(Object o) {
                    return finalValue;
                }
            });
            if (o != null && o.equals(finalValue)) {
                publish(UfotoCacheMessage.builder().cacheOperateType(UfotoCacheMessage.CacheOperateType.PUT).key(key).name(this.name).value(value).build());
            }
            return toValueWrapper(o);
        }
        return toValueWrapper(value);
    }

    @Override
    public void evict(Object key) {
        final Object cacheKey = getKey(key);
        try {
            if (isSecondary) {
                synchronized (this.name) {
                    final Boolean delete = redisTemplate.delete(cacheKey);
                    if (delete != null && delete) {
                        if (ufotoCacheProperties.isAllowStats()) {
                            redisStatsCounter.recordEviction();
                        }
                    }
                }
            }
            publish(UfotoCacheMessage.builder().cacheOperateType(UfotoCacheMessage.CacheOperateType.EVICT).name(this.name).key(key).build());
            caffeineCache.invalidate(cacheKey);
        } catch (Exception e) {
            log.error(e.getMessage(), e);
        }
    }

    //通知本地缓存删除缓存
    private void publish(UfotoCacheMessage message) {
        ufotoCacheDistributedProducer.publish(message);
    }

    @Override
    public void clear() {
        try {
            if (isSecondary) {
                synchronized (this.name) {
                    final Set<Object> keys = redisTemplate.keys(getPrefixKey().concat("*"));
                    if (!CollectionUtils.isEmpty(keys)) {
                        final Long delete = redisTemplate.delete(keys);
                        if (Objects.equals(delete.intValue(), keys.size())) {
                            //delete success
                            if (ufotoCacheProperties.isAllowStats()) {
                                redisStatsCounter.recordEviction(keys.size());
                            }
                        }
                    }
                }
            }
            caffeineCache.invalidateAll();
            publish(UfotoCacheMessage.builder().cacheOperateType(UfotoCacheMessage.CacheOperateType.EVICT).name(this.name).build());
        } catch (Exception e) {
            log.error(e.getMessage(), e);
        }
    }

    private Object getKey(Object key) {
        return getPrefixKey().concat(":").concat(String.valueOf(key));
    }


    private String getPrefixKey() {
        final String cachePrefix = ufotoCacheProperties.getCachePrefix();
        if (!StringUtils.isEmpty(cachePrefix)) {
            return cachePrefix.concat(":").concat(this.name);
        }
        return this.name;
    }

    private long getExpire() {
        Long cacheNameExpire = ufotoCacheProperties.getExpires().get(this.name);
        final long expire = cacheNameExpire == null ? ufotoCacheProperties.getDefaultExpiration() : cacheNameExpire;
        if (expire < ufotoCacheProperties.getExpireAfterWrite()) {
            //如果本地缓存时间大于redis时间,redis时间与本地一致
            return ufotoCacheProperties.getExpireAfterWrite();
        }
        return expire;
    }

    public Cache<Object, Object> getCaffeineCache() {
        return caffeineCache;
    }

    public void clearLocal(Object key) {
        log.debug("key:{}", key);
        if (key == null) {
            caffeineCache.invalidateAll();
        } else {
            caffeineCache.invalidate(getKey(key));
        }
    }

    public void putLocal(Object key, Object value) {
        caffeineCache.put(getKey(key), value);
    }

    private Object wrapValue(Object value) {
        if (isAllowNullValues() && value == null) {
            return NullValue.INSTANCE;
        }
        return value;
    }

    /**
     * retrieve redis stats counter
     *
     * @return
     */
    public CacheStats getRedisStats() {
        if (ufotoCacheProperties.isAllowStats()) {
            return redisStatsCounter.snapshot();
        }
        return CacheStats.empty();
    }

    public long estimatedSize() {
        final Set<Object> keys = redisTemplate.keys(getPrefixKey().concat("*"));
        return keys.size();
    }

    private com.github.benmanes.caffeine.cache.Cache<Object, Object> createCaffeineCache(String name) {
        //默认caffeine缓存时间为写入失效时间
        long expire = ufotoCacheProperties.getExpireAfterWrite();
        //如果指定了缓存时间
        final Map<String, Long> expires = ufotoCacheProperties.getExpires();
        final Long exp = expires.get(name);
        if (exp != null) {
            expire = exp;
        }
        final Caffeine<Object, Object> caffeine = Caffeine.newBuilder()
                .maximumSize(ufotoCacheProperties.getMaximumSize())
                .initialCapacity(ufotoCacheProperties.getInitialCapacity());
        if (ufotoCacheProperties.isAllowStats()) {
            caffeine.recordStats();
        }
        return caffeine.expireAfterWrite(Duration.ofSeconds(expire)).build();
    }
}
