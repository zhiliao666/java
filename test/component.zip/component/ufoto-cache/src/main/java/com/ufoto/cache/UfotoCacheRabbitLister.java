package com.ufoto.cache;

import com.rabbitmq.client.Channel;
import com.ufoto.cache.UfotoCacheMessage.CacheOperateType;
import lombok.extern.slf4j.Slf4j;
import org.springframework.amqp.rabbit.annotation.RabbitListener;
import org.springframework.amqp.support.AmqpHeaders;
import org.springframework.messaging.handler.annotation.Header;
import org.springframework.messaging.handler.annotation.Payload;

@Slf4j
public class UfotoCacheRabbitLister {

    private final UfotoCacheManager ufotoCacheManager;

    UfotoCacheRabbitLister(UfotoCacheManager ufotoCacheManager) {
        this.ufotoCacheManager = ufotoCacheManager;
    }

    @RabbitListener(queues = "#{ufotoCacheQueue.name}")
    public void onMessage(@Payload UfotoCacheMessage ufotoCacheMessage,
                          Channel channel,
                          @Header(AmqpHeaders.DELIVERY_TAG) long deliveryTag) {
        log.debug("start handle message....");
        try {
            log.debug("rabbitMessage->message:{}", ufotoCacheMessage);
            CacheOperateType cacheOperateType = ufotoCacheMessage.getCacheOperateType();
            if (cacheOperateType == null) {
                cacheOperateType = CacheOperateType.EVICT;
            }
            switch (cacheOperateType) {
                case EVICT:
                    ufotoCacheManager.clearLocal(ufotoCacheMessage.getName(), ufotoCacheMessage.getKey());
                    break;
                case PUT:
                    ufotoCacheManager.putLocal(ufotoCacheMessage.getName(), ufotoCacheMessage.getKey(), ufotoCacheMessage.getValue());
                    break;
                default:
                    throw new RuntimeException("illegal cacheOperationType of (EVICT/PUT)");
            }

        } catch (Exception e) {
            log.error(e.getMessage(), e);
        } finally {
            try {
                channel.basicAck(deliveryTag, false);
            } catch (Exception e) {
                log.error(e.getMessage(), e);
            }
        }
    }
}
