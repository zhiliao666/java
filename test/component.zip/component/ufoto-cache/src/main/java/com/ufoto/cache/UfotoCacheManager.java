package com.ufoto.cache;

import com.github.benmanes.caffeine.cache.Caffeine;
import lombok.extern.slf4j.Slf4j;
import org.springframework.cache.Cache;
import org.springframework.cache.support.AbstractCacheManager;
import org.springframework.data.redis.core.RedisTemplate;
import org.springframework.util.CollectionUtils;

import java.util.ArrayList;
import java.util.Collection;
import java.util.concurrent.ConcurrentHashMap;

/**
 * <p>
 * Author     : Chan
 * CreateDate : 2019-05-14 19:23
 * Description:
 * </p>
 */
@Slf4j
public class UfotoCacheManager extends AbstractCacheManager {

    private final ConcurrentHashMap<String, Cache> cacheMap = new ConcurrentHashMap<>();
    private final UfotoCacheDistributedProducer ufotoCacheDistributedProducer;
    private final UfotoCacheProperties ufotoCacheProperties;
    private final RedisTemplate<Object, Object> redisTemplate;
    private Caffeine<Object, Object> caffeine;

    public UfotoCacheManager(UfotoCacheDistributedProducer ufotoCacheDistributedProducer,
                             UfotoCacheProperties ufotoCacheProperties,
                             RedisTemplate<Object, Object> redisTemplate) {
        this.ufotoCacheDistributedProducer = ufotoCacheDistributedProducer;
        this.ufotoCacheProperties = ufotoCacheProperties;
        this.redisTemplate = redisTemplate;
    }

    public UfotoCacheManager(UfotoCacheDistributedProducer ufotoCacheDistributedProducer,
                             UfotoCacheProperties ufotoCacheProperties,
                             RedisTemplate<Object, Object> redisTemplate,
                             Caffeine<Object, Object> caffeine) {
        this.ufotoCacheDistributedProducer = ufotoCacheDistributedProducer;
        this.ufotoCacheProperties = ufotoCacheProperties;
        this.redisTemplate = redisTemplate;
        this.caffeine = caffeine;
    }

    @Override
    public Cache getCache(String name) {
        name = getCacheName(name);
        Cache cache = this.cacheMap.get(name);
        if (cache != null) {
            return cache;
        } else {
            synchronized (this.cacheMap) {
                cache = this.cacheMap.get(name);
                if (cache == null) {
                    cache = getMissingCache(name);
                    if (cache != null) {
                        cache = decorateCache(cache);
                        this.cacheMap.putIfAbsent(name, cache);
                    }
                }
                return cache;
            }
        }
    }

    @Override
    protected Cache getMissingCache(String name) {
        name = getCacheName(name);
        return new UfotoCache(
                redisTemplate,
                name,
                ufotoCacheProperties,
                ufotoCacheDistributedProducer,
                caffeine);
    }

    @Override
    protected Collection<? extends Cache> loadCaches() {
        if (CollectionUtils.isEmpty(cacheMap)) return new ArrayList<>();
        return cacheMap.values();
    }

    private String getCacheName(String name) {
        return name;
    }


    public void clearLocal(String cacheName, Object key) {
        log.debug("cacheName:{},key:{}", cacheName, key);
        Cache cache = cacheMap.get(cacheName);
        if (cache == null) return;
        UfotoCache ufotoCache = (UfotoCache) cache;
        ufotoCache.clearLocal(key);
    }

    public ConcurrentHashMap<String, Cache> getCacheMap() {
        return cacheMap;
    }

    public void putLocal(String name, Object key, Object value) {
        log.debug("cacheName:{},key:{},value:{}", name, key, value);
        Cache cache = cacheMap.get(name);
        if (cache == null) {
            return;
        }
        UfotoCache ufotoCache = (UfotoCache) cache;
        ufotoCache.putLocal(key, value);
    }
}
