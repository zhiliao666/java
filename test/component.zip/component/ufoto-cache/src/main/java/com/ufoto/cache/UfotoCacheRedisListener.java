package com.ufoto.cache;

import lombok.extern.slf4j.Slf4j;
import org.springframework.beans.factory.annotation.Qualifier;
import org.springframework.data.redis.connection.Message;
import org.springframework.data.redis.connection.MessageListener;
import org.springframework.data.redis.core.RedisTemplate;

/**
 * <p>
 * Author     : Chan
 * CreateDate : 2019-05-15 13:03
 * Description:
 * </p>
 */
@Slf4j
public class UfotoCacheRedisListener implements MessageListener {

    private final UfotoCacheManager ufotoCacheManager;
    private final UfotoCacheProperties ufotoCacheProperties;
    private final RedisTemplate<Object, Object> redisTemplate;

    public UfotoCacheRedisListener(UfotoCacheManager ufotoCacheManager,
                                   UfotoCacheProperties ufotoCacheProperties,
                                   @Qualifier("cacheRedisTemplate") RedisTemplate<Object, Object> redisTemplate) {
        this.ufotoCacheManager = ufotoCacheManager;
        this.ufotoCacheProperties = ufotoCacheProperties;
        this.redisTemplate = redisTemplate;
    }

    @Override
    public void onMessage(Message message, byte[] pattern) {
        log.debug("start handle message....");
        final byte[] body = message.getBody();
        try {
            UfotoCacheMessage cacheMessage = (UfotoCacheMessage) redisTemplate.getValueSerializer().deserialize(body);
            if (cacheMessage == null) return;
            log.debug("redisMessage->topic:{},message:{}", ufotoCacheProperties.getTopic(), cacheMessage);
            ufotoCacheManager.clearLocal(cacheMessage.getName(), cacheMessage.getKey());
        } catch (Exception e) {
            log.error(e.getMessage(), e);
        }
    }
}
