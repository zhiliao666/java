package com.ufoto.cache;

import com.github.benmanes.caffeine.cache.stats.CacheStats;
import lombok.Builder;
import lombok.Data;

import java.io.Serializable;

/**
 * <p>
 * Author     : Chan
 * CreateDate : 2019-05-15 14:31
 * Description:
 * </p>
 */
@Builder
@Data
public class CacheStatDto implements Serializable {
    private String key;

    private UfotoCacheStats caffeineStats;
    private UfotoCacheStats redisStats;

    @Builder
    public static class UfotoCacheStats {
        private CacheStats cacheStats;
        private long estimatedSize;

        public long getEstimatedSize() {
            return this.estimatedSize;
        }

        public long getHitCount() {
            return cacheStats.hitCount();
        }

        public long getMissCount() {
            return cacheStats.missCount();
        }

        public long getLoadSuccessCount() {
            return cacheStats.loadSuccessCount();
        }

        public long getLoadFailureCount() {
            return cacheStats.loadFailureCount();
        }

        public long getTotalLoadTime() {
            return cacheStats.totalLoadTime();
        }

        public long getEvictionCount() {
            return cacheStats.evictionCount();
        }

        public long getEvictionWeight() {
            return cacheStats.evictionWeight();
        }

        public double getHitRate() {
            long requestCount = cacheStats.requestCount();
            return (requestCount == 0) ? 1.0 : (double) getHitCount() / requestCount;
        }

        public double getMissRate() {
            long requestCount = cacheStats.requestCount();
            return (requestCount == 0) ? 0.0 : (double) getMissCount() / requestCount;
        }

    }
}
