## 引入依赖
```
<dependency>
    <groupId>com.ufoto</groupId>
    <artifactId>ufoto-cache</artifactId>
    <version>0.0.7-RELEASE</version>
</dependency>
```

## 使用步骤
1. 添加`@EnableUfotoCache`注解
2. 默认使用`ufotoCacheManager`,如有必要,可在项目中自定义`CacheManager`
3. 相关配置可参考`UfotoCacheProperties`

可以通过下面的接口查看统计信息,其中name是不必要字段,如果传入,则必须是`cache`为定义的cacheNames
```
GET /cache/stats?name=xxx
```

### change log
1. 缓存同步更新
