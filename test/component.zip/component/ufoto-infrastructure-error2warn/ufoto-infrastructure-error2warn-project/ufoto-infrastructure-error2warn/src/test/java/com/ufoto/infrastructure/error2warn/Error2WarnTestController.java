package com.ufoto.infrastructure.error2warn;

import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.RestController;

import java.net.SocketTimeoutException;

/**
 * @author Luo Bao Ding
 * @since 2019/4/15
 */
@RestController
public class Error2WarnTestController {

    public Error2WarnTestController() {

    }

    @RequestMapping("/socketTimeoutException")
    public String socketTimeoutException() throws SocketTimeoutException {
        throw new SocketTimeoutException();
    }

}
