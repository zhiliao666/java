package com.ufoto.infrastructure.error2warn;

import org.junit.Test;
import org.junit.runner.RunWith;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.SpringBootConfiguration;
import org.springframework.boot.test.autoconfigure.web.servlet.WebMvcTest;
import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Import;
import org.springframework.http.MediaType;
import org.springframework.test.context.junit4.SpringRunner;
import org.springframework.test.web.servlet.MockMvc;

import static org.hamcrest.core.Is.is;
import static org.springframework.test.web.servlet.request.MockMvcRequestBuilders.get;
import static org.springframework.test.web.servlet.result.MockMvcResultMatchers.*;

/**
 * @author Luo Bao Ding
 * @since 2019/4/16
 */
@RunWith(SpringRunner.class)
@WebMvcTest(Error2WarnTestController.class)
public class IntegrationTest {

    @Autowired
    private MockMvc mvc;

    @SpringBootConfiguration
    @Import(Error2WarnAutoConfiguration.class)
    static class TestAppConfiguration {

        @Bean
        public Error2WarnTestController error2WarnTestController() {
            return new Error2WarnTestController();
        }
    }


    @Test
    public void handleSocketTimeoutException() throws Exception {

        mvc.perform(get("/socketTimeoutException").contentType(MediaType.APPLICATION_JSON))
                .andExpect(status().is4xxClientError())
                .andExpect(content().contentTypeCompatibleWith(MediaType.APPLICATION_JSON))
                .andExpect(jsonPath("$.c", is(500)))
        ;

    }


}
