package com.ufoto.infrastructure.error2warn;

import org.assertj.core.api.Assertions;
import org.junit.Assert;
import org.junit.Test;
import org.springframework.boot.autoconfigure.AutoConfigurations;
import org.springframework.boot.autoconfigure.logging.ConditionEvaluationReportLoggingListener;
import org.springframework.boot.env.YamlPropertySourceLoader;
import org.springframework.boot.logging.LogLevel;
import org.springframework.boot.origin.OriginTrackedValue;
import org.springframework.boot.test.context.runner.ApplicationContextRunner;
import org.springframework.core.env.PropertySource;
import org.springframework.core.io.ClassPathResource;

import java.io.IOException;
import java.util.List;
import java.util.Map;

/**
 * @author Luo Bao Ding
 * @since 2019/4/16
 */
public class Error2WarnAutoConfigurationTest {
    private ApplicationContextRunner contextRunner = new ApplicationContextRunner()
            .withInitializer(new ConditionEvaluationReportLoggingListener(LogLevel.INFO))
            .withConfiguration(AutoConfigurations.of(Error2WarnAutoConfiguration.class));

    @Test
    public void normalBeanExistence() throws IOException {
        String yaml = "application.yaml";
        ClassPathResource resource = new ClassPathResource(yaml);
        YamlPropertySourceLoader loader = new YamlPropertySourceLoader();
        List<PropertySource<?>> list = loader.load(yaml, resource);
        Map<String, OriginTrackedValue> propsMap = (Map<String, OriginTrackedValue>) list.get(0).getSource();
        String[] propsArray = propsMap.entrySet().stream().map(entry -> "" + entry.getKey() + "=" + entry.getValue().getValue())
                .toArray(String[]::new);

        contextRunner.withPropertyValues(propsArray).run(context -> {
            Assertions.assertThat(context).hasSingleBean(Error2WarnProperties.class);
            Error2WarnProperties properties = context.getBean(Error2WarnProperties.class);

            Assert.assertTrue(properties.getExceptions().size() > 0);
            Assertions.assertThat(context).hasSingleBean(Error2WarnExceptionHandler.class);
        });

    }
}