package com.ufoto.infrastructure.error2warn;

import java.util.ArrayList;
import java.util.List;

/**
 * @author Luo Bao Ding
 * @since 2019/4/15
 */
public class ExceptionUtil {

    public static Throwable getRootCause(final Throwable throwable) {
        final List<Throwable> list = getThrowableList(throwable);
        return list.size() < 2 ? null : list.get(list.size() - 1);
    }

    public static List<Throwable> getThrowableList(Throwable throwable) {
        final List<Throwable> list = new ArrayList<>();
        while (throwable != null && !list.contains(throwable)) {
            list.add(throwable);
            throwable = throwable.getCause();
        }
        return list;
    }
}
