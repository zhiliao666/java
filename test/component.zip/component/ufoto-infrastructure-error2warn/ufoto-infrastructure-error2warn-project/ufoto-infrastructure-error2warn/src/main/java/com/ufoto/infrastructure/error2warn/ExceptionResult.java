package com.ufoto.infrastructure.error2warn;

import java.io.Serializable;

/**
 * @author Luo Bao Ding
 * @since 2019/4/15
 */
public class ExceptionResult implements Serializable {
    private int c;

    private String m;

    public ExceptionResult() {
    }

    public ExceptionResult(int c, String m) {
        this.c = c;
        this.m = m;
    }

    public int getC() {
        return c;
    }

    public void setC(int c) {
        this.c = c;
    }

    public String getM() {
        return m;
    }

    public void setM(String m) {
        this.m = m;
    }
}
