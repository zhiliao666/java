package com.ufoto.infrastructure.error2warn;

import org.springframework.boot.context.properties.EnableConfigurationProperties;
import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;

/**
 * @author Luo Bao Ding
 * @since 2019/4/15
 */
@Configuration
@EnableConfigurationProperties(Error2WarnProperties.class)
public class Error2WarnAutoConfiguration {

    @Bean
    public Error2WarnExceptionHandler error2WarnExceptionHandler(Error2WarnProperties error2WarnProperties) {
        return new Error2WarnExceptionHandler(error2WarnProperties);
    }
}
