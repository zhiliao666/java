package com.ufoto.infrastructure.error2warn;

import org.slf4j.LoggerFactory;
import org.springframework.core.Ordered;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.util.StringUtils;
import org.springframework.web.bind.annotation.ControllerAdvice;
import org.springframework.web.bind.annotation.ExceptionHandler;

import javax.servlet.http.HttpServletRequest;
import java.util.Set;
import java.util.StringJoiner;

/**
 * @author Luo Bao Ding
 * @since 2019/4/15
 */
@ControllerAdvice
public class Error2WarnExceptionHandler implements Ordered {
    private static final org.slf4j.Logger LOGGER = LoggerFactory.getLogger(Error2WarnExceptionHandler.class);
    public static final int BIZ_CODE = 500;

    private final Error2WarnProperties error2WarnProperties;

    public Error2WarnExceptionHandler(Error2WarnProperties error2WarnProperties) {
        this.error2WarnProperties = error2WarnProperties;
    }

    /**
     * hit : the caller handled any exception thrown by this method
     *
     * <p>
     * see:  org.springframework.web.servlet.mvc.method.annotation.ExceptionHandlerExceptionResolver
     * #doResolveHandlerMethodException(javax.servlet.http.HttpServletRequest, javax.servlet.http.HttpServletResponse, org.springframework.web.method.HandlerMethod, java.lang.Exception)
     * </p>
     */
    @ExceptionHandler(Exception.class)
    public ResponseEntity<ExceptionResult> exceptionHandle(Exception exception, HttpServletRequest request) throws Exception {
        Set<String> exceptions = error2WarnProperties.getExceptions();
        if (exceptions.contains(exception.getClass().getName()) || isContainsRootCause(exception, exceptions)) {
            String message = exception.toString();

            if (LOGGER.isWarnEnabled()) {
                String method = request.getMethod();
                String contentType = request.getContentType();
                if (StringUtils.hasText(contentType)) {
                    int index = contentType.indexOf(";");
                    if (index > -1) {
                        contentType = contentType.substring(0, index);
                    }

                } else {
                    contentType = "-";
                }
                String requestURI = request.getRequestURI();
                String queryString = request.getQueryString();
                String protocol = request.getProtocol();
                queryString = StringUtils.hasText(queryString) ? queryString : "-";
                StringJoiner joiner = new StringJoiner(" ");
                joiner.add(method);
                joiner.add(requestURI);
                joiner.add(queryString);
                joiner.add(protocol);
                joiner.add(contentType);
                joiner.add(exception.toString());

                LOGGER.warn(joiner.toString());
            }

            ExceptionResult result = new ExceptionResult(BIZ_CODE, message);
            return new ResponseEntity<>(result, HttpStatus.REQUEST_TIMEOUT);
        }
        throw exception;
    }

    @Override
    public int getOrder() {
        return Ordered.LOWEST_PRECEDENCE - 10;
    }

    private boolean isContainsRootCause(Exception exception, Set<String> exceptions) {
        Throwable rootCause = ExceptionUtil.getRootCause(exception);

        return rootCause != null && exceptions.contains(
                rootCause.getClass().getName());
    }


}
