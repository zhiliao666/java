package com.ufoto.infrastructure.error2warn;

import org.springframework.boot.context.properties.ConfigurationProperties;

import java.util.HashSet;
import java.util.Set;

/**
 * @author Luo Bao Ding
 * @since 2019/4/15
 */
@ConfigurationProperties("app.error2warn")
public class Error2WarnProperties {

    private Set<String> exceptions = new HashSet<>();

    public Set<String> getExceptions() {
        return exceptions;
    }

}
