package com.ufoto.logging.kafka.keying;

/**
 * Evenly distributes all written log messages over all available kafka partitions.
 * This strategy can lead to unexpected read orders on clients.
 * @since 0.0.1
 */
public class NoKeyKeyingStrategy<E> implements KeyingStrategy<E> {

    @Override
    public byte[] createKey(E e) {
        return null;
    }
}
