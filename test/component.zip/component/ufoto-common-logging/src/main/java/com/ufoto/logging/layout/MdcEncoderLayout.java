package com.ufoto.logging.layout;
import java.util.Map;

import com.ufoto.logging.util.IpUtil;

import ch.qos.logback.classic.spi.ILoggingEvent;
import ch.qos.logback.core.CoreConstants;
import ch.qos.logback.core.LayoutBase;
import ch.qos.logback.core.util.CachingDateFormatter;

public class MdcEncoderLayout extends LayoutBase<ILoggingEvent> {
	
	final CachingDateFormatter cachingDateFormatter = new CachingDateFormatter("yyyy-MM-dd HH:mm:ss.SSS");
	
	/**
	 * %d{-} %host %topic %msg%n
	 * %d 时间 默认格式化为yyyy-MM-dd HH:mm:ss.SSS %d{-} 时间无需格式化打印毫秒时间
	 * %host 主机ip
	 * %topic 日志主题
	 * %msg 具体日志内容
	 * %n 换行符
	 * @param pattern
	 */
	public MdcEncoderLayout(String pattern){
		this.pattern = pattern;
	}
	
	/**
	 * 日志格式化
	 */
	private String pattern;
	
	public String getPattern() {
		return pattern;
	}

	public void setPattern(String pattern) {
		this.pattern = pattern;
	}

	@Override
	public String doLayout(ILoggingEvent event) {
		StringBuffer sbuf = new StringBuffer("{\"time\":\"");
		
		if(pattern.contains("%d{-}")){
			sbuf.append(System.currentTimeMillis()).append("\",");
		}else{
			sbuf.append(cachingDateFormatter.format(System.currentTimeMillis())).append("\",");
		}
		
		if(pattern.contains("%topic")){
			sbuf.append("\"topic\":\"").append(event.getLoggerName()).append("\",");
		}
		
		if(pattern.contains("%host")){
			sbuf.append("\"host\":\"").append(IpUtil.getHostIpOrName()).append("\",");
		}
		
    	Map<String, String> mdcMap = event.getMDCPropertyMap();
    	for (Map.Entry<String, String> entry : mdcMap.entrySet()) { 
    		sbuf.append("\"").append(entry.getKey()).append("\":\"").append(entry.getValue()).append("\",");
    	}
    	sbuf.append("\"message\":").append(event.getFormattedMessage()).append("}");
    	
    	if(pattern.contains("%n")){
    		sbuf.append(CoreConstants.LINE_SEPARATOR);
    	}
	    return sbuf.toString();
	}

}
