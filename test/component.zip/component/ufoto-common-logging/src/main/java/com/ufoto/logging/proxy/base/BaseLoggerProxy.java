package com.ufoto.logging.proxy.base;

import org.slf4j.Logger;

public abstract class BaseLoggerProxy {
	
	protected final Logger logger;

    public BaseLoggerProxy(Logger logger) {
        this.logger = logger;
    }
    
    public abstract void log(String msg);
}
