package com.ufoto.logging.proxy;

import com.ufoto.logging.proxy.base.BaseLoggerProxy;
import com.ufoto.logging.util.JSONUtil;
import org.slf4j.Logger;
import org.slf4j.MDC;

import java.util.Map;

/**
 * ufoto日志代理打印类
 *
 * @author zhangqh
 * @date 2018年12月14日
 */
public class UfotoLoggerProxy extends BaseLoggerProxy {


    private UfotoLoggerProxy(Logger logger) {
        super(logger);
    }

    public static UfotoLoggerProxy getUfotoLoggerProxy(String topic, String pattern, String fileName, boolean isDebug) {
        Logger logger = (Logger) UfotoLogFactory.getLogger(topic)
                .enableCustomStatus()
                .withFileName(fileName)
                .withMDCLayout(pattern)
                .enableDebug(isDebug)
                .build();

        return new UfotoLoggerProxy(logger);
    }

    /**
     * 生成代理日志打印
     *
     * @param topic   主题
     * @param pattern 格式化 目前支持%d{-} %host %topic %msg%n
     * @return
     */
    public static UfotoLoggerProxy getUfotoLoggerProxy(String topic, String pattern) {
        return getUfotoLoggerProxy(topic, pattern, topic, false);
    }

    /**
     * @param topic
     * @param pattern
     * @param fileName 文件名
     * @return
     */
    public static UfotoLoggerProxy getUfotoLoggerProxy(String topic, String pattern, String fileName) {
        return getUfotoLoggerProxy(topic, pattern, fileName, false);
    }

    /**
     * @param topic
     * @param pattern
     * @param isDebug 是否开启debug 即是否开启控制台打印 线上环境建议不要开启
     * @return
     */
    public static UfotoLoggerProxy getUfotoLoggerProxy(String topic, String pattern, boolean isDebug) {
        return getUfotoLoggerProxy(topic, pattern, topic, isDebug);
    }

    /**
     * @param msg
     * @param mdc mdc数据
     */
    public void log(Map<String, Object> msg, Map<String, String> mdc) {
        if (mdc != null && !mdc.isEmpty()) {
            MDC.setContextMap(mdc);
        }
        logger.info(JSONUtil.toJSON(msg));
    }

    @Override
    public void log(String msg) {
        logger.info(msg);
    }


}
