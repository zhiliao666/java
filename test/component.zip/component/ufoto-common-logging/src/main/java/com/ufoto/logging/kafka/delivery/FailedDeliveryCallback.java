package com.ufoto.logging.kafka.delivery;

import org.apache.kafka.clients.producer.ProducerRecord;

/**
 * @since 0.0.1
 */
public interface FailedDeliveryCallback<K, V, E> {
    void onFailedDelivery(ProducerRecord<K, V> record, E evt, Throwable throwable);
}
