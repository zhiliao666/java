package com.ufoto.logging.kafka.disruptor;

import ch.qos.logback.classic.spi.ILoggingEvent;
import com.ufoto.lmax.event.Event;
import com.ufoto.logging.kafka.delivery.FailedDeliveryCallback;
import lombok.Builder;
import lombok.Data;
import lombok.EqualsAndHashCode;
import org.apache.kafka.clients.producer.ProducerRecord;

/**
 * <p>
 * Description:
 *
 * </p>
 *
 * @author Chan
 * @date 2020/2/27 14:08
 */
@EqualsAndHashCode(callSuper = true)
@Data
@Builder
public class KafkaLogEvent extends Event {
    private ILoggingEvent event;
    private ProducerRecord<byte[], byte[]> record;
    private FailedDeliveryCallback<byte[], byte[], ILoggingEvent> deliveryCallback;
}
