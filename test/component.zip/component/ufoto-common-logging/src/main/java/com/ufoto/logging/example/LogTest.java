package com.ufoto.logging.example;

import com.ufoto.logging.proxy.UfotoLogFactory;
import com.ufoto.logging.util.JSONUtil;
import org.slf4j.Logger;

import java.util.HashMap;
import java.util.Map;

public class LogTest {

    private static final Logger logger = (Logger) UfotoLogFactory.getLogger("test")
            .build();
    //private static final Logger logger = LoggerFactory.getLogger(LogTest.class);

    public static void main(String[] args) {
//		Long starttime = System.currentTimeMillis();
//		for(int i=0;i<10000;i++){
//			logger.info("测试"+i);
//		}
//		Long endtime = System.currentTimeMillis();
//		System.out.println("执行时间："+(endtime-starttime));
//		fastjsonTest();
    }


    public static void fastjsonTest() {
        Map<String, Object> map1 = new HashMap<String, Object>();
        map1.put("t1", "key134533333333333333333333354353");
        map1.put("t2", "key23453333333中国3333333333333354353");
        Map<String, Object> map = new HashMap<String, Object>();
        map.put("key1", map1);
        map.put("key2", "key23453333333中国3333333333333354353");
        map.put("key3", "key33453333333中国中国中国中国中国中国中国中国中国中国中国3333333333333354353");
        map.put("key4", "key43453333333中国3333333333333354353");
        map.put("key5", "key53453333333中国中国中国3333333333333354353");
        Long starttime = System.currentTimeMillis();
        for (int i = 0; i < 1; i++) {
            System.out.println(JSONUtil.toJSON(map));
        }
        Long endtime = System.currentTimeMillis();
        System.out.println("执行时间：" + (endtime - starttime));
    }
}
