package com.ufoto.logging.example;

import org.slf4j.Logger;

import com.ufoto.logging.proxy.UfotoLogFactory;
import com.ufoto.logging.proxy.UfotoLoggerProxy;

/**
 * Logger自定义日志文件打印常量管理类
 * 
 * 注：此文件由client应用端自行管理
 *
 * @author zhangqh
 * @date 2018年12月7日
 */
public class LogTopicContant {
	
	//------------------1.1.2之前 版本 ------------------------//
	
	/**
	 * 使用此方式打印日志降会在项目目录的logs目录下生成一个topic1.log的文件
	 */
	public static final Logger topic1 = (Logger) UfotoLogFactory.getLogger("topic1")
			.enableCustomStatus()
			.withFileName("topic1")
			.withMDCLayout("%d{-} %host %topic %msg%n")
			.enableConsoleAppender()
			.build();
	
	public static final Logger topic2 = (Logger) UfotoLogFactory.getLogger("topic2")
			.enableCustomStatus()
			.withFileName("topic2")
			.withMDCLayout("%d{-} %host %topic %msg%n")
			.enableConsoleAppender()
			.build();
	
	//------------------1.2.0 版本 配置参见1.1.1------------------------//
	
	public static final UfotoLoggerProxy proxyTopic1 = UfotoLoggerProxy.getUfotoLoggerProxy("proxyTopic1","%d{-} %topic %msg%n",true);
	
	public static final UfotoLoggerProxy proxyTopic2 = UfotoLoggerProxy.getUfotoLoggerProxy("proxyTopic2","%d{-} %topic %msg%n");
}
