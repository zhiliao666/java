package com.ufoto.logging.initializer;


import org.springframework.boot.ApplicationArguments;
import org.springframework.boot.ApplicationRunner;
/**
 * 为了适配spring boot admin重新reload配置文件自定义日志系统失效的问题
 *
 * @author zhangqh
 * @date 2018年12月25日
 */
public class RemoveLoggingConfigInitializer implements ApplicationRunner
{


//	@Override
//	public void initialize(ConfigurableApplicationContext applicationContext) {
//		// 1, 删除spring上下文中logging.config spring boot admin中从新reload就不会重新刷新日志系统上下文
//		ConfigurableEnvironment environment = applicationContext.getEnvironment();
//		environment.getSystemProperties().remove("logging.config");
//		
//		// 2,也可以通过删除系统变量中logging.config实现同等效果
//		// System.getProperties().remove("logging.config");
//		
//		System.out.println("测试删除日志config");
//		
//	}

	@Override
	public void run(ApplicationArguments args) throws Exception {
		
		System.getProperties().remove("logging.config");
		
		System.out.println("清空初始化之前配置的logging.config，保证动态reload配置的时候不会覆盖自定义的日志配置系统");
	}

}
