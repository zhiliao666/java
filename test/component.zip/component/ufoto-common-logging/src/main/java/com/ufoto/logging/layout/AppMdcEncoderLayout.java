package com.ufoto.logging.layout;

import ch.qos.logback.classic.spi.ILoggingEvent;
import ch.qos.logback.core.CoreConstants;
import com.google.common.collect.Maps;
import com.ufoto.logging.util.IpUtil;
import com.ufoto.logging.util.JSONUtil;
import org.apache.commons.lang3.StringUtils;
import org.apache.commons.lang3.time.DateFormatUtils;
import org.springframework.util.CollectionUtils;

import java.util.Map;

/**
 * <p>
 * Author     : Chan
 * CreateDate : 2018-12-17 23:07
 * Description:
 * </p>
 */
public class AppMdcEncoderLayout extends MdcEncoderLayout {

    public AppMdcEncoderLayout(String pattern) {
        super(pattern);
    }

    public String doLayout(ILoggingEvent event) {
        if (StringUtils.isBlank(this.getPattern()) || !this.getPattern().contains("%m")) {
            return event.getFormattedMessage() + CoreConstants.LINE_SEPARATOR;
        }
        Map<String, Object> map = Maps.newHashMap();
        if (this.getPattern().contains("%d{-}")) {
            map.put("time", System.currentTimeMillis() / 1000);
        } else if (this.getPattern().contains("%ds{-}")) {
            map.put("time", System.currentTimeMillis() / 1000);
        } else {
            map.put("time", DateFormatUtils.format(System.currentTimeMillis(), "yyyy-MM-dd HH:mm:ss.SSS"));
        }
        if (this.getPattern().contains("%topic")) {
            map.put("topic", event.getLoggerName());
        }
        if (this.getPattern().contains("%host")) {
            map.put("host", IpUtil.getHostIpOrName());
        }
        Map<String, String> mdcMap = event.getMDCPropertyMap();
        if (!CollectionUtils.isEmpty(mdcMap)) {
            map.putAll(mdcMap);
        }
        if (this.getPattern().contains("%m")) {
            map.put("message", event.getFormattedMessage());
        }

        return JSONUtil.toJSON(map) + CoreConstants.LINE_SEPARATOR;
    }

}
