package com.ufoto.logging.kafka;

import ch.qos.logback.core.Layout;
import com.ufoto.logging.kafka.delivery.FailedDeliveryCallback;
import com.ufoto.logging.kafka.keying.KeyingStrategy;
import com.ufoto.logging.kafka.keying.NoKeyKeyingStrategy;
import lombok.Builder;
import lombok.Data;

import java.io.Serializable;

@Builder
@Data
public class KafkaAppenderConfig<K, V, E> implements Serializable {
    private String topic;
    private KeyingStrategy<E> keyingStrategy;
    private FailedDeliveryCallback<K, V, E> failedDeliveryCallback;
    private Layout<E> kafkaLayout;


    public FailedDeliveryCallback<K, V, E> getFailedDeliveryCallback() {
        return failedDeliveryCallback;
    }

    public KeyingStrategy<E> getKeyingStrategy() {
        if (keyingStrategy == null) {
            return new NoKeyKeyingStrategy<>();
        }
        return keyingStrategy;
    }
}
