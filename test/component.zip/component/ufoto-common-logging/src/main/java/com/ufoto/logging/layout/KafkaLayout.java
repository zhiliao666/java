package com.ufoto.logging.layout;

import ch.qos.logback.classic.spi.ILoggingEvent;
import ch.qos.logback.core.LayoutBase;
import com.ufoto.logging.util.IpUtil;
import com.ufoto.logging.util.JSONUtil;
import org.apache.commons.lang3.time.DateFormatUtils;
import org.springframework.util.CollectionUtils;

import java.util.HashMap;
import java.util.Map;

public class KafkaLayout extends LayoutBase<ILoggingEvent> {
    @Override
    public String doLayout(ILoggingEvent event) {
        Map<String, Object> map = new HashMap<>();
        int currentTimestamp = (int) (System.currentTimeMillis() / 1000);
        map.put("time", currentTimestamp);
        map.put("datetime", DateFormatUtils.format(System.currentTimeMillis(), "yyyy-MM-dd HH:mm:ss.SSS"));
        map.put("topic", event.getLoggerName());
        map.put("host", IpUtil.getHostIpOrName());
        Map<String, String> mdcMap = event.getMDCPropertyMap();
        if (!CollectionUtils.isEmpty(mdcMap)) {
            map.putAll(mdcMap);
        }
        String message = event.getFormattedMessage();
        map.put("message", JSONUtil.toMap(message, String.class, Object.class));
        return JSONUtil.toJSON(map);
    }
}
