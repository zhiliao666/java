package com.ufoto.logging.kafka;

import ch.qos.logback.classic.spi.ILoggingEvent;
import ch.qos.logback.core.Appender;
import ch.qos.logback.core.UnsynchronizedAppenderBase;
import ch.qos.logback.core.encoder.Encoder;
import ch.qos.logback.core.spi.AppenderAttachable;
import ch.qos.logback.core.spi.AppenderAttachableImpl;
import com.ufoto.logging.kafka.delivery.AsynchronousDeliveryStrategy;
import com.ufoto.logging.kafka.delivery.DeliveryStrategy;
import com.ufoto.logging.util.SpringContextHolder;
import org.apache.commons.lang3.StringUtils;
import org.apache.kafka.clients.producer.KafkaProducer;
import org.apache.kafka.clients.producer.ProducerRecord;
import org.springframework.core.env.Environment;

import java.util.HashMap;
import java.util.Iterator;
import java.util.Map;
import java.util.concurrent.ConcurrentLinkedQueue;

/**
 * @since 0.0.1
 */
public class KafkaAppender<E> extends UnsynchronizedAppenderBase<E> implements AppenderAttachable<E> {

    /**
     * Kafka clients uses this prefix for its slf4j logging.
     * This appender defers appends of any Kafka logs since it could cause harmful infinite recursion/self feeding effects.
     */
    private static final String KAFKA_LOGGER_PREFIX = KafkaProducer.class.getPackage().getName().replaceFirst("\\.producer$", "");
    public static final String APPLICATION_NAME = "applicationName";

    private final AppenderAttachableImpl<E> aai = new AppenderAttachableImpl<>();
    private final ConcurrentLinkedQueue<E> queue = new ConcurrentLinkedQueue<>();
    private final DeliveryStrategy deliveryStrategy = new AsynchronousDeliveryStrategy();
    private KafkaAppenderConfig<byte[], byte[], E> kafkaAppenderConfig;
    private Encoder<E> encoder = null;
    private Environment env = null;
    private final static Map<String, String> envMap = new HashMap<>();
    public static final String PROFILE = "profile";
    public static final String IF_SEND = "spring.kafka.if-send";
    public static final String CAN_SEND = "1";

    public KafkaAppender() {

    }

    @Override
    public void doAppend(E e) {
        ensureDeferredAppends();
        if (e instanceof ILoggingEvent && ((ILoggingEvent) e).getLoggerName().startsWith(KAFKA_LOGGER_PREFIX)) {
            deferAppend(e);
        } else {
            super.doAppend(e);
        }
    }

    @Override
    public void addAppender(Appender<E> newAppender) {
        aai.addAppender(newAppender);
    }

    @Override
    public Iterator<Appender<E>> iteratorForAppenders() {
        return aai.iteratorForAppenders();
    }

    @Override
    public Appender<E> getAppender(String name) {
        return aai.getAppender(name);
    }

    @Override
    public boolean isAttached(Appender<E> appender) {
        return aai.isAttached(appender);
    }

    @Override
    public void detachAndStopAllAppenders() {
        aai.detachAndStopAllAppenders();
    }

    @Override
    public boolean detachAppender(Appender<E> appender) {
        return aai.detachAppender(appender);
    }

    @Override
    public boolean detachAppender(String name) {
        return aai.detachAppender(name);
    }

    @Override
    public void append(E e) {
        final byte[] payload = encoder.encode(e);
        final byte[] key = this.kafkaAppenderConfig.getKeyingStrategy().createKey(e);
        final String topic = generateTopic();
        if (env == null) {
            env = SpringContextHolder.getBean(Environment.class);
        }
        if (!CAN_SEND.equals(env.getProperty(IF_SEND, String.class, "1"))) {
            return;
        }
        final ProducerRecord<byte[], byte[]> record = new ProducerRecord<>(topic, key, payload);
        deliveryStrategy.send(record, e, this.getKafkaAppenderConfig().getFailedDeliveryCallback());
    }

    private String generateTopic() {
        StringBuilder topic = new StringBuilder();
        String profile = envMap.get(PROFILE);
        String applicationName = envMap.get(APPLICATION_NAME);
        if (StringUtils.isBlank(profile)) {
            env = SpringContextHolder.getBean(Environment.class);
            String[] profiles = env.getActiveProfiles();
            if (profiles.length > 0) {
                envMap.put(PROFILE, profiles[0]);
                topic.append(envMap.get(PROFILE)).append("_");
            }
        } else {
            topic.append(profile).append("_");
        }
        if (StringUtils.isBlank(applicationName)) {
            if (env == null) {
                env = SpringContextHolder.getBean(Environment.class);
            }
            applicationName = env.getProperty("spring.application.name");
            if (StringUtils.isNotBlank(applicationName)) {
                envMap.put(APPLICATION_NAME, applicationName.replaceAll("-", "_"));
                topic.append(envMap.get(APPLICATION_NAME)).append("_");
            }
        } else {
            topic.append(applicationName).append("_");
        }
        return topic.append(this.kafkaAppenderConfig.getTopic().replaceAll("[.-]", "_")).toString();
    }

    private void deferAppend(E event) {
        queue.add(event);
    }

    // drains queue events to super
    private void ensureDeferredAppends() {
        E event;

        while ((event = queue.poll()) != null) {
            super.doAppend(event);
        }
    }


    public Encoder<E> getEncoder() {
        return encoder;
    }

    public void setEncoder(Encoder<E> encoder) {
        this.encoder = encoder;
    }


    public KafkaAppenderConfig<byte[], byte[], E> getKafkaAppenderConfig() {
        return kafkaAppenderConfig;
    }

    public void setKafkaAppenderConfig(KafkaAppenderConfig<byte[], byte[], E> kafkaAppenderConfig) {
        this.kafkaAppenderConfig = kafkaAppenderConfig;
    }
}
