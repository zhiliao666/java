package com.ufoto.logging.kafka;

import com.lmax.disruptor.BlockingWaitStrategy;
import com.ufoto.lmax.LMaxDisruptor;
import com.ufoto.lmax.consumers.CustomizerExecuteConsumer;
import com.ufoto.logging.kafka.disruptor.KafkaLogConsumer;
import com.ufoto.logging.kafka.disruptor.KafkaLogEvent;
import org.apache.kafka.clients.producer.ProducerConfig;
import org.apache.kafka.common.serialization.ByteArraySerializer;
import org.springframework.beans.factory.annotation.Qualifier;
import org.springframework.boot.autoconfigure.kafka.KafkaProperties;
import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;
import org.springframework.context.annotation.Primary;
import org.springframework.core.env.Environment;
import org.springframework.kafka.core.DefaultKafkaProducerFactory;
import org.springframework.kafka.core.KafkaTemplate;
import org.springframework.kafka.core.ProducerFactory;
import org.springframework.kafka.support.LoggingProducerListener;
import org.springframework.kafka.support.ProducerListener;

import java.util.Map;

@Configuration
public class KafkaConfig {
    private final KafkaProperties properties;
    private final Environment env;

    public KafkaConfig(KafkaProperties properties,
                       Environment env) {
        this.properties = properties;
        this.env = env;
    }

    @Bean(
            name = "kafkaLogEventLMaxDisruptor",
            initMethod = "startDisruptor",
            destroyMethod = "shutdown"
    )
    public LMaxDisruptor<KafkaLogEvent> kafkaLogEventLMaxDisruptor(KafkaLogConsumer kafkaLogConsumer) {
        LMaxDisruptor<KafkaLogEvent> disruptor = LMaxDisruptor.<KafkaLogEvent>builder()
                .waitStrategy(new BlockingWaitStrategy())
                .consumer(CustomizerExecuteConsumer.class)
                .build();
        int consumer = env.getProperty("spring.kafka.disruptor.consumer.num", Integer.class, 6);
        KafkaLogConsumer[] consumerList = new KafkaLogConsumer[consumer];
        for (int i = 0; i < consumer; i++) {
            consumerList[i] = kafkaLogConsumer;
        }
        disruptor.subscribeCustomizer(
                dis -> dis.handleEventsWithWorkerPool(consumerList)
        );
        return disruptor;
    }

    @Primary
    @Bean
    public KafkaTemplate<?, ?> kafkaTemplate(@Qualifier("kafkaProducerFactory") ProducerFactory<Object, Object> kafkaProducerFactory,
                                             ProducerListener<Object, Object> kafkaProducerListener) {
        KafkaTemplate<Object, Object> kafkaTemplate = new KafkaTemplate<>(kafkaProducerFactory);
        kafkaTemplate.setProducerListener(kafkaProducerListener);
        kafkaTemplate.setDefaultTopic(this.properties.getTemplate().getDefaultTopic());
        return kafkaTemplate;
    }

    @Bean
    public ProducerListener<Object, Object> kafkaProducerListener() {
        return new LoggingProducerListener<>();
    }

    @Primary
    @Bean("kafkaProducerFactory")
    public ProducerFactory<Object, Object> kafkaProducerFactory() {
        return this.buildKafkaProducerFactory(this.properties.buildProducerProperties(), this.properties.getProducer().getTransactionIdPrefix());
    }

    public ProducerFactory<Object, Object> buildKafkaProducerFactory(Map<String, Object> configs, String transactionIdPrefix) {
        configs.put(ProducerConfig.KEY_SERIALIZER_CLASS_CONFIG, ByteArraySerializer.class);
        configs.put(ProducerConfig.VALUE_SERIALIZER_CLASS_CONFIG, ByteArraySerializer.class);
        DefaultKafkaProducerFactory<Object, Object> factory = new DefaultKafkaProducerFactory<>(configs);
        if (transactionIdPrefix != null) {
            factory.setTransactionIdPrefix(transactionIdPrefix);
        }
        return factory;
    }
}
