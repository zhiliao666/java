package com.ufoto.logging.kafka.delivery;

import ch.qos.logback.classic.spi.ILoggingEvent;
import com.fasterxml.jackson.core.type.TypeReference;
import com.ufoto.logging.layout.AppMdcEncoderLayout;
import com.ufoto.logging.proxy.UfotoLogFactory;
import com.ufoto.logging.util.JSONUtil;
import com.ufoto.logging.util.LogUtil;
import com.ufoto.logging.util.ObjectMapperFactory;
import lombok.extern.slf4j.Slf4j;
import org.apache.kafka.clients.producer.ProducerRecord;
import org.slf4j.Logger;

import java.util.Map;

@Slf4j
public class AppFailedDeliveryCallback implements FailedDeliveryCallback<byte[], byte[], ILoggingEvent> {

    private static Logger logger = UfotoLogFactory.getLogger("kafka.failed.delivery")
            .enableCustomStatus()
            .withFileName("kafka/kafka_failed_delivery")
            .withLayout(new AppMdcEncoderLayout(null))
            .build();

    @Override
    public void onFailedDelivery(ProducerRecord<byte[], byte[]> record, ILoggingEvent evt, Throwable throwable) {
        //发送失败记录日志
        log.error(throwable.getMessage(), throwable);

        Map<String, Object> map = ObjectMapperFactory.getInstance().convertValue(evt, new TypeReference<Map<String, Object>>() {
        });
        map.put("throwable", LogUtil.exception2String(throwable));
        logger.error(JSONUtil.toJSON(map));
    }
}
