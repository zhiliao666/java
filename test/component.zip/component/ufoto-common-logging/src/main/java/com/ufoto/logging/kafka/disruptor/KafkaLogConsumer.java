package com.ufoto.logging.kafka.disruptor;

import ch.qos.logback.classic.spi.ILoggingEvent;
import com.ufoto.lmax.consumer.Consumer;
import com.ufoto.logging.kafka.delivery.AppFailedDeliveryCallback;
import com.ufoto.logging.kafka.delivery.FailedDeliveryCallback;
import org.springframework.kafka.core.KafkaTemplate;
import org.springframework.kafka.support.SendResult;
import org.springframework.stereotype.Component;
import org.springframework.util.concurrent.ListenableFuture;
import org.springframework.util.concurrent.ListenableFutureCallback;

/**
 * <p>
 * Description:
 *
 * </p>
 *
 * @author Chan
 * @date 2020/2/27 14:11
 */
@Component
public class KafkaLogConsumer extends Consumer<KafkaLogEvent> {

    private final KafkaTemplate kafkaTemplate;

    public KafkaLogConsumer(KafkaTemplate kafkaTemplate) {
        super("business_log");
        this.kafkaTemplate = kafkaTemplate;
    }

    @Override
    public void consume(KafkaLogEvent event) {
        if (event == null || event.getRecord() == null || event.getEvent() == null) {
            return;
        }
        final ListenableFuture future = kafkaTemplate.send(event.getRecord());
        future.addCallback(new ListenableFutureCallback<SendResult<byte[], byte[]>>() {
            @Override
            public void onFailure(Throwable ex) {
                FailedDeliveryCallback<byte[], byte[], ILoggingEvent> deliveryCallback = event.getDeliveryCallback();
                if (deliveryCallback == null) {
                    deliveryCallback = new AppFailedDeliveryCallback();
                }
                deliveryCallback.onFailedDelivery(event.getRecord(), event.getEvent(), ex);
            }

            @Override
            public void onSuccess(SendResult<byte[], byte[]> result) {

            }
        });
    }

    @Override
    public boolean clear() {
        return true;
    }
}
