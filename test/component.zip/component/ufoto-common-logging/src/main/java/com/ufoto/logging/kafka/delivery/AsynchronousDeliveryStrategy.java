package com.ufoto.logging.kafka.delivery;

import ch.qos.logback.classic.spi.ILoggingEvent;
import com.ufoto.lmax.LMaxDisruptor;
import com.ufoto.logging.kafka.disruptor.KafkaLogEvent;
import com.ufoto.logging.util.SpringContextHolder;
import org.apache.kafka.clients.producer.ProducerRecord;

public class AsynchronousDeliveryStrategy implements DeliveryStrategy<byte[], byte[], ILoggingEvent> {

    @Override
    public boolean send(ProducerRecord<byte[], byte[]> record,
                        final ILoggingEvent event,
                        final FailedDeliveryCallback<byte[], byte[], ILoggingEvent> failedDeliveryCallback) {
        try {
            @SuppressWarnings("unchecked")
            LMaxDisruptor<KafkaLogEvent> kafkaLogEventLMaxDisruptor = (LMaxDisruptor<KafkaLogEvent>) SpringContextHolder.getBean("kafkaLogEventLMaxDisruptor");
            kafkaLogEventLMaxDisruptor.send(KafkaLogEvent.builder()
                    .deliveryCallback(failedDeliveryCallback)
                    .event(event)
                    .record(record)
                    .build());
            return true;
        } catch (Exception e) {
            failedDeliveryCallback.onFailedDelivery(record, event, e);
            return false;
        }
    }

}
