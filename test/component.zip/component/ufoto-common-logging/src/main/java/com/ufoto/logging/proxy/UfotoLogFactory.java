package com.ufoto.logging.proxy;

import com.ufoto.logging.proxy.builder.LogBuilder;

/**
 * 日志创建工厂类
 *
 * @author zhangqh
 * @date 2018年11月15日
 */
public class UfotoLogFactory {
	
	private final static String LOGGING_CONFIG = "logging.config" ;
	
	public static LogBuilder getLogger(Class<?> clazz){
		return getLogger(clazz.getName());
	}

	public static LogBuilder getLogger(String loggerName) {
		return new LogBuilder(loggerName);
	}
	
	public static void enableDefaultLogFormat(){
		System.setProperty(LOGGING_CONFIG, "classpath:com/ufoto/logging/xml/ufoto-base-logback.xml");
	}
	
		
}
