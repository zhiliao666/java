package com.ufoto.logging.util;

import java.io.PrintWriter;
import java.io.StringWriter;

public class LogUtil {
    public static String exception2String(Throwable e) {
        try (StringWriter writer = new StringWriter();
             PrintWriter printWriter = new PrintWriter(writer)) {
            e.printStackTrace(printWriter);
            printWriter.flush();
            return writer.toString();
        } catch (Exception ex) {
            return e.getMessage();
        }
    }
}
