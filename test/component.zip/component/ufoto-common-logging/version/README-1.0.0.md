

## 1,配置参数说明

>loggerName  日志名称/对应业务主题名称  
 basePath   日志存放跟路径 可以是相对路径 如当前项目目录的logs目录下 则配置为：/logs  
 backPath  日志备份回滚目录  
 fileName   日志文件名称  
 fileNamePattern 日志文件回滚条件格式Pattern  
 maxFileSize 日志文件最大大小 默认大小2MB  
 maxHistory  历史日志保留最长时间 默认30天  
 totalSizeCap 日志存储总大小限制 如： maxHistory 配置为30 totalSizeCap配置为3G 意思就是最多保持30天的历史日志数据 如果30天内的数据大于3GB将会按时间清除老日志文件   
 layout 自定义日志格式化layout 默认的为SimpleEncoderLayout  
 enablePatternLayout 是否启用PatternLayoutEncoder 默认是false  
 enableConsoleAppender 是否开启控制台打印 默认false  
 enableFileAppender 是否开启文件打印 默认true  
 encoderPattern PatternLayoutEncoder日志格式化对应的Pattern  
 
## 2,使用说明
 
### 2.1 简单的日志打印示例如下：

```
public class LogTest {
	
	/**
	 * 自定义的Logger使用方式
	 */
	private static final Logger logger = (Logger) UfotoLogFactory.getLogger(LogTest.class).build();
	/**
	 * 默认的Logger使用方式
	 */
//	private static final Logger logger = LoggerFactory.getLogger(LogTest.class);
	
	public static void main(String[] args) {
		for(int i=0;i<1000;i++){
			logger.info("测试"+i);
		}
	}
}
```

运行将会在项目根目录下生成一个logs的文件夹下边就会产生一个ufoto_log.log文件，怎样是不是超级简单跟原先logback的使用是不是几乎没区别

### 2.2 针对业务需求定制打印示例如下

具体参数配置参考上边参数说明

```
private static final Logger logger = (Logger) UfotoLogFactory.getLogger(LogTest.class)  
			.enableConsoleAppender() // 这些配置根据项目需要使用  
			.disableFileAppender()  
			.enablePatternLayout()  
			.build();
```

## 3,springboot中如何使用该工具类

1，springboot项目这边就不介绍了
2，在pom文件中应用如下配置，这边提供的是本人的maven私服
```
<repositories>
	 	 <repository>
	        <id>public</id>
	        <name>Team Maven Repository</name>
	        <url>http://maven.ufotosoft.com/nexus/content/repositories/releases/</url>
	        <releases>
	            <enabled>true</enabled>
	        </releases>
	        <snapshots>
	            <enabled>true</enabled>
	        </snapshots>
	    </repository>
</repositories>

<dependency>
  <groupId>com.ufoto</groupId>
  <artifactId>ufoto-common-logging</artifactId>
  <version>1.0.0</version>
</dependency>
```

这样就可以直接在项目中按如下方式使用了

	
