

## 1,工具配置以及使用说明

	在1.0.0版本之上新增了如下配置：
	
>customStatus 是否开始自定义日志开关 默认false 该字段如果是false那么其他配置降不会生效 就默认参考logback原生配置	
 
## 2,使用方式

具体使用[参见](https://git.ufotosoft.com/web/component/ufoto-common-logging/blob/master/src/main/java/com/ufoto/logging/example/LogTopicContant.java)
 
日志格式化配置说明：
> %d 时间 默认格式化为yyyy-MM-dd HH:mm:ss.SSS %d{-} 时间无需格式化打印毫秒时间  
 %host 主机ip  
 %topic 日志主题  
 %msg 具体日志内容  
 %n 换行符 

具体生成的日志格式如下：

```
{"time":"2018-12-07 20:02:09.455","topic":"topic2","host":"192.168.63.76","message":"message"}

```
字段说明：

> time 日志打印时间
topic 日志主题
host 对应日志打印机器ip
message 日志内容

如果需要打印请求会话id，需要应用端主动设置MDC,示例代码如下：

```
MDC.put("sessionId", UUID.randomUUID());
LogConfigContant.topic1.info(nam
```

当然也许你觉得这样很麻烦，也可以在应用程序中设置拦截器，统一设置会话id，示例代码如下：
```
@Component
public class LogInterceptor extends HandlerInterceptorAdapter {
	
	/**
	 * 会话sessionid
	 */
	private final static String SESSION_KEY = "sessionId";

	@Override
	public void postHandle(HttpServletRequest arg0, HttpServletResponse arg1,
			Object arg2, ModelAndView arg3) throws Exception {
	}

	@Override
	public boolean preHandle(HttpServletRequest request,
			HttpServletResponse response, Object handler) throws Exception {
		// 设置SessionId
		String token = UUID.randomUUID().toString().replace("-", "");
		MDC.put(SESSION_KEY, token);
		return true;
	}
	
	@Override
	public void afterCompletion(HttpServletRequest arg0,
			HttpServletResponse arg1, Object arg2, Exception arg3)
			throws Exception {
		// 刪除SessionId
		MDC.remove(SESSION_KEY);
	}
}
```

这样降会生成如下日志文件：
```
{"time":"2018-12-07 20:02:09.455","topic":"topic2","host":"192.168.63.76","sessionId:"a659b205-703a-43f6-9dde-fcae5ecd6722","message":"message"}

```

注：以上新增了会话ID,当然如果业务上有其他的打印需求，也是可以通过MDC动态的扩展
