

## 1,工具配置以及使用说明

	参见1.0.0版本中的说明
 
## 2,统一日志分类管理接入说明
 
### 2.1 第一种方式（推荐方式）

只需在项目启动类中增加一行代码：UfotoLogFactory.enableDefaultLogFormat();

示例如下：

```
@SpringBootApplication
public class TestApplication {

	public static void main(String[] args) {
		// 增加分类日志管理配置
		UfotoLogFactory.enableDefaultLogFormat();
		SpringApplication.run(TestApplication.class, args);
	}
}
```


### 2.2 第二种方式

如果项目中已经有logback的xml配置的可以在对应的配置文件中增加一行配置如下：<include resource="com/ufoto/xml/ufoto-default-logback.xml" />

示例如下：

```
<?xml version="1.0" encoding="UTF-8"?>
<configuration>

    <include resource="com/ufoto/xml/ufoto-default-logback.xml" />
	
</configuration>
```

这样项目启动之后就会在项目的logs目录下生成如下日志结构：

![avatar](logdir.png)

error,info,debug,warn目录中对应的是每天的日志回滚文件，每天一个文件，默认保留30天
