
## 1,日志级别介绍及使用场景说明

常用的日志级别(低到高)有：OFF、FATAL、ERROR、WARN、INFO、DEBUG、TRACE、 ALL

这边我们只介绍我们常用的4种日志级别ERROR、WARN、INFO、DEBUG
	
### 1.1 ERROR错误日志

主要是打印一些应用中不可预知的错误，比如有的场景必须需要用到catch，如一些第三方接口或者rpc的调用到又不想因为接口调用失败而让程序终止，那么这个时候就可以才catch中打印error错误日志了，
当然这种也视业务情况而定，也可以打印warn告警级别的日志
	
推荐打印方式：如果有用户或者会话ID可以带上方便异常情况排查问题

```
logger.error(" invoke rpc error username:{}，sessionId:{}",userName,sessionId,e);

```

不建议方式：
	
```
e.printStackTrace(); // 有堆栈信息但是没有一些用户或者会话相关信息，也不利于统计日志管理

logger.error(" invoke rpc error username:{},e:{}",userName,e.getMessage());// e.getMessage() 无堆栈信息，不利于事后排查问题

```
### 1.2 WARN告警日志

警告日志，我的理解是主要有两点

1. 对业务流程无影响
2. 是一种可以提前预见的信息  

使用场景： 

1. 参数验证，如接口参数非空判断
2. 业务中一些不影响流程的可以打告警日志（这个视业务情况而定）
 
### 1.3 INFO提示日志

提示日志，主要是应用系统中的一些提示信息  
使用场景： 
 1. 比如一些启动相关的提示或者配置信息（如数据库连接信息，tomcat服务启动信息）
 2. 业务中一些比较重要的提示信息（如定义任务相关的执行信息）
 
### 1.4 DEBUG调试日志

调试信息我觉得主要是应用程序一些地方需要使用到调试用的  
使用场景： 
该级别日志主要用于在开发、测试阶段输出。该级别的日志应尽可能地详尽，便于在开发、测试阶段出现问题或者异常时，对其进行分析

推荐使用方式：

```
if(logger.isDebugEnabled()){
	logger.debug(" username:{} ",userName);
}

或者

logger.debug(" username:{} ",userName);

```

不推荐使用：

```
logger.debug(" username:"+userName);
```