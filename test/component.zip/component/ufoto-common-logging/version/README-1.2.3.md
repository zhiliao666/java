### 使用方式 与之前的Logger类似

```
private static Logger logger2 = UfotoLogFactory.getLogger("test")
            .enableCustomStatus()
            .disableFileAppender()
            .withLayout(new AppMdcEncoderLayout(null))
            .withFileName("test/test2")
            .enableKafkaAppender()
            .withKafkaAppenderConfig(KafkaAppenderConfig.<ILoggingEvent>builder()
                    .topic("test")
                    .build()).build();
```

#### 说明

1. 入口: `enableKafkaAppender()`
2. kafka的消息layout默认是`KafkaLayout`
3. 可通过`KafkaAppenderConfig`配置topic、key路由策略、失败策略
4. kafka的其他配置可通过spring boot的配置来完成 `spring.kafka....`
5. kafka topic 的规则 `${profile}_${applicaitonName}_${loggerName/topic}`
6. 失败策略可通过`com.ufoto.logging.kafka.KafkaAppenderConfig.KafkaAppenderConfigBuilder.failedDeliveryCallback(..)`设置。
默认写入日志文件
7. 日志统一遵循以下格式。
    ```
    {
        "datetime":"2019-07-04 10:15:34.450",
        "host":"172.31.71.3",
        "topic":"game.record",
        "time":1562235334,
        "message":{
            "endTime":1562235329,
            "game":"BrickElimination",
            "gameFlag":"01",
            "gameType":2,
            "roomId":"01-6362617-5727758-HwyE-1562235311925",
            "score":2,
            "startTime":1562235317,
            "status":2,
            "targetScore":2,
            "targetUid":6362617,
            "uid":5727758,
            "victory":0
        }
    }
    
    message表示需要打印的日志，host、topic、time为统一字段，不需要设置。
    message中原则上不允许嵌套json，不允许数组。
    ```
    
