注：本工具类是封装在Logback的基础之上，所以在使用的时候项目必须有对应的logback依赖，并对logback之使用和原理有一定理解，如果未使用过logback建议先看[logback之详细使用和介绍](https://github.com/zhiliao666/java-log/tree/master/zhiliao-logback)

推荐[日志约定可以点击查看](https://git.ufotosoft.com/web/component/ufoto-common-logging/blob/master/version/log-protocol.md)

### [版本1.0.0 使用说明](https://git.ufotosoft.com/web/component/ufoto-common-logging/blob/master/version/README-1.0.0.md)

	1，支持自定义日志文件打印，可以极大的方便和满足中业务中自定义日志文件打印的需求
	
### [版本1.1.0 使用说明](https://git.ufotosoft.com/web/component/ufoto-common-logging/blob/master/version/README-1.1.0.md)

	1，在1.0.0的基础之上新增日志级别分类管理，方便统一管理不同级别的日志文件

### [版本1.1.1 使用说明](https://git.ufotosoft.com/web/component/ufoto-common-logging/blob/master/version/README-1.1.1.md)
	在1.1.0的基础新增了如下功能
	
	1，之上新增了time,host,topic等字段,并且支持对应的日志格式化配置%d{-} %host %topic %msg%n
	2，增加MDC日志打印扩展
	
### 版本1.2.0 使用说明  

在1.1.1的基础新增了如下功能  
	
1.包结构调整了，增加了一层目录logging防止本地类冲突问题，由原来com.ufoto修改为com.ufoto.logging  
2.增加了日志代理打印的使用方式，[具体使用参加](https://git.ufotosoft.com/web/component/ufoto-common-logging/blob/master/src/main/java/com/ufoto/logging/example/LogTopicContant.java)  

### 版本1.2.1 使用说明  

主要fix的是之前版本在spring boot admin上reload配置导致自定义日志失效的问题

### [版本1.2.3 使用说明](https://git.ufotosoft.com/web/component/ufoto-common-logging/blob/master/version/README-1.2.3.md)
新增发送日志到kafka
