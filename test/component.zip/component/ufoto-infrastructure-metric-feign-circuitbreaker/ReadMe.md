# 简介
hystrix熔断时, 此包将自动打印熔断日志到统一格式的日志文件

# RELEASE 
## v 1.2.3.RELEASE
- **撤除滤除feign RuntimeException**, 因为官方已做处理

```xml
        <dependency>
            <groupId>com.ufoto.infrastructure.metric</groupId>
            <artifactId>ufoto-infrastructure-metric-feign-circuitbreaker</artifactId>
            <version>1.2.3.RELEASE</version>
        </dependency>
```

## v 1.2.2.RELEASE
- **滤除feign RuntimeException**
- 移除使用ufoto基础日志包

```xml
        <dependency>
            <groupId>com.ufoto.infrastructure.metric</groupId>
            <artifactId>ufoto-infrastructure-metric-feign-circuitbreaker</artifactId>
            <version>1.2.2.RELEASE</version>
        </dependency>
```

项目中需要修改AbstractFallbackFactory的包路径为com.ufoto.infrastructure.metric.feign.circuitbreaker.AbstractFallbackFactory

# 快速开始
1. 添加仓库  
    ```xml
            <repository>
                <id>ufoto-nexus</id>
                <name>Team Maven Repository</name>
                <url>http://maven.ufotosoft.com/nexus/content/repositories/releases/</url>
                <releases>
                    <enabled>true</enabled>
                </releases>
                <snapshots>
                    <enabled>false</enabled>
                </snapshots>
            </repository>
    ```  
    
2. 引入依赖
    ```xml
        <dependency>
            <groupId>com.ufoto.infrastructure</groupId>
            <artifactId>ufoto-statistic-circuitbreaker</artifactId>
            <version>1.2.1.RELEASE</version>
        </dependency>
    ```
    
3. demo
    ```java
    @FeignClient(name = "ribbon-practice-server-say-hello", fallbackFactory = RetryFeignClientFallbackFactory.class)
    public interface RetryFeignClient {
    
        @RequestMapping("/retry")
        String retry();
    
        @RequestMapping("/sleep/{timeInSeconds}")
        String sleep(@PathVariable("timeInSeconds") int timeInSeconds);
    
    
    }
 
    @Component
     public class RetryFeignClientFallbackFactory extends AbstractFallbackFactory<RetryFeignClient> {
     
         private final RetryFeignClientFallback fallback;
     
         public RetryFeignClientFallbackFactory(RetryFeignClientFallback fallback) {
             this.fallback = fallback;
         }
     
         @Override
         protected RetryFeignClient doCreate() {//仅需实现此方法
             return fallback;
         }
     
     
     }
  
    @Component
    public class RetryFeignClientFallback implements RetryFeignClient {
    
        @Override
        public String retry() {
            return "fallback";
    
        }
    
        @Override
        public String sleep(int timeInSeconds) {
            return "fallback";
        }
    }
    ```
    
# 隐含假定
- 微服务调用所用的是open-feign
- 日志框架所用的是logback