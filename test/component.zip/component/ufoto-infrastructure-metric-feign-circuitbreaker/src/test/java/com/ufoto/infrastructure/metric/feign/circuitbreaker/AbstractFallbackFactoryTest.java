package com.ufoto.infrastructure.metric.feign.circuitbreaker;

import org.junit.Test;

import static org.junit.Assert.assertEquals;

/**
 * @author Luo Bao Ding
 * @since 2019/4/28
 */
public class AbstractFallbackFactoryTest {

    @Test
    public void testDoCreate() {
        String echoFallback = new EchoFallbackFactory().create(new RuntimeException("mock exception"));
        assertEquals(echoFallback, "echo fallback");
    }

    @Test
    public void testDoCreateWithoutLogging() {
        String echoFallback = new EchoFallbackFactory().create(new RuntimeException());
        assertEquals(echoFallback, "echo fallback");
    }

    static class EchoFallbackFactory extends AbstractFallbackFactory<String> {
        @Override
        protected String doCreate() {
            return "echo fallback";
        }
    }
}