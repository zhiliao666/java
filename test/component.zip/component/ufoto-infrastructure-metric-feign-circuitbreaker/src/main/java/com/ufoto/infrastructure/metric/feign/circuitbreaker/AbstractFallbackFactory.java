package com.ufoto.infrastructure.metric.feign.circuitbreaker;

import feign.hystrix.FallbackFactory;
import org.apache.commons.lang3.exception.ExceptionUtils;
import org.slf4j.Logger;

/**
 * @author Luo Bao Ding
 * @since 2018/10/19
 */
public abstract class AbstractFallbackFactory<T> implements FallbackFactory<T> {

    private static final Logger LOGGER = LoggerUtil.getLogger("circuit-breaker");

    protected abstract T doCreate();

    @Override
    public T create(Throwable cause) {
        logFallback(cause);
        return doCreate();
    }

    public static void logFallback(Throwable cause) {
        String msg = ExceptionUtils.getMessage(cause);
        String rootCauseMessage = ExceptionUtils.getRootCauseMessage(cause);
        LOGGER.warn("{}; Caused by: {}", msg, rootCauseMessage);
    }


}
