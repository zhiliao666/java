# Encapsulate Disruptor

## 推荐初始化`Metrics.addRegistry(new SimpleMeterRegistry());`用于统计

## 初始化`LMaxDisruptor`
```
LMaxDisruptor<Order> disruptor = LMaxDisruptor.<Order>builder()
                                .waitStrategy(new BlockingWaitStrategy())
                                .consumer(LinearExecuteConsumer.class)
                                .build();
        disruptor.subscribeConsumer(consumer1, consumer2, consumer3);
        disruptor.startDisruptor();
```

## 创建`Consumer` 必须继承Consumer类实现

```
匿名类
private final static Consumer<Order> consumer1 = new Consumer<Order>("C1") {
        @Override
        public void consume(Order event) {
            System.out.println("1 " + event);
        }
    };
```

## `disruptor`绑定消费者

```
disruptor.subscribeConsumer(consumer1, consumer2, consumer3);
```

## 启动`disruptor`

```
disruptor.startDisruptor();
```

## 调用`send`发送消息

```
disruptor.send(Order.builder().orderId(finalI + "").build())
```

## examples in `com.ufoto.lmax.example`
