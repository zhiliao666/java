/**
 * <p>
 * Author     : Chan
 * CreateDate : 2019/11/27 12:27
 * Description: 定义具体的消费者
 * </p>
 */
package com.ufoto.lmax.consumer;

