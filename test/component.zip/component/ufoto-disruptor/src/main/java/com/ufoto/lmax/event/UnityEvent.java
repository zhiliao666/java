package com.ufoto.lmax.event;

import lombok.Builder;
import lombok.Data;
import lombok.EqualsAndHashCode;

import java.io.Serializable;
import java.util.List;

/**
 * <p>
 * Author     : Chan
 * CreateDate : 2019/11/27 09:51
 * Description: 统一的事件,不同的业务事件的组合
 * </p>
 */
@EqualsAndHashCode(callSuper = true)
@Data
@Builder
public class UnityEvent extends Event implements Serializable {

    //事件list
    private List<EventMap> eventMaps;

}
