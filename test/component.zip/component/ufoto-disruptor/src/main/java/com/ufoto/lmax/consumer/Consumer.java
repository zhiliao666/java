package com.ufoto.lmax.consumer;

import com.ufoto.lmax.ContextEvent;
import com.ufoto.lmax.ContextHandler;
import io.micrometer.core.instrument.Metrics;
import io.micrometer.core.instrument.Tags;
import io.micrometer.core.instrument.Timer;
import lombok.extern.slf4j.Slf4j;


/**
 * <p>
 * Author     : Chan
 * CreateDate : 2019/11/15 18:14
 * Description: 具体的消费者必须实现此类
 * </p>
 */
@Slf4j
public abstract class Consumer<T> implements ContextHandler<T>, ClearEventConsumer {

    private String consumerId;
    private final Timer timer;

    public Consumer(String consumerId) {
        this.consumerId = consumerId;
        timer = Metrics.timer("consumer.message", Tags.of("consumerId", consumerId));
    }

    @Override
    public void onEvent(ContextEvent<T> event, long sequence, boolean endOfBatch) throws Exception {
        timer.record(() -> {
            log.debug("Consumer:{},onEvent: {},sequence:{},endOfBatch:{}", consumerId, event, sequence, endOfBatch);
            consume(event.getContext());
            if (clear()) {
                event.setContext(null);
            }
        });
    }

    @Override
    public void onEvent(ContextEvent<T> event) throws Exception {
        timer.record(() -> {
            log.debug("Consumer:{},onEvent: {}", consumerId, event);
            consume(event.getContext());
            if (clear()) {
                event.setContext(null);
            }
        });
    }
}
