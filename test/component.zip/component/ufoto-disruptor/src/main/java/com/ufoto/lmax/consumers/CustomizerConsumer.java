package com.ufoto.lmax.consumers;

import com.lmax.disruptor.dsl.Disruptor;
import com.ufoto.lmax.ContextEvent;

/**
 * <p>
 * Author     : Chan
 * CreateDate : 2019/11/4 11:13
 * Description:
 * </p>
 */
public interface CustomizerConsumer<T> {

    void consume(Disruptor<ContextEvent<T>> disruptor);

}
