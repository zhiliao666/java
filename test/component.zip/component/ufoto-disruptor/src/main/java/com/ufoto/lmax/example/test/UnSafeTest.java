package com.ufoto.lmax.example.test;

import com.lmax.disruptor.util.Util;
import sun.misc.Unsafe;

/**
 * <p>
 * Description:
 *
 * </p>
 *
 * @author Chan
 * @date 2020/1/10 14:08
 */
public class UnSafeTest {

    public static void main(String[] args) {
        final Unsafe unsafe = Util.getUnsafe();

    }

}
