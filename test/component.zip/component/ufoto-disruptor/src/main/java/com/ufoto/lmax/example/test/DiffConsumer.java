package com.ufoto.lmax.example.test;

import com.lmax.disruptor.EventHandler;

/**
 * <p>
 * Description:
 *
 * </p>
 *
 * @author Chan
 * @date 2020/1/2 17:25
 */
public class DiffConsumer implements EventHandler<DiffBean> {

    private long start;
    private int index = 0;

    public DiffConsumer() {
        this.start = System.currentTimeMillis();
    }

    @Override
    public void onEvent(DiffBean event, long sequence, boolean endOfBatch) throws Exception {
        index++;
        if (index == DiffMain.COUNT) {
            System.out.println("disruptor cost: " + (System.currentTimeMillis() - start));
        }
    }
}
