package com.ufoto.lmax.example.test;

import com.lmax.disruptor.RingBuffer;
import com.lmax.disruptor.YieldingWaitStrategy;
import com.lmax.disruptor.dsl.Disruptor;
import com.lmax.disruptor.dsl.ProducerType;
import com.ufoto.lmax.thread.DefaultThreadFactory;

/**
 * <p>
 * Description:
 *
 * </p>
 *
 * @author Chan
 * @date 2020/1/2 18:08
 */
public class DisruptorTest {

    public static void main(String[] args) {
        Disruptor<TestBean> disruptor = new Disruptor<>(
                TestBean::new,
                256,
                new DefaultThreadFactory(),//用于创建消费者线程
                ProducerType.SINGLE,
                new YieldingWaitStrategy());
        consumer(disruptor);
        disruptor.start();

        //发布事件
        producer(disruptor);
//        producerWithRingBuffer(disruptor.getRingBuffer());

        disruptor.shutdown();
    }

    public static void producer(Disruptor<TestBean> disruptor) {
        for (int i = 0; i < 300; i++) {
            int finalI = i;
            disruptor.publishEvent((event, sequence) -> event.setId(finalI + ""));
        }
    }

    public static void producerWithRingBuffer(RingBuffer<TestBean> ringBuffer) {
        for (int i = 0; i < 10; i++) {
            final long seq = ringBuffer.next();
            final TestBean testBean = ringBuffer.get(seq);
            testBean.setId(String.format("%02d", i));
            ringBuffer.publish(0);
        }
    }

    private static void consumer(Disruptor<TestBean> disruptor) {
        TestConsumer c1 = new TestConsumer("C1");
        c1.setRingBuffer(disruptor.getRingBuffer());
        TestConsumer c2 = new TestConsumer("C2");
        TestConsumer c3 = new TestConsumer("C3");
        TestConsumer c4 = new TestConsumer("C4");
        TestConsumer c5 = new TestConsumer("C5");

        disruptor.handleEventsWith(c1, c2);

//        disruptor.handleEventsWithWorkerPool(c1,c2,c3);

//        disruptor.handleEventsWithWorkerPool(c1, c2)
//                .thenHandleEventsWithWorkerPool(c3, c4);


//        disruptor.handleEventsWith(c1).handleEventsWith(c2).handleEventsWith(c3);
//        disruptor.handleEventsWith(c1, c3);
//        disruptor.after(c1).then(c4);
//        disruptor.after(c3).then(c2);
//        disruptor.after(c2, c4).then(c5);
    }

}
