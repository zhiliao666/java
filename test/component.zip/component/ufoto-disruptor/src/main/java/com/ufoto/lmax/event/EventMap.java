package com.ufoto.lmax.event;

import com.ufoto.lmax.consumer.Consumer;
import lombok.Builder;
import lombok.Data;

import java.io.Serializable;

/**
 * <p>
 * Author     : Chan
 * CreateDate : 2019/11/27 10:19
 * Description: 定义一组事件与消费者之间的映射
 * </p>
 */
@Data
@Builder
public class EventMap implements Serializable {
    //具体的事件类
    private Event event;
    //事件与消费者的映射
    private Consumer<? extends Event> consumer;
}
