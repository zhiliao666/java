package com.ufoto.lmax.consumers;

import com.lmax.disruptor.dsl.Disruptor;
import com.ufoto.lmax.ContextEvent;
import com.ufoto.lmax.ContextHandler;

/**
 * <p>
 * Author     : Chan
 * CreateDate : 2019/11/4 11:20
 * Description: 多个消费者之间只有一个执行
 * </p>
 */
public class OnlyOneExecuteConsumer<T> implements ContextConsumer<T> {

    private final Disruptor<ContextEvent<T>> disruptor;

    public OnlyOneExecuteConsumer(Disruptor<ContextEvent<T>> disruptor) {
        this.disruptor = disruptor;
    }

    @SafeVarargs
    @Override
    public final void consume(ContextHandler<T>... handlers) {
        disruptor.handleEventsWithWorkerPool(handlers);
    }
}
