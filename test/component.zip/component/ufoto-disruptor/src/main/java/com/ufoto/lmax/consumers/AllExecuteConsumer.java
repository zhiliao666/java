package com.ufoto.lmax.consumers;

import com.lmax.disruptor.dsl.Disruptor;
import com.ufoto.lmax.ContextEvent;
import com.ufoto.lmax.ContextHandler;

/**
 * <p>
 * Author     : Chan
 * CreateDate : 2019/11/4 11:30
 * Description: 多个消费者同时执行
 * </p>
 */
public class AllExecuteConsumer<T> implements ContextConsumer<T> {

    private final Disruptor<ContextEvent<T>> disruptor;

    public AllExecuteConsumer(Disruptor<ContextEvent<T>> disruptor) {
        this.disruptor = disruptor;
    }

    @SafeVarargs
    @Override
    public final void consume(ContextHandler<T>... handlers) {
        disruptor.handleEventsWith(handlers);
    }
}
