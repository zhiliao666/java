package com.ufoto.lmax.example.test;

/**
 * <p>
 * Description:
 *
 * </p>
 *
 * @author Chan
 * @date 2020/1/2 18:11
 */
public class TestBean {
    private String id;

    public TestBean() {
    }

    public String getId() {
        return id;
    }

    public void setId(String id) {
        this.id = id;
    }

    @Override
    public String toString() {
        return super.toString() + "{" +
                "id='" + id + '\'' +
                '}';
    }
}
