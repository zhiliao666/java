package com.ufoto.lmax;


import java.util.concurrent.atomic.AtomicReference;

/**
 * Event的包装类
 *
 * @param <T> 具体的Event类型
 */
public class ContextEvent<T> {

    final private AtomicReference<T> ref = new AtomicReference<T>();

    public T getContext() {
        return ref.get();
    }

    public void setContext(T context) {
        ref.set(context);
    }

    @Override
    public String toString() {
        final T context = getContext();
        return context == null ? "null" : context.toString();
    }
}
