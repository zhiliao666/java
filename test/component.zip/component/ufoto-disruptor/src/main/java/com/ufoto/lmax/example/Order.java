package com.ufoto.lmax.example;

import com.ufoto.lmax.event.Event;
import lombok.Builder;
import lombok.Data;
import lombok.ToString;

/**
 * <p>
 * Author     : Chan
 * CreateDate : 2019/11/4 11:47
 * Description:
 * </p>
 */
@ToString
@Builder
public class Order extends Event {
    private String orderId;
}
