package com.ufoto.lmax.consumers;

import com.lmax.disruptor.dsl.Disruptor;
import com.ufoto.lmax.ContextEvent;
import com.ufoto.lmax.ContextHandler;

/**
 * <p>
 * Author     : Chan
 * CreateDate : 2019/11/19 13:05
 * Description: 线性执行 事件可传递
 * </p>
 */
public class CustomizerExecuteConsumer<T> implements ContextConsumer<T> {

    private final Disruptor<ContextEvent<T>> disruptor;

    public CustomizerExecuteConsumer(Disruptor<ContextEvent<T>> disruptor) {
        this.disruptor = disruptor;
    }

    @SafeVarargs
    @Override
    public final void consume(ContextHandler<T>... handlers) {

    }

    @Override
    public void customizer(CustomizerConsumer<T> customizerConsumer) {
        customizerConsumer.consume(disruptor);
    }
}
