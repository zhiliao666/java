package com.ufoto.lmax.example.test;

import lombok.Data;

/**
 * <p>
 * Description:
 *
 * </p>
 *
 * @author Chan
 * @date 2020/1/2 17:19
 */
@Data
public class DiffBean {
    private String id;
}
