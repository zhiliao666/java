package com.ufoto.lmax.consumer;

/**
 * <p>
 * Description:
 *
 * </p>
 *
 * @author Chan
 * @date 2020/1/13 11:22
 */
public interface ClearEventConsumer {

    default boolean clear() {
        return false;
    }

}
