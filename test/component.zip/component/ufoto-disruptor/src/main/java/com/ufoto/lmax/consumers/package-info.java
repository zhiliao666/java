/**
 * <p>
 * Author     : Chan
 * CreateDate : 2019/11/19 13:00
 * Description:  定义了多个消费者之间的执行方式
 * </p>
 */
package com.ufoto.lmax.consumers;

