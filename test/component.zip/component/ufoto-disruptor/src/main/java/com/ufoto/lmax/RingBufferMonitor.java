package com.ufoto.lmax;

import lombok.Builder;
import lombok.Data;

import java.io.Serializable;

/**
 * <p>
 * Description:
 *
 * </p>
 *
 * @author Chan
 * @date 2020/1/9 15:15
 */
@Builder
@Data
public class RingBufferMonitor implements Serializable {
    private long bufferSize;
    private long cursor;
    private long remainingCapacity;
}
