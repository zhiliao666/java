package com.ufoto.lmax.example.test;

import com.lmax.disruptor.EventHandler;
import com.lmax.disruptor.RingBuffer;
import com.lmax.disruptor.WorkHandler;

/**
 * <p>
 * Description:
 *
 * </p>
 *
 * @author Chan
 * @date 2020/1/2 18:10
 */
public class TestConsumer implements EventHandler<TestBean>, WorkHandler<TestBean> {
    private String consumerId;
    private RingBuffer<TestBean> ringBuffer;

    public TestConsumer(String consumerId) {
        this.consumerId = consumerId;
    }

    public void setRingBuffer(RingBuffer<TestBean> ringBuffer) {
        this.ringBuffer = ringBuffer;
    }

    @Override
    public void onEvent(TestBean event, long sequence, boolean endOfBatch) throws Exception {
        System.out.printf("%d, consumerId:%s, sequence:%d, event:%s\n", System.nanoTime(), consumerId, sequence, event);
    }

    @Override
    public void onEvent(TestBean event) throws Exception {
        System.out.printf("%d, consumerId:%s, event:%s\n", System.nanoTime(), consumerId, event);
    }
}
