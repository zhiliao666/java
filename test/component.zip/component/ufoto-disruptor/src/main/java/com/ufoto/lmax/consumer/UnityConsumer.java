package com.ufoto.lmax.consumer;


import com.ufoto.lmax.ContextEvent;
import com.ufoto.lmax.event.Event;
import com.ufoto.lmax.event.EventMap;
import com.ufoto.lmax.event.UnityEvent;
import lombok.extern.slf4j.Slf4j;

import java.util.List;

/**
 * <p>
 * Author     : Chan
 * CreateDate : 2019/11/27 09:52
 * Description:
 * </p>
 */
@SuppressWarnings("unchecked")
@Slf4j
public class UnityConsumer extends Consumer<UnityEvent> {

    public UnityConsumer(String consumerId) {
        super(consumerId);
    }

    @Override
    public void consume(UnityEvent event) {
        final List<EventMap> eventMaps = event.getEventMaps();
        if (eventMaps == null || eventMaps.isEmpty()) {
            log.debug("没有设置事件:{}", event);
            return;
        }

        eventMaps.stream()
                .filter(eventMap -> {
                    boolean flag = true;
                    final Consumer<? extends Event> consumer = eventMap.getConsumer();
                    if (consumer == null) {
                        log.warn("没有设置事件与消费者之间的映射: {}", eventMap);
                        flag = false;
                    }
                    final Event actualEvent = eventMap.getEvent();
                    if (actualEvent == null) {
                        log.warn("没有设置具体的事件:{}", eventMap);
                        flag = false;
                    }
                    return flag;
                })
                .forEach(eventMap -> {
                    try {
                        ContextEvent contextEvent = new ContextEvent<>();
                        contextEvent.setContext(eventMap.getEvent());
                        eventMap.getConsumer().onEvent(contextEvent);
                    } catch (Exception e) {
                        log.error(e.getMessage(), e);
                    }
                });
    }
}
