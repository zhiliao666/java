package com.ufoto.lmax;

import com.lmax.disruptor.EventHandler;
import com.lmax.disruptor.WorkHandler;

/**
 * 事件处理类 也即是消费者,所有的消费者基于此接口创建
 *
 * @param <T> 具体的事件类
 */
public interface ContextHandler<T> extends EventHandler<ContextEvent<T>>, WorkHandler<ContextEvent<T>> {

    /**
     * 具体的时间消费
     *
     * @param event 事件类
     */
    void consume(T event);

}
