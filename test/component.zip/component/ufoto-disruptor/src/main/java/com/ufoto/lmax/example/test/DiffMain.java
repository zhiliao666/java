package com.ufoto.lmax.example.test;

import com.lmax.disruptor.YieldingWaitStrategy;
import com.lmax.disruptor.dsl.Disruptor;
import com.lmax.disruptor.dsl.ProducerType;
import lombok.extern.slf4j.Slf4j;

import java.util.UUID;
import java.util.concurrent.ArrayBlockingQueue;
import java.util.concurrent.CountDownLatch;
import java.util.concurrent.Executors;

/**
 * <p>
 * Description:
 *
 * </p>
 *
 * @author Chan
 * @date 2020/1/2 16:33
 */
@Slf4j
public class DiffMain {

    public final static int COUNT = 10_000;

    public static void main(String[] args) throws Exception {
        for (int i = 0; i < 10; i++) {
            testDisruptor(); // 527 2020 11627 11999
            testArrayBlockingQueue();//530 2300 15181
        }
    }

    public static void testDisruptor() throws Exception {
        Disruptor<DiffBean> disruptor = new Disruptor<>(
                DiffBean::new,
                1024 * 1024,
                Executors.defaultThreadFactory(),
                ProducerType.SINGLE,
                new YieldingWaitStrategy());
        disruptor.handleEventsWith(new DiffConsumer());
        disruptor.start();
        CountDownLatch latch = new CountDownLatch(1);
        new Thread(() -> {
            for (int i = 0; i < COUNT; i++) {
                disruptor.publishEvent((event, sequence) -> event.setId(UUID.randomUUID().toString()));
            }
            latch.countDown();
        }).start();
        latch.await();
        disruptor.shutdown();
    }

    public static void testArrayBlockingQueue() throws Exception {
        ArrayBlockingQueue<DiffBean> queue = new ArrayBlockingQueue<>(COUNT);
        CountDownLatch latch = new CountDownLatch(2);
        long start = System.currentTimeMillis();
        new Thread(() -> {
            for (int i = 0; i < COUNT; i++) {
                try {
                    DiffBean diffBean = new DiffBean();
                    diffBean.setId(UUID.randomUUID().toString());
                    queue.put(diffBean);
                } catch (InterruptedException e) {
                    e.printStackTrace();
                }
            }
            latch.countDown();
        }).start();

        new Thread(() -> {
            for (int i = 0; i < COUNT; i++) {
                try {
                    final DiffBean order = queue.take();
//                    System.out.println(order);
                } catch (InterruptedException e) {
                    e.printStackTrace();
                }
            }
            long end = System.currentTimeMillis();
            System.out.println("queue cost: " + (end - start));
            latch.countDown();
        }).start();
        latch.await();
    }


}
