package com.ufoto.lmax.example;

import com.lmax.disruptor.BlockingWaitStrategy;
import com.ufoto.lmax.consumer.Consumer;
import com.ufoto.lmax.LMaxDisruptor;
import com.ufoto.lmax.consumers.AllExecuteConsumer;
import io.micrometer.core.instrument.Metrics;
import io.micrometer.core.instrument.search.Search;
import io.micrometer.core.instrument.simple.SimpleMeterRegistry;

import java.util.UUID;

/**
 * <p>
 * Author     : Chan
 * CreateDate : 2019/11/8 16:30
 * Description:
 * </p>
 */
public class AllExecuteConsumerExample {

    private static LMaxDisruptor<Order> disruptor;
    private final static Consumer<Order> consumer1 = new Consumer<Order>("C1") {
        @Override
        public void consume(Order event) {
            System.out.println("1 " + event);
        }
    };
    private final static Consumer<Order> consumer2 = new Consumer<Order>("C2") {
        @Override
        public void consume(Order event) {
            System.out.println("2 " + event);
        }
    };
    private final static Consumer<Order> consumer3 = new Consumer<Order>("C3") {
        @Override
        public void consume(Order event) {
            System.out.println("3 " + event);
        }
    };

    static {
        Metrics.addRegistry(new SimpleMeterRegistry());
        disruptor = LMaxDisruptor.<Order>builder()
                .waitStrategy(new BlockingWaitStrategy())
                .consumer(AllExecuteConsumer.class)
                .build();
        disruptor.subscribeConsumer(consumer1, consumer2, consumer3);
        disruptor.startDisruptor();
    }

    public static void main(String[] args) throws Exception {
        for (int i = 0; i < 10000; i++) {
            disruptor.send(Order.builder().orderId(UUID.randomUUID().toString()).build());
        }

        Thread.sleep(1000);
        disruptor.shutdown();
        Search.in(Metrics.globalRegistry).meters().forEach(each ->
                System.out.println(
                        String.format("name:%s,tags:%s,type:%s,value:%s",
                                each.getId().getName(), each.getId().getTags(), each.getId().getType(), each.measure())
                ));
    }


}
