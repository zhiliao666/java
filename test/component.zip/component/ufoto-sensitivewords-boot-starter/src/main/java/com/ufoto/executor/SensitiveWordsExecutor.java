package com.ufoto.executor;

import com.ctrip.framework.apollo.model.ConfigChange;
import com.ctrip.framework.apollo.model.ConfigChangeEvent;
import com.ctrip.framework.apollo.spring.annotation.ApolloConfigChangeListener;
import org.apache.commons.lang3.StringUtils;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.util.Assert;

/**
 * @Author Wang, Qing
 * @Date 2020/1/7 18:55
 */
public class SensitiveWordsExecutor {

    @Autowired
    private NoNeedBannedFilterExecutor noNeedBannedFilterExecutor;
    @Autowired
    private NeedBannedFilterExecutor needBannedFilterExecutor;

    public SensitiveWordsExecutor() {

    }

    public boolean containsForLoginBanned(String word) {
        return needBannedFilterExecutor.contains(true, word);
    }

    public boolean contains(String word) {
        return noNeedBannedFilterExecutor.contains(true, word);
    }

    @ApolloConfigChangeListener({"application"})
    private void someOnChange(ConfigChangeEvent changeEvent) {
        try {

            // 基本入参判断
            Assert.notNull(changeEvent, "changeEvent is null");

            doNoNeedBannedWordsRefresh(changeEvent);

            doNeedBannedWordsRefresh(changeEvent);

        } catch (Exception e) {
            System.err.println("error to refresh sensitive words config");
        }

    }

    private void doNeedBannedWordsRefresh(ConfigChangeEvent changeEvent) {
        ConfigChange sensitiveTimestampChange = changeEvent.getChange("sensitive.words.need.banned.timestamp");

        ConfigChange sensitiveUrlChange = changeEvent.getChange("sensitive.words.need.banned.url");

        if (null != sensitiveTimestampChange && null != sensitiveUrlChange) {

            // 其中1种情况触发

            String newTimestamp = sensitiveTimestampChange.getNewValue();

            String newUrl = sensitiveUrlChange.getNewValue();

            if (StringUtils.isNotEmpty(newTimestamp) && StringUtils.isNotEmpty(newUrl)) {
                needBannedFilterExecutor.refresh(newUrl);
            }
        }
    }

    private void doNoNeedBannedWordsRefresh(ConfigChangeEvent changeEvent) {
        ConfigChange sensitiveTimestampChange = changeEvent.getChange("sensitive.words.no.need.banned.timestamp");

        ConfigChange sensitiveUrlChange = changeEvent.getChange("sensitive.words.no.need.banned.url");

        if (null != sensitiveTimestampChange && null != sensitiveUrlChange) {

            // 其中1种情况触发

            String newTimestamp = sensitiveTimestampChange.getNewValue();

            String newUrl = sensitiveUrlChange.getNewValue();

            if (StringUtils.isNotEmpty(newTimestamp) && StringUtils.isNotEmpty(newUrl)) {
                noNeedBannedFilterExecutor.refresh(newUrl);
            }
        }
    }
}
