package com.ufoto.entity;

import java.util.HashMap;
import java.util.Map;

public class DfaNodeNew {

    private char ch;

    private boolean leaf;

    private String word = null;

    private Comparable ext;

    private DfaNodeNew parent;

    /**
     * chat -> node
     */
    private Map<Character, DfaNodeNew> cMap = new HashMap<>(0);

    /**
     * string -> node
     * 用于拼音
     */
    private Map<String, DfaNodeNew> sMap = new HashMap<>(0);

    public Map<Character, DfaNodeNew> getcMap() {
        return cMap;
    }

    public Map<String, DfaNodeNew> getsMap() {
        return sMap;
    }

    public DfaNodeNew getNode(char c) {
        return this.cMap.get(c);
    }

    public DfaNodeNew getNode(String s) {
        return this.sMap.get(s);
    }

    public char getCh() {
        return ch;
    }

    public void setCh(char ch) {
        this.ch = ch;
    }

    public boolean isLeaf() {
        return leaf;
    }

    public void setLeaf(boolean leaf) {
        this.leaf = leaf;
    }

    public String getWord() {
        return word;
    }

    public void setWord(String word) {
        this.word = word;
    }

    public Comparable getExt() {
        return ext;
    }

    public void setExt(Comparable ext) {
        this.ext = ext;
    }

    public DfaNodeNew getParent() {
        return parent;
    }

    public void setParent(DfaNodeNew parent) {
        this.parent = parent;
    }

    public void setcMap(Map<Character, DfaNodeNew> cMap) {
        this.cMap = cMap;
    }

    public void setsMap(Map<String, DfaNodeNew> sMap) {
        this.sMap = sMap;
    }

    public void putNode(char c, DfaNodeNew node) {
        this.cMap.put(c, node);
        node.parent = this;
    }

    public void putNode(String s, DfaNodeNew node) {
        this.sMap.put(s, node);
        node.parent = this;
    }

    public DfaNodeNew(char ch, boolean leaf) {
        this.ch = ch;
        this.leaf = leaf;
    }
}

