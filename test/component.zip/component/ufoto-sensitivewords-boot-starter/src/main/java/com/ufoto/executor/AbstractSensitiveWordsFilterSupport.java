package com.ufoto.executor;

import com.google.common.collect.Sets;
import java.util.Set;

public abstract class AbstractSensitiveWordsFilterSupport {

    protected interface Callback {

        /**
         * 匹配掉敏感词回调
         */
        boolean call(String word);
    }

    protected abstract boolean processor(boolean partMatch, String content, Callback callback)
        throws RuntimeException;

    public boolean contains(boolean partMatch, String content) throws RuntimeException {

        return processor(partMatch, content, new Callback() {
            @Override
            public boolean call(String word) {
                return true; // 有敏感词立即返回
            }
        });
    }

    public Set<String> getWords(boolean partMatch, String content) throws RuntimeException {
        final Set<String> words = Sets.newHashSet();

        processor(partMatch, content, new Callback() {
            @Override
            public boolean call(String word) {
                words.add(word);
                return false; // 继续匹配后面的敏感词
            }
        });

        return words;
    }

}
