package com.ufoto.config;

import com.ufoto.executor.SensitiveWordsExecutor;
import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;

/**
 *
 * @Author Wang, Qing
 * @Date 2020/1/7 17:17
 */
@Configuration
public class SensitiveAutoConfigure {

    @Bean
    SensitiveWordsExecutor sensitiveWordsExecutor() {
        return new SensitiveWordsExecutor();
    }
}
