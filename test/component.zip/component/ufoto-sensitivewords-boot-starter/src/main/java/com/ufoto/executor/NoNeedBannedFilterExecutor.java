package com.ufoto.executor;

import com.google.common.base.Strings;
import com.google.common.collect.Maps;
import com.ufoto.config.DfaConfig;
import com.ufoto.entity.DfaNode;
import org.apache.commons.lang3.StringUtils;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.InitializingBean;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.stereotype.Component;

import java.io.BufferedReader;
import java.io.IOException;
import java.io.InputStream;
import java.io.InputStreamReader;
import java.net.URL;
import java.net.URLConnection;
import java.util.HashMap;

/**
 * DFA 脱敏算法实现支持类
 */
@Component
public final class NoNeedBannedFilterExecutor extends AbstractSensitiveWordsFilterSupport implements InitializingBean {

    /**
     * 新老版本校验开关
     */
    @Value("${sensitive.new.version.enable:true}")
    private Boolean sensitiveNewVersionEnable;

    @Value("${sensitive.stop.word:、，。|}")
    private String sensitiveStopWord;

    @Value("${sensitive.words.enable:true}")
    private Boolean sensitiveWordsEnable;

    @Value("${sensitive.words.no.need.banned.url:https://s3.amazonaws.com/social.ufotosoft.com/sensitivewords/no-need-banned-account-words.txt}")
    private String sensitiveWordsNoNeedBannedUrl;

    private static Logger logger = LoggerFactory.getLogger("NoNeedBannedFilterExecutor");

    private volatile HashMap<Character, DfaNode> cacheNodes = Maps.newHashMap();

    private volatile DfaFilter dfaFilter = new DfaFilter();

    public NoNeedBannedFilterExecutor() {
    }

    private void init(String path) {

//        if (!sensitiveWordsEnable) {
//            cacheNodes = Maps.newHashMap();
//            return;
//        }
        if (Strings.isNullOrEmpty(path)) {
            path = sensitiveWordsNoNeedBannedUrl;
        }
        URLConnection urlConn; // 试图连接并取得返回状态码
        URL url;
        InputStream is = null;
        BufferedReader br = null;
        HashMap<Character, DfaNode> map = Maps.newHashMap();
        DfaFilter dfa = new DfaFilter();
        //配置新版本校验规则
        DfaConfig config = new DfaConfig.Builder()
                //忽略大小写
                .setIgnoreCase(true)
                //去除间隔
                .setSupportStopWord(true)
                .setStopWord(sensitiveStopWord)
                //支持拼音
                .setSupportPinyin(true)
                //支持简繁体切换
                .setSupportSimpleTraditional(true)
                //支持半角全角，默认不支持，配置半角只能识别半角
                .setSupportDbc(true).build();
        dfa.setConfig(config);
        try {

            url = new URL(path);
            urlConn = url.openConnection();
            is = urlConn.getInputStream();
            br = new BufferedReader(new InputStreamReader(is));
            String word;
            while ((word = br.readLine()) != null) {
                put(word.trim(), map);
                //新版本初始化
                dfa.putWord(word.trim(),1);
            }
            cacheNodes = map;
            dfaFilter=dfa;
            logger.info("load sensitive success");
        } catch (IOException e) {
            logger.error(e.getLocalizedMessage());
        } finally {
            try {
                if (is != null) {
                    is.close();
                }
                if (br != null) {
                    br.close();
                }
            } catch (IOException e) {
                logger.error(e.getLocalizedMessage());
            }
        }
    }

    public void refresh(String path) {
        init(path);
    }

    private boolean put(String word, HashMap<Character, DfaNode> map) throws RuntimeException {

        if (StringUtils.isBlank(word)) {
            return false;
        }

        word = StringUtils.trim(word);
        if (word.length() < 2) {
            return false;
        }

        Character firstChar = word.charAt(0);
        DfaNode node = map.get(firstChar);
        if (node == null) {
            node = new DfaNode(firstChar);
            map.put(firstChar, node);
        }

        for (int i = 1; i < word.length(); i++) {
            Character nextChar = word.charAt(i);

            DfaNode nextNode = null;
            if (!node.isLeaf()) {
                nextNode = node.getChilds().get(nextChar);
            }
            if (nextNode == null) {
                nextNode = new DfaNode(nextChar);
            }

            node.addChild(nextNode);
            node = nextNode;

            if (i == word.length() - 1) {
                node.setWord(true);
            }
        }

        return true;
    }

    @Override
    protected boolean processor(boolean partMatch, String content, Callback callback)
            throws RuntimeException {
        if (StringUtils.isBlank(content)) {
            return false;
        }

        content = StringUtils.trim(content);
        if (content.length() < 2) {
            return false;
        }

        for (int index = 0; index < content.length(); index++) {
            char firstChar = content.charAt(index);

            DfaNode node = cacheNodes.get(firstChar);
            if (node == null || node.isLeaf()) {
                continue;
            }

            int charCount = 1;
            for (int i = index + 1; i < content.length(); i++) {
                char wordChar = content.charAt(i);

                node = node.getChilds().get(wordChar);
                if (node != null) {
                    charCount++;
                } else {
                    break;
                }

                if (partMatch && node.isWord()) {
                    if (callback.call(StringUtils.substring(content, index, index + charCount))) {
                        return true;
                    }
                    break;
                } else if (node.isWord()) {
                    if (callback.call(StringUtils.substring(content, index, index + charCount))) {
                        return true;
                    }
                }

                if (node.isLeaf()) {
                    break;
                }
            }

            if (partMatch) {
                index += charCount;
            }
        }

        return false;
    }

    @Override
    public boolean contains(boolean partMatch, String content) throws RuntimeException {
        if (sensitiveNewVersionEnable){
            return dfaFilter.matchWord(content).size() > 0;
        }
        return super.contains(partMatch, content);
    }

    @Override
    public void afterPropertiesSet() throws Exception {
        init(null);
    }
}
