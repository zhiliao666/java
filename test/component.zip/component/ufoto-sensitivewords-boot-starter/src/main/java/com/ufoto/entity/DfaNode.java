package com.ufoto.entity;

import com.google.common.collect.Maps;
import java.util.Map;
import java.util.Set;

/**
 * dfa多叉树模型
 */
public class DfaNode {

    private char _char;
    private DfaNode parent;
    private boolean word;
    private Map<Character, DfaNode> childs;

    public DfaNode() {
    }

    public DfaNode(char _char) {
        this._char = _char;
    }

    public boolean isWord() {
        return word;
    }

    public void setWord(boolean word) {
        this.word = word;
    }

    public boolean isLeaf() {
        return (childs == null || childs.isEmpty());
    }

    public char getChar() {
        return _char;
    }

    public void setChar(char _char) {
        this._char = _char;
    }

    public void addChild(DfaNode child) {
        if (this.childs == null) {
            childs = Maps.newHashMap();
        }

        this.childs.put(child.getChar(), child);
        //child.setParent(this);
    }

    public void removeChild(DfaNode child) {
        if (this.childs != null) {
            this.childs.remove(child.getChar());
        }
    }

    public DfaNode getParent() {
        return parent;
    }

    public void setParent(DfaNode parent) {
        this.parent = parent;
    }

    public Map<Character, DfaNode> getChilds() {
		/*if (this.childs == null) {
			this.childs = Maps.newHashMap();
		}*/
        return this.childs;
    }

    public void setChilds(Map<Character, DfaNode> childs) {
        this.childs = childs;
    }

    public void print(DfaNode node) {
        System.out.println(node.getChar());
        if (node.getChilds() != null) {
            Set<Character> keys = node.getChilds().keySet();
            for (Character _char : keys) {
                print(node.getChilds().get(_char));
            }
        }
    }
}
