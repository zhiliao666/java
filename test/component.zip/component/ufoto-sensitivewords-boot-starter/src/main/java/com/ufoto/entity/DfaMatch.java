package com.ufoto.entity;

public class DfaMatch {

    private int start;

    private int end;

    private DfaNodeNew matched;

    public int getStart() {
        return start;
    }

    public int getEnd() {
        return end;
    }

    public DfaNodeNew getMatched() {
        return matched;
    }

    public DfaMatch(int start, int end, DfaNodeNew matched) {
        this.start = start;
        this.end = end;
        this.matched = matched;
    }

    public String getWord() {
        return this.matched.getWord();
    }

}