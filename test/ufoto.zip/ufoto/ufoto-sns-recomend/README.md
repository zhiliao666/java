# 推荐服务文档

<a name="ufoto-sns-recommend"></a>
# ufoto-sns-recommend

提供社交产品的推荐功能的微服务。

<a name="ab15b7e4"></a>
## 流程介绍

核心功能接口为:

> com.ufoto.api.SnsActController#recommend
> com.ufoto.api.ApiSnsActController.recommend


主要实现方法是调用 _RecommendService.recommendUsers()_ 方法来获取推荐用户的uid列表，然后根据对应列表通过 _UfotoAppUserService.selectRecommendDtoBySortedUidList()_ 方法组装用户信息，并返回结果。

具体展开介绍一下 _RecommendService.recommendUsers()_ 中的流程和相关概念。

<a name="RecommendService"></a>
### RecommendService

在Service这一层，主要控制的是推荐结果的缓存和处理并发竞争的问题。

缓存很好理解，目前一次推荐会生成20条结果，并缓存在Redis的一个对应用户的List当中。当客户端请求第10到20个结果时，可以直接从Redis当中获取内容，避免再次计算。

并发竞争问题则是在有重复提交的情况下，为了避免对同一个用户的推荐内容同时计算多次，这里简单地使用Redis的SETNX方法来实现了分布式锁。

另外也针对不同的DirtyCase做了不同的处理逻辑，正常情况下会调用 _getNormalResult()_ 方法，也就是调用 _RecommendCore.doRecommendAndGetResult()_ 来计算推荐结果:

```java
//....省略缓存获取、锁竞争相应代码

//判断是否是Snap 的新用户发起的请求
if (dirtyCaseUtil.ifSnapNewUserRequest(recommendAdvanceRequest)) {
    logger.debug("recommend in dirty case : snap new user");
    redisResult = getSnapNewUserResult(resultListKey, needClean, recommendAdvanceRequest, start, end);
} else if(dirtyCaseUtil.ifNeedGiftReceiveCardRequest(recommendAdvanceRequest)){
    logger.debug("recommend in dirty case : snap new user");
    redisResult = getGiftReceiveCardResult(resultListKey, needClean, recommendAdvanceRequest, start, end);
} else {
    redisResult = getNormalResult(resultListKey, needClean, recommendAdvanceRequest, start, end);
}

//....省略释放锁等代码
```

<a name="RecommendCore"></a>
### RecommendCore

在RecommendCore这一层，会执行召回、过滤、排序、打散逻辑，并把结果写入缓存。

<a name="Invoker"></a>
#### Invoker

Invoker负责召回、过滤、排序这三件事的实现，并且在一般情况下是根据 _ufoto-experiment_ 对应服务返回的策略配置来实例化。<br />目前Invoker的获取统一入口:

> com.ufoto.business.recommendNG.InvokerFactory#obtainInvoker


```java
    public Invoker obtainInvoker(RecommendAdvanceRequest recommendAdvanceRequest) {
        if (dirtyCaseUtil.ifNeedGiftReceiveCardRequest(recommendAdvanceRequest)) {
            return specialCaseInvokerCache.get(GIFT);
        } else if (dirtyCaseUtil.ifNullForDefaultRequest(recommendAdvanceRequest)) {
            return specialCaseInvokerCache.get(DEFAULT);
        } else if (dirtyCaseUtil.ifHighRiskRequest(recommendAdvanceRequest)) {
            return specialCaseInvokerCache.get(High_Risk);
        } else {
            return createInvokerFromRuleEngine(recommendAdvanceRequest);
        }
    }
```

```java
//获取对应的召回者
Invoker invoker = invokerFactory.obtainInvoker(recommendAdvanceRequest);

//开始召回、过滤、排序
invoker.cleanThreadLocalCache();
List<String> uidList = invoker.invoke(MIN_RECALL_SIZE,recommendAdvanceRequest,recalledUidSet);
```

<a name="RecommendShuffleStrategy"></a>
#### RecommendShuffleStrategy

RecommendShuffleStrategy负责根据业务结果，将对应的推荐内容打散。

```java

//打散
List<RecommendShuffleStrategy> shuffleStrategyList = createDefaultShuffle(uid);
for(RecommendShuffleStrategy shuffleStrategy :shuffleStrategyList){
    uidStringArray = shuffleStrategy.shuffle(uidStringArray);
}
```

<a name="29b3a59d"></a>
## 如何扩展

正常情况下需要调整的推荐业务，一般都是增加召回、过滤、排序、打散的策略，这里将分别介绍如何新增对应的策略。

> 每一种策略，包括召回、过滤、排序、打散、候选、reagent，在扩展是需要同时制定RecommendMetadata元数据信息，以便于在不同场景下使用。


<a name="3c77505b"></a>
### 召回

1. 实现 _com.ufoto.business.recommendNG.Recall_ 接口，并且一般情况下可以将对应的实现类放在 _com.ufoto.business.recommendNG.recall_ 目录下。
1. 编写对应的单元测试。因为Recall的业务实现通过黑盒的方式非常难以测试，建议通过单元测试的方式来保证逻辑的正确性。可以参考相同包名下其他实现类的测试。
1. 在MySQL中的 ufoto_exper.ufoto_strategy 中添加对应的新策略。
1. 在BETA环境配置对应的策略，并且启用后测试接口返回是否正常。

<a name="6eb90473"></a>
### 召回成分（候选策略、Reagent）

1. 实现 _com.ufoto.business.recommendNG.Reagent_ 接口，并且将对应的实现类放在 _com.ufoto.business.recommendNG.reagent_ 目录下。
1. 编写对应的单元测试。
1. 在MySQL中的 ufoto_exper.ufoto_strategy 中添加对应的新策略。
1. 在BETA环境配置对应的策略，并且启用后测试接口返回是否正常。

<a name="bb8472c4"></a>
### 过滤

1. 实现 _com.ufoto.business.recommend.RecommendFilterStrategy_ 接口，并将对应实现类放在 _com.ufoto.business.recommend.filter.{业务}_ 目录下。
1. 编写对应的单元测试。

> 过滤策略目前不通过规则引擎配置，所以在程序中通过每种过滤策略的元数据信息
> 注册成不同的DirtyCase下的过滤策略组(`com.ufoto.manager.RecommendStrategyRegister`)，
> 相关实现在`com.ufoto.utils.strategy.InvokerUtil`


<a name="c360e994"></a>
### 排序

1. 继承 _com.ufoto.business.recommend.sort.BaseNormalSortStrategy_ 基类，实现对应的 _getScore()_ 方法，本质是向Map中加入对应的"uid-分数"的键值对。
1. 编写对应的单元测试。
1. 在MySQL中的 ufoto_exper.ufoto_strategy 中添加对应的新策略。
1. 在BETA环境配置对应的策略，并且启用后测试接口返回是否正常。

<a name="a57f705f"></a>
### 打散

1. 实现 _com.ufoto.business.recommend.shuffle.base.ShuffleCutter_ 。
1. 实现 _com.ufoto.business.recommend.shuffle.base.ShuffleDealer_ 。
1. 继承 _com.ufoto.business.recommend.shuffle.base.BaseShuffleStrategy_ 基类，并在构造函数中给 _cutter_ 和 _dealer_ 赋值。

```java
public class DemoShuffleStrategy extends BaseShuffleStrategy {

    public DemoShuffleStrategy(){
        this.cutter = new DemoCutter();
        this.dealer = new DemoDealer();
    }

}
```

<a name="4dfff12d"></a>
### 特别说明
<a name="t0Uqe"></a>
#### 缓存

1. 元数据： com.ufoto.annotation.RecommendMetadata#updateCache
1. 策略实现类: com.ufoto.business.recommend.**.*Strategy#updateCache
1. 如果当前策略需要实现updateCache方法，同时需要将元数据中的updateCache设置为true
> 基于以上设置，所有策略中的缓存都会集中管理，
> 
> 缓存管理类如下
> com.ufoto.config.CacheConfig#recommendLoadingCache
> 
> 缓存在启动时会自动同步到recommendLoadingCache，启动加载类如下com.ufoto.manager.RecommendCacheUpdaterRunner
> 
> 并且每隔12分钟同步一次，定时器入口类如下com.ufoto.business.recommend.RecommendCacheUpdater#updateCacheByAnnotation

<a name="NZWWq"></a>
#### 过滤策略
基于当前的DirtyCase，目前所有的策略可以分为一下分支：

- NORMAL,_//正常的 用户可以使用_
- DEFAULT,_//默认的--_
- GIFT,_//礼物--_
- High_Risk_//高危用户--_

每一种分支所对应的Invoker和过滤策略均不同，由于除过滤策略以外的任何策略，在规则引擎均可配置，所以次分支目前主要用来区分不同case下的过滤策略组，事见`com.ufoto.manager.RecommendStrategyRegister`<br />_
<a name="ZI6TR"></a>
#### 规则引擎
正常的case下，策略是通过规则引擎获取，目前规则引擎单独以jar包的形式为推荐提供服务。<br />依赖如下
```xml
<dependency>
  <groupId>com.ufoto</groupId>
  <artifactId>ufoto-recommend-rule-engine</artifactId>
  <version>0.0.3</version>
</dependency>
```

> 规则引擎会在推荐系统启动时构建，事见
> com.ufoto.runner.RuleBuildRunner
> com.ufoto.runner.RuleCacheManager
> 
> 规则引擎的获取见
> com.ufoto.runner.RuleEngineManager#strategyNG
> 
> 规则引擎的参数见
> com.ufoto.utils.strategy.ParamsConverter#obtainStrategyRequest
> com.ufoto.dto.ConditionRequest



<a name="LTyrJ"></a>
## 如何测试

<a name="93b824b5"></a>
### 单元测试

项目中有维护部分单元测试，覆盖率并没有确认过。测试类和对应类包名路径相同。建议如果需要修改相关类的业务前，确认是否有对应的单元测试，并且保证修改之后测试仍然可以通过。

<a name="992fa1d7"></a>
### 线上健康检查

一般上线之后，会调用 _/snsActApi/recommend_ 接口，确保有正常返回推荐列表内容即可。

<a name="a1bd9760"></a>
## 定时任务

<a name="aa109c2a"></a>
### 冷数据写入MySQL
任务入口类: com.ufoto.utils.quartz.DumpRedisJob,每天执行一次

<a name="c4dc89b3"></a>
### 新热用户更新

部署在 _54.234.177.220_ 机器上的crontab，每天一次，在 _/home/ubuntu/NewHotScript/_ 中，成功或者失败后会发邮件到脚本中配置的邮箱。

<a name="d2c1dc84"></a>
### 清理过期的Redis内容

对应 com.ufoto.service.CleanRedisServiceImpl ，清理各种过期的Redis内容。

<a name="6e4d6109"></a>
## 优化建议

<a name="aa109c2a-1"></a>
### 冷数据写入MySQL

目前判断冷数据的方法是便利用户uid，然后判断对应的活跃时间是否超过阈值（12天没有活跃）。在用户中心采用snowflake方法生成用户uid的话，需要修改对应的实现方法，比如通过bi数据库的用户活跃表来进行用户筛选。

另外也需要修改对应的定时执行方式，可以使用Quartz来保证只有一个节点会执行这个任务。

目前对应导出的表在svd数据库中，每条记录都有对应的时间戳，最好有定时任务定期清理太长时间没有回归的用户。

<a name="RedisCommandTimeoutException"></a>
### RedisCommandTimeoutException

目前Redis的实例上的slowlog已经几乎没有超过10毫秒的请求，但是由于Lettuce实现pipeline的方式可能会导致某个连接上堆积任务过多从而超时。

建议尝试调整连接数量来优化性能。当然由于当前的排序策略中使用的获取数据的方法非常消耗Redis性能，可以尝试换成MySQL来实现排序相关数据的获取，根据官方的benchmark，在并发数量合适的情况下两者的QPS旗鼓相当。

参考：[https://github.com/lettuce-io/lettuce-core/issues/757](https://github.com/lettuce-io/lettuce-core/issues/757)

<a name="REDIS_GIFT_RECEIVE_USER_SET_KEY"></a>
### REDIS_GIFT_RECEIVE_USER_SET_KEY

对应的用于GiftReceive场景下用户召回的Set，但是只有在最初上线的时候向Set当中导入了一批用户，并没有更新机制，如果这里的用户都删除了帐号或者头像非法，则将没有内容进行展示。
