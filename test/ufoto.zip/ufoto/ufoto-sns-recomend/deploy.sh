#!/bin/bash  

function help() {
	echo "Usage: deploy.sh [beta|prod|dev]"	
}


function build_up() {
	mvn clean
	mvn package -Dmaven.test.skip=true
}


function upload_to_prod() {
	chmod 400 "us_ufoto.pem"
	#scp -o StrictHostKeyChecking=no -i "us_ufoto.pem" -vv ./target/ufoto-sns-recommend-0.0.1-SNAPSHOT.jar ubuntu@ec2-35-172-234-30.compute-1.amazonaws.com:~/
	scp -o StrictHostKeyChecking=no -i "us_ufoto.pem"  ./target/ufoto-sns-recommend-0.0.1-SNAPSHOT.jar ubuntu@ec2-34-201-26-156.compute-1.amazonaws.com:~/
	scp -o StrictHostKeyChecking=no -i "us_ufoto.pem"  ./target/ufoto-sns-recommend-0.0.1-SNAPSHOT.jar ubuntu@ec2-34-206-52-132.compute-1.amazonaws.com:~/
}

function upload_to_beta() {
    scp -i "us_jumper.pem" ./target/ufoto-sns-recommend.jar ubuntu@34.235.147.189:~/
    ssh -o StrictHostKeyChecking=no -i "us_jumper.pem" ubuntu@34.235.147.189 "bash /home/ubuntu/publish_ufoto_sns_recommend.sh"
    #aws s3 cp ./target/ufoto-sns-recommend-0.0.1-SNAPSHOT.jar s3://test.ufotosoft.com/beta-package/ufoto-sns-recommend-0.0.1-SNAPSHOT.jar  --acl public-read
    #ssh -o StrictHostKeyChecking=no -i "us_ufoto.pem" ubuntu@54.208.210.215 "bash /home/ubuntu/publish_ufoto_sns_recommend.sh s3"
}

function upload_to_test() {
    scp ./target/ufoto-sns-recommend.jar ufoto@192.168.62.65:~/ufoto-sns-recommend.jar
    ssh  ufoto@192.168.62.65 "bash /home/ufoto/publish-ufoto-sns-recommend.sh"
}

function beta_deploy() {
    echo "============START==========="
    
    build_up
    upload_to_beta
    
    echo "============E N D==========="
}

function prod_deploy() {
    echo "============START==========="

    build_up
    upload_to_prod

    echo "============E N D==========="
}
function test_deploy() {
    echo "============START==========="

    build_up
    upload_to_test

    echo "============E N D==========="
}

if [ $# -eq 0 ]; then
    echo -e "No commands provided. Defaulting to [beta]\n"
    beta_deploy
    exit 0
fi

case "$1" in
"beta")
    beta_deploy 
    ;;
"prod")
    prod_deploy
    ;;   
"dev")
    test_deploy
    ;;   
*)
    help
    ;;
esac

