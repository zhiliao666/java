package com.ufoto.business.recommendNG.invoker;

import com.google.common.collect.Lists;
import com.google.common.collect.Sets;
import com.ufoto.BaseUnitTest;
import com.ufoto.business.recommendNG.Invoker;
import com.ufoto.business.recommendNG.captain.NGDefaultCaptain;
import com.ufoto.dto.RecommendAdvanceRequest;
import org.junit.Assert;
import org.junit.Before;
import org.junit.Test;
import org.mockito.Mock;
import org.springframework.beans.factory.annotation.Autowired;

import java.util.LinkedList;
import java.util.List;
import java.util.Set;

import static org.junit.Assert.*;
import static org.mockito.Mockito.when;
import static org.mockito.ArgumentMatchers.any;

/**
 * Created by echo on 11/1/18.
 */
public class WeightCompositeInvokerTest extends BaseUnitTest{

    @Autowired
    NGDefaultCaptain ngDefaultCaptain;

    List<String> resultA ;
    List<String> resultB ;
    List<String> resultC ;

    @Mock
    Invoker normalInvokerA;
    @Mock
    Invoker normalInvokerB;
    @Mock
    Invoker normalInvokerC;

    @Mock
    Invoker lessInvokerA;
    @Mock
    Invoker lessInvokerB;
    @Mock
    Invoker lessInvokerC;

    @Mock
    Invoker noItemInvokerA;

    @Before
    public void setUp(){
        resultA = new LinkedList<>();
        resultB = new LinkedList<>();
        resultC = new LinkedList<>();
        for(int i = 0;i<500;i++){
            resultA.add(String.valueOf(i));
            resultB.add(String.valueOf(i+1000));
            resultC.add(String.valueOf(i+3000));
        }

        when(normalInvokerA.invoke(any(),any(),any())).thenAnswer(invocation ->{
            Object[] arguments = invocation.getArguments();
            Integer minSize = (Integer) arguments[0];
            Set<String> invokedSet = (Set)arguments[2];
            List<String> result = Lists.newLinkedList(resultA);
            result.removeAll(invokedSet);
            return result.subList(0,minSize);
        });

        when(normalInvokerB.invoke(any(),any(),any())).thenAnswer(invocation ->{
            Object[] arguments = invocation.getArguments();
            Integer minSize = (Integer) arguments[0];
            Set<String> invokedSet = (Set)arguments[2];
            List<String> result = Lists.newLinkedList(resultB);
            result.removeAll(invokedSet);
            return result.subList(0,minSize);
        });

        when(normalInvokerC.invoke(any(),any(),any())).thenAnswer(invocation ->{
            Object[] arguments = invocation.getArguments();
            Integer minSize = (Integer) arguments[0];
            Set<String> invokedSet = (Set)arguments[2];
            List<String> result = Lists.newLinkedList(resultC);
            result.removeAll(invokedSet);
            return result.subList(0,minSize);
        });

        when(lessInvokerA.invoke(any(),any(),any())).thenAnswer(invocation ->{
            Object[] arguments = invocation.getArguments();
            Integer minSize = (Integer) arguments[0];
            minSize /=2;
            Set<String> invokedSet = (Set)arguments[2];
            List<String> result = Lists.newLinkedList(resultA);
            result.removeAll(invokedSet);
            return result.subList(0,minSize);
        });

        when(lessInvokerB.invoke(any(),any(),any())).thenAnswer(invocation ->{
            Object[] arguments = invocation.getArguments();
            Integer minSize = (Integer) arguments[0];
            minSize /=3;
            Set<String> invokedSet = (Set)arguments[2];
            List<String> result = Lists.newLinkedList(resultB);
            result.removeAll(invokedSet);
            return result.subList(0,minSize);
        });

        when(lessInvokerC.invoke(any(),any(),any())).thenAnswer(invocation ->{
            Object[] arguments = invocation.getArguments();
            Integer minSize = (Integer) arguments[0];
            minSize /=4;
            Set<String> invokedSet = (Set)arguments[2];
            List<String> result = Lists.newLinkedList(resultC);
            result.removeAll(invokedSet);
            return result.subList(0,minSize);
        });

        when(noItemInvokerA.invoke(any(),any(),any())).thenReturn(Lists.newLinkedList());
    }

    @Test
    public void testNormalA(){
        List<Invoker> children = Lists.newArrayList(normalInvokerA,normalInvokerB,normalInvokerC);
        List<Float> weightList = Lists.newArrayList(1F,1F,1F);
        List<Integer> assembleWeightList = Lists.newArrayList(1,1,1);
        WeightCompositeInvoker invoker = new WeightCompositeInvoker(children,weightList,assembleWeightList,ngDefaultCaptain);
        List<String> result = invoker.invoke(30,new RecommendAdvanceRequest(),Sets.newHashSet());
        Assert.assertEquals(30,result.size());
        Assert.assertEquals(30,Sets.newHashSet(result).size());
        for(String item : result){
            Assert.assertTrue(
                    resultA.subList(0,10).contains(item) ||
                    resultB.subList(0,10).contains(item) ||
                    resultC.subList(0,10).contains(item)
            );
        }
    }

    @Test
    public void testNormalB(){
        List<Invoker> children = Lists.newArrayList(normalInvokerA,normalInvokerB,normalInvokerC);
        List<Float> weightList = Lists.newArrayList(1F,1F,1F);
        List<Integer> assembleWeightList = Lists.newArrayList(1,1,1);
        WeightCompositeInvoker invoker = new WeightCompositeInvoker(children,weightList,assembleWeightList,ngDefaultCaptain);
        List<String> result = invoker.invoke(40,new RecommendAdvanceRequest(),Sets.newHashSet());
        Assert.assertEquals(40,result.size());
        Assert.assertEquals(40,Sets.newHashSet(result).size());
        for(String item : result){
            Assert.assertTrue(
                    resultA.subList(0,14).contains(item) ||
                            resultB.subList(0,14).contains(item) ||
                            resultC.subList(0,14).contains(item)
            );
        }
    }

    @Test
    public void testNormalC(){
        List<Invoker> children = Lists.newArrayList(normalInvokerA,normalInvokerB,normalInvokerC);
        List<Float> weightList = Lists.newArrayList(2F,1F,3F);
        List<Integer> assembleWeightList = Lists.newArrayList(1,1,1);
        WeightCompositeInvoker invoker = new WeightCompositeInvoker(children,weightList,assembleWeightList,ngDefaultCaptain);
        List<String> result = invoker.invoke(50,new RecommendAdvanceRequest(),Sets.newHashSet());
        Assert.assertEquals(50,result.size());
        Assert.assertEquals(50,Sets.newHashSet(result).size());
        for(String item : result){
            Assert.assertTrue(
                    resultA.subList(0,17).contains(item) ||
                            resultB.subList(0,9).contains(item) ||
                            resultC.subList(0,25).contains(item)
            );
        }
    }

    @Test
    public void testNormalD(){
        List<Invoker> children = Lists.newArrayList(normalInvokerA,normalInvokerB,normalInvokerC);
        List<Float> weightList = Lists.newArrayList(2F,1F,3F);
        List<Integer> assembleWeightList = Lists.newArrayList(3,2,1);
        WeightCompositeInvoker invoker = new WeightCompositeInvoker(children,weightList,assembleWeightList,ngDefaultCaptain);
        List<String> result = invoker.invoke(50,new RecommendAdvanceRequest(),Sets.newHashSet());
        Assert.assertEquals(50,result.size());
        Assert.assertEquals(50,Sets.newHashSet(result).size());
        for(String item : result){
            Assert.assertTrue(
                    resultA.subList(0,17).contains(item) ||
                            resultB.subList(0,9).contains(item) ||
                            resultC.subList(0,25).contains(item)
            );
        }
    }

    /**
     * 如果某个召回者权重为0
     */
    @Test
    public void testNormalE(){
        List<Invoker> children = Lists.newArrayList(normalInvokerA,normalInvokerB,normalInvokerC);
        List<Float> weightList = Lists.newArrayList(0F,1F,1F);
        List<Integer> assembleWeightList = Lists.newArrayList(1,1,1);
        WeightCompositeInvoker invoker = new WeightCompositeInvoker(children,weightList,assembleWeightList,ngDefaultCaptain);
        List<String> result = invoker.invoke(30,new RecommendAdvanceRequest(),Sets.newHashSet());
        Assert.assertEquals(60,result.size());
        Assert.assertEquals(60,Sets.newHashSet(result).size());
        for(String item : result){
            Assert.assertTrue(
                    resultA.subList(0,30).contains(item) ||
                            resultB.subList(0,15).contains(item) ||
                            resultC.subList(0,15).contains(item)
            );
        }

        children = Lists.newArrayList(normalInvokerA,normalInvokerB,normalInvokerC);
        weightList = Lists.newArrayList(1F,0F,1F);
        assembleWeightList = Lists.newArrayList(1,1,1);
        invoker = new WeightCompositeInvoker(children,weightList,assembleWeightList,ngDefaultCaptain);
        result = invoker.invoke(30,new RecommendAdvanceRequest(),Sets.newHashSet());
        Assert.assertEquals(60,result.size());
        Assert.assertEquals(60,Sets.newHashSet(result).size());
        for(String item : result){
            Assert.assertTrue(
                    resultA.subList(0,15).contains(item) ||
                            resultB.subList(0,30).contains(item) ||
                            resultC.subList(0,15).contains(item)
            );
        }

        children = Lists.newArrayList(normalInvokerA,normalInvokerB,normalInvokerC);
        weightList = Lists.newArrayList(1F,0F,0F);
        assembleWeightList = Lists.newArrayList(1,1,1);
        invoker = new WeightCompositeInvoker(children,weightList,assembleWeightList,ngDefaultCaptain);
        result = invoker.invoke(30,new RecommendAdvanceRequest(),Sets.newHashSet());
        Assert.assertEquals(90,result.size());
        Assert.assertEquals(90,Sets.newHashSet(result).size());
        for(String item : result){
            Assert.assertTrue(
                    resultA.subList(0,30).contains(item) ||
                            resultB.subList(0,30).contains(item) ||
                            resultC.subList(0,30).contains(item)
            );
        }
    }

    /**
     * 个别召回者的召回结果偏少的结果
     */
    @Test
    public void testLessInvokeA(){
        List<Invoker> children = Lists.newArrayList(lessInvokerA,normalInvokerB,normalInvokerC);
        List<Float> weightList = Lists.newArrayList(1F,1F,1F);
        List<Integer> assembleWeightList = Lists.newArrayList(3,2,1);
        WeightCompositeInvoker invoker = new WeightCompositeInvoker(children,weightList,assembleWeightList,ngDefaultCaptain);
        List<String> result = invoker.invoke(30,new RecommendAdvanceRequest(),Sets.newHashSet());
        Assert.assertEquals(15,result.size());
        Assert.assertEquals(15,Sets.newHashSet(result).size());
        for(String item : result){
            Assert.assertTrue(
                    resultA.subList(0,5).contains(item) ||
                            resultB.subList(0,5).contains(item) ||
                            resultC.subList(0,5).contains(item)
            );
        }

        children = Lists.newArrayList(normalInvokerA,lessInvokerB,normalInvokerC);
        weightList = Lists.newArrayList(1F,1F,1F);
        assembleWeightList = Lists.newArrayList(3,2,1);
        invoker = new WeightCompositeInvoker(children,weightList,assembleWeightList,ngDefaultCaptain);
        result = invoker.invoke(30,new RecommendAdvanceRequest(),Sets.newHashSet());
        Assert.assertEquals(9,result.size());
        Assert.assertEquals(9,Sets.newHashSet(result).size());
        for(String item : result){
            Assert.assertTrue(
                    resultA.subList(0,4).contains(item) ||
                            resultB.subList(0,4).contains(item) ||
                            resultC.subList(0,4).contains(item)
            );
        }

        children = Lists.newArrayList(normalInvokerA,normalInvokerB,lessInvokerC);
        weightList = Lists.newArrayList(1F,1F,1F);
        assembleWeightList = Lists.newArrayList(3,2,1);
        invoker = new WeightCompositeInvoker(children,weightList,assembleWeightList,ngDefaultCaptain);
        result = invoker.invoke(60,new RecommendAdvanceRequest(),Sets.newHashSet());
        Assert.assertEquals(15,result.size());
        Assert.assertEquals(15,Sets.newHashSet(result).size());
        for(String item : result){
            Assert.assertTrue(
                    resultA.subList(0,5).contains(item) ||
                            resultB.subList(0,5).contains(item) ||
                            resultC.subList(0,5).contains(item)
            );
        }
    }


    /**
     * 所有召回者的召回结果偏少的结果
     */
    @Test
    public void testLessInvokeB(){
        List<Invoker> children = Lists.newArrayList(lessInvokerA,lessInvokerB,lessInvokerC);
        List<Float> weightList = Lists.newArrayList(1F,1F,1F);
        List<Integer> assembleWeightList = Lists.newArrayList(3,2,1);
        WeightCompositeInvoker invoker = new WeightCompositeInvoker(children,weightList,assembleWeightList,ngDefaultCaptain);
        List<String> result = invoker.invoke(300,new RecommendAdvanceRequest(),Sets.newHashSet());
        Assert.assertEquals(12,result.size());
        Assert.assertEquals(12,Sets.newHashSet(result).size());
        for(String item : result){
            Assert.assertTrue(
                    resultA.subList(0,4).contains(item) ||
                            resultB.subList(0,4).contains(item) ||
                            resultC.subList(0,4).contains(item)
            );
        }


        children = Lists.newArrayList(lessInvokerC,lessInvokerA,lessInvokerB);
        weightList = Lists.newArrayList(1F,1F,1F);
        assembleWeightList = Lists.newArrayList(3,2,1);
        invoker = new WeightCompositeInvoker(children,weightList,assembleWeightList,ngDefaultCaptain);
        result = invoker.invoke(300,new RecommendAdvanceRequest(),Sets.newHashSet());
        Assert.assertEquals(12,result.size());
        Assert.assertEquals(12,Sets.newHashSet(result).size());
        for(String item : result){
            Assert.assertTrue(
                    resultA.subList(0,4).contains(item) ||
                            resultB.subList(0,4).contains(item) ||
                            resultC.subList(0,4).contains(item)
            );
        }

        children = Lists.newArrayList(lessInvokerB,lessInvokerC,lessInvokerA);
        weightList = Lists.newArrayList(1F,1F,1F);
        assembleWeightList = Lists.newArrayList(3,2,1);
        invoker = new WeightCompositeInvoker(children,weightList,assembleWeightList,ngDefaultCaptain);
        result = invoker.invoke(300,new RecommendAdvanceRequest(),Sets.newHashSet());
        Assert.assertEquals(12,result.size());
        Assert.assertEquals(12,Sets.newHashSet(result).size());
        for(String item : result){
            Assert.assertTrue(
                    resultA.subList(0,4).contains(item) ||
                            resultB.subList(0,4).contains(item) ||
                            resultC.subList(0,4).contains(item)
            );
        }
    }

    /**
     * 所有召回者的召回结果偏少的结果,本身权重分配不同
     */
    @Test
    public void testLessInvokeC(){
        List<Invoker> children = Lists.newArrayList(lessInvokerA,lessInvokerB,lessInvokerC);
        List<Float> weightList = Lists.newArrayList(3F,1F,1F);
        List<Integer> assembleWeightList = Lists.newArrayList(3,2,1);
        WeightCompositeInvoker invoker = new WeightCompositeInvoker(children,weightList,assembleWeightList,ngDefaultCaptain);
        List<String> result = invoker.invoke(300,new RecommendAdvanceRequest(),Sets.newHashSet());
        Assert.assertEquals(10,result.size());
        Assert.assertEquals(10,Sets.newHashSet(result).size());
        for(String item : result){
            Assert.assertTrue(
                    resultA.subList(0,6).contains(item) ||
                            resultB.subList(0,2).contains(item) ||
                            resultC.subList(0,2).contains(item)
            );
        }


        children = Lists.newArrayList(lessInvokerC,lessInvokerA,lessInvokerB);
        weightList = Lists.newArrayList(2F,3F,1F);
        assembleWeightList = Lists.newArrayList(3,2,1);
        invoker = new WeightCompositeInvoker(children,weightList,assembleWeightList,ngDefaultCaptain);
        result = invoker.invoke(300,new RecommendAdvanceRequest(),Sets.newHashSet());
        Assert.assertEquals(12,result.size());
        Assert.assertEquals(12,Sets.newHashSet(result).size());
        for(String item : result){
            Assert.assertTrue(
                    resultA.subList(0,6).contains(item) ||
                            resultB.subList(0,2).contains(item) ||
                            resultC.subList(0,4).contains(item)
            );
        }
//
//        children = Lists.newArrayList(lessInvokerB,lessInvokerC,lessInvokerA);
//        weightList = Lists.newArrayList(1F,1F,1F);
//        assembleWeightList = Lists.newArrayList(3,2,1);
//        invoker = new WeightCompositeInvoker(children,weightList,assembleWeightList,ngDefaultCaptain);
//        result = invoker.invoke(300,new RecommendAdvanceRequest(),Sets.newHashSet());
//        Assert.assertEquals(12,result.size());
//        Assert.assertEquals(12,Sets.newHashSet(result).size());
//        for(String item : result){
//            Assert.assertTrue(
//                    resultA.subList(0,4).contains(item) ||
//                            resultB.subList(0,4).contains(item) ||
//                            resultC.subList(0,4).contains(item)
//            );
//        }
    }


    /**
     * 所有召回者的召回结果偏少的结果,本身权重分配不同,并且有权重0 的情况
     */
    @Test
    public void testLessInvokeD(){
        List<Invoker> children = Lists.newArrayList(lessInvokerA,lessInvokerB,lessInvokerC);
        List<Float> weightList = Lists.newArrayList(3F,1F,0F);
        List<Integer> assembleWeightList = Lists.newArrayList(3,2,1);
        WeightCompositeInvoker invoker = new WeightCompositeInvoker(children,weightList,assembleWeightList,ngDefaultCaptain);
        List<String> result = invoker.invoke(300,new RecommendAdvanceRequest(),Sets.newHashSet());
        Assert.assertEquals(123,result.size());
        Assert.assertEquals(123,Sets.newHashSet(result).size());
        for(String item : result){
            Assert.assertTrue(
                    resultA.subList(0,36).contains(item) ||
                            resultB.subList(0,12).contains(item) ||
                            resultC.subList(0,75).contains(item)
            );
        }


        children = Lists.newArrayList(lessInvokerC,lessInvokerA,lessInvokerB);
        weightList = Lists.newArrayList(2F,0F,1F);
        assembleWeightList = Lists.newArrayList(3,2,1);
        invoker = new WeightCompositeInvoker(children,weightList,assembleWeightList,ngDefaultCaptain);
        result = invoker.invoke(300,new RecommendAdvanceRequest(),Sets.newHashSet());
        Assert.assertEquals(174,result.size());
        Assert.assertEquals(174,Sets.newHashSet(result).size());
        for(String item : result){
            Assert.assertTrue(
                    resultA.subList(0,150).contains(item) ||
                            resultB.subList(0,8).contains(item) ||
                            resultC.subList(0,16).contains(item)
            );
        }


        children = Lists.newArrayList(noItemInvokerA,lessInvokerC);
        weightList = Lists.newArrayList(1F,0F);
        assembleWeightList = Lists.newArrayList(3,2);
        invoker = new WeightCompositeInvoker(children,weightList,assembleWeightList,ngDefaultCaptain);
        result = invoker.invoke(300,new RecommendAdvanceRequest(),Sets.newHashSet());
        Assert.assertEquals(75,result.size());
        Assert.assertEquals(75,Sets.newHashSet(result).size());
        for(String item : result){
            Assert.assertTrue(
                    resultC.subList(0,75).contains(item)
            );
        }
    }
}