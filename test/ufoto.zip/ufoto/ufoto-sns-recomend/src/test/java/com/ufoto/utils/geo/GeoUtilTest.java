package com.ufoto.utils.geo;

import org.junit.Assert;
import org.junit.Test;

import java.security.InvalidParameterException;

/**
 * Created by echo on 10/24/18.
 */
public class GeoUtilTest {

    @Test
    public void testGetLonLatBound(){
        double[] result = null;
        result = GeoUtil.getLonLatBound(111,0D,0D);
        Assert.assertEquals(result[0],-1,0.1D);
        Assert.assertEquals(result[1],1,0.1D);
        Assert.assertEquals(result[2],-1,0.1D);
        Assert.assertEquals(result[3],1,0.1D);

        result = GeoUtil.getLonLatBound(111,50D,0D);
        Assert.assertEquals(result[0],49,0.1D);
        Assert.assertEquals(result[1],51,0.1D);
        Assert.assertEquals(result[2],-1,0.1D);
        Assert.assertEquals(result[3],1,0.1D);

        result = GeoUtil.getLonLatBound(111,-50D,0D);
        Assert.assertEquals(result[0],-51,0.1D);
        Assert.assertEquals(result[1],-49,0.1D);
        Assert.assertEquals(result[2],-1,0.1D);
        Assert.assertEquals(result[3],1,0.1D);

        result = GeoUtil.getLonLatBound(1113,175D,0D);
        Assert.assertEquals(result[0],165,0.1D);
        Assert.assertEquals(result[1],-175,0.1D);
        Assert.assertEquals(result[2],-10,0.1D);
        Assert.assertEquals(result[3],10,0.1D);

        result = GeoUtil.getLonLatBound(1113,-175D,0D);
        Assert.assertEquals(result[0],175,0.1D);
        Assert.assertEquals(result[1],-165,0.1D);
        Assert.assertEquals(result[2],-10,0.1D);
        Assert.assertEquals(result[3],10,0.1D);

        //--------------------------------
        result = GeoUtil.getLonLatBound(111,50D,50D);
        Assert.assertEquals(result[0],48.44,0.1D);
        Assert.assertEquals(result[1],51.56,0.1D);
        Assert.assertEquals(result[2],49,0.1D);
        Assert.assertEquals(result[3],51,0.1D);

        result = GeoUtil.getLonLatBound(111,-50D,50D);
        Assert.assertEquals(result[0],-51.56,0.1D);
        Assert.assertEquals(result[1],-48.44,0.1D);
        Assert.assertEquals(result[2],49,0.1D);
        Assert.assertEquals(result[3],51,0.1D);

        result = GeoUtil.getLonLatBound(1113,175D,50D);
        Assert.assertEquals(result[0],159.4,0.1D);
        Assert.assertEquals(result[1],-169.4,0.1D);
        Assert.assertEquals(result[2],40,0.1D);
        Assert.assertEquals(result[3],60,0.1D);

        result = GeoUtil.getLonLatBound(1113,-175D,50D);
        Assert.assertEquals(result[0],169.4,0.1D);
        Assert.assertEquals(result[1],-159.4,0.1D);
        Assert.assertEquals(result[2],40,0.1D);
        Assert.assertEquals(result[3],60,0.1D);

        //------------------------------
        result = GeoUtil.getLonLatBound(111,50D,-50D);
        Assert.assertEquals(result[0],48.44,0.1D);
        Assert.assertEquals(result[1],51.56,0.1D);
        Assert.assertEquals(result[2],-51,0.1D);
        Assert.assertEquals(result[3],-49,0.1D);

        result = GeoUtil.getLonLatBound(111,-50D,-50D);
        Assert.assertEquals(result[0],-51.56,0.1D);
        Assert.assertEquals(result[1],-48.44,0.1D);
        Assert.assertEquals(result[2],-51,0.1D);
        Assert.assertEquals(result[3],-49,0.1D);

        result = GeoUtil.getLonLatBound(1113,175D,-50D);
        Assert.assertEquals(result[0],159.4,0.1D);
        Assert.assertEquals(result[1],-169.4,0.1D);
        Assert.assertEquals(result[2],-60,0.1D);
        Assert.assertEquals(result[3],-40,0.1D);

        result = GeoUtil.getLonLatBound(1113,-175D,-50D);
        Assert.assertEquals(result[0],169.4,0.1D);
        Assert.assertEquals(result[1],-159.4,0.1D);
        Assert.assertEquals(result[2],-60,0.1D);
        Assert.assertEquals(result[3],-40,0.1D);

        //------------------------------
        result = GeoUtil.getLonLatBound(111,50D,-80D);
        Assert.assertEquals(result[0],44.25,0.1D);
        Assert.assertEquals(result[1],55.75,0.1D);
        Assert.assertEquals(result[2],-81,0.1D);
        Assert.assertEquals(result[3],-79,0.1D);

        result = GeoUtil.getLonLatBound(111,-50D,-80D);
        Assert.assertEquals(result[0],-55.75,0.1D);
        Assert.assertEquals(result[1],-44.25,0.1D);
        Assert.assertEquals(result[2],-81,0.1D);
        Assert.assertEquals(result[3],-79,0.1D);

        result = GeoUtil.getLonLatBound(1113,175D,-80D);
        Assert.assertEquals(result[0],114.75,0.1D);
        Assert.assertEquals(result[1],-124.7,0.1D);
        Assert.assertEquals(result[2],-85,0.1D);
        Assert.assertEquals(result[3],-70,0.1D);

        result = GeoUtil.getLonLatBound(1113,-175D,-80D);
        Assert.assertEquals(result[0],124.7,0.1D);
        Assert.assertEquals(result[1],-114.75,0.1D);
        Assert.assertEquals(result[2],-85,0.1D);
        Assert.assertEquals(result[3],-70,0.1D);

        //------------------------------
        result = GeoUtil.getLonLatBound(111,50D,80D);
        Assert.assertEquals(result[0],44.25,0.1D);
        Assert.assertEquals(result[1],55.75,0.1D);
        Assert.assertEquals(result[2],79,0.1D);
        Assert.assertEquals(result[3],81,0.1D);

        result = GeoUtil.getLonLatBound(111,-50D,80D);
        Assert.assertEquals(result[0],-55.75,0.1D);
        Assert.assertEquals(result[1],-44.25,0.1D);
        Assert.assertEquals(result[2],79,0.1D);
        Assert.assertEquals(result[3],81,0.1D);

        result = GeoUtil.getLonLatBound(1113,175D,80D);
        Assert.assertEquals(result[0],114.75,0.1D);
        Assert.assertEquals(result[1],-124.7,0.1D);
        Assert.assertEquals(result[2],70,0.1D);
        Assert.assertEquals(result[3],85,0.1D);

        result = GeoUtil.getLonLatBound(1113,-175D,80D);
        Assert.assertEquals(result[0],124.7,0.1D);
        Assert.assertEquals(result[1],-114.75,0.1D);
        Assert.assertEquals(result[2],70,0.1D);
        Assert.assertEquals(result[3],85,0.1D);
    }

    @Test
    public void testGetLonLatBoundMinusDist(){
        double[] result = null;
        result = GeoUtil.getLonLatBound(0,0D,0D);
        Assert.assertEquals(result[0],0,0.1D);
        Assert.assertEquals(result[1],0,0.1D);
        Assert.assertEquals(result[2],0,0.1D);
        Assert.assertEquals(result[3],0,0.1D);

        result = GeoUtil.getLonLatBound(-1,0D,0D);
        Assert.assertEquals(result[0],0,0.1D);
        Assert.assertEquals(result[1],0,0.1D);
        Assert.assertEquals(result[2],0,0.1D);
        Assert.assertEquals(result[3],0,0.1D);
    }

    @Test
    public void testInBound(){
        double[] locationBound ;
        double lon ;
        double lat ;

        locationBound = new double[]{0,1,0,1};
        lon = 0.5;
        lat = 0.5;
        Assert.assertTrue(GeoUtil.ifInBound(locationBound,lon,lat));

        locationBound = new double[]{0,1,0,1};
        lon = 0.5;
        lat = -0.5;
        Assert.assertTrue(!GeoUtil.ifInBound(locationBound,lon,lat));//not

        locationBound = new double[]{-1,1,-1,1};
        lon = -0.5;
        lat = -0.5;
        Assert.assertTrue(GeoUtil.ifInBound(locationBound,lon,lat));

        locationBound = new double[]{-175,-170,-1,1};
        lon = -0.5;
        lat = -0.5;
        Assert.assertTrue(!GeoUtil.ifInBound(locationBound,lon,lat)); //not

        locationBound = new double[]{-175,-170,-1,1};
        lon = -172;
        lat = -0.5;
        Assert.assertTrue(GeoUtil.ifInBound(locationBound,lon,lat));

        locationBound = new double[]{175,-170,-1,1};
        lon = 178;
        lat = -0.5;
        Assert.assertTrue(GeoUtil.ifInBound(locationBound,lon,lat));

        locationBound = new double[]{175,-170,-1,1};
        lon = -178;
        lat = -0.5;
        Assert.assertTrue(GeoUtil.ifInBound(locationBound,lon,lat));

        locationBound = new double[]{175,-170,-1,1};
        lon = -165;
        lat = -0.5;
        Assert.assertTrue(!GeoUtil.ifInBound(locationBound,lon,lat));//not

        locationBound = new double[]{175,-170,-1,1};
        lon = -178;
        lat = -1.5;
        Assert.assertTrue(!GeoUtil.ifInBound(locationBound,lon,lat)); //not
    }

    @Test(expected = InvalidParameterException.class)
    public void testInvalidInBoundA(){
        double[] locationBound ;
        double lon ;
        double lat ;

        locationBound = new double[]{0,1,2,1};
        lon = 0.5;
        lat = 0.5;
        Assert.assertTrue(GeoUtil.ifInBound(locationBound,lon,lat));
    }

    @Test(expected = InvalidParameterException.class)
    public void testInvalidInBoundB(){
        double[] locationBound ;
        double lon ;
        double lat ;

        locationBound = new double[]{0,1,2};
        lon = 0.5;
        lat = 0.5;
        Assert.assertTrue(GeoUtil.ifInBound(locationBound,lon,lat));
    }

    @Test(expected = InvalidParameterException.class)
    public void testInvalidInBoundC(){
        double[] locationBound ;
        double lon ;
        double lat ;

        locationBound = new double[]{0,1,-95,3};
        lon = 0.5;
        lat = 0.5;
        Assert.assertTrue(GeoUtil.ifInBound(locationBound,lon,lat));
    }


    @Test(expected = InvalidParameterException.class)
    public void testInvalidInBoundD(){
        double[] locationBound ;
        double lon ;
        double lat ;

        locationBound = new double[]{0,1,0,95};
        lon = 0.5;
        lat = 0.5;
        Assert.assertTrue(GeoUtil.ifInBound(locationBound,lon,lat));
    }

    @Test(expected = InvalidParameterException.class)
    public void testInvalidInBoundE(){
        double[] locationBound ;
        double lon ;
        double lat ;

        locationBound = new double[]{190,1,0,95};
        lon = 0.5;
        lat = 0.5;
        Assert.assertTrue(GeoUtil.ifInBound(locationBound,lon,lat));
    }

    @Test(expected = InvalidParameterException.class)
    public void testInvalidInBoundF(){
        double[] locationBound ;
        double lon ;
        double lat ;

        locationBound = new double[]{-190,1,0,95};
        lon = 0.5;
        lat = 0.5;
        Assert.assertTrue(GeoUtil.ifInBound(locationBound,lon,lat));
    }
}