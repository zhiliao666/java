package com.ufoto.dao.svd;

import com.google.common.collect.Lists;
import com.ufoto.entity.UfotoSvdUserTopNMatch;
import org.junit.Assert;
import org.junit.Test;
import org.junit.runner.RunWith;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.context.SpringBootTest;
import org.springframework.test.context.junit4.SpringRunner;
import org.springframework.transaction.annotation.Transactional;

import java.util.List;
import java.util.Random;

/**
 * Created by echo on 8/18/18.
 */
@SpringBootTest
@RunWith(SpringRunner.class)
public class UfotoSvdUserTopNMatchMapperTest {

    @Autowired
    UfotoSvdUserTopNMapper ufotoSvdUserTopNMapper;

    @Autowired
    UfotoSvdUserTopNMatchMapper ufotoSvdUserTopNMatchMapper;

    @Test
    @Transactional(transactionManager = "svdTransactionManager")
    public void selectByUser() {
        long uid = 233L;
        int limit = 10;
        Integer offset = 0;

        for(int i=0;i<10;i++){
            uid+=i;
            List<UfotoSvdUserTopNMatch> ufotoSvdUserTopNList = createData(uid,100);
            ufotoSvdUserTopNList.forEach(x->ufotoSvdUserTopNMatchMapper.insert(x));

            List<Long> iIdList = ufotoSvdUserTopNMapper.selectTopNMatchByUid(uid,limit,offset);
            Assert.assertTrue(iIdList.size()==limit);
        }
    }

    @Test
    @Transactional(transactionManager = "svdTransactionManager")
    public void noEnoughDataToSelect() {
        long uid = 233L;
        int limit = 10;
        int offset = 5;
        int createDataSize = 10;

        for(int i=0;i<10;i++){
            uid+=i;
            List<UfotoSvdUserTopNMatch> ufotoSvdUserTopNList = createData(uid,createDataSize);
            ufotoSvdUserTopNList.forEach(x->ufotoSvdUserTopNMatchMapper.insert(x));

            List<Long> iIdList = ufotoSvdUserTopNMapper.selectTopNMatchByUid(uid,limit,offset);
            Assert.assertTrue(iIdList.size()==(offset+limit-createDataSize));
        }
    }


    @Test
    @Transactional(transactionManager = "svdTransactionManager")
    public void selectCount() {
        long uid = 233L;
        int limit = 10;
        int offset = 5;
        int createDataSize = 10;

        for(int i=0;i<10;i++){
            uid+=i;
            List<UfotoSvdUserTopNMatch> ufotoSvdUserTopNList = createData(uid,createDataSize);
            ufotoSvdUserTopNList.forEach(x->ufotoSvdUserTopNMatchMapper.insert(x));

            Long count = ufotoSvdUserTopNMapper.selectTopNMatchCountByUid(uid);
            Assert.assertTrue(count==createDataSize);
        }
    }

    private List<UfotoSvdUserTopNMatch> createData(Long uid,Integer size){
        List<UfotoSvdUserTopNMatch> result = Lists.newLinkedList();
        for(int i=0;i<size;i++){
            UfotoSvdUserTopNMatch ufotoSvdUserTopN = new UfotoSvdUserTopNMatch();
            ufotoSvdUserTopN.setUId(uid);
            ufotoSvdUserTopN.setIId(new Random().nextLong());
            ufotoSvdUserTopN.setRank(i);
            result.add(ufotoSvdUserTopN);
        }
        return result;
    }
}