package com.ufoto.utils.redis;

import com.ufoto.BaseUnitTest;
import org.apache.commons.lang3.RandomUtils;
import org.junit.Assert;
import org.junit.Test;
import org.springframework.beans.factory.annotation.Autowired;

import java.util.Map;
import java.util.stream.Collectors;
import java.util.stream.LongStream;

/**
 * <p>
 * Author     : Chan
 * CreateDate : 2019-09-18 19:25
 * Description:
 * </p>
 */
public class RedisServiceObjServiceImplTest extends BaseUnitTest {

    @Autowired
    private RedisServiceObjService redisServiceObjService;

    @Test
    public void sremove() {
        redisServiceObjService.sremove("like:373236319310053377", 373800770224521217L);
    }

    @Test
    public void testHscan() {
        String key = "test_hscan";
        for (int i = 0; i < 200_000; i++) {
            redisServiceObjService.hIncrBy(key, i + "", RandomUtils.nextLong(1, 100));
        }
        final Map<String, Integer> hscan = redisServiceObjService.hscanWithInteger(key);
        Assert.assertEquals(200_000, hscan.size());
    }

    @Test
    public void testHmget() {
        String key = "test_hmget";
        for (int i = 0; i < 200_000; i++) {
            redisServiceObjService.hIncrBy(key, i + "", RandomUtils.nextLong(1, 100));
        }
        final Map<String, Integer> hmget = redisServiceObjService.hmgetWithInteger(key,
                LongStream.range(0, 200_000).mapToObj(x -> x + "").collect(Collectors.toList()), 0);
        Assert.assertEquals(200_000, hmget.size());
        redisServiceObjService.delete(key);
    }
}
