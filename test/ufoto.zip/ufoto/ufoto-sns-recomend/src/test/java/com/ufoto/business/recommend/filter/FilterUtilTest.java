package com.ufoto.business.recommend.filter;

import com.google.common.collect.Sets;
import com.ufoto.BaseUnitTest;
import com.ufoto.business.recommend.filter.like.LikeLimitFilterStrategy;
import com.ufoto.dto.RecommendAdvanceRequest;
import com.ufoto.utils.CommonUtil;
import com.ufoto.utils.redis.RedisKeyConstant;
import com.ufoto.utils.redis.RedisService;
import lombok.extern.slf4j.Slf4j;
import org.apache.commons.lang3.RandomUtils;
import org.junit.Assert;
import org.junit.Test;
import org.springframework.beans.factory.annotation.Autowired;

import java.util.Set;

@Slf4j
public class FilterUtilTest extends BaseUnitTest {

    @Autowired
    private FilterUtil filterUtil;
    @Autowired
    private RedisService redisService;


    @Test
    public void testExcludeWhoLikeMe() {
        long uid = 20L;
        for (int i = 0; i < 10; i++) {
            redisService.sadd(RedisKeyConstant.REDIS_BE_LIKED_TEMP_SET_KEY_ + uid, RandomUtils.nextLong(100, 1000) + "");
        }
        RecommendAdvanceRequest request = new RecommendAdvanceRequest();
        request.setUid(uid);
        final Set<String> set1 = filterUtil.whoLikedMe(request);
        final Set<String> set2 = filterUtil.whoLikedMe(request);
        final Set<String> set3 = filterUtil.whoLikedMe(request);
        redisService.del(RedisKeyConstant.REDIS_BE_LIKED_TEMP_SET_KEY_ + uid);
        Assert.assertEquals(set1.size(), set2.size());
        Assert.assertEquals(set2.size(), set3.size());
        Assert.assertEquals(set1.size(), set3.size());
    }

    @Test
    public void testFilterExcludeWhoLikedMe() {
        long uid = 20L;
        Set<String> sets = Sets.newHashSet();
        for (int i = 0; i < 10; i++) {
            sets.add(RandomUtils.nextLong(100, 1000) + "");
        }
        redisService.sadd(RedisKeyConstant.REDIS_BE_LIKED_TEMP_SET_KEY_ + uid, sets.toArray(new String[]{}));
        RecommendAdvanceRequest request = new RecommendAdvanceRequest();
        request.setUid(uid);
        filterUtil.filterExcludeWhoLikedMe(request, CommonUtil.getRandomNItemFromSet(sets, 4), LikeLimitFilterStrategy.class);
    }

}
