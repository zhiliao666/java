package com.ufoto.business.recommendNG.invoker;

import com.ufoto.BaseUnitTest;
import com.ufoto.business.recommend.RecommendFilterStrategy;
import com.ufoto.business.recommend.RecommendSortStrategy;
import com.ufoto.business.recommendNG.Reagent;
import com.ufoto.business.recommendNG.Recall;
import com.ufoto.business.recommendNG.core.NGRecommendCoreImpl;
import com.ufoto.business.recommendNG.reagent.IWantItAllReagent;
import com.ufoto.business.recommendNG.recall.NGRandomRecall;
import com.ufoto.dto.RecommendAdvanceRequest;
import com.ufoto.utils.redis.RedisService;
import com.ufoto.utils.strategy.InvokerUtil;
import org.apache.commons.lang.math.RandomUtils;
import org.assertj.core.util.Sets;
import org.junit.Assert;
import org.junit.Before;
import org.junit.Test;
import org.mockito.Mock;
import org.springframework.beans.factory.annotation.Autowired;

import java.util.Arrays;
import java.util.List;
import java.util.Set;

import static org.mockito.ArgumentMatchers.any;
import static org.mockito.Mockito.when;

public class BaseInvokerTest extends BaseUnitTest {

    @Autowired
    NGRandomRecall ngRandomRecall;

    @Autowired
    IWantItAllReagent iWantItAllReagent;

    @Autowired
    RedisService redisService;
    @Autowired
    InvokerUtil invokerUtil;
    @Autowired
    NGRecommendCoreImpl ngRecommendCore;
    @Mock
    Recall commonRecall;

    @Mock
    Recall largeSizeRecall;

    @Mock
    Recall max200Recall;

    @Mock
    Recall withThreadLocalRecall;

    @Mock
    Reagent commonReagentA;

    @Mock
    Reagent commonReagentB;

    @Mock
    RecommendFilterStrategy commonFilterStrategy;

    @Mock
    RecommendFilterStrategy oddFilterStrategy;

    @Mock
    RecommendFilterStrategy onlyOneItemFilterStrategy;

    @Mock
    RecommendSortStrategy commonSortStrategy;

    InvokerEnvConfig invokerEnvConfig;

    Set<String> randomRecallResult = Sets.newTreeSet("100", "101", "102", "103", "104");
    Set<String> commonRecallResult = Sets.newTreeSet("1000", "1001", "1002", "1003", "1004");
    Set<String> recalledResult = Sets.newTreeSet("100", "1000");
    Set<String> withThreadLocalRecallResultA = Sets.newTreeSet(
            "10000", "10001", "10002", "10003", "10004", "10005",
            "20000", "20001", "20002", "20003", "20004", "20005",
            "30000", "30001", "30002", "30003", "30004", "30005",
            "40000", "40001", "40002", "40003", "40004", "40005"
    );
    Set<String> withThreadLocalRecallResultB = Sets.newTreeSet(
            "50000", "50001", "50002", "50003", "50004", "50005",
            "60000", "60001", "60002", "60003", "60004", "60005",
            "70000", "70001", "70002", "70003", "70004", "70005",
            "80000", "80001", "80002", "80003", "80004", "80005"
    );


    @Before
    public void setUp() {
        when(commonRecall.recall(any(), any())).thenReturn(commonRecallResult);
        when(largeSizeRecall.recall(any(), any())).thenAnswer(invocation -> {
            Object[] arguments = invocation.getArguments();
            Integer minSize = (Integer) arguments[0];
            Set<String> result = Sets.newHashSet();
            int startNum = 2333;
            for (int i = 0; i < minSize; i++) {
                result.add(String.valueOf(startNum + i));
            }
            return result;
        });
        when(max200Recall.recall(any(), any())).thenAnswer(invocation -> {
            Object[] arguments = invocation.getArguments();
            Integer minSize = (Integer) arguments[0];
            if (minSize > 200) minSize = 200;
            Set<String> result = Sets.newHashSet();
            int startNum = 23333;
            for (int i = 0; i < minSize; i++) {
                result.add(String.valueOf(startNum + i));
            }
            return result;
        });
        when(withThreadLocalRecall.recall(any(), any())).thenAnswer(invocation -> {
            Object[] arguments = invocation.getArguments();
            RecommendAdvanceRequest request = (RecommendAdvanceRequest) arguments[1];
            if (request.getUid() % 2 == 1) return withThreadLocalRecallResultA;
            return withThreadLocalRecallResultB;
        });
        when(withThreadLocalRecall.ifRecallOnlyOnce()).thenReturn(true);
        when(withThreadLocalRecall.ifNeedThreadLocalCache()).thenReturn(true);

        when(commonReagentA.makeReagents(any(), any())).thenAnswer(invocation -> {
            Object[] arguments = invocation.getArguments();
            Set<String> recallResult = (Set<String>) arguments[1];
            return recallResult;
        });
        when(commonReagentA.randomReagents(any(), any())).thenReturn(randomRecallResult);
        when(commonReagentB.makeReagents(any(), any())).thenAnswer(invocation -> {
            Set<String> result = Sets.newHashSet();
            Object[] arguments = invocation.getArguments();
            Set<String> recallResult = (Set<String>) arguments[1];
            int size = recallResult.size();
            if (size == 0 || size == 1) return recallResult;

            Set<Integer> itemSet = Sets.newHashSet();
            while (itemSet.size() < size / 2) {
                itemSet.add(RandomUtils.nextInt(size));
            }
            int i = 0;
            for (String uid : recallResult) {
                if (itemSet.contains(i)) result.add(uid);
                i += 1;
            }
            return result;
        });//随机返回其中一半的内容
        when(commonReagentB.randomReagents(any(), any())).thenReturn(randomRecallResult);
        when(commonFilterStrategy.filter(any(), any(), any())).thenAnswer(invocation -> {
            Object[] arguments = invocation.getArguments();
            Set<String> recallResult = (Set<String>) arguments[0];
            return recallResult;
        });
        when(oddFilterStrategy.filter(any(), any(), any())).thenAnswer(invocation -> {
            Set<String> result = Sets.newHashSet();
            Object[] arguments = invocation.getArguments();
            Set<String> recallResult = (Set<String>) arguments[0];
            int size = recallResult.size();
            if (size == 0 || size == 1) return recallResult;
            int i = 0;
            for (String uid : recallResult) {
                if (i % 2 == 1) result.add(uid);
                i += 1;
            }
            return result;
        });//只返回奇数

        when(onlyOneItemFilterStrategy.filter(any(), any(), any())).thenAnswer(invocation -> {
            Set<String> result = Sets.newHashSet();
            Object[] arguments = invocation.getArguments();
            Set<String> recallResult = (Set<String>) arguments[0];
            int size = recallResult.size();
            if (size == 0 || size == 1) return recallResult;
            int rand = RandomUtils.nextInt(recallResult.size());
            int i = 0;
            for (String uid : recallResult) {
                if (i == rand) {
                    result.add(uid);
                    break;
                }
                i += 1;
            }
            return result;
        });//只返一个元素
        when(commonSortStrategy.sort(any(), any())).thenAnswer(invocation -> {
            Object[] arguments = invocation.getArguments();
            Set<String> recallResult = (Set<String>) arguments[0];
            return recallResult.toArray(new String[]{});
        });


        invokerEnvConfig = InvokerEnvConfig.builder().maxRecallTime(5).recallSizeIncreaseRate(2).build();
    }


    //case: random recall
    @Test
    public void testRandomRecall() {
        BaseInvoker invoker = new BaseInvoker(ngRandomRecall,
                Arrays.asList(commonReagentA),
                Arrays.asList(commonFilterStrategy),
                commonSortStrategy,
                invokerEnvConfig,
                redisService);
        List<String> result = invoker.invoke(5, new RecommendAdvanceRequest(), Sets.newHashSet());
        Assert.assertEquals(randomRecallResult, Sets.newHashSet(result));
    }

    //case: all reagent
    @Test
    public void testWantAllReagent() {
        BaseInvoker invoker = new BaseInvoker(commonRecall,
                Arrays.asList(iWantItAllReagent),
                Arrays.asList(commonFilterStrategy),
                commonSortStrategy,
                invokerEnvConfig,
                redisService);
        List<String> result = invoker.invoke(5, new RecommendAdvanceRequest(), Sets.newHashSet());
        Assert.assertEquals(commonRecallResult, Sets.newHashSet(result));
    }

    //bad case: random recall + all reagent
    @Test(expected = RuntimeException.class)
    public void testRandomRecallAndWantAllReagent() {
        BaseInvoker invoker = new BaseInvoker(ngRandomRecall,
                Arrays.asList(iWantItAllReagent),
                Arrays.asList(commonFilterStrategy),
                commonSortStrategy,
                invokerEnvConfig,
                redisService);
        invoker.invoke(5, new RecommendAdvanceRequest(), Sets.newHashSet());
    }

    //case: with thread local cache
    @Test
    public void testThreadLocalCache() {
        final BaseInvoker invoker = new BaseInvoker(withThreadLocalRecall,
                Arrays.asList(commonReagentA),
                Arrays.asList(commonFilterStrategy),
                commonSortStrategy,
                invokerEnvConfig,
                redisService);

        final int[] fuckingResult = {0};
        Thread threadA = new Thread(new Runnable() {
            @Override
            public void run() {
                int recallSize = 5;
                Set<String> tempRecallResult = Sets.newTreeSet();
                tempRecallResult.addAll(withThreadLocalRecallResultA);
                tempRecallResult.removeAll(recalledResult);
                RecommendAdvanceRequest request = new RecommendAdvanceRequest();
                request.setUid(1L);

                List<String> result = invoker.invoke(recallSize, request, Sets.newHashSet(recalledResult));

                Assert.assertEquals(recallSize, result.size());
                for (String item : result) {
                    Assert.assertTrue(tempRecallResult.contains(item));
                }

                request.setUid(2L);
                recallSize = 6;
                recalledResult.addAll(result);
                tempRecallResult.removeAll(recalledResult);
                result = invoker.invoke(recallSize, request, Sets.newHashSet(recalledResult));

                Assert.assertEquals(recallSize, result.size());
                for (String item : result) {
                    Assert.assertTrue(tempRecallResult.contains(item));
                }
                //test clean cache
                invoker.cleanThreadLocalCache();

                request.setUid(2L);
                tempRecallResult.addAll(withThreadLocalRecallResultB);
                tempRecallResult.removeAll(recalledResult);

                result = invoker.invoke(recallSize, request, Sets.newHashSet(recalledResult));

                Assert.assertEquals(recallSize, result.size());
                for (String item : result) {
                    Assert.assertTrue(tempRecallResult.contains(item));
                }
                fuckingResult[0] += 1;
            }
        });

        Thread threadB = new Thread(new Runnable() {
            @Override
            public void run() {
                int recallSize = 5;
                Set<String> tempRecallResult = Sets.newTreeSet();
                tempRecallResult.addAll(withThreadLocalRecallResultB);
                tempRecallResult.removeAll(recalledResult);
                RecommendAdvanceRequest request = new RecommendAdvanceRequest();
                request.setUid(2L);

                List<String> result = invoker.invoke(recallSize, request, Sets.newHashSet(recalledResult));

                Assert.assertEquals(recallSize, result.size());
                for (String item : result) {
                    Assert.assertTrue(tempRecallResult.contains(item));
                }

                request.setUid(1L);
                recallSize = 6;
                recalledResult.addAll(result);
                tempRecallResult.removeAll(recalledResult);
                result = invoker.invoke(recallSize, request, Sets.newHashSet(recalledResult));

                Assert.assertEquals(recallSize, result.size());
                for (String item : result) {
                    Assert.assertTrue(tempRecallResult.contains(item));
                }
                //test clean cache
                invoker.cleanThreadLocalCache();

                request.setUid(1L);
                tempRecallResult.addAll(withThreadLocalRecallResultA);
                tempRecallResult.removeAll(recalledResult);

                result = invoker.invoke(recallSize, request, Sets.newHashSet(recalledResult));

                Assert.assertEquals(recallSize, result.size());
                for (String item : result) {
                    Assert.assertTrue(tempRecallResult.contains(item));
                }
                fuckingResult[0] += 1;
            }
        });

        threadA.start();
        threadB.start();
        try {
            threadA.join();
            threadB.join();
        } catch (InterruptedException e) {
            e.printStackTrace();
        }

        Assert.assertEquals(2, fuckingResult[0]);
    }

    //case: invoked item won't show again
    @Test
    public void testInvokedResult() {
        BaseInvoker invoker = new BaseInvoker(commonRecall,
                Arrays.asList(commonReagentA),
                Arrays.asList(commonFilterStrategy),
                commonSortStrategy,
                invokerEnvConfig,
                redisService);
        Set<String> expectedResult = Sets.newHashSet(commonRecallResult);
        expectedResult.removeAll(recalledResult);

        List<String> result = invoker.invoke(5, new RecommendAdvanceRequest(), recalledResult);

        Assert.assertEquals(expectedResult, Sets.newHashSet(result));
    }

    //case: recall enough but filter some
    @Test
    public void testReagent() {
        int minSize = 100;
        BaseInvoker invoker = new BaseInvoker(largeSizeRecall,
                Arrays.asList(commonReagentB),
                Arrays.asList(commonFilterStrategy),
                commonSortStrategy,
                invokerEnvConfig,
                redisService);
        List<String> result = invoker.invoke(minSize, new RecommendAdvanceRequest(), Sets.newHashSet());
        Set<String> expectedResult = largeSizeRecall.recall(minSize, new RecommendAdvanceRequest());

        Assert.assertEquals(expectedResult.size(), minSize);
        Assert.assertEquals(expectedResult.size(), result.size());
        Assert.assertNotEquals(expectedResult, Sets.newHashSet(result));
    }

    @Test
    public void testFilter() {
        int minSize = 100;
        BaseInvoker invoker = new BaseInvoker(largeSizeRecall,
                Arrays.asList(commonReagentA),
                Arrays.asList(oddFilterStrategy),
                commonSortStrategy,
                invokerEnvConfig,
                redisService);
        List<String> result = invoker.invoke(minSize, new RecommendAdvanceRequest(), Sets.newHashSet());
        Set<String> expectedResult = largeSizeRecall.recall(minSize, new RecommendAdvanceRequest());

        Assert.assertEquals(expectedResult.size(), minSize);
        Assert.assertEquals(expectedResult.size(), result.size());
        Assert.assertNotEquals(expectedResult, Sets.newHashSet(result));
    }

    //case test two reagent
    @Test
    public void testTwoReagent() {
        int minSize = 100;
        BaseInvoker invoker = new BaseInvoker(largeSizeRecall,
                Arrays.asList(commonReagentA, commonReagentB),
                Arrays.asList(commonFilterStrategy),
                commonSortStrategy,
                invokerEnvConfig,
                redisService);
        List<String> result = invoker.invoke(minSize, new RecommendAdvanceRequest(), Sets.newHashSet());
        Set<String> expectedResult = largeSizeRecall.recall(minSize, new RecommendAdvanceRequest());

        Assert.assertEquals(expectedResult.size(), minSize);
        Assert.assertEquals(expectedResult.size(), result.size());
        Assert.assertNotEquals(expectedResult, Sets.newHashSet(result));
    }


    //case: recall enough but filter and run max recall
    @Test
    public void testStrictFilter() {
        int minSize = 100;
        BaseInvoker invoker = new BaseInvoker(largeSizeRecall,
                Arrays.asList(commonReagentA, commonReagentB),
                Arrays.asList(onlyOneItemFilterStrategy),
                commonSortStrategy,
                invokerEnvConfig,
                redisService);
        List<String> result = invoker.invoke(minSize, new RecommendAdvanceRequest(), Sets.newHashSet());

        Assert.assertEquals(invokerEnvConfig.getMaxRecallTime(), result.size());
    }

}
