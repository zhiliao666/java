package com.ufoto;

import com.google.common.collect.Lists;
import com.google.common.collect.Sets;
import com.google.common.hash.BloomFilter;
import com.google.common.hash.Funnels;
import com.ufoto.dto.ConditionRequest;
import com.ufoto.dto.FilterRequestDto;
import com.ufoto.mq.kafka.HighRiskMsg;
import com.ufoto.utils.DateUtil;
import com.ufoto.utils.json.JSONUtil;
import org.apache.commons.lang3.RandomUtils;
import org.junit.Test;
import org.springframework.util.CollectionUtils;
import org.springframework.web.client.RestTemplate;

import java.util.ArrayList;
import java.util.List;
import java.util.Map;
import java.util.stream.Collectors;
import java.util.stream.IntStream;

import static org.junit.Assert.assertFalse;
import static org.junit.Assert.assertTrue;

/**
 * <p>
 *
 * </p>
 *
 * @author created by chenzhou at 2018-08-14 10:51
 */
public class CommonTest {

    @Test
    public void test01() {
        RestTemplate restTemplate = new RestTemplate();
        IntStream.range(0, 20).parallel().forEach(i -> {
            restTemplate.getForEntity("http://54.208.210.215:2233/snsActApi/recommend?uid=613", Object.class);
        });
    }

    @Test
    public void test02() {
        System.out.println(Sets.newHashSet("123", null));
    }

    @Test
    public void testBoom() {
        long a = Long.valueOf(Integer.MAX_VALUE);
        long b = a + 1;
        long c = a + 2;
        long d = a * 4;
        int bi = (int) b;
        int ci = (int) c;
        int di = (int) d;

        System.out.println(Long.toHexString(a));
        System.out.println(Long.toHexString(b));
        System.out.println(Long.toHexString(c));
        System.out.println(Long.toHexString(d));
        System.out.println(Integer.toHexString(bi));
        System.out.println(Integer.toHexString(ci));
        System.out.println(Integer.toHexString(di));


        BloomFilter<Integer> filter = BloomFilter.create(Funnels.integerFunnel(),
                5, 0.001);
        IntStream.range(0, 100000).forEach(filter::put);

        assertTrue(filter.mightContain(1));
        assertTrue(filter.mightContain(2));
        assertTrue(filter.mightContain(3));
        assertFalse(filter.mightContain(100000));
    }

    @Test
    public void generateFilterRequestDto() {
        String json = "[366328164751769601, 366382133750530049, 366351488332595201, 366462383763226625, 366368389729353729, 366464171002298369, 366385812637483009, 366352564473561089, 366389768533049345, 366411079741341697, 366430614926131201, 366454472861286401, 366001292419530753, 366462339483959297, 366440389839683585, 366423293428760577, 366311512446337025, 366417431482073089, 366435344150691841, 366450794536370177, 366459649215430657, 366426074357170177, 366407788684902401, 363002919672348673, 366284134294749185, 365796571687682049, 366368146992398337, 366371698703859713, 366370514412765185, 365977049732481025, 366313906009800705, 366405149217783809, 366455860777451521, 366373908540030977, 366287777886633985, 366443038815289345, 366380235945410561, 366383399381762049, 366212074444947457, 366376781940260865, 366453010450087937, 366440877691764737, 366430331638644737, 366329952770981889, 366356331323457537, 366424988837740545, 366376919383408641, 366362072792956929, 366427297810481153, 366378535448739841, 366405068171247617, 366454538346954753, 366228180622639105, 366349798594314241, 366428358289915905, 366398714194952193, 366441699242672129, 366404713182134273, 366461172309819393, 366372680267464705, 366172258424586241, 366308928218202113, 365928876213272577, 366236851406635009, 366446873302532097, 366398540953419777, 366448951060070401, 366435391374360577, 366316725026684929, 366370305767112705, 366205329316249601, 364670806959063041, 366408621182943233, 366388153344327681, 366396615872741377, 366449723088830465, 366355381418459137, 366341990582845441, 366379367225360385, 366355212497059841, 366455729080500225, 366396303929769985, 366460198962855937, 366384576232161281, 366432135805927425, 366381302024241153, 366405102405156865, 366412608569344001, 366424844385910785, 366426131840106497, 366434474876993537, 366364130103263233, 366441268265353217, 366444405927706625, 365838580796358657, 366437504158531585, 366320777756147713, 366377409244561409, 366418351628484609, 366407775745474561, 366420840201322497, 366410501460066305, 366443494807437313, 366397109445853185, 366453695346376705, 366439198573461505, 366434691097559041, 366361752683675649, 366392137568223233, 366414736562061313, 366437309530243073, 366392437439987713, 366464253491675137, 366440284990472193, 366311117594558465, 366440422572032001, 366287672450220033, 366347003157807105, 366394365695754241]";
        final List<String> list = JSONUtil.toList(json, String.class);
        final FilterRequestDto dto = FilterRequestDto.builder().recallUids(Sets.newHashSet(list)).build();
        System.out.println(JSONUtil.toJSON(dto));
    }

    @Test
    public void testConditionRequest() {
        ConditionRequest conditionRequest = new ConditionRequest();
        conditionRequest.setUid(100L);
        System.out.println(JSONUtil.toJSON(conditionRequest));
    }

    @Test
    public void testGroup() {
        List<HighRiskMsg> list = Lists.newArrayList();
        for (int i = 0; i < 100; i++) {
            HighRiskMsg highRiskMsg = new HighRiskMsg();
            highRiskMsg.setLayered(RandomUtils.nextInt(1, 10));
            highRiskMsg.setUid(i + 100L);
            highRiskMsg.setTimestamp(DateUtil.getCurrentSecondIntValue());
            list.add(highRiskMsg);
        }
        final Map<Boolean, List<HighRiskMsg>> map = list.stream().collect(Collectors.groupingBy(r -> r.getLayered() % 2 == 0));
        System.out.println(map);
    }

    private void removeEmptyIndex(List<List<String>> subUidList, List<Integer> assembleWeightList) {
        int remove = 0;
        for (int i = 0; i < subUidList.size(); i++) {
            final List<String> list = subUidList.get(i);
            if (CollectionUtils.isEmpty(list)) {
                remove++;
                subUidList.remove(i);
                assembleWeightList.remove(i);
                i--;
            }
        }
    }

    @Test
    public void testAssemble() {

        List<List<String>> subUidList = new ArrayList<>();
        subUidList.add(Lists.newArrayList("2", "1"));
        subUidList.add(Lists.newArrayList());
        subUidList.add(Lists.newArrayList("122", "3232"));
        subUidList.add(Lists.newArrayList());
        subUidList.add(Lists.newArrayList());

        List<Integer> assembleWeightList = new ArrayList<>();
        assembleWeightList.add(1);
        assembleWeightList.add(1);
        assembleWeightList.add(1);
        assembleWeightList.add(1);
        assembleWeightList.add(1);

        removeEmptyIndex(subUidList, assembleWeightList);

        List<List<String>> copySubUidList = Lists.newLinkedList(subUidList);
        List<Integer> copyWeightList = Lists.newLinkedList(assembleWeightList);
        List<String> result = Lists.newLinkedList();
        Integer totalWeight = copyWeightList.stream().reduce(0, Integer::sum);
        int totalSize = copySubUidList.stream().mapToInt(List::size).sum();

        for (int _ = 0; _ < totalSize; _++) {
            Integer rand = org.apache.commons.lang.math.RandomUtils.nextInt(totalWeight);
            for (int i = 0; i < copyWeightList.size(); i++) {
                if (rand < copyWeightList.get(i) && copySubUidList.get(i).size() > 0) {
                    result.add(copySubUidList.get(i).get(0));
                    copySubUidList.get(i).remove(0);
                    if (copySubUidList.get(i).size() == 0) {
                        copySubUidList.remove(i);
                        totalWeight -= copyWeightList.get(i);
                        copyWeightList.remove(i);
                    }
                    break;
                }
                rand -= copyWeightList.get(i);
            }
        }

        System.out.println(result);
        System.out.println(copySubUidList);
    }
}
