package com.ufoto.utils.redis;

import com.ufoto.BaseUnitTest;
import org.junit.Assert;
import org.junit.Test;
import org.springframework.beans.factory.annotation.Autowired;

/**
 * <p>
 * Author     : Chan
 * CreateDate : 2019-10-11 13:04
 * Description:
 * </p>
 */
public class RedisLockTest extends BaseUnitTest {

    @Autowired
    private RedisService redisService;

    @Test
    public void tryGetDistributedLock() throws Exception {
        final boolean lock = RedisLock.tryGetDistributedLock(redisService, "test_lock1", "aaa:bbb", 50);
        Thread.sleep(10000);
        final boolean releaseDistributedLock = RedisLock.releaseDistributedLock(redisService, "test_lock1", "aaa:bbb");
        Assert.assertTrue(lock);
        Assert.assertTrue(releaseDistributedLock);
    }

    @Test
    public void releaseDistributedLock() {
        final boolean releaseDistributedLock = RedisLock.releaseDistributedLock(redisService, "test_lock", "aaa:bbb");
        Assert.assertTrue(releaseDistributedLock);
    }
}
