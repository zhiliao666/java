package com.ufoto.business.recommend.shuffle.dealer;

import org.apache.commons.lang.math.RandomUtils;
import org.junit.Assert;
import org.junit.Test;

import static org.junit.Assert.*;

/**
 * Created by echo on 3/30/19.
 */
public class DealChatBotDealerTest {

    @Test
    public void testRandom(){
        int maxChatBotCount = 2;
        int minChatBotCount = 2;
        for(int i=0;i<100;i++){
            int chatBotCount = RandomUtils.nextInt(maxChatBotCount - minChatBotCount+1)+minChatBotCount;
            System.out.println(chatBotCount);
            Assert.assertTrue(chatBotCount>=minChatBotCount && chatBotCount<=maxChatBotCount);
        }

        maxChatBotCount = 10;
        minChatBotCount = 2;
        for(int i=0;i<100;i++){
            int chatBotCount = RandomUtils.nextInt(maxChatBotCount - minChatBotCount+1)+minChatBotCount;
            System.out.println(chatBotCount);
            Assert.assertTrue(chatBotCount>=minChatBotCount && chatBotCount<=maxChatBotCount);
        }
    }
}