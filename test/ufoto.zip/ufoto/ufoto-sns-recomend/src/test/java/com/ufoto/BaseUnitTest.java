package com.ufoto;

import com.google.common.collect.Lists;
import com.google.common.collect.Maps;
import com.google.common.collect.Sets;
import com.ufoto.utils.json.JSONUtil;
import org.apache.commons.lang.math.RandomUtils;
import org.junit.Before;
import org.junit.runner.RunWith;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.context.SpringBootTest;
import org.springframework.http.MediaType;
import org.springframework.mock.web.MockHttpServletResponse;
import org.springframework.test.context.ActiveProfiles;
import org.springframework.test.context.junit4.SpringRunner;
import org.springframework.test.web.servlet.MockMvc;
import org.springframework.test.web.servlet.MvcResult;
import org.springframework.test.web.servlet.setup.MockMvcBuilders;
import org.springframework.web.context.WebApplicationContext;

import java.util.List;
import java.util.Map;
import java.util.Objects;
import java.util.Set;
import java.util.stream.Collectors;

import static org.springframework.test.web.servlet.request.MockMvcRequestBuilders.get;
import static org.springframework.test.web.servlet.request.MockMvcRequestBuilders.post;

/**
 * 继承基准测试类
 *
 * @author luozq
 * @date 18-7-12
 */
@ActiveProfiles("dev")
@RunWith(SpringRunner.class)
@SpringBootTest
public class BaseUnitTest {

    private Logger logger = LoggerFactory.getLogger(this.getClass());

    @Autowired
    private WebApplicationContext context;

    protected MockMvc mockMvc;

    @Before
    public void letUsMakeALongNameSoThatNoOneWillConflictWithSubClassFuckIt() {
        mockMvc = MockMvcBuilders.webAppContextSetup(context).build();
    }

    /**
     * get 提交
     *
     * @param url
     * @return
     */
    protected MvcResult launchGetRequset(String url) {
        MvcResult result = null;
        try {
            result = mockMvc.perform(get(url)).andReturn();
            MockHttpServletResponse response = result.getResponse();
            logger.info("result is:{}", response.getContentAsString());

        } catch (Exception e) {
            logger.error("异常信息e:{}", e);
        }
        return result;
    }

    /**
     * post提交
     *
     * @param url
     * @param data
     * @param <K>
     * @return
     */
    protected <K> MvcResult lauchPostRequest(String url, K data) {
        String json = Objects.requireNonNull(JSONUtil.toJSON(data));
        MvcResult result = null;
        try {
            result = mockMvc.perform(post(url).content(json).contentType(MediaType.APPLICATION_JSON_UTF8)).andReturn();
            MockHttpServletResponse response = result.getResponse();
            logger.info("result is:{}", response.getContentAsString());
        } catch (Exception e) {
            logger.error("异常信息e:{}", e);
        }
        return result;
    }

    protected Map<String, String> createRandomNoiseMap(int mapSize) {
        Map<String, String> result = Maps.newHashMap();
        while (result.size() < mapSize) {
            result.put(String.valueOf(RandomUtils.nextDouble()), String.valueOf(RandomUtils.nextDouble()));
        }
        return result;
    }

    protected List<String> createRandomNoiseList(int listSize) {
        List<String> result = Lists.newLinkedList();
        while (result.size() < listSize) {
            result.add(String.valueOf(RandomUtils.nextDouble()));
        }
        return result;
    }

    protected Set<String> createRandomNoiseSet(int setSize) {
        Set<String> result = Sets.newHashSet();
        while (result.size() < setSize) {
            result.add(String.valueOf(RandomUtils.nextDouble()));
        }
        return result;
    }

    protected String[] createRandomNoiseArray(int size) {
        return createRandomNoiseSet(size).toArray(new String[size]);
    }

    protected Set<Long> createRandomUidSet(int setSize) {
        Set<Long> result = Sets.newHashSet();
        while (result.size() < setSize) {
            result.add(RandomUtils.nextLong());
        }
        return result;
    }

    protected Set<String> createRandomUidStringSet(int setSize) {
        return createRandomUidSet(setSize).stream().map(x -> String.valueOf(x)).collect(Collectors.toSet());
    }

    protected String[] createRandomUidStringArray(int setSize) {
        return createRandomUidStringSet(setSize).toArray(new String[]{});
    }
}
