package com.ufoto.ufotosnsrecommend;

import com.ufoto.business.recommend.bean.SortParamsBean;
import com.ufoto.business.recommend.sort.fromOthers.FromOthersSortStrategy;
import org.assertj.core.util.Lists;
import org.junit.Test;
import org.junit.runner.RunWith;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.context.SpringBootTest;
import org.springframework.test.context.junit4.SpringRunner;

import java.util.List;
import java.util.Map;

@SpringBootTest
@RunWith(SpringRunner.class)
public class fromOthersTest {
    @Autowired
    FromOthersSortStrategy fromOthersSortStrategy;
    @Test
    public void fromOthersTest(){
        List<String> list = Lists.newArrayList();
        SortParamsBean sortParamsBean=new SortParamsBean();
        sortParamsBean.setUid(23L);
        list.add(701+"");
        list.add(702+"");
        list.add(703+"");
        list.add(704+"");
        list.add(705+"");
        Map<String, Double> score = fromOthersSortStrategy.getScore(list, sortParamsBean);
        score.forEach((a,b)->
            System.out.println(a+"_"+b)
        );

    }

}
