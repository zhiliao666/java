package com.ufoto.business.recommend.sort.lang;

import com.google.common.collect.Lists;
import com.ufoto.business.recommend.bean.SortParamsBean;
import com.ufoto.utils.redis.RedisKeyConstant;
import com.ufoto.utils.redis.RedisService;
import org.junit.Test;
import org.junit.runner.RunWith;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.context.SpringBootTest;
import org.springframework.test.context.junit4.SpringRunner;

import java.util.List;
import java.util.Map;

import static org.junit.Assert.*;

/**
 * Created by echo on 9/5/18.
 */
@SpringBootTest
@RunWith(SpringRunner.class)
public class SameLanguageSortStrategyTest {

    @Autowired
    private SameLanguageSortStrategy sameLanguageSortStrategy;


    @Autowired
    private RedisService redisService;


    /**
     * 测试BR和非BR情况的分数获取结果
     *
     */
    @Test
    public void  testBrOrNoneGetScore(){
        redisService.sadd(RedisKeyConstant.REDIS_REGION_USERS_SET_KEY_+"BR","2018090501");
        redisService.sadd(RedisKeyConstant.REDIS_REGION_USERS_SET_KEY_+"BR","2018090502");
        redisService.sadd(RedisKeyConstant.REDIS_REGION_USERS_SET_KEY_+"CN","2018090503");
        redisService.sadd(RedisKeyConstant.REDIS_REGION_USERS_SET_KEY_+"CN","2018090504");

        List<String> recallUids= Lists.newArrayList("2018090501","2018090502","2018090503","2018090504");
        SortParamsBean sortParamsBean=new SortParamsBean();
        sortParamsBean.setCountryCode("BR");

        Map<String, Double> result = sameLanguageSortStrategy.getScore(recallUids,sortParamsBean);
        assertEquals(result.get("2018090501"),1D,0.1D);
        assertEquals(result.get("2018090502"),1D,0.1D);
        assertEquals(result.get("2018090503"),0D,0.1D);
        assertEquals(result.get("2018090504"),0D,0.1D);


        sortParamsBean=new SortParamsBean();
        sortParamsBean.setCountryCode("CN");

        result = sameLanguageSortStrategy.getScore(recallUids,sortParamsBean);
        assertEquals(result.get("2018090501"),0D,0.1D);
        assertEquals(result.get("2018090502"),0D,0.1D);
        assertEquals(result.get("2018090503"),1D,0.1D);
        assertEquals(result.get("2018090504"),1D,0.1D);

        redisService.sremove(RedisKeyConstant.REDIS_REGION_USERS_SET_KEY_+"BR","2018090501");
        redisService.sremove(RedisKeyConstant.REDIS_REGION_USERS_SET_KEY_+"BR","2018090502");
        redisService.sremove(RedisKeyConstant.REDIS_REGION_USERS_SET_KEY_+"CN","2018090503");
        redisService.sremove(RedisKeyConstant.REDIS_REGION_USERS_SET_KEY_+"CN","2018090504");
    }
}