package com.ufoto.utils.redis;

import com.google.common.collect.Lists;
import com.ufoto.BaseUnitTest;
import lombok.extern.slf4j.Slf4j;
import org.apache.commons.lang.math.RandomUtils;
import org.junit.Assert;
import org.junit.Test;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.data.redis.core.DefaultTypedTuple;
import org.springframework.data.redis.core.ZSetOperations;

import java.util.List;
import java.util.Map;
import java.util.stream.Collectors;

/**
 * <p>
 * Author     : Chan
 * CreateDate : 2019-07-25 16:54
 * Description:
 * </p>
 */
@Slf4j
public class RedisServiceImplTest extends BaseUnitTest {
    @Autowired
    private RedisService redisService;

    @Test
    public void zscan() {
        String key = "test_zset";
        redisService.del(key);
        List<ZSetOperations.TypedTuple<String>> datas = Lists.newArrayList();
        for (int i = 0; i < 1000; i++) {
            datas.add(new DefaultTypedTuple<>(i + "", RandomUtils.nextDouble()));
            redisService.zadd(key, i + "", RandomUtils.nextDouble());
        }

        final List<ZSetOperations.TypedTuple<String>> tuples = redisService.zscan(key);
        Assert.assertEquals(datas.size(), tuples.size());

        final Map<Object, Double> collect = tuples.stream().collect(Collectors.toMap(ZSetOperations.TypedTuple::getValue, ZSetOperations.TypedTuple::getScore));
        for (ZSetOperations.TypedTuple<String> tuple : datas) {
            if (collect.get(tuple.getValue()) == null) {
                throw new RuntimeException("not equal");
            }
        }
        log.warn("tuples equals");
        redisService.del(key);
    }
}
