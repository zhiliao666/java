package com.ufoto.business.recommendNG.recall;

import com.ufoto.BaseUnitTest;
import com.ufoto.dto.RecommendAdvanceRequest;
import org.junit.Assert;
import org.junit.Test;
import org.springframework.beans.factory.annotation.Autowired;

import java.util.Set;

import static org.junit.Assert.*;

/**
 * Created by echo on 12/28/18.
 *
 * todo:非常不正经的测试，需要重写
 */
public class NGAreaSvdRecallTest extends BaseUnitTest{

    @Autowired
    NGAreaSvdRecall ngAreaSvdRecall;

    @Test
    public void testRecall(){
        //
        RecommendAdvanceRequest recallRequest = new RecommendAdvanceRequest();
        recallRequest.setUid(1L);
        Set<String> result = ngAreaSvdRecall.recall(1,recallRequest);
        Assert.assertTrue(!result.isEmpty());

        recallRequest.setUid(2L);
        result = ngAreaSvdRecall.recall(1,recallRequest);
        Assert.assertTrue(result.isEmpty());
    }

}