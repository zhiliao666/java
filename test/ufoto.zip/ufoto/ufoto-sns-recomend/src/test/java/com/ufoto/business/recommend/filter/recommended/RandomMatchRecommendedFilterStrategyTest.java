package com.ufoto.business.recommend.filter.recommended;

import com.google.common.collect.Lists;
import com.google.common.collect.Sets;
import com.ufoto.BaseUnitTest;
import com.ufoto.dto.RecommendAdvanceRequest;
import com.ufoto.service.RecommendService;
import com.ufoto.utils.RedisValueTransformUtil;
import com.ufoto.utils.redis.RedisKeyConstant;
import com.ufoto.utils.redis.RedisService;
import org.apache.commons.lang.math.RandomUtils;
import org.junit.Assert;
import org.junit.Test;
import org.springframework.beans.factory.annotation.Autowired;

import java.util.Set;
import java.util.stream.Collectors;

/**
 * Created by echo on 1/15/19.
 */
public class RandomMatchRecommendedFilterStrategyTest extends BaseUnitTest {

    @Autowired
    RecommendService recommendService;

    @Autowired
    RandomMatchRecommendedFilterStrategy randomMatchRecommendedFilterStrategy;

    @Autowired
    RedisService redisService;

    @Autowired
    RecommendedBFManager recommendedBFManager;

    @Test
    public void testFilter() {
        Long requestUid = 233L;
        //清理对应的RedisKey
        redisService.del(RedisKeyConstant.REDIS_BE_LIKED_SET_KEY_ + requestUid);
        redisService.del(RedisKeyConstant.REDIS_BE_SUPER_LIKED_SET_KEY_ + requestUid);
        redisService.del(RedisKeyConstant.REDIS_BE_UN_LIKED_SET_KEY_NEW + requestUid);
        recommendedBFManager.clean(requestUid);

        //所有当前用户已经看过的内容
        Set<Long> recommendedUidSet = createRandomUidSet(100);
        recommendedUidSet.remove(requestUid);
        //所有已经看过当前用户的其他用户
        Set<Long> beShownUidSet = createRandomUidSet(100);
        beShownUidSet.remove(requestUid);
        //随机生成一部分认为是被召回的内容
        Set<Long> someRecalledUidSet = createRandomUidSet(100);
        someRecalledUidSet.remove(requestUid);
        someRecalledUidSet.addAll(recommendedUidSet);
        someRecalledUidSet.addAll(beShownUidSet);
        Set<String> recallUidSet = someRecalledUidSet.stream().map(x -> String.valueOf(x)).collect(Collectors.toSet());
        //期望得到的返回值
        Set<Long> exceptLongResult = someRecalledUidSet;
        exceptLongResult.removeAll(recommendedUidSet);
        exceptLongResult.removeAll(beShownUidSet);
        Set<String> exceptResult = exceptLongResult.stream().map(x -> String.valueOf(x)).collect(Collectors.toSet());


        for (Long uid : recommendedUidSet) {
            recommendService.addRedisUserRecommended(requestUid, uid);
        }
        for (Long uid : beShownUidSet) {
            boolean ifLike = RandomUtils.nextBoolean();
            if (ifLike)
                recommendService.addRedisUserBeLiked(requestUid, uid);
            else
                recommendService.addRedisUserBeUnLiked(requestUid, uid);
        }

        RecommendAdvanceRequest request = new RecommendAdvanceRequest();
        request.setUid(requestUid);
        Set<String> result = randomMatchRecommendedFilterStrategy.filter(recallUidSet, Lists.newLinkedList(), request);

        Assert.assertEquals(exceptResult, result);
    }

    @Test
    public void testEmptyInput() {
        RecommendAdvanceRequest request = new RecommendAdvanceRequest();
        request.setUid(233L);
        Set<String> result = randomMatchRecommendedFilterStrategy.filter(Sets.newHashSet(), Lists.newLinkedList(), request);
        Assert.assertEquals(Sets.newHashSet(), result);

        result = randomMatchRecommendedFilterStrategy.filter(null, Lists.newLinkedList(), request);
        Assert.assertEquals(Sets.newHashSet(), result);
    }
}
