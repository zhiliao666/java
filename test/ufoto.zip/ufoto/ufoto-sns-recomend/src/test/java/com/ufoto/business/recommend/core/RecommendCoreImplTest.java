package com.ufoto.business.recommend.core;

import com.ufoto.dao.svd.UfotoSvdUserTopNMapper;
import org.junit.Test;
import org.junit.runner.RunWith;
import org.springframework.boot.test.context.SpringBootTest;
import org.springframework.boot.test.mock.mockito.MockBean;
import org.springframework.test.context.junit4.SpringRunner;

import static org.junit.Assert.*;

/**
 * Created by echo on 8/22/18.
 */
@SpringBootTest
@RunWith(SpringRunner.class)
public class RecommendCoreImplTest {


    @MockBean
    UfotoSvdUserTopNMapper ufotoSvdUserTopNMapper;

    @Test
    public void test(){

    }

}