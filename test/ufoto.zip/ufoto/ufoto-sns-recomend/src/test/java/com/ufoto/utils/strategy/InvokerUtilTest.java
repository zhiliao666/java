package com.ufoto.utils.strategy;

import com.google.common.collect.Lists;
import com.google.common.collect.Maps;
import com.ufoto.BaseUnitTest;
import com.ufoto.constants.EStrategyCategory;
import com.ufoto.business.recommend.sort.CompositeRecommendSortStrategy;
import com.ufoto.business.recommend.sort.SpecificRecommendSortStrategy;
import com.ufoto.business.recommend.sort.likeme.LikeMeSortStrategy;
import com.ufoto.business.recommend.sort.popular.PopularSortStrategy;
import com.ufoto.business.recommendNG.Invoker;
import com.ufoto.business.recommendNG.invoker.BaseInvoker;
import com.ufoto.business.recommendNG.invoker.ChainCompositeInvoker;
import com.ufoto.business.recommendNG.invoker.WeightCompositeInvoker;
import com.ufoto.business.recommendNG.reagent.ActIn24HoursReagent;
import com.ufoto.business.recommendNG.reagent.NewUserIn24HoursReagent;
import com.ufoto.business.recommendNG.recall.NGSvdRecall;
import com.ufoto.dto.CommonStrategyBean;
import org.junit.Assert;
import org.junit.Test;
import org.springframework.beans.factory.annotation.Autowired;

import java.util.Arrays;
import java.util.List;
import java.util.Map;
import java.util.stream.Collectors;

/**
 * Created by echo on 10/19/18.
 */
public class InvokerUtilTest extends BaseUnitTest{

    @Autowired
    private InvokerUtil invokerUtil;

    /**
     *  测试没有对应recall的异常情况
     */
    @Test(expected = RuntimeException.class)
    public void baseInvokerTestA() {
        CommonStrategyBean baseInvokerBean =
                commonStrategyBeanTemplate(EStrategyCategory.INVOKER.getCategory(),
                        "baseInvoker",null,null,null);

        List<CommonStrategyBean> children = Arrays.asList(
                commonStrategyBeanTemplate(EStrategyCategory.REAGENT.getCategory(),
                        "base",null,null,ActIn24HoursReagent.class.getName()),
                commonStrategyBeanTemplate(EStrategyCategory.REAGENT.getCategory(),
                        "base",null,null,NewUserIn24HoursReagent.class.getName())
        );
        baseInvokerBean.setChildren(children);

        Map<String,CommonStrategyBean> inputMap = Maps.newHashMap();
        inputMap.put(EStrategyCategory.INVOKER.getCategory(),baseInvokerBean);
        inputMap.put(EStrategyCategory.SORT.getCategory(),defaultSortStrategyBean());

        Invoker invoker = invokerUtil.createInvoker(inputMap,null);
    }

    /**
     *  测试没有对应reagent的异常情况
     */
    @Test(expected = RuntimeException.class)
    public void baseInvokerTestB() {
        CommonStrategyBean baseInvokerBean =
                commonStrategyBeanTemplate(EStrategyCategory.INVOKER.getCategory(),
                        "baseInvoker",null,null,null);

        List<CommonStrategyBean> children = Arrays.asList(
                commonStrategyBeanTemplate(EStrategyCategory.RECALL.getCategory(),
                        "base",null,null,NGSvdRecall.class.getName())
        );
        baseInvokerBean.setChildren(children);

        Map<String,CommonStrategyBean> inputMap = Maps.newHashMap();
        inputMap.put(EStrategyCategory.INVOKER.getCategory(),baseInvokerBean);
        inputMap.put(EStrategyCategory.SORT.getCategory(),defaultSortStrategyBean());

        Invoker invoker = invokerUtil.createInvoker(inputMap,null);
    }

    /**
     *  测试没有对应sort的异常情况
     */
    @Test(expected = RuntimeException.class)
    public void baseInvokerTestC() {
        CommonStrategyBean baseInvokerBean =
                commonStrategyBeanTemplate(EStrategyCategory.INVOKER.getCategory(),
                        "baseInvoker",null,null,null);

        List<CommonStrategyBean> children = Arrays.asList(
                commonStrategyBeanTemplate(EStrategyCategory.RECALL.getCategory(),
                        "base",null,null,NGSvdRecall.class.getName()),
                commonStrategyBeanTemplate(EStrategyCategory.REAGENT.getCategory(),
                        "base",null,null,ActIn24HoursReagent.class.getName()),
                commonStrategyBeanTemplate(EStrategyCategory.REAGENT.getCategory(),
                        "base",null,null,NewUserIn24HoursReagent.class.getName())
        );
        baseInvokerBean.setChildren(children);

        Map<String,CommonStrategyBean> inputMap = Maps.newHashMap();
        inputMap.put(EStrategyCategory.INVOKER.getCategory(),baseInvokerBean);
//        inputMap.put(EStrategyCategory.SORT.getCategory(),defaultSortStrategyBean());

        Invoker invoker = invokerUtil.createInvoker(inputMap,null);
    }

    /**
     *  正常情况
     */
    @Test()
    public void baseInvokerTestD() {
        CommonStrategyBean baseInvokerBean =
                commonStrategyBeanTemplate(EStrategyCategory.INVOKER.getCategory(),
                        "baseInvoker",null,null,null);

        List<String> reagentClassNameList = Arrays.asList(
                ActIn24HoursReagent.class.getName(),
                NewUserIn24HoursReagent.class.getName()
        );
        List<CommonStrategyBean> children = Arrays.asList(
                commonStrategyBeanTemplate(EStrategyCategory.RECALL.getCategory(),
                        "base",null,null,NGSvdRecall.class.getName()),
                commonStrategyBeanTemplate(EStrategyCategory.REAGENT.getCategory(),
                        "base",null,null,reagentClassNameList.get(0)),
                commonStrategyBeanTemplate(EStrategyCategory.REAGENT.getCategory(),
                        "base",null,null,reagentClassNameList.get(1))
        );
        baseInvokerBean.setChildren(children);

        Map<String,CommonStrategyBean> inputMap = Maps.newHashMap();
        inputMap.put(EStrategyCategory.INVOKER.getCategory(),baseInvokerBean);
        inputMap.put(EStrategyCategory.SORT.getCategory(),defaultSortStrategyBean());

        BaseInvoker invoker = (BaseInvoker) invokerUtil.createInvoker(inputMap,null);
        Assert.assertEquals(invoker.getRecallStrategy().getClass(),NGSvdRecall.class );
        Assert.assertEquals(reagentClassNameList.size(),invoker.getReagentList().size());
        Assert.assertTrue(reagentClassNameList.contains(invoker.getReagentList().get(0).getClass().getName()));
        Assert.assertTrue(reagentClassNameList.contains(invoker.getReagentList().get(1).getClass().getName()));
        Assert.assertTrue(invoker.getRecommendSortStrategy() instanceof CompositeRecommendSortStrategy);
        Map<SpecificRecommendSortStrategy,Double> sortBeanMap  = ((CompositeRecommendSortStrategy)invoker.getRecommendSortStrategy()).getSortStrategyWeightMap();
        Assert.assertEquals(sortBeanMap.size(),getDefaultSortBeanNameList().size());
        for(String sortClassName : sortBeanMap.keySet().stream().map(x->x.getClass().getName()).collect(Collectors.toList())){
            boolean flag = false;
            for(String defaultClassName : getDefaultSortBeanNameList()){
                if(sortClassName.startsWith(defaultClassName)){
                    flag = true;
                    break;
                }
            }
            Assert.assertTrue(flag);
        }
        Assert.assertEquals(getDefaultSortBeanWeightList().size() , sortBeanMap.size());
    }

    /**
     *  正常情况
     */
    @Test()
    public void baseInvokerTestE() {
        CommonStrategyBean baseInvokerBean =
                commonStrategyBeanTemplate(EStrategyCategory.INVOKER.getCategory(),
                        "baseInvoker",null,null,null);

        List<String> reagentClassNameList = Arrays.asList(
                ActIn24HoursReagent.class.getName()
        );
        List<CommonStrategyBean> children = Arrays.asList(
                commonStrategyBeanTemplate(EStrategyCategory.RECALL.getCategory(),
                        "base",null,null,NGSvdRecall.class.getName()),
                commonStrategyBeanTemplate(EStrategyCategory.REAGENT.getCategory(),
                        "base",null,null,reagentClassNameList.get(0))
        );
        baseInvokerBean.setChildren(children);

        Map<String,CommonStrategyBean> inputMap = Maps.newHashMap();
        inputMap.put(EStrategyCategory.INVOKER.getCategory(),baseInvokerBean);
        inputMap.put(EStrategyCategory.SORT.getCategory(),defaultSortStrategyBean());

        BaseInvoker invoker = (BaseInvoker) invokerUtil.createInvoker(inputMap,null);
        Assert.assertEquals(invoker.getRecallStrategy().getClass(),NGSvdRecall.class );
        Assert.assertEquals(reagentClassNameList.size(),invoker.getReagentList().size());
        Assert.assertTrue(reagentClassNameList.contains(invoker.getReagentList().get(0).getClass().getName()));
        Assert.assertTrue(invoker.getRecommendSortStrategy() instanceof CompositeRecommendSortStrategy);
        Map<SpecificRecommendSortStrategy,Double> sortBeanMap  = ((CompositeRecommendSortStrategy)invoker.getRecommendSortStrategy()).getSortStrategyWeightMap();
        Assert.assertEquals(sortBeanMap.size(),getDefaultSortBeanNameList().size());
        for(String sortClassName : sortBeanMap.keySet().stream().map(x->x.getClass().getName()).collect(Collectors.toList())){
            boolean flag = false;
            for(String defaultClassName : getDefaultSortBeanNameList()){
                if(sortClassName.startsWith(defaultClassName)){
                    flag = true;
                    break;
                }
            }
            Assert.assertTrue(flag);
        }
        Assert.assertEquals(getDefaultSortBeanWeightList().size() , sortBeanMap.size());
    }

    /**
     * 没有children的组合节点
     */
    @Test(expected = RuntimeException.class)
    public void compositeInvokerTestA() {
        CommonStrategyBean rootInvoker = commonStrategyBeanTemplate(EStrategyCategory.INVOKER.getCategory(),
                "composite",null,null,null);

//        List<CommonStrategyBean> children = Lists.newArrayList(
//                createDefaultBaseInvoker(),
//                createDefaultBaseInvoker(),
//                createDefaultBaseInvoker()
//        );
//        rootInvoker.setChildren(children);

        Map<String,CommonStrategyBean> inputMap = Maps.newHashMap();
        inputMap.put(EStrategyCategory.INVOKER.getCategory(),rootInvoker);
        inputMap.put(EStrategyCategory.SORT.getCategory(),defaultSortStrategyBean());

        Invoker invoker = invokerUtil.createInvoker(inputMap,null);
    }

    /**
     * 有children的组合节点(1个）
     */
    @Test()
    public void compositeInvokerTestB() {
        CommonStrategyBean rootInvoker = commonStrategyBeanTemplate(EStrategyCategory.INVOKER.getCategory(),
                "composite",null,null,null);

        List<CommonStrategyBean> children = Lists.newArrayList(
//                createDefaultBaseInvoker(),
//                createDefaultBaseInvoker(),
                createDefaultBaseInvoker()
        );
        rootInvoker.setChildren(children);

        Map<String,CommonStrategyBean> inputMap = Maps.newHashMap();
        inputMap.put(EStrategyCategory.INVOKER.getCategory(),rootInvoker);
        inputMap.put(EStrategyCategory.SORT.getCategory(),defaultSortStrategyBean());

        ChainCompositeInvoker invoker = (ChainCompositeInvoker) invokerUtil.createInvoker(inputMap,null);
        Assert.assertEquals(invoker.getChildren().size(),children.size());
    }

    /**
     * 有children的组合节点(n个）
     */
    @Test()
    public void compositeInvokerTestC() {
        CommonStrategyBean rootInvoker = commonStrategyBeanTemplate(EStrategyCategory.INVOKER.getCategory(),
                "composite",null,null,null);

        List<CommonStrategyBean> children = Lists.newArrayList(
                createDefaultBaseInvoker(),
                createDefaultBaseInvoker(),
                createDefaultBaseInvoker(),
                createDefaultBaseInvoker()
        );
        rootInvoker.setChildren(children);

        Map<String,CommonStrategyBean> inputMap = Maps.newHashMap();
        inputMap.put(EStrategyCategory.INVOKER.getCategory(),rootInvoker);
        inputMap.put(EStrategyCategory.SORT.getCategory(),defaultSortStrategyBean());

        ChainCompositeInvoker invoker = (ChainCompositeInvoker) invokerUtil.createInvoker(inputMap,null);
        Assert.assertEquals(invoker.getChildren().size(),children.size());
    }


    /**
     * 无children的权重组合节点
     */
    @Test(expected = RuntimeException.class)
    public void weightInvokerTestA() {
        CommonStrategyBean rootInvoker = commonStrategyBeanTemplate(EStrategyCategory.INVOKER.getCategory(),
                "weight",null,null,null);

        Map<String,CommonStrategyBean> inputMap = Maps.newHashMap();
        inputMap.put(EStrategyCategory.INVOKER.getCategory(),rootInvoker);
        inputMap.put(EStrategyCategory.SORT.getCategory(),defaultSortStrategyBean());

        Invoker invoker =  invokerUtil.createInvoker(inputMap,null);
    }

    /**
     * children的权重异常
     */
    @Test(expected = RuntimeException.class)
    public void weightInvokerTestB() {
        CommonStrategyBean rootInvoker = commonStrategyBeanTemplate(EStrategyCategory.INVOKER.getCategory(),
                "weight",null,null,null);

        List<CommonStrategyBean> children = Lists.newArrayList(
                createDefaultBaseInvoker(),
                createDefaultBaseInvoker(),
                createDefaultBaseInvoker(),
                createDefaultBaseInvoker()
        );
        children.get(0).setAssembleWeight(10);
        children.get(0).setWeight(10F);
        rootInvoker.setChildren(children);

        Map<String,CommonStrategyBean> inputMap = Maps.newHashMap();
        inputMap.put(EStrategyCategory.INVOKER.getCategory(),rootInvoker);
        inputMap.put(EStrategyCategory.SORT.getCategory(),defaultSortStrategyBean());

        Invoker invoker =  invokerUtil.createInvoker(inputMap,null);
    }

    /**
     * children的权重非法
     */
    @Test(expected = RuntimeException.class)
    public void weightInvokerTestC() {
        CommonStrategyBean rootInvoker = commonStrategyBeanTemplate(EStrategyCategory.INVOKER.getCategory(),
                "weight",null,null,null);

        List<CommonStrategyBean> children = Lists.newArrayList(
                createDefaultBaseInvoker()
        );
        children.get(0).setAssembleWeight(-10);
        children.get(0).setWeight(0.25F);
        rootInvoker.setChildren(children);

        Map<String,CommonStrategyBean> inputMap = Maps.newHashMap();
        inputMap.put(EStrategyCategory.INVOKER.getCategory(),rootInvoker);
        inputMap.put(EStrategyCategory.SORT.getCategory(),defaultSortStrategyBean());

        Invoker invoker =  invokerUtil.createInvoker(inputMap,null);
    }

    /**
     * 正常
     */
    @Test()
    public void weightInvokerTestD() {
        CommonStrategyBean rootInvoker = commonStrategyBeanTemplate(EStrategyCategory.INVOKER.getCategory(),
                "weight",null,null,null);

        List<CommonStrategyBean> children = Lists.newArrayList(
                createDefaultBaseInvoker(),
                createDefaultBaseInvoker(),
                createDefaultBaseInvoker()
        );
        children.get(0).setAssembleWeight(10);
        children.get(0).setWeight(0.25F);
        children.get(1).setAssembleWeight(1);
        children.get(1).setWeight(0.75F);
        children.get(2).setAssembleWeight(100);
        children.get(2).setWeight(25F);
        rootInvoker.setChildren(children);

        Map<String,CommonStrategyBean> inputMap = Maps.newHashMap();
        inputMap.put(EStrategyCategory.INVOKER.getCategory(),rootInvoker);
        inputMap.put(EStrategyCategory.SORT.getCategory(),defaultSortStrategyBean());

        WeightCompositeInvoker invoker = (WeightCompositeInvoker) invokerUtil.createInvoker(inputMap,null);
        Assert.assertEquals(invoker.getChildren().size(),invoker.getAssembleWeightList().size());
        Assert.assertEquals(invoker.getChildren().size(),invoker.getWeightList().size());
        Assert.assertEquals(invoker.getChildren().size(),children.size());
        Assert.assertTrue(invoker.getAssembleWeightList().containsAll(children.stream().map(x->x.getAssembleWeight()).collect(Collectors.toList())));
    }


    private CommonStrategyBean commonStrategyBeanTemplate(String category,String type,
                                            Float weight,Integer assembleWeight,
                                            String strategy){
        CommonStrategyBean commonStrategyBean = new CommonStrategyBean();
//        commonStrategyBean.setId(null);
        commonStrategyBean.setCategory(category);
        commonStrategyBean.setType(type);
        commonStrategyBean.setWeight(weight);
        commonStrategyBean.setAssembleWeight(assembleWeight);
        commonStrategyBean.setStrategy(strategy);
//        commonStrategyBean.setPath(null);
//        commonStrategyBean.setChildren(null);

        return commonStrategyBean;
    }

    private CommonStrategyBean defaultSortStrategyBean(){
        CommonStrategyBean rootBean = commonStrategyBeanTemplate(EStrategyCategory.SORT.getCategory(),
                "weight",null,null,null);

        List<CommonStrategyBean> children = Lists.newLinkedList();
        Arrays.asList(
                commonStrategyBeanTemplate(EStrategyCategory.SORT.getCategory(),
                        "base",10F,null,LikeMeSortStrategy.class.getName()),
                commonStrategyBeanTemplate(EStrategyCategory.SORT.getCategory(),
                        "base",-0.01F,null,PopularSortStrategy.class.getName())
        );
        List<String> nameList = getDefaultSortBeanNameList();
        List<Float> weightList = getDefaultSortBeanWeightList();
        for(int i =0;i<nameList.size();i++){
            children.add(commonStrategyBeanTemplate(EStrategyCategory.SORT.getCategory(),
                    "base",weightList.get(i),null,nameList.get(i))) ;
        }
        rootBean.setChildren(children);

        return rootBean;
    }

    private List<String> getDefaultSortBeanNameList(){
        return Arrays.asList(LikeMeSortStrategy.class.getName(),PopularSortStrategy.class.getName());
    }

    private List<Float> getDefaultSortBeanWeightList(){
        return Arrays.asList(10F,-0.01F);
    }

    private CommonStrategyBean createDefaultBaseInvoker(){

        CommonStrategyBean baseInvokerBean =
                commonStrategyBeanTemplate(EStrategyCategory.INVOKER.getCategory(),
                        "baseInvoker",null,null,null);

        List<String> reagentClassNameList = Arrays.asList(
                ActIn24HoursReagent.class.getName()
        );
        List<CommonStrategyBean> children = Arrays.asList(
                commonStrategyBeanTemplate(EStrategyCategory.RECALL.getCategory(),
                        "base",null,null,NGSvdRecall.class.getName()),
                commonStrategyBeanTemplate(EStrategyCategory.REAGENT.getCategory(),
                        "base",null,null,reagentClassNameList.get(0))
        );
        baseInvokerBean.setChildren(children);

        Map<String,CommonStrategyBean> inputMap = Maps.newHashMap();
        inputMap.put(EStrategyCategory.INVOKER.getCategory(),baseInvokerBean);
        inputMap.put(EStrategyCategory.SORT.getCategory(),defaultSortStrategyBean());

        return baseInvokerBean;
    }


}
