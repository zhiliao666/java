package com.ufoto.business.recommend.filter.nohead;

import com.google.common.collect.Lists;
import com.google.common.collect.Sets;
import com.ufoto.BaseUnitTest;
import com.ufoto.dto.RecommendAdvanceRequest;
import com.ufoto.utils.redis.RedisKeyConstant;
import com.ufoto.utils.redis.RedisService;
import org.junit.Assert;
import org.junit.Test;
import org.springframework.beans.factory.annotation.Autowired;

import java.util.HashSet;
import java.util.Set;

import static org.junit.Assert.*;

/**
 * Created by echo on 10/25/18.
 */
public class NoHeadFilterStrategyTest extends BaseUnitTest{

    @Autowired
    NoHeadFilterStrategy ngNoHeadFilterStrategy;

    @Autowired
    RedisService redisService;

    @Test
    public void testFilter(){
        Set<String> noHeadUserSet = Sets.newHashSet("100","101","102");
        Set<String> recallUserSet = Sets.newHashSet("99","100","101");
        Set<String> expectedSet = Sets.newHashSet(recallUserSet);
        expectedSet.removeAll(noHeadUserSet);

        redisService.sadd(RedisKeyConstant.REDIS_NO_HEAD_USER_SET_KEY,noHeadUserSet.toArray(new String[]{}));
        ngNoHeadFilterStrategy.updateCache();
        Set<String> result = ngNoHeadFilterStrategy.filter(recallUserSet,
                Lists.newLinkedList(),
                new RecommendAdvanceRequest());

        Assert.assertEquals(expectedSet,result);
    }

    @Test
    public void testEmptyRecallFilter(){
        Set<String> noHeadUserSet = Sets.newHashSet("100","101","102");
        Set<String> recallUserSet = Sets.newHashSet();
        Set<String> expectedSet = Sets.newHashSet(recallUserSet);
        expectedSet.removeAll(noHeadUserSet);

        redisService.sadd(RedisKeyConstant.REDIS_NO_HEAD_USER_SET_KEY,noHeadUserSet.toArray(new String[]{}));
        Set<String> result = ngNoHeadFilterStrategy.filter(recallUserSet,
                Lists.newLinkedList(),
                new RecommendAdvanceRequest());

        Assert.assertEquals(expectedSet,result);

        noHeadUserSet = Sets.newHashSet("100","101","102");
        recallUserSet = null;

        redisService.sadd(RedisKeyConstant.REDIS_NO_HEAD_USER_SET_KEY,noHeadUserSet.toArray(new String[]{}));
        ngNoHeadFilterStrategy.updateCache();
        result = ngNoHeadFilterStrategy.filter(recallUserSet,
                Lists.newLinkedList(),
                new RecommendAdvanceRequest());

        Assert.assertEquals(Sets.newHashSet(),result);
    }

}