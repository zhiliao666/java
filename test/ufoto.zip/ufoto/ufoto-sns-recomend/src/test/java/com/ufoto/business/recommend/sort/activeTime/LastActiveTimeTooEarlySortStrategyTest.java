package com.ufoto.business.recommend.sort.activeTime;

import com.google.common.collect.Lists;
import com.ufoto.BaseUnitTest;
import com.ufoto.business.recommend.bean.SortParamsBean;
import com.ufoto.utils.DateUtil;
import com.ufoto.utils.redis.RedisKeyConstant;
import com.ufoto.utils.redis.RedisService;
import org.junit.Assert;
import org.junit.Before;
import org.junit.Test;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.core.env.Environment;

import java.util.List;
import java.util.Map;

/**
 * Created by echo on 11/28/18.
 */
public class LastActiveTimeTooEarlySortStrategyTest extends BaseUnitTest{

    @Autowired
    RedisService redisService;

    @Autowired
    LastActiveTimeTooEarlySortStrategy lastActiveTimeTooEarlySortStrategy;

    @Autowired
    private Environment env;

    SortParamsBean normalSortParamsBean;

    SortParamsBean noLastActTimeSortParamsBean;//发起请求的用户没有生日信息

    List<String> normalUidList= Lists.newArrayList("1","2","3","4","5","6","7","8","9","10","11","12","13","14","15","16","17","18","28");

    List<String> noLastActTimeUidList = Lists.newArrayList("1001","1002","1003","1004","1005","1006");

    /**
     * 有活跃时间的请求用户
     */
    @Test
    public void testNormalGetScore(){
        int threshold = env.getProperty("recommend.sort.LastActiveTimeTooEarlySortStrategy.threshold", Integer.class, 60*60*8);//默认8小时
        List<String> allUidList = Lists.newLinkedList(normalUidList);
        allUidList.addAll(noLastActTimeUidList);
        Map<String, Double> result = lastActiveTimeTooEarlySortStrategy.getScore(allUidList,normalSortParamsBean);
        for(Map.Entry<String,Double> entry : result.entrySet()){
            Long itemId = Long.valueOf(entry.getKey());
            if(itemId<1000){
                Double expected = itemId*60*60>threshold?1D:0D;
                Assert.assertEquals(
                        expected,
                        entry.getValue(),
                        0.1D);
            }else{
                Assert.assertEquals(
                        0D,
                        entry.getValue(),
                        0.1D);
            }
        }

    }


}
