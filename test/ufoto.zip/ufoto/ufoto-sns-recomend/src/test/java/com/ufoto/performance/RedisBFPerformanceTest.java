package com.ufoto.performance;

import com.google.common.base.Charsets;
import com.google.common.collect.Sets;
import com.google.common.hash.BloomFilter;
import com.google.common.hash.Funnels;
import com.ufoto.BaseUnitTest;
import com.ufoto.business.recommend.filter.recommended.RecommendedBFManager;
import com.ufoto.utils.redis.RedisService;
import org.apache.commons.lang.math.RandomUtils;
import org.junit.Test;
import org.springframework.beans.factory.annotation.Autowired;

import java.nio.charset.StandardCharsets;
import java.util.List;
import java.util.Set;

/**
 * Created by echo on 1/15/19.
 */
public class RedisBFPerformanceTest extends BaseUnitTest{

    @Autowired
    private RedisService redisService;

    @Autowired
    private RecommendedBFManager recommendedBFManager;


    @Test
    public void testBFPutPerformance(){
        Long uid = 23333L;

        int itemSize = 10;
        for(int _=0; _<8;_++){
            itemSize *= 10;
            Set<String> readyToInsertItemSet = Sets.newHashSet();
            recommendedBFManager.clean(uid);
            while(readyToInsertItemSet.size()<itemSize){
                readyToInsertItemSet.add(String.valueOf(RandomUtils.nextLong()));
            }
            System.out.println("size:"+itemSize);
            System.out.println("========START=========");
            System.out.println(System.currentTimeMillis());
            for(String item : readyToInsertItemSet){
                recommendedBFManager.BFPut(uid,item);
            }
            System.out.println(System.currentTimeMillis());
            System.out.println("========END=========");
        }

    }

    @Test
    public void testBFMultiPutPerformance(){
        Long uid = 23333L;

        int itemSize = 10;
        for(int _=0; _<8;_++){
            itemSize *= 10;
            Set<String> readyToInsertItemSet = Sets.newHashSet();
            recommendedBFManager.clean(uid);
            while(readyToInsertItemSet.size()<itemSize){
                readyToInsertItemSet.add(String.valueOf(RandomUtils.nextLong()));
            }
            System.out.println("size:"+itemSize);
            System.out.println("========START=========");
            System.out.println(System.currentTimeMillis());
            recommendedBFManager.BFMultiPut(uid,readyToInsertItemSet);
            System.out.println(System.currentTimeMillis());
            System.out.println("========END=========");
        }

    }

    @Test
    public void testGuavaBFPutPerformance(){

        int itemSize = 10;
        for(int _=0; _<6;_++){
            itemSize *= 10;
            BloomFilter bf = BloomFilter.create(Funnels.stringFunnel(Charsets.UTF_8),1000000,0.0005);
            Set<String> readyToInsertItemSet = Sets.newHashSet();

            while(readyToInsertItemSet.size()<itemSize){
                readyToInsertItemSet.add(String.valueOf(RandomUtils.nextLong()));
            }
            System.out.println("size:"+itemSize);
            System.out.println("========START=========");
            System.out.println(System.currentTimeMillis());
            for(String item : readyToInsertItemSet){
                bf.put(item);
            }
            System.out.println(System.currentTimeMillis());
            System.out.println("========END=========");
        }

    }

    @Test
    public void testBFFilter(){
        Long uid = 233333333L;
        recommendedBFManager.clean(uid);

        String item = "1";
        recommendedBFManager.BFPut(uid,item);

//        byte[] result = redisService.getRedisTemplate().getConnectionFactory().getConnection().get(testKey.getBytes(StandardCharsets.UTF_8));
//        System.out.println(result);
//        boolean result = redisService.BFMightContain(testKey,item);
//        System.out.println(result);


//        String result = redisService.getRedisTemplate().opsForValue().get(testKey);
//        System.out.println(result);
//        result = redisService.get(testKey);
//        System.out.println(result);
    }
}
