package com.ufoto.business.recommendNG.reagent;

import com.google.common.collect.Sets;
import com.ufoto.BaseUnitTest;
import com.ufoto.dto.RecommendAdvanceRequest;
import com.ufoto.utils.redis.RedisKeyConstant;
import com.ufoto.utils.redis.RedisKeyUtil;
import com.ufoto.utils.redis.RedisService;
import org.junit.Assert;
import org.junit.Test;
import org.springframework.beans.factory.annotation.Autowired;

import java.util.Arrays;
import java.util.Set;

/**
 * Created by echo on 12/18/18.
 */
public class AreaActIn24HoursReagentTest extends BaseUnitTest{

    @Autowired
    private AreaActIn24HoursReagent areaActIn24HoursReagent;

    @Autowired
    private RedisService redisService;

    Integer areaId = 9;

    @Test
    public void MakeReagent(){
        String[] inReagentUidArray = new String[]{"1","2","3"};
        Set<String> recalledUidSet = Sets.newHashSet(Arrays.asList("3","4","5","6"));
        Set<String> exceptedResult = Sets.newHashSet(inReagentUidArray);
        exceptedResult.retainAll(recalledUidSet);

        RecommendAdvanceRequest request = new RecommendAdvanceRequest();
        request.setAreaId(areaId);

        redisService.del(
                RedisKeyUtil.obtainKey(RedisKeyConstant.REDIS_AREA_ACT_IN_24H_USER_SET_KEY,areaId)
        );
        redisService.sadd(
                RedisKeyUtil.obtainKey(RedisKeyConstant.REDIS_AREA_ACT_IN_24H_USER_SET_KEY,areaId),
                inReagentUidArray
        );
        areaActIn24HoursReagent.updateCache();

        Set<String> result = areaActIn24HoursReagent.makeReagents(request,recalledUidSet);
        Assert.assertEquals(exceptedResult,result);

        inReagentUidArray = new String[]{"1111","2222","3333"};
        recalledUidSet = Sets.newHashSet(Arrays.asList("3333","4444","5555","6666"));
        exceptedResult = Sets.newHashSet(inReagentUidArray);
        exceptedResult.retainAll(recalledUidSet);
        redisService.del( RedisKeyConstant.REDIS_ACT_IN_24H_USER_SET_KEY );
        redisService.sadd(
                RedisKeyConstant.REDIS_ACT_IN_24H_USER_SET_KEY,
                inReagentUidArray
        );
        areaActIn24HoursReagent.updateCache();
        request.setAreaId(null);

        result = areaActIn24HoursReagent.makeReagents(request,recalledUidSet);
        Assert.assertEquals(exceptedResult,result);
    }

    @Test
    public void EmptyMakeReagent(){
        areaActIn24HoursReagent.updateCache();
        RecommendAdvanceRequest request = new RecommendAdvanceRequest();
        Set<String> result = areaActIn24HoursReagent.makeReagents(request,Sets.newHashSet());
        Assert.assertEquals(result,Sets.newHashSet());
    }

    @Test
    public void RandomReagents(){
        String[] inReagentUidArray = new String[]{"1","2","3"};
        redisService.del(
                RedisKeyUtil.obtainKey(RedisKeyConstant.REDIS_AREA_ACT_IN_24H_USER_SET_KEY,areaId)
        );
        redisService.sadd(
                RedisKeyUtil.obtainKey(RedisKeyConstant.REDIS_AREA_ACT_IN_24H_USER_SET_KEY,areaId),
                inReagentUidArray
        );
        RecommendAdvanceRequest request = new RecommendAdvanceRequest();
        request.setAreaId(areaId);
        areaActIn24HoursReagent.updateCache();

        Set<String> result = areaActIn24HoursReagent.randomReagents(request,3);
        Assert.assertEquals(Sets.newHashSet(inReagentUidArray),result);

        inReagentUidArray = new String[]{"1","2","3","4","5","6"};
        redisService.del(
                RedisKeyUtil.obtainKey(RedisKeyConstant.REDIS_AREA_ACT_IN_24H_USER_SET_KEY,areaId)
        );
        redisService.sadd(
                RedisKeyUtil.obtainKey(RedisKeyConstant.REDIS_AREA_ACT_IN_24H_USER_SET_KEY,areaId),
                inReagentUidArray
        );
        areaActIn24HoursReagent.updateCache();

        result = areaActIn24HoursReagent.randomReagents(request,3);
        Assert.assertTrue(result.size()==3);
        Assert.assertTrue(Sets.newHashSet(inReagentUidArray).containsAll(result));
    }

}