package com.ufoto.dao.svd;

import com.google.common.collect.Lists;
import com.google.common.collect.Sets;
import com.ufoto.entity.UfotoSvdItemSimilarityTopN;
import com.ufoto.utils.DateUtil;
import org.junit.Assert;
import org.junit.Test;
import org.junit.runner.RunWith;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.context.SpringBootTest;
import org.springframework.test.context.junit4.SpringRunner;
import org.springframework.transaction.annotation.Transactional;

import java.util.List;
import java.util.Random;
import java.util.Set;

import static org.junit.Assert.*;

/**
 * Created by echo on 9/25/18.
 */
@SpringBootTest
@RunWith(SpringRunner.class)
public class UfotoSvdUserSimilarityMapperTest {

    @Autowired
    UfotoSvdItemSimilarityMapper ufotoSvdItemSimilarityMapper;

    @Test
    @Transactional(transactionManager = "svdTransactionManager")
    public void testSelect(){
        long iid = 233L;
        List<Long> iidList = Lists.newLinkedList();
        Set<Long> iidSet = Sets.newHashSet();
        for(int i=0;i<10;i++){
            iid+=i;
            iidList.add(iid);
            List<UfotoSvdItemSimilarityTopN> ufotoSvdItemSimilarityTopNList = createData(iid,100);
            ufotoSvdItemSimilarityTopNList.forEach(x->ufotoSvdItemSimilarityMapper.insert(x));
            ufotoSvdItemSimilarityTopNList.forEach(x->iidSet.add(x.getSIId()));
        }

        List<Long> iIdList = ufotoSvdItemSimilarityMapper.selectTopNSimilarityByIids(iidList);
        Set<Long> selectedIdSet = Sets.newHashSet(iIdList);
        Assert.assertEquals(selectedIdSet,iidSet);

        iidList = Lists.newLinkedList();
        iIdList = ufotoSvdItemSimilarityMapper.selectTopNSimilarityByIids(iidList);
        selectedIdSet = Sets.newHashSet(iIdList);
        Assert.assertEquals(selectedIdSet,Sets.newHashSet());
    }

    @Test
    @Transactional(transactionManager = "svdTransactionManager")
    public void testSelectCount(){
        long iid = 233L;
        List<Long> iidList = Lists.newLinkedList();
        Set<Long> iidSet = Sets.newHashSet();
        final int iidNum = 10;
        final int eachSize = 100;
        for(int i=0;i<iidNum;i++){
            iid+=i;
            iidList.add(iid);
            List<UfotoSvdItemSimilarityTopN> ufotoSvdItemSimilarityTopNList = createData(iid,eachSize);
            ufotoSvdItemSimilarityTopNList.forEach(x->ufotoSvdItemSimilarityMapper.insert(x));
            ufotoSvdItemSimilarityTopNList.forEach(x->iidSet.add(x.getSIId()));
        }

        int count = ufotoSvdItemSimilarityMapper.selectTopNCountSimilarityByIids(iidList);
        Assert.assertEquals(count,iidSet.size());

        iidList = Lists.newLinkedList();
        count = ufotoSvdItemSimilarityMapper.selectTopNCountSimilarityByIids(iidList);
        Assert.assertEquals(count,(0));
    }



    private List<UfotoSvdItemSimilarityTopN> createData(Long iid, Integer size){
        List<UfotoSvdItemSimilarityTopN> result = Lists.newLinkedList();
        for(int i=0;i<size;i++){
            UfotoSvdItemSimilarityTopN ufotoSvdItemSimilarityTopN = new UfotoSvdItemSimilarityTopN();
            ufotoSvdItemSimilarityTopN.setIId(iid);
            ufotoSvdItemSimilarityTopN.setSIId(new Random().nextLong());
            ufotoSvdItemSimilarityTopN.setRank(i);
            ufotoSvdItemSimilarityTopN.setCreateTime(DateUtil.getCurrentSecondIntValue());
            result.add(ufotoSvdItemSimilarityTopN);
        }
        return result;
    }
}