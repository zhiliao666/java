package com.ufoto.ufotosnsrecommend;

import com.ufoto.api.RecommendToolController;
import com.ufoto.utils.ApiResult;
import org.junit.Test;
import org.junit.runner.RunWith;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.context.SpringBootTest;
import org.springframework.test.context.junit4.SpringRunner;

import java.util.Set;

@SpringBootTest
@RunWith(SpringRunner.class)
public class userEditTest {

    @Autowired
    RecommendToolController recommendToolController;

    @Test
    public void  userNotRecommendTest(){
        ApiResult<Boolean> booleanApiResult = recommendToolController.userEditNotRecommended(123456L);
        System.out.println(booleanApiResult.getC());
        System.out.println(booleanApiResult.getD());
        System.out.println(booleanApiResult.getM());
    }

    @Test
    public void  userEditCanBeRecommendedTest(){
        ApiResult<Boolean> booleanApiResult = recommendToolController.userEditCanBeRecommended(123456L);

        System.out.println(booleanApiResult.getC());
        System.out.println(booleanApiResult.getD());
        System.out.println(booleanApiResult.getM());


    }

    @Test
    public void  getUserRecommendStatusTest(){
        ApiResult<Boolean> booleanApiResult = recommendToolController.getUserRecommendStatus(123456L);
        System.out.println(booleanApiResult.getC());
        System.out.println(booleanApiResult.getD());
        System.out.println(booleanApiResult.getM());
    }
    @Test
    public void  getUserBeLikedUnreadUids(){
        ApiResult<Set<String>>  booleanApiResult = recommendToolController.getUserBeLikedUnreadUids(22L);
        booleanApiResult.getD().forEach(System.out::println);

    }

}
