package com.ufoto.business.recommendNG.recall;

import com.ufoto.BaseUnitTest;
import com.ufoto.dto.RecommendAdvanceRequest;
import com.ufoto.utils.redis.RedisKeyConstant;
import com.ufoto.utils.redis.RedisServiceObjService;
import org.junit.Test;
import org.springframework.beans.factory.annotation.Autowired;

import java.util.Set;

/**
 * <p>
 * Description:
 *
 * </p>
 *
 * @author Chan
 * @date 2020/2/15 13:08
 */
public class NGHighRiskRecallTest extends BaseUnitTest {

    @Autowired
    private NGHighRiskRecall ngHighRiskRecall;
    @Autowired
    private RedisServiceObjService redisServiceObjService;

    @Test
    public void testRecall() {
        RecommendAdvanceRequest recommendAdvanceRequest = new RecommendAdvanceRequest();
        recommendAdvanceRequest.setUid(16L);
        final Set<String> recall = ngHighRiskRecall.recall(100, recommendAdvanceRequest);
        System.out.println(recall);
    }

}
