package com.ufoto.utils;

import com.google.common.collect.Lists;
import com.google.common.collect.Maps;
import com.ufoto.BaseUnitTest;
import com.ufoto.business.recommend.bean.SortParamsBean;
import com.ufoto.business.recommend.sort.age.AgeDiff18SortStrategy;
import com.ufoto.business.recommend.sort.age.AgeDiffSelfSortStrategy;
import com.ufoto.dto.UserGeo;
import com.ufoto.utils.redis.RedisKeyConstant;
import com.ufoto.utils.redis.RedisKeyUtil;
import com.ufoto.utils.redis.RedisService;
import lombok.extern.slf4j.Slf4j;
import org.apache.commons.lang3.RandomUtils;
import org.junit.Test;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.data.geo.Point;

import java.util.List;
import java.util.Map;
import java.util.stream.Collectors;
import java.util.stream.IntStream;

import static org.junit.Assert.assertEquals;

/**
 * <p>
 * Author     : Chan
 * CreateDate : 2019-07-18 10:59
 * Description:
 * </p>
 */
@Slf4j
public class KeyTransitionUtilTest extends BaseUnitTest {
    @Autowired
    private RedisService redisService;

    @Test
    public void signUp() {
        Long uid = 20L;
        redisService.hDel(RedisKeyUtil.obtainKey(RedisKeyConstant.REDIS_USER_HASH_KEY, uid), RedisKeyConstant.REDIS_USER_HASH_SIGN_UP);
        final Integer currentSecondIntValue = DateUtil.getCurrentSecondIntValue();
        final String signUp = KeyTransitionUtil.signUp(redisService, uid);
        final String signUp2 = KeyTransitionUtil.signUp(redisService, uid);
        assertEquals(currentSecondIntValue, Integer.valueOf(signUp));
        assertEquals(currentSecondIntValue, Integer.valueOf(signUp2));
    }

    @Test
    public void activityTime() {
        Long uid = 20L;
        redisService.hDel(RedisKeyUtil.obtainKey(RedisKeyConstant.REDIS_USER_HASH_KEY, uid), RedisKeyConstant.REDIS_USER_HASH_ACTIVITY_TIME);
        final Integer currentSecondIntValue = DateUtil.getCurrentSecondIntValue();
        final String act1 = KeyTransitionUtil.activityTime(redisService, uid);
        final String act2 = KeyTransitionUtil.activityTime(redisService, uid);
        assertEquals(currentSecondIntValue, Integer.valueOf(act1));
        assertEquals(currentSecondIntValue, Integer.valueOf(act2));
    }

    @Test
    public void activityTimeList() {
        //生成用户
        final List<String> uids = IntStream.range(10, 21).mapToObj(String::valueOf).collect(Collectors.toList());
        //清除数据
        for (String uid : uids) {
            redisService.hDel(RedisKeyUtil.obtainKey(RedisKeyConstant.REDIS_USER_HASH_KEY, uid), RedisKeyConstant.REDIS_USER_HASH_ACTIVITY_TIME);
        }

        final List<String> list2 = uids.subList(3, uids.size());
        for (String uid : list2) {
            redisService.hset(RedisKeyUtil.obtainKey(RedisKeyConstant.REDIS_USER_HASH_KEY, uid), RedisKeyConstant.REDIS_USER_HASH_ACTIVITY_TIME, RandomUtils.nextLong(DateUtil.getCurrentSecondIntValue() - 864000, DateUtil.getCurrentSecondIntValue()) + "");
        }

        final Map<String, String> actMap = KeyTransitionUtil.activityTimeList(redisService, uids);
        log.warn("actMap: {}", actMap);

        //清除数据
        for (String uid : uids) {
            redisService.hDel(RedisKeyUtil.obtainKey(RedisKeyConstant.REDIS_USER_HASH_KEY, uid), RedisKeyConstant.REDIS_USER_HASH_ACTIVITY_TIME);
        }
    }

    @Test
    public void userGeo() {
        Long uid = 20L;
        redisService.hDel(RedisKeyUtil.obtainKey(RedisKeyConstant.REDIS_USER_HASH_KEY, uid), RedisKeyConstant.REDIS_USER_HASH_LATITUDE);
        redisService.hDel(RedisKeyUtil.obtainKey(RedisKeyConstant.REDIS_USER_HASH_KEY, uid), RedisKeyConstant.REDIS_USER_HASH_LONGITUDE);

        final UserGeo userGeo = KeyTransitionUtil.userGeo(redisService, uid + "");

        redisService.hset(RedisKeyUtil.obtainKey(RedisKeyConstant.REDIS_USER_HASH_KEY, uid), RedisKeyConstant.REDIS_USER_HASH_LONGITUDE, 77d + "");
        redisService.hset(RedisKeyUtil.obtainKey(RedisKeyConstant.REDIS_USER_HASH_KEY, uid), RedisKeyConstant.REDIS_USER_HASH_LATITUDE, 78d + "");

        final UserGeo userGeo2 = KeyTransitionUtil.userGeo(redisService, uid + "");

        System.out.println();
    }

    @Test
    public void userGeoMap() {
        //生成用户
        final List<String> uids = IntStream.range(10, 21).mapToObj(String::valueOf).collect(Collectors.toList());
        for (String uid : uids) {
            redisService.hDel(RedisKeyUtil.obtainKey(RedisKeyConstant.REDIS_USER_HASH_KEY, uid),
                    RedisKeyConstant.REDIS_USER_HASH_LONGITUDE,
                    RedisKeyConstant.REDIS_USER_HASH_LATITUDE);
        }
        //生成数据
        //#define GEO_LAT_MIN -85.05112878
        //#define GEO_LAT_MAX 85.05112878
        //#define GEO_LONG_MIN -180
        //#define GEO_LONG_MAX 180
        final List<String> list1 = uids.subList(0, 2);
        final Map<String, Point> pointMap = list1.stream().collect(Collectors.toMap(u -> u, v -> new Point(RandomUtils.nextDouble(1, 180), RandomUtils.nextDouble(1, 85))));

        final List<String> list2 = uids.subList(3, uids.size());
        for (String uid : list2) {
            Map<String, String> map = Maps.newHashMap();
            map.put(RedisKeyConstant.REDIS_USER_HASH_LONGITUDE, RandomUtils.nextDouble(1, 180) + "");
            map.put(RedisKeyConstant.REDIS_USER_HASH_LATITUDE, RandomUtils.nextDouble(1, 90) + "");
            redisService.hMSet(RedisKeyUtil.obtainKey(RedisKeyConstant.REDIS_USER_HASH_KEY, uid), map);
        }
        //获取数据
        final Map<String, UserGeo> userGeoMap = KeyTransitionUtil.userGeoMap(redisService, uids);
        log.warn("userGeoMap:{}", userGeoMap);

        for (String uid : uids) {
            redisService.hDel(RedisKeyUtil.obtainKey(RedisKeyConstant.REDIS_USER_HASH_KEY, uid),
                    RedisKeyConstant.REDIS_USER_HASH_LONGITUDE,
                    RedisKeyConstant.REDIS_USER_HASH_LATITUDE);
        }
    }

    @Test
    public void selectGenders() {
        List<String> recallUids = Lists.newArrayList();
        for (int i = 0; i < 10; i++) {
            recallUids.add(RandomUtils.nextLong(10, 100) + "");
        }

        for (String uid : recallUids.subList(0, 3)) {
            redisService.hset(RedisKeyUtil.obtainKey(RedisKeyConstant.REDIS_USER_HASH_KEY, uid),
                    RedisKeyConstant.REDIS_USER_HASH_GENDER, RandomUtils.nextInt(1, 3) + "");
        }

        final Map<Long, Integer> map = KeyTransitionUtil.selectGenders(redisService, recallUids);
        log.debug("genderMap:{}", map);
        for (String uid : recallUids.subList(0, 3)) {
            redisService.hDel(RedisKeyUtil.obtainKey(RedisKeyConstant.REDIS_USER_HASH_KEY, uid),
                    RedisKeyConstant.REDIS_USER_HASH_GENDER);
        }
    }

    @Test
    public void selectPopular() {
        List<String> recallUids = Lists.newArrayList();
        for (int i = 0; i < 10; i++) {
            recallUids.add(RandomUtils.nextLong(10, 100) + "");
        }

        for (String uid : recallUids.subList(0, 3)) {
            redisService.hset(RedisKeyUtil.obtainKey(RedisKeyConstant.REDIS_USER_HASH_KEY, uid),
                    RedisKeyConstant.REDIS_USER_HASH_POPULAR, RandomUtils.nextDouble(0, 3) + "");
        }

        final Map<String, Double> map = KeyTransitionUtil.selectPopularMap(redisService, recallUids);
        log.warn("popularMap:{}", map);

        for (String uid : recallUids.subList(0, 3)) {
            redisService.hDel(RedisKeyUtil.obtainKey(RedisKeyConstant.REDIS_USER_HASH_KEY, uid),
                    RedisKeyConstant.REDIS_USER_HASH_POPULAR);
        }

    }

    @Test
    public void userMatchNum() {
        long uid = 20L;
        final Double matchNum = KeyTransitionUtil.userMatchNum(redisService, uid);

        redisService.hIncrBy(RedisKeyUtil.obtainKey(RedisKeyConstant.REDIS_USER_HASH_KEY, uid), RedisKeyConstant.REDIS_USER_HASH_MATCH_NUM, 12L);
        final Double matchNum2 = KeyTransitionUtil.userMatchNum(redisService, uid);

        System.out.println();
    }

    @Test
    public void userMatchNumMap() {
        List<Long> uids = Lists.newArrayList();
        for (int i = 10; i <= 20; i++) {
            uids.add((long) i);
        }

        for (Long uid : uids.subList(0, 3)) {

        }


    }

    @Test
    public void ageMap() {
        List<Long> uids = Lists.newArrayList();
        for (int i = 30; i < 40; i++) {
            uids.add((long) i);
        }

        for (Long uid : uids.subList(0, 3)) {
            redisService.hset(RedisKeyUtil.obtainKey(RedisKeyConstant.REDIS_USER_HASH_KEY, uid), RedisKeyConstant.REDIS_USER_HASH_AGE, RandomUtils.nextInt(18, 30) + "");
        }
        for (Long uid : uids.subList(3, 6)) {
            redisService.hset(RedisKeyUtil.obtainKey(RedisKeyConstant.REDIS_USER_HASH_KEY, uid), RedisKeyConstant.REDIS_USER_HASH_BIRTH_TIMESTAMP, (1565166242 - RandomUtils.nextInt(18, 30) * 365 * 24 * 3600) + "");
        }

//        final Map<String, Integer> ageMap = KeyTransitionUtil.ageMap(redisService, uids.stream().map(String::valueOf).collect(Collectors.toList()));
//        log.debug("ageMap:{}", ageMap);

        final SortParamsBean sortParamsBean = new SortParamsBean();
        sortParamsBean.setUid(22L);
        final Map<String, Double> map = SpringContextUtil.getBean(AgeDiffSelfSortStrategy.class)
                .getScore(uids.stream().map(String::valueOf).collect(Collectors.toList()), sortParamsBean);
        log.debug("scoreMap:{}", map);

        final Map<String, Double> score = SpringContextUtil.getBean(AgeDiff18SortStrategy.class)
                .getScore(uids.stream().map(String::valueOf).collect(Collectors.toList()), sortParamsBean);
        log.debug("scoreMap:{}", score);

    }
}
