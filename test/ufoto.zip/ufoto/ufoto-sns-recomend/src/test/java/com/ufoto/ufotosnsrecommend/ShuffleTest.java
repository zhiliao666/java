package com.ufoto.ufotosnsrecommend;


import com.ufoto.business.recommend.shuffle.GenderShuffleStrategy;
import com.ufoto.business.recommend.shuffle.LikeMeShuffleStrategy;
import com.ufoto.business.recommend.shuffle.SuperLikeMeShuffleStrategy;
import com.ufoto.utils.redis.RedisService;
import org.junit.Test;
import org.junit.runner.RunWith;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.context.SpringBootTest;
import org.springframework.core.env.Environment;
import org.springframework.test.context.junit4.SpringRunner;

@RunWith(SpringRunner.class)
@SpringBootTest
public class ShuffleTest {

    @Autowired
    RedisService redisService;

    @Autowired
    Environment env;

    @Test
    public void genderShuffleTest(){
        boolean genderShuffleOn = Boolean.valueOf(env.getProperty("recommend.shuffle.genderShuffleOn"));
        System.out.println(genderShuffleOn);

        GenderShuffleStrategy genderShuffleStrategy = new GenderShuffleStrategy(redisService);

        String[] uidArray = new String[]{"301","302","303","304"};

        String[] result = genderShuffleStrategy.shuffle(uidArray);

        System.out.println(result);
    }


    @Test
    public void likeMeShuffleTest(){
        boolean likeMeShuffleOn = Boolean.valueOf(env.getProperty("recommend.shuffle.likeMeShuffleOn"));
        System.out.println(likeMeShuffleOn);

        LikeMeShuffleStrategy likeMeShuffleStrategy = new LikeMeShuffleStrategy(redisService,0.9F,301L);

        String[] uidArray = new String[]{"301","302","303","304"};

        String[] result = likeMeShuffleStrategy.shuffle(uidArray);

        System.out.println(result);
    }


    @Test
    public void superLikeMeShuffleTest(){
        SuperLikeMeShuffleStrategy superLikeMeShuffleStrategy = new SuperLikeMeShuffleStrategy(redisService,301L);

        String[] uidArray = new String[]{"301","302","303","304"};

        String[] result = superLikeMeShuffleStrategy.shuffle(uidArray);

        System.out.println(result);
    }
}
