package com.ufoto.service;

import com.ufoto.SpringUnitTest;
import com.ufoto.entity.UfotoAppCard;
import org.junit.Test;
import org.springframework.beans.factory.annotation.Autowired;

import static org.junit.Assert.*;

/**
 * <p>
 * Author     : Chan
 * CreateDate : 2018/10/9 17:20
 * Description:
 * </p>
 */
public class UfotoAppCardServiceImplTest extends SpringUnitTest {
    @Autowired
    private UfotoAppCardService ufotoAppCardService;
    @Test
    public void newUfotoAppCard() {
        UfotoAppCard card = new UfotoAppCard();
        card.setDescription("Do you like swimming?");
        card.setIsDelete(0);
        card.setType(1);
        card.setTypeSub(1);
        card.setUserName("swimming");
        card.setFirstImg("http://123.jpg");
        ufotoAppCardService.newUfotoAppCard(card);
    }
}