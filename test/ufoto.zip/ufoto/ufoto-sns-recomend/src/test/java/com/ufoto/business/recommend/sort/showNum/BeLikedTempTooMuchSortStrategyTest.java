package com.ufoto.business.recommend.sort.showNum;

import com.google.common.collect.Lists;
import com.ufoto.BaseUnitTest;
import com.ufoto.business.recommend.bean.SortParamsBean;
import com.ufoto.utils.redis.RedisKeyConstant;
import com.ufoto.utils.redis.RedisService;
import org.apache.commons.collections.CollectionUtils;
import org.apache.commons.lang.math.RandomUtils;
import org.junit.Assert;
import org.junit.Before;
import org.junit.Test;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.core.env.Environment;

import java.util.List;
import java.util.Map;

/**
 * Created by echo on 1/8/19.
 */
public class BeLikedTempTooMuchSortStrategyTest extends BaseUnitTest{


    @Autowired
    RedisService redisService;

    @Autowired
    BeLikedTempTooMuchSortStrategy beLikedTempTooMuchSortStrategy;

    @Autowired
    private Environment env;

    SortParamsBean normalSortParamsBean;

    List<String> normalUidList= Lists.newArrayList("1","2","3","4","5","6","7","8","9","10","11","12","13","14","15","16","17","18","28");

    List<String> beLikedTooMuchUidList = Lists.newArrayList("1001","1002","1003","1004","1005","1006");

    @Before
    public void setUp(){
        int BE_LIKED_TEMP_TOO_MUCH_THRESHOLD = env.getProperty("recommend.sort.beLikedTempTooMuchThreshold", Integer.class, 30);
        normalSortParamsBean = new SortParamsBean();
        normalSortParamsBean.setUid(6L);

        for(String uidStr: normalUidList){
            int beLikedTempSize = RandomUtils.nextInt(BE_LIKED_TEMP_TOO_MUCH_THRESHOLD);
            if(beLikedTempSize==0) continue;
            String[] randomArray = createRandomNoiseArray(beLikedTempSize);
            redisService.del(RedisKeyConstant.REDIS_BE_LIKED_TEMP_SET_KEY_ + uidStr);
            redisService.del(RedisKeyConstant.REDIS_BE_SUPER_LIKED_TEMP_SET_KEY_ + uidStr);
            redisService.sadd(RedisKeyConstant.REDIS_BE_LIKED_TEMP_SET_KEY_ + uidStr,randomArray);
        }

        for(String uidStr: beLikedTooMuchUidList){
            int beLikedTempSize = RandomUtils.nextInt(BE_LIKED_TEMP_TOO_MUCH_THRESHOLD)+BE_LIKED_TEMP_TOO_MUCH_THRESHOLD+1;
            if(beLikedTempSize==0) continue;
            String[] randomArray = createRandomNoiseArray(beLikedTempSize);
            redisService.del(RedisKeyConstant.REDIS_BE_LIKED_TEMP_SET_KEY_ + uidStr);
            redisService.del(RedisKeyConstant.REDIS_BE_SUPER_LIKED_TEMP_SET_KEY_ + uidStr);
            redisService.sadd(RedisKeyConstant.REDIS_BE_LIKED_TEMP_SET_KEY_ + uidStr,randomArray);
        }
    }

    @Test
    public void testNormal(){
        Map<String,Double> result = beLikedTempTooMuchSortStrategy.getScore(normalUidList,normalSortParamsBean);
        for(Map.Entry<String,Double> entry : result.entrySet()){
            Assert.assertEquals(entry.getValue(),0D,0.00001D);
        }
        result = beLikedTempTooMuchSortStrategy.getScore(beLikedTooMuchUidList,normalSortParamsBean);
        for(Map.Entry<String,Double> entry : result.entrySet()){
            Assert.assertEquals(entry.getValue(),1D,0.00001D);
        }
    }

    @Test
    public void testNullImput(){
        Map<String,Double> result = beLikedTempTooMuchSortStrategy.getScore(Lists.newLinkedList(),normalSortParamsBean);
        Assert.assertTrue(result.size()==0);
    }
}