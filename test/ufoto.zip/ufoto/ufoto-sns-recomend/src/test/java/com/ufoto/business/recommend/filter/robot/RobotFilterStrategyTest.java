package com.ufoto.business.recommend.filter.robot;

import com.google.common.collect.Lists;
import com.google.common.collect.Sets;
import com.ufoto.BaseUnitTest;
import com.ufoto.dto.RecommendAdvanceRequest;
import com.ufoto.utils.DateUtil;
import com.ufoto.utils.redis.RedisKeyConstant;
import com.ufoto.utils.redis.RedisKeyUtil;
import com.ufoto.utils.redis.RedisService;
import org.apache.commons.lang.math.RandomUtils;
import org.junit.Assert;
import org.junit.Test;
import org.springframework.beans.factory.annotation.Autowired;

import java.util.Set;

/**
 * Created by echo on 11/27/18.
 */
public class RobotFilterStrategyTest extends BaseUnitTest{

    @Autowired
    RobotFilterStrategy robotFilterStrategy;

    @Autowired
    RedisService redisService;

    @Test
    public void testFilter(){
        Set<String> needFilterUserSet = Sets.newHashSet("100","101","102");
        Set<String> recallUserSet = Sets.newHashSet("99","100","101");
        Set<String> expectedSet = Sets.newHashSet(recallUserSet);
        expectedSet.removeAll(needFilterUserSet);

        redisService.del(RedisKeyConstant.REDIS_ROBOT_UID_ALL_SET_KEY);
        for(String uid : needFilterUserSet){
            redisService.sadd(RedisKeyConstant.REDIS_ROBOT_UID_ALL_SET_KEY, uid);
        }
        robotFilterStrategy.updateCache();
        Set<String> result = robotFilterStrategy.filter(recallUserSet,
                Lists.newLinkedList(),
                new RecommendAdvanceRequest());

        Assert.assertEquals(expectedSet,result);
    }
    /**
     * 测试输入找回结果为空的情况
     */
    @Test
    public void testEmptyRecallFilter(){
        Set<String> needFilterUserSet = Sets.newHashSet("100","101","102");
        Set<String> recallUserSet = Sets.newHashSet();
        Set<String> expectedSet = Sets.newHashSet(recallUserSet);
        expectedSet.removeAll(needFilterUserSet);

        redisService.del(RedisKeyConstant.REDIS_ROBOT_UID_ALL_SET_KEY);
        for(String uid : needFilterUserSet){
            redisService.sadd(RedisKeyConstant.REDIS_ROBOT_UID_ALL_SET_KEY, uid);
        }
        Set<String> result = robotFilterStrategy.filter(recallUserSet,
                Lists.newLinkedList(),
                new RecommendAdvanceRequest());

        Assert.assertEquals(expectedSet,result);

        needFilterUserSet = Sets.newHashSet("100","101","102");
        recallUserSet = null;

        redisService.del(RedisKeyConstant.REDIS_ROBOT_UID_ALL_SET_KEY);
        for(String uid : needFilterUserSet){
            redisService.sadd(RedisKeyConstant.REDIS_ROBOT_UID_ALL_SET_KEY, uid);
        }
        robotFilterStrategy.updateCache();
        result = robotFilterStrategy.filter(recallUserSet,
                Lists.newLinkedList(),
                new RecommendAdvanceRequest());

        Assert.assertEquals(Sets.newHashSet(),result);
    }


}