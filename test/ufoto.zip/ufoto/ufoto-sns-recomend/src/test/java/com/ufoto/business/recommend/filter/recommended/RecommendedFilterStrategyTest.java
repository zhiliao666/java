package com.ufoto.business.recommend.filter.recommended;

import com.google.common.collect.Lists;
import com.google.common.collect.Sets;
import com.ufoto.BaseUnitTest;
import com.ufoto.dto.RecommendAdvanceRequest;
import com.ufoto.service.RecommendService;
import com.ufoto.utils.CommonUtil;
import com.ufoto.utils.redis.RedisKeyConstant;
import com.ufoto.utils.redis.RedisKeyUtil;
import com.ufoto.utils.redis.RedisService;
import org.apache.commons.lang.math.RandomUtils;
import org.junit.Assert;
import org.junit.Test;
import org.springframework.beans.factory.annotation.Autowired;

import java.util.Set;
import java.util.stream.Collectors;

/**
 * Created by echo on 1/15/19.
 */
public class RecommendedFilterStrategyTest extends BaseUnitTest {

    @Autowired
    RecommendService recommendService;

    @Autowired
    RecommendedFilterStrategy recommendedFilterStrategy;

    @Autowired
    RedisService redisService;

    @Autowired
    RecommendedBFManager recommendedBFManager;

    @Test
    public void testFilter() {
        Long requestUid = 233L;
        //清理对应的RedisKey
        redisService.del(RedisKeyConstant.REDIS_BE_LIKED_TEMP_SET_KEY_ + requestUid);
        recommendedBFManager.clean(requestUid);

        //所有当前用户已经看过的内容
        Set<Long> recommendedUidSet = createRandomUidSet(100);
        recommendedUidSet.remove(requestUid);
        //已经看过但是又被Like的一批人
        Set<Long> beLikedTempUidSet = CommonUtil.getRandomNItemFromSet(recommendedUidSet.stream().map(String::valueOf).collect(Collectors.toSet()), 10).stream().map(Long::valueOf).collect(Collectors.toSet());
        //随机生成一部分认为是被召回的内容
        Set<Long> someRecalledUidSet = createRandomUidSet(100);
        someRecalledUidSet.remove(requestUid);
        someRecalledUidSet.addAll(recommendedUidSet);
        someRecalledUidSet.addAll(beLikedTempUidSet);
        Set<String> recallUidSet = someRecalledUidSet.stream().map(x -> String.valueOf(x)).collect(Collectors.toSet());
        //期望得到的返回值
        Set<Long> exceptLongResult = someRecalledUidSet;
        exceptLongResult.removeAll(recommendedUidSet);
        exceptLongResult.addAll(beLikedTempUidSet);
        Set<String> exceptResult = exceptLongResult.stream().map(x -> String.valueOf(x)).collect(Collectors.toSet());


        for (Long uid : recommendedUidSet) {
            recommendService.addRedisUserRecommended(requestUid, uid);
        }
        for (Long uid : beLikedTempUidSet) {
            recommendService.addRedisUserBeLiked(requestUid, uid);
        }

        RecommendAdvanceRequest request = new RecommendAdvanceRequest();
        request.setUid(requestUid);
        Set<String> result = recommendedFilterStrategy.filter(recallUidSet, Lists.newLinkedList(), request);

        Assert.assertEquals(exceptResult, result);
    }

    @Test
    public void testEmptyInput() {
        RecommendAdvanceRequest request = new RecommendAdvanceRequest();
        request.setUid(233L);
        Set<String> result = recommendedFilterStrategy.filter(Sets.newHashSet(), Lists.newLinkedList(), request);
        Assert.assertEquals(Sets.newHashSet(), result);

        result = recommendedFilterStrategy.filter(null, Lists.newLinkedList(), request);
        Assert.assertEquals(Sets.newHashSet(), result);
    }
}
