package com.ufoto.service;

import com.ufoto.BaseUnitTest;
import com.ufoto.entity.UfotoAppUser;
import com.ufoto.utils.DateUtil;
import com.ufoto.utils.redis.RedisKeyConstant;
import com.ufoto.utils.redis.RedisKeyUtil;
import com.ufoto.utils.redis.RedisService;
import org.junit.Assert;
import org.junit.Test;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.core.env.Environment;

import java.util.Date;
import java.util.Map;

/**
 * Created by echo on 9/6/18.
 */
public class RecommendServiceTest extends BaseUnitTest {

    @Autowired
    RecommendServiceImpl recommendService;

    @Autowired
    RedisService redisService;

    @Autowired
    Environment env;

    /**
     * 尝试将用户的基本信息加入到Redis的用户画像当中去
     */
    @Test
    public void testAddUserProfile() {
        //normal case
        UfotoAppUser user = new UfotoAppUser();
        user.setId(233L);
        user.setLatitude(23.33D);
        user.setUuid("fuckingBoringWork");
        user.setCountryCode("UK");
        user.setUserName("JOJO");
        user.setLocation("Somewhere");
        user.setHometown("London");
        user.setEmail("jojo@noHumanAgain.com");
        user.setFirstImg("https://i4.nbimg.com/510372/bd001cc239fc99d0.jpg");
        user.setCreateTime(DateUtil.getCurrentSecondIntValue() - 60 * 60 * 24 * 3);
        user.setPhone("110");
        user.setHeadImg("https://i4.nbimg.com/510372/bd001cc239fc99d0.jpg");
        user.setIsDelete(0);
        user.setFromType(3);
        user.setUpdateTime(DateUtil.getCurrentSecondIntValue() - 60 * 60 * 24 * 2);
        user.setType(2);
        user.setGender(1);
        user.setLongitude(23.333D);
        user.setBirthTime(new Date());
        user.setDescription("Your next words are ");
        user.setLang("en");

        redisService.del(RedisKeyUtil.obtainKey(RedisKeyConstant.REDIS_USER_HASH_KEY, user.getId()));
        recommendService.addRedisUser(user);

        Map<String, String> profile = redisService.hGetAll(RedisKeyUtil.obtainKey(RedisKeyConstant.REDIS_USER_HASH_KEY, user.getId()));
        Assert.assertEquals(profile.get("latitude"), "" + user.getLatitude());
        Assert.assertEquals(profile.get("uuid"), user.getUuid());
        Assert.assertEquals(profile.get("country_code"), user.getCountryCode());
        Assert.assertEquals(profile.get("user_name"), user.getUserName());
        Assert.assertEquals(profile.get("location"), user.getLocation());
        Assert.assertEquals(profile.get("hometown"), user.getHometown());
        Assert.assertEquals(profile.get("email"), user.getEmail());
        Assert.assertEquals(profile.get("first_img"), user.getFirstImg());
        Assert.assertEquals(profile.get("create_time"), "" + user.getCreateTime());
        Assert.assertEquals(profile.get("phone"), user.getPhone());
        Assert.assertEquals(profile.get("head_img"), user.getHeadImg());
        Assert.assertEquals(profile.get("is_delete"), "" + user.getIsDelete());
        Assert.assertEquals(profile.get("from_type"), "" + user.getFromType());
        Assert.assertEquals(profile.get("update_time"), "" + user.getUpdateTime());
        Assert.assertEquals(profile.get("type"), "" + user.getType());
        Assert.assertEquals(profile.get("gender"), "" + user.getGender());
        Assert.assertEquals(profile.get("longitude"), "" + user.getLongitude());
        Assert.assertEquals(profile.get("birth_time"), DateUtil.getDateString("yyyy-MM-dd HH:mm:ss", user.getBirthTime().getTime()));
        Assert.assertEquals(profile.get("description"), "" + user.getDescription());
        Assert.assertEquals(profile.get("lang"), "" + user.getLang());

        //null birth
        user.setBirthTime(null);
        redisService.del(RedisKeyUtil.obtainKey(RedisKeyConstant.REDIS_USER_HASH_KEY, user.getId()));
        recommendService.addRedisUser(user);
        profile = redisService.hGetAll(RedisKeyUtil.obtainKey(RedisKeyConstant.REDIS_USER_HASH_KEY, user.getId()));
        Assert.assertEquals(profile.get("birth_time"), null);
    }

    /**
     * 测试修改用户性别相应方法
     * <p>
     * todo:用例不完备,只测试了user hash
     */
    @Test
    public void testUserAddGender() {
        long uid = 233L;
        int gender = 1;
        redisService.del(RedisKeyUtil.obtainKey(RedisKeyConstant.REDIS_USER_HASH_KEY, uid));
        recommendService.addRedisUserGender(uid, gender);

        Assert.assertEquals(
                redisService.hget(RedisKeyUtil.obtainKey(RedisKeyConstant.REDIS_USER_HASH_KEY, uid),
                        RedisKeyConstant.REDIS_USER_HASH_GENDER),
                String.valueOf(gender));
    }


    /**
     * 测试修改用户最近活跃时间相应方法
     * <p>
     * todo:用例不完备,只测试了user hash
     */
    @Test
    public void testUserActivityTime() {
        long uid = 233L;
        int timestamp = DateUtil.getCurrentSecondIntValue();
        redisService.del(RedisKeyUtil.obtainKey(RedisKeyConstant.REDIS_USER_HASH_KEY, uid));
        recommendService.addRedisUserActivityTimestamp(uid, timestamp);

        Assert.assertEquals(
                redisService.hget(RedisKeyUtil.obtainKey(RedisKeyConstant.REDIS_USER_HASH_KEY, uid),
                        RedisKeyConstant.REDIS_USER_HASH_ACTIVITY_TIME),
                String.valueOf(timestamp));
    }

    /**
     * 测试修改用户注册时间相应方法
     * <p>
     * todo:用例不完备,只测试了user hash
     */
    @Test
    public void testUserSignUpTime() {
        long uid = 233L;
        int timestamp = DateUtil.getCurrentSecondIntValue();
        redisService.del(RedisKeyUtil.obtainKey(RedisKeyConstant.REDIS_USER_HASH_KEY, uid));
        recommendService.addRedisUserSignUpTimestamp(uid, timestamp);

        Assert.assertEquals(
                redisService.hget(RedisKeyUtil.obtainKey(RedisKeyConstant.REDIS_USER_HASH_KEY, uid),
                        RedisKeyConstant.REDIS_USER_HASH_SIGN_UP),
                String.valueOf(timestamp));
    }


    /**
     * 测试修改用户生日时间相应方法
     * <p>
     * todo:用例不完备,只测试了user hash
     */
    @Test
    public void testUserBirthTimestamp() {
        long uid = 233L;
        long timestamp = DateUtil.getCurrentSecondIntValue() * 1000L;
        redisService.del(RedisKeyUtil.obtainKey(RedisKeyConstant.REDIS_USER_HASH_KEY, uid));
        recommendService.addRedisUserBirthTimestamp(uid, timestamp);

        Assert.assertEquals(
                redisService.hget(RedisKeyUtil.obtainKey(RedisKeyConstant.REDIS_USER_HASH_KEY, uid),
                        RedisKeyConstant.REDIS_USER_HASH_BIRTH_TIMESTAMP),
                String.valueOf(timestamp));
        Assert.assertEquals(
                redisService.hget(RedisKeyUtil.obtainKey(RedisKeyConstant.REDIS_USER_HASH_KEY, uid),
                        RedisKeyConstant.REDIS_USER_HASH_BIRTH_DATE),
                DateUtil.getDateString("yyyy-MM-dd HH:mm:ss", timestamp));
    }

    @Test
    public void testAddRedisRegionUser() {
        //todo: country user hash
        Long uid = 9L;
        String country = "CN";
        Integer areaId = 25;
        String getAreaId = null;

        redisService.del(RedisKeyConstant.REDIS_REGION_USERS_SET_KEY_ + country);
        redisService.del(RedisKeyConstant.REDIS_REGION_USERS_SET_KEY_ + "all");
        redisService.del(RedisKeyUtil.obtainKey(RedisKeyConstant.REDIS_USER_HASH_KEY, uid));

        //normal case
        recommendService.addRedisRegionUser(uid, country, areaId);
        Assert.assertTrue(redisService.isMember(RedisKeyConstant.REDIS_REGION_USERS_SET_KEY_ + country, uid + ""));
        Assert.assertTrue(redisService.isMember(RedisKeyConstant.REDIS_REGION_USERS_SET_KEY_ + "all", uid + ""));
        getAreaId = redisService.hget(RedisKeyUtil.obtainKey(RedisKeyConstant.REDIS_USER_HASH_KEY, uid),
                RedisKeyConstant.REDIS_USER_HASH_AREA_ID);
        Assert.assertEquals(String.valueOf(areaId), getAreaId);

        //country null
        redisService.del(RedisKeyConstant.REDIS_REGION_USERS_SET_KEY_ + country);
        redisService.del(RedisKeyConstant.REDIS_REGION_USERS_SET_KEY_ + "all");
        redisService.del(RedisKeyUtil.obtainKey(RedisKeyConstant.REDIS_USER_HASH_KEY, uid));
        recommendService.addRedisRegionUser(uid, null, areaId);
        Assert.assertTrue(!redisService.isMember(RedisKeyConstant.REDIS_REGION_USERS_SET_KEY_ + country, uid + ""));
        Assert.assertTrue(!redisService.isMember(RedisKeyConstant.REDIS_REGION_USERS_SET_KEY_ + "all", uid + ""));
        getAreaId = redisService.hget(RedisKeyUtil.obtainKey(RedisKeyConstant.REDIS_USER_HASH_KEY, uid),
                RedisKeyConstant.REDIS_USER_HASH_AREA_ID);
        Assert.assertNull(getAreaId);

        //areaId null
        redisService.del(RedisKeyConstant.REDIS_REGION_USERS_SET_KEY_ + country);
        redisService.del(RedisKeyConstant.REDIS_REGION_USERS_SET_KEY_ + "all");
        redisService.del(RedisKeyUtil.obtainKey(RedisKeyConstant.REDIS_USER_HASH_KEY, uid));
        recommendService.addRedisRegionUser(uid, country, null);
        Assert.assertTrue(redisService.isMember(RedisKeyConstant.REDIS_REGION_USERS_SET_KEY_ + country, uid + ""));
        Assert.assertTrue(redisService.isMember(RedisKeyConstant.REDIS_REGION_USERS_SET_KEY_ + "all", uid + ""));
        getAreaId = redisService.hget(RedisKeyUtil.obtainKey(RedisKeyConstant.REDIS_USER_HASH_KEY, uid),
                RedisKeyConstant.REDIS_USER_HASH_AREA_ID);
        Assert.assertNull(getAreaId);
    }

    @Test
    public void testAddNewUser() {
        Long uid = 9L;
        int newComeShowNumLimit = Integer.valueOf(env.getProperty("recommend.newComeShowNumLimit"));

        String[] beLikedUidArray = createRandomNoiseArray(20);
        String[] beDislikedUidArray = createRandomNoiseArray(20);
        redisService.del(RedisKeyConstant.REDIS_BE_LIKED_SET_KEY_ + uid);
        redisService.del(RedisKeyConstant.REDIS_BE_UN_LIKED_SET_KEY_ + uid);
        redisService.sremove(RedisKeyConstant.REDIS_NEW_COME_USER_SET_KEY, String.valueOf(uid));

        // new come user
        recommendService.addNewComeUser(uid);
        Assert.assertTrue(redisService.isMember(RedisKeyConstant.REDIS_NEW_COME_USER_SET_KEY, String.valueOf(uid)));

        // no more new come user
        redisService.sadd(RedisKeyConstant.REDIS_BE_LIKED_SET_KEY_ + uid, beLikedUidArray);
        redisService.sadd(RedisKeyConstant.REDIS_BE_UN_LIKED_SET_KEY_ + uid, beDislikedUidArray);
        redisService.sremove(RedisKeyConstant.REDIS_NEW_COME_USER_SET_KEY, String.valueOf(uid));

        recommendService.addNewComeUser(uid);
        Assert.assertTrue(!redisService.isMember(RedisKeyConstant.REDIS_NEW_COME_USER_SET_KEY, String.valueOf(uid)));
    }

    @Test
    public void checkIsNewComeUser() {
        Long uid = 9L;
        int newComeShowNumLimit = Integer.valueOf(env.getProperty("recommend.newComeShowNumLimit"));

        String[] beLikedUidArray = createRandomNoiseArray(20);
        String[] beDislikedUidArray = createRandomNoiseArray(20);
        redisService.del(RedisKeyConstant.REDIS_BE_LIKED_SET_KEY_ + uid);
        redisService.del(RedisKeyConstant.REDIS_BE_UN_LIKED_SET_KEY_ + uid);
        redisService.sadd(RedisKeyConstant.REDIS_NEW_COME_USER_SET_KEY, String.valueOf(uid));

        recommendService.checkIsNewComeUser(uid);
        Assert.assertTrue(redisService.isMember(RedisKeyConstant.REDIS_NEW_COME_USER_SET_KEY, String.valueOf(uid)));

        redisService.sadd(RedisKeyConstant.REDIS_BE_LIKED_SET_KEY_ + uid, beLikedUidArray);
        redisService.sadd(RedisKeyConstant.REDIS_BE_UN_LIKED_SET_KEY_ + uid, beDislikedUidArray);
        redisService.sadd(RedisKeyConstant.REDIS_NEW_COME_USER_SET_KEY, String.valueOf(uid));

        recommendService.checkIsNewComeUser(uid);
        Assert.assertTrue(!redisService.isMember(RedisKeyConstant.REDIS_NEW_COME_USER_SET_KEY, String.valueOf(uid)));
    }

}
