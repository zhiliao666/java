package com.ufoto.business.recommendNG.captain;

import com.google.common.collect.Lists;
import org.assertj.core.util.Sets;
import org.junit.Assert;
import org.junit.Test;
import org.junit.runner.RunWith;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.context.SpringBootTest;
import org.springframework.test.context.junit4.SpringRunner;

import java.security.InvalidParameterException;
import java.util.List;
import java.util.Set;


@SpringBootTest
@RunWith(SpringRunner.class)
public class NGDefaultCaptainTest {

    @Autowired
    NGDefaultCaptain ngDefaultCaptain;

    @Test
    public void assemble() {
        List<List<String>> subUidList = Lists.newLinkedList();
        List<Integer> assembleWeightList = Lists.newLinkedList();

        subUidList.add(Lists.newArrayList("1", "2", "3", "4", "5"));
        assembleWeightList.add(1);
        subUidList.add(Lists.newArrayList("11", "12", "13", "14", "15"));
        assembleWeightList.add(2);
        subUidList.add(Lists.newArrayList("21", "22", "23", "24", "25"));
        assembleWeightList.add(3);
        subUidList.add(Lists.newArrayList("31", "32", "33", "34", "35"));
        assembleWeightList.add(4);
        subUidList.add(Lists.newArrayList("41", "42", "43", "44", "45"));
        assembleWeightList.add(5);

        Set<String> exceptedResultSet = Sets.newHashSet();
        subUidList.forEach(list -> exceptedResultSet.addAll(list));

        List<String> result = ngDefaultCaptain.assemble(null, subUidList, assembleWeightList);

        Assert.assertEquals(Sets.newHashSet(result), exceptedResultSet);
    }


    @Test(expected = InvalidParameterException.class)
    public void invalidAssemble() {
        List<List<String>> subUidList = Lists.newLinkedList();
        List<Integer> assembleWeightList = Lists.newLinkedList();

        subUidList.add(Lists.newArrayList("1", "2", "3", "4", "5"));
        assembleWeightList.add(1);
        subUidList.add(Lists.newArrayList("11", "12", "13", "14", "15"));
        assembleWeightList.add(2);
        subUidList.add(Lists.newArrayList("21", "22", "23", "24", "25"));
        assembleWeightList.add(3);
        subUidList.add(Lists.newArrayList("31", "32", "33", "34", "35"));
        assembleWeightList.add(4);
        subUidList.add(Lists.newArrayList("41", "42", "43", "44", "45"));

        ngDefaultCaptain.assemble(null, subUidList, assembleWeightList);
    }
}
