package com.ufoto.service;

import com.google.common.collect.Lists;
import com.google.common.collect.Sets;
import com.ufoto.BaseUnitTest;
import com.ufoto.dto.RecommendListRequest;
import com.ufoto.dto.sns.SnsRecommendExpandDto;
import com.ufoto.entity.UfotoAppUser;
import com.ufoto.mq.request.recommend.UserSubscriptionRequest;
import com.ufoto.utils.json.JSONUtil;
import com.ufoto.utils.redis.RedisKeyConstant;
import com.ufoto.utils.redis.RedisService;
import org.junit.Test;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.util.CollectionUtils;

import java.util.List;
import java.util.Map;
import java.util.Set;

/**
 * <p>
 *
 * </p>
 *
 * @author created by chenzhou at 2018-08-17 11:32
 */
public class UfotoAppUserServiceImplTest extends BaseUnitTest {

    @Autowired
    private UfotoAppUserService ufotoAppUserService;

    @Autowired
    private RedisService redisService;

    @Test
    public void selectOneById() {
        final UfotoAppUser ufotoAppUser1 = ufotoAppUserService.selectOneById(20L);
        final UfotoAppUser ufotoAppUser2 = ufotoAppUserService.selectOneById(20L);
        final UfotoAppUser ufotoAppUser3 = ufotoAppUserService.selectOneById(20L);
        System.out.println();
    }

    @Test
    public void selectRecommendDtoBySortedUidList() {
        RecommendListRequest centerRequest = new RecommendListRequest();
        centerRequest.setUids(Lists.newArrayList("20", "22"));
        final List<SnsRecommendExpandDto> snsRecommendDtos = ufotoAppUserService.selectRecommendDtoBySortedUidList(centerRequest);
        System.out.println(JSONUtil.toJSON(snsRecommendDtos));
    }

    @Test
    public void subscriptionUserMap() {
        UfotoAppUserServiceImpl ufotoAppUserService1 = (UfotoAppUserServiceImpl) ufotoAppUserService;
        final Map<String, Boolean> map = ufotoAppUserService1.subscriptionUserMap(Lists.newArrayList("100", "200"));
        System.out.println(map);

        UserSubscriptionRequest subscriptionRequest = UserSubscriptionRequest.builder()
                .expireUids(Sets.newHashSet("200"))
                .validUids(Sets.newHashSet("500"))
                .build();
        final Set<String> expireUids = subscriptionRequest.getExpireUids();
        final Set<String> validUids = subscriptionRequest.getValidUids();
        if (!CollectionUtils.isEmpty(expireUids)) {
            redisService.sremove(RedisKeyConstant.REDIS_SUBSCRIPTION_USER_SET, expireUids.toArray(new String[]{}));
        }
        if (!CollectionUtils.isEmpty(validUids)) {
            redisService.sadd(RedisKeyConstant.REDIS_SUBSCRIPTION_USER_SET, validUids.toArray(new String[]{}));
        }
    }
}
