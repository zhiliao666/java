package com.ufoto.ufotosnsrecommend;

import com.ufoto.api.RecommendToolController;
import com.ufoto.service.RecommendService;
import com.ufoto.utils.redis.RedisKeyConstant;
import com.ufoto.utils.redis.RedisService;
import org.junit.Before;
import org.junit.runner.RunWith;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.context.SpringBootTest;
import org.springframework.test.context.junit4.SpringRunner;

import java.util.Optional;

/**
 * Created by echo on 3/27/18.
 */
@RunWith(SpringRunner.class)
@SpringBootTest
public class UserPopularTests {

    @Autowired
    private RecommendToolController recommendToolController;

    @Autowired
    private RedisService redisService;

    @Autowired
    private RecommendService recommendService;

    private final Long normalUid = 2999L;
    private final Long notEnoughBeLikeduid = 2998L;

    @Before
    public void setUp() {
        for (int i = 3000; i < 3050; i++) {
            recommendService.addRedisUserBeLiked(normalUid, (long) i);
        }
        System.out.println("===================================SetUp=======================");
    }

    private double getScore(long uid) {
        long beLikedNum = Optional.ofNullable(redisService.sCard(RedisKeyConstant.REDIS_BE_LIKED_SET_KEY_ + uid)).orElse(0L);
        long beDislikeNum = Optional.ofNullable(redisService.sCard(RedisKeyConstant.REDIS_BE_UN_LIKED_SET_KEY_NEW + uid)).orElse(0L);
        if (beLikedNum + beDislikeNum > 30 && beLikedNum > 0 && beDislikeNum > 0) {
            Double score = beLikedNum * 1.0D / beDislikeNum;
            return score;
        }
        return 0;
    }

}
