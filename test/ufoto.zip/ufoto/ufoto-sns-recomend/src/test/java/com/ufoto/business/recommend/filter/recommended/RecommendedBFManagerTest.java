package com.ufoto.business.recommend.filter.recommended;

import com.google.common.collect.Lists;
import com.google.common.collect.Sets;
import com.ufoto.BaseUnitTest;
import com.ufoto.utils.redis.RedisService;
import org.junit.Assert;
import org.junit.Test;
import org.springframework.beans.factory.annotation.Autowired;

import java.util.List;
import java.util.Set;

import static org.junit.Assert.*;

/**
 * Created by echo on 1/16/19.
 */
public class RecommendedBFManagerTest extends BaseUnitTest{

    @Autowired
    RedisService redisService;

    @Autowired
    RecommendedBFManager recommendedBFManager;


    @Test
    public void BFPutAndContainTest(){
        List<String> inBFItemList = Lists.newArrayList();
        for(int _=0;_<100;_++){
            inBFItemList.add(String.valueOf(_));
        }
        List<String> notInBFItemList = Lists.newArrayList();
        for(int _=10000;_<10100;_++){
            notInBFItemList.add(String.valueOf(_));
        }
        Long uid = 2333L;
        recommendedBFManager.clean(uid);

        for(String item:inBFItemList){
            boolean result = recommendedBFManager.BFMightContain(uid,item);
            Assert.assertFalse(result);
        }
        for(String item:notInBFItemList){
            boolean result = recommendedBFManager.BFMightContain(uid,item);
            Assert.assertFalse(result);
        }

        for(String item : inBFItemList){
            recommendedBFManager.BFPut(uid,item);
        }
        recommendedBFManager.BFPut(uid,inBFItemList.get(0));

        for(String item:inBFItemList){
            boolean result = recommendedBFManager.BFMightContain(uid,item);
            Assert.assertTrue(result);
        }
        for(String item:notInBFItemList){
            boolean result = recommendedBFManager.BFMightContain(uid,item);
            Assert.assertFalse(result);
        }

        //test null input
        boolean result = recommendedBFManager.BFMightContain(uid,null);
        Assert.assertFalse(result);
        result = recommendedBFManager.BFMightContain(null,"stoi");
        Assert.assertFalse(result);
        result = recommendedBFManager.BFMightContain(null,null);
        Assert.assertFalse(result);

    }

    @Test
    public void BFMultiPutTest(){
        List<String> inBFItemList = Lists.newArrayList();
        for(int _=0;_<15600;_++){
            inBFItemList.add(String.valueOf(_));
        }
        List<String> notInBFItemList = Lists.newArrayList();
        for(int _=100000;_<115600;_++){
            notInBFItemList.add(String.valueOf(_));
        }
        Long uid = 2333L;
        recommendedBFManager.clean(uid);

        for(String item:inBFItemList){
            boolean result = recommendedBFManager.BFMightContain(uid,item);
            Assert.assertTrue(!result);
        }
        for(String item:notInBFItemList){
            boolean result = recommendedBFManager.BFMightContain(uid,item);
            Assert.assertTrue(!result);
        }

        recommendedBFManager.BFMultiPut(uid,inBFItemList);

        for(String item:inBFItemList){
            boolean result = recommendedBFManager.BFMightContain(uid,item);
            Assert.assertTrue(result);
        }
        int fpCount = 0;
        for(String item:notInBFItemList){
            boolean result = recommendedBFManager.BFMightContain(uid,item);
            if(result) fpCount+=1;
        }
        float fpp= fpCount*1.0F/notInBFItemList.size();
        System.out.println(fpp);
        Assert.assertTrue(fpp<0.01);

        recommendedBFManager.BFMultiPut(uid,null);
        recommendedBFManager.BFMultiPut(uid, Sets.newHashSet());
        recommendedBFManager.BFMultiPut(null,Sets.newHashSet());
        recommendedBFManager.BFMultiPut(null,null);
    }

    @Test
    public void BFFilterTest(){
        List<String> inBFItemList = Lists.newArrayList();
        for(int _=0;_<15600;_++){
            inBFItemList.add(String.valueOf(_));
        }
        Set<String> inBFItemSet = Sets.newHashSet(inBFItemList);

        List<String> notInBFItemList = Lists.newArrayList();
        for(int _=100000;_<115600;_++){
            notInBFItemList.add(String.valueOf(_));
        }
        Set<String> notInBFItemSet = Sets.newHashSet(notInBFItemList);

        Long uid = 2333L;
        recommendedBFManager.clean(uid);

        Set<String> result = recommendedBFManager.BFFilter(uid, inBFItemSet);
        Assert.assertEquals(result,inBFItemSet);
        result = recommendedBFManager.BFFilter(uid, notInBFItemSet);
        Assert.assertEquals(result,notInBFItemSet);

        Set<String> mergedItemSet = Sets.newHashSet(inBFItemSet);
        mergedItemSet.addAll(notInBFItemSet);

        recommendedBFManager.BFMultiPut(uid,inBFItemList);

        System.out.println(System.currentTimeMillis());
        result = recommendedBFManager.BFFilter(uid, mergedItemSet);
        System.out.println(System.currentTimeMillis());
        for(String item : result){
            Assert.assertTrue(notInBFItemList.contains(item));
        }
        float fpp = (notInBFItemList.size() - result.size()) *1.0F / notInBFItemList.size();
        System.out.println(fpp);
        Assert.assertTrue(fpp<0.01);

        //test null input
        result = recommendedBFManager.BFFilter(uid, null);
        Assert.assertEquals(result,Sets.newHashSet());
        result = recommendedBFManager.BFFilter(null, mergedItemSet);
        Assert.assertEquals(result,Sets.newHashSet());
        //not exist key
        result = recommendedBFManager.BFFilter(1294861023865L, mergedItemSet);
        Assert.assertEquals(result,mergedItemSet);
        //filter again ,test cache
        result = recommendedBFManager.BFFilter(uid, mergedItemSet);
        System.out.println(System.currentTimeMillis());
        for(String item : result){
            Assert.assertTrue(notInBFItemList.contains(item));
        }
        recommendedBFManager.BFMultiPut(uid,inBFItemList);
        result = recommendedBFManager.BFFilter(uid, mergedItemSet);
        System.out.println(System.currentTimeMillis());
        for(String item : result){
            Assert.assertTrue(notInBFItemList.contains(item));
        }
    }

}