package com.ufoto.api;

import com.ufoto.BaseUnitTest;
import com.ufoto.business.common.ApiCommonInfoBusiness;
import org.junit.Before;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.mock.mockito.MockBean;

/**
 * Created by echo on 12/18/18.
 */
public class ApiSnsActControllerTest extends BaseUnitTest {

    @MockBean
    ApiCommonInfoBusiness apiCommonInfoBusiness;

    @Autowired
    ApiSnsActController apiSnsActController;

    @Before
    public void setUp() {

    }
}
