package com.ufoto.ufotosnsrecommend;

import com.google.common.collect.Lists;
import com.ufoto.BaseUnitTest;
import com.ufoto.dto.ConditionRequest;
import com.ufoto.dto.RecommendAdvanceRequest;
import com.ufoto.utils.DateUtil;
import com.ufoto.utils.redis.RedisKeyConstant;
import com.ufoto.utils.redis.RedisKeyUtil;
import com.ufoto.utils.redis.RedisService;
import com.ufoto.utils.strategy.ParamsConverter;
import org.joda.time.DateTime;
import org.joda.time.Period;
import org.joda.time.PeriodType;
import org.junit.Test;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.data.redis.core.RedisCallback;
import org.springframework.data.redis.core.RedisTemplate;
import org.springframework.data.redis.serializer.RedisSerializer;

import java.nio.charset.Charset;
import java.nio.charset.StandardCharsets;
import java.text.SimpleDateFormat;
import java.util.Date;
import java.util.List;

/**
 * <p>
 *
 * </p>
 *
 * @author created by chenzhou at 2018-06-12 09:40
 */
public class ParamsConverterTest extends BaseUnitTest {

    @Autowired
    private RedisService redisService;

    @Autowired
    private ParamsConverter paramsConverter;

    @Test
    public void testConverter() {
        final Charset charset = StandardCharsets.UTF_8;

        Long uid = 521L;
        final byte[] uidValues = RedisKeyUtil.serializeUid(uid).getBytes(charset);
        final RedisTemplate<String, String> redisTemplate = redisService.getRedisTemplate();
        final RedisSerializer<String> stringSerializer = redisTemplate.getStringSerializer();

        final List<Object> objects = redisTemplate.executePipelined((RedisCallback<Object>) connection -> {
            //0) 是否是女性
//            return connection.sIsMember(RedisKeyConstant.REDIS_GENDER_FEMALE_SET_KEY.getBytes(charset), uidValues);
//            //1)是否是男性
//            return connection.sIsMember(RedisKeyConstant.REDIS_GENDER_MALE_SET_KEY.getBytes(charset), uidValues);
//            //2)生日 毫秒
//            return stringSerializer.deserialize(connection.get((RedisKeyConstant.REDIS_USER_BIRTH_TIMESTAMP_STR_KEY_ + uid).getBytes(charset)));
//            //3)是否是新用户
//           return  connection.sIsMember(RedisKeyConstant.REDIS_NEW_COME_USER_SET_KEY.getBytes(charset), uidValues);
//            //4)送出like数
//            return connection.sCard((RedisKeyConstant.REDIS_MY_LIKED_SET_KEY_ + uid).getBytes(charset));
//            //5) 送出dislike数--(已推荐过的列表 与 用户送出like的列表的交集，或许可以单独存储一个pool，只是需要数量的话计算交集集合不划算)
//            return SerializationUtils.deserialize(connection.sInter((RedisKeyConstant.REDIS_MY_LIKED_SET_KEY_ + uid).getBytes(charset), (RedisKeyConstant.REDIS_RECOMMENDED_SET_KEY_ + uid).getBytes(charset)), stringSerializer);
//            //6) 滑动数量 每天用户滑动的数量(如果要计算用户的总的滑动数量，可单独处理REDIS_DAILY_ACT_NUM_ZSET_KEY_)
//           return connection.zScore((RedisKeyConstant.REDIS_DAILY_ACT_NUM_ZSET_KEY_ + "20180614").getBytes(charset), uidValues);
//            //7) 被like数 + 被超级喜欢数
//           return  connection.sCard((RedisKeyConstant.REDIS_BE_LIKED_TEMP_SET_KEY_ + uid).getBytes(charset));
//            //8)
//            return connection.sCard((RedisKeyConstant.REDIS_BE_SUPER_LIKED_TEMP_SET_KEY_ + uid).getBytes(charset));
//            //9) 被dislike数
//            return connection.sCard((RedisKeyConstant.REDIS_BE_UN_LIKED_SET_KEY_ + uid).getBytes(charset));
//            //10) 成功match次数
//           return connection.zScore(RedisKeyConstant.REDIS_MATCH_NUM_ZSET_KEY.getBytes(charset), uidValues);
//            //11) 受欢迎程度(被like数/被dislike数)
//            return connection.zScore(RedisKeyConstant.REDIS_USER_POPULAR_ZSET_KEY.getBytes(charset), uidValues);
//            //12) 挑剔程度(送出like数/送出dislike数)
//            return connection.zScore(RedisKeyConstant.REDIS_USER_TASTE_ZSET_KEY.getBytes(charset), uidValues);
//            //13) 热门用户(运营筛选) -- 是否是热门用户
//            return connection.sIsMember(RedisKeyConstant.REDIS_HOT_USER_SET_KEY.getBytes(charset), uidValues);
            return null;
        });

        final Object activityTimestamp = objects.get(0);
        if (activityTimestamp == null) {
            System.out.println(0);
        } else {
            long timestamp = Long.valueOf(String.valueOf(activityTimestamp));
            DateTime begin = new DateTime(new SimpleDateFormat("yyyy-MM-dd").format(new Date(timestamp * 1000)));
            DateTime end = new DateTime(DateUtil.getOffsetDateString(0, null, null, "yyyy-MM-dd"));
            Period p = new Period(begin, end, PeriodType.days());
            System.out.println(p.getDays());
        }
    }

    @Test
    public void teste() {
        List<String> recallUids = Lists.newArrayList();
        for (int i = 0; i < 10; i++) {
            recallUids.add(String.valueOf(i));
        }
        final RedisTemplate<String, String> redisTemplate = redisService.getRedisTemplate();
        final RedisSerializer<String> redisSerializer = redisTemplate.getStringSerializer();

    }

    @Test
    public void testRequest() {
        RecommendAdvanceRequest request = new RecommendAdvanceRequest();
        request.setUid(20L);
        Integer areaId = 24;

        final Long uid = request.getUid();
        Charset charset = StandardCharsets.UTF_8;

        final byte[] uidValues = RedisKeyUtil.serializeUid(uid).getBytes(charset);

        final List<Object> objects = redisService.execPipelineForWrite(connection -> {
            //0) 获取性别
            connection.hSet(RedisKeyUtil.obtainKey(RedisKeyConstant.REDIS_USER_HASH_KEY, uid).getBytes(charset),
                    RedisKeyConstant.REDIS_USER_HASH_GENDER.getBytes(charset), "1".getBytes(charset));
            //1)生日 毫秒
            connection.hSet(RedisKeyUtil.obtainKey(RedisKeyConstant.REDIS_USER_HASH_KEY, uid).getBytes(charset),
                    RedisKeyConstant.REDIS_USER_HASH_BIRTH_TIMESTAMP.getBytes(charset),
                    (DateTime.now().minusYears(18).getMillis() + "").getBytes(charset));
            //2)是否是新用户
            connection.sAdd(((areaId == null ? "" : (areaId + "_")) + RedisKeyConstant.REDIS_NEW_COME_USER_SET_KEY).getBytes(charset), uidValues);
            //3)送出like数
            connection.sAdd((RedisKeyConstant.REDIS_MY_LIKED_SET_KEY_ + uid).getBytes(charset), "30".getBytes(charset));
            //送出dislike数--(已推荐过的列表 与 用户送出like的列表的交集，或许可以单独存储一个pool，只是需要数量的话计算交集集合不划算)
            //SerializationUtils.deserialize(connection.sInter((RedisKeyConstant.REDIS_MY_LIKED_SET_KEY_ + uid).getBytes(charset), (RedisKeyConstant.REDIS_RECOMMENDED_SET_KEY_ + uid).getBytes(charset)), stringSerializer);
            //4) 用户送出like的列表的交集
            connection.sAdd((RedisKeyConstant.REDIS_MY_LIKED_SET_KEY_ + uid).getBytes(charset), "31".getBytes(charset));
            //5) 已推荐过的数量  已看过的数量?
            connection.sCard((RedisKeyConstant.REDIS_MY_LIKED_SET_KEY_ + -1).getBytes(charset));//todo:暂时为0,反正没有用到，之后改为从u_h_当中获取
            //connection.sCard((RedisKeyConstant.REDIS_RECOMMENDED_SET_KEY_ + uid).getBytes(charset));
            //6) 滑动数量 每天用户滑动的数量(如果要计算用户的总的滑动数量，可单独处理REDIS_DAILY_ACT_NUM_ZSET_KEY_)
            connection.zScore(((areaId == null ? "" : (areaId + "_")) + RedisKeyConstant.REDIS_DAILY_ACT_NUM_ZSET_KEY_ + DateUtil.getOffsetDateString(0, null, null, "yyyyMMdd")).getBytes(charset), uidValues);
            //7) 被like数 + 被超级喜欢数
            connection.sAdd((RedisKeyConstant.REDIS_BE_LIKED_TEMP_SET_KEY_ + uid).getBytes(charset), "23".getBytes(charset));
            //8)
            connection.sAdd((RedisKeyConstant.REDIS_BE_SUPER_LIKED_TEMP_SET_KEY_ + uid).getBytes(charset), "24".getBytes(charset));
            //9) 被dislike数
            connection.sCard((RedisKeyConstant.REDIS_BE_UN_LIKED_SET_KEY_NEW + uid).getBytes(charset));
            //13) 热门用户(运营筛选) -- 是否是热门用户
            connection.sAdd(RedisKeyConstant.REDIS_HOT_USER_SET_KEY.getBytes(charset), uidValues);
            //被滑动数量--暂时没有相关数据
            //connection.get((RedisKeyConstant.REDIS_USER_ACTIVITY_TIMESTAMP_STR_KEY_ + uid).getBytes(charset));
            //14 活跃时间--最近X天有登录
            connection.hSet(RedisKeyUtil.obtainKey(RedisKeyConstant.REDIS_USER_HASH_KEY, uid).getBytes(charset),
                    RedisKeyConstant.REDIS_USER_HASH_ACTIVITY_TIME.getBytes(), (DateUtil.getCurrentSecondIntValue() + "").getBytes(charset));
            //15) 获取用户fromType
            connection.hSet(
                    RedisKeyUtil.obtainKey(RedisKeyConstant.REDIS_USER_HASH_KEY, uid).getBytes(StandardCharsets.UTF_8),
                    RedisKeyConstant.REDIS_USER_HASH_FROM_TYPE.getBytes(StandardCharsets.UTF_8), "3".getBytes(charset));
            return null;
        });

        final ConditionRequest strategyRequest = paramsConverter.obtainStrategyRequest(request);
        System.out.println(strategyRequest);
    }

}
