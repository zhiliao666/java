package com.ufoto.utils.redis;

import com.google.common.collect.Lists;
import com.google.common.collect.Sets;
import com.ufoto.BaseUnitTest;
import org.junit.Assert;
import org.junit.Before;
import org.junit.Test;
import org.junit.runner.RunWith;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.context.SpringBootTest;
import org.springframework.test.context.junit4.SpringRunner;

import java.util.Collections;
import java.util.List;
import java.util.Set;

import static org.junit.Assert.*;

/**
 * Created by echo on 9/25/18.
 */
public class RedisServiceTest extends BaseUnitTest{

    @Autowired
    RedisService redisService;

    private final static String TEST_REDIS_KEY = "TEST_REDIS_KEY";

    @Before
    public void setUpEnv(){
        redisService.del(TEST_REDIS_KEY);
    }

    @Test
    public void testLPush(){
        String[] testItems = {"item1","item2","item3"};
        List<String> testList = Lists.newArrayList(testItems);
        Collections.reverse(testList);

        long result = redisService.lpush(TEST_REDIS_KEY,testItems);
        Assert.assertEquals(result,testItems.length);

        List<String> resultList = redisService.lrange(TEST_REDIS_KEY,0,-1);
        Assert.assertEquals(resultList,testList);

        String anotherItem = "item4";
        testList.add(0,anotherItem);
        result = redisService.lpush(TEST_REDIS_KEY,anotherItem);
        Assert.assertEquals(result,testList.size());
        resultList = redisService.lrange(TEST_REDIS_KEY,0,-1);
        Assert.assertEquals(resultList,testList);
    }

    @Test
    public void testRPush(){
        String[] testItems = {"item1","item2","item3"};
        List<String> testList = Lists.newArrayList(testItems);

        long result = redisService.rpush(TEST_REDIS_KEY,testItems);
        Assert.assertEquals(result,testItems.length);

        List<String> resultList = redisService.lrange(TEST_REDIS_KEY,0,-1);
        Assert.assertEquals(resultList,testList);

        String anotherItem = "item4";
        testList.add(anotherItem);
        result = redisService.rpush(TEST_REDIS_KEY,anotherItem);
        Assert.assertEquals(result,testList.size());
        resultList = redisService.lrange(TEST_REDIS_KEY,0,-1);
        Assert.assertEquals(resultList,testList);
    }

    @Test
    public void testLPop(){
        String[] testItems = {"item1","item2","item3"};
        redisService.rpush(TEST_REDIS_KEY,testItems);
        for(int i=0;i<testItems.length;i++){
            Assert.assertEquals(testItems[i],redisService.lpop(TEST_REDIS_KEY));
        }
    }


    @Test
    public void testRPop(){
        String[] testItems = {"item1","item2","item3"};
        redisService.rpush(TEST_REDIS_KEY,testItems);
        for(int i=testItems.length-1;i>=0;i--){
            Assert.assertEquals(testItems[i],redisService.rpop(TEST_REDIS_KEY));
        }
    }

    @Test
    public void testSetIntersection(){
        String[] testItemArray = {"fuckingGood!","SpiderMan!"};
        Set<String> testStrSet = Sets.newHashSet(testItemArray);
        redisService.sadd(TEST_REDIS_KEY,testItemArray);
        Set<String> mySet = Sets.newHashSet("SpiderMan!");

        Set<String> result = redisService.setIntersection(TEST_REDIS_KEY,mySet);
        testStrSet.retainAll(mySet);
        Assert.assertEquals(testStrSet,result);
    }

    @Test
    public void testSetIntersectionEmptySet(){
        String[] testItemArray = {"fuckingGood!","SpiderMan!"};
        Set<String> testStrSet = Sets.newHashSet(testItemArray);
        redisService.sadd(TEST_REDIS_KEY,testItemArray);
        Set<String> mySet = null;

        Set<String> result = redisService.setIntersection(TEST_REDIS_KEY,mySet);
        Assert.assertEquals(mySet,result);

        result = redisService.setIntersection(TEST_REDIS_KEY,Sets.newHashSet());
        Assert.assertEquals(Sets.newHashSet(),result);
    }

    @Test
    public void testSetIntersectionInvalidKey(){
        Set<String> mySet = Sets.newHashSet("SpiderMan!");
        redisService.del(TEST_REDIS_KEY);
        Set<String> result = redisService.setIntersection(TEST_REDIS_KEY,mySet);
        Assert.assertEquals(Sets.newHashSet(),result);
    }

    @Test
    public void testHIncrBy(){
        String key = "FuckingKey";
        String field = "FuckingField";
        redisService.del(key);

        Long result = redisService.hIncrBy(key,field,1L);
        Assert.assertEquals(result,Long.valueOf(1L));

        result = redisService.hIncrBy(key,field,1L);
        Assert.assertEquals(result,Long.valueOf(2L));
        String fieldResult = redisService.hget(key,field);
        Assert.assertEquals(fieldResult,String.valueOf(2L));

    }


}