package com.ufoto.dao.bi;

import com.ufoto.BaseUnitTest;
import com.ufoto.dto.DumpUserDto;
import org.junit.Assert;
import org.junit.Test;
import org.springframework.beans.factory.annotation.Autowired;

import java.sql.Date;
import java.time.LocalDate;
import java.util.List;

/**
 * Created by echo on 4/16/19.
 */
public class UfotoDayActiveUserRecordMapperTest extends BaseUnitTest {

    @Autowired
    UfotoDayActiveUserRecordMapper ufotoDayActiveUserRecordMapper;

    @Test
    public void testSelectUidListByDate() {
        int limitDays = 12;
        LocalDate limitLocalDate = LocalDate.now().minusDays(limitDays + 1);
        List<DumpUserDto> uidList = ufotoDayActiveUserRecordMapper.selectUidListByDate(0, Date.valueOf(limitLocalDate));

        Assert.assertEquals(uidList.size(), 3);
    }

}
