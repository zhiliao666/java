package com.ufoto.business.recommend.filter.chatsnap;

import com.google.common.collect.Lists;
import com.google.common.collect.Sets;
import com.ufoto.BaseUnitTest;
import com.ufoto.dto.RecommendAdvanceRequest;
import com.ufoto.utils.redis.RedisKeyConstant;
import com.ufoto.utils.redis.RedisKeyUtil;
import com.ufoto.utils.redis.RedisService;
import org.apache.commons.lang3.RandomUtils;
import org.junit.Test;
import org.springframework.beans.factory.annotation.Autowired;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

/**
 * <p>
 * Author     : Chan
 * CreateDate : 2019-08-29 16:56
 * Description:
 * </p>
 */
public class ChatSnapFilterStrategyTest extends BaseUnitTest {

    @Autowired
    private ChatSnapFilterStrategy chatSnapFilterStrategy;

    @Autowired
    private RedisService redisService;

    @Test
    public void filter() {
        List<String> uids = new ArrayList<>();
        for (int i = 0; i < 50; i++) {
            uids.add(RandomUtils.nextLong(100, 200) + "");
        }

        for (String uid : uids.subList(0, 10)) {
            Map<String, String> map = new HashMap<>();
            map.put(RedisKeyConstant.REDIS_USER_HASH_FROM_TYPE, RandomUtils.nextInt(1, 11) + "");
            map.put(RedisKeyConstant.REDIS_USER_HASH_GENDER, RandomUtils.nextInt(0, 3) + "");
            redisService.hMSet(RedisKeyUtil.obtainKey(RedisKeyConstant.REDIS_USER_HASH_KEY, uid), map);
        }

        redisService.hset(RedisKeyUtil.obtainKey(RedisKeyConstant.REDIS_USER_HASH_KEY, 20),
                RedisKeyConstant.REDIS_USER_HASH_GENDER, "1");
        redisService.hset(RedisKeyUtil.obtainKey(RedisKeyConstant.REDIS_USER_HASH_KEY, 20),
                RedisKeyConstant.REDIS_USER_HASH_FROM_TYPE, "3");
        RecommendAdvanceRequest request = new RecommendAdvanceRequest();
        request.setUid(20L);
        chatSnapFilterStrategy.filter(Sets.newHashSet(uids), Lists.newArrayList(), request);
    }
}
