package com.ufoto.business.recommend.sort.act;

import com.google.common.collect.Lists;
import com.ufoto.BaseUnitTest;
import com.ufoto.business.recommend.bean.SortParamsBean;
import com.ufoto.utils.DateUtil;
import com.ufoto.utils.redis.RedisKeyConstant;
import com.ufoto.utils.redis.RedisService;
import lombok.extern.slf4j.Slf4j;
import org.apache.commons.lang3.RandomUtils;
import org.junit.Test;
import org.springframework.beans.factory.annotation.Autowired;

import java.util.List;
import java.util.Map;

/**
 * <p>
 * Author     : Chan
 * CreateDate : 2019-09-09 17:00
 * Description:
 * </p>
 */
@Slf4j
public class DailyActNumSortStrategyTest extends BaseUnitTest {

    @Autowired
    private DailyActNumSortStrategy dailyActNumSortStrategy;

    @Autowired
    private RedisService redisService;

    @Test
    public void getScore() {
        String key = RedisKeyConstant.REDIS_DAILY_ACT_NUM_ZSET_KEY_ + DateUtil.getCurrentDateStr("yyyyMMdd");
        List<String> list = Lists.newArrayList();
        for (int i = 0; i < 100; i++) {
            final String uid = RandomUtils.nextLong(100, 200) + "";
            list.add(uid);
            redisService.zadd(key, uid, RandomUtils.nextDouble(10, 100));
        }
        dailyActNumSortStrategy.updateCache();

        final Map<String, Double> score = dailyActNumSortStrategy.getScore(list.subList(20, 30), new SortParamsBean());
        log.debug("scoreMap:{}", score);
    }
}
