package com.ufoto.service;

import com.google.common.collect.Lists;
import com.google.common.collect.Maps;
import com.google.common.collect.Sets;
import com.ufoto.BaseUnitTest;
import com.ufoto.business.recommend.filter.recommended.RecommendedBFManager;
import com.ufoto.dao.bi.UfotoDayActiveUserRecordMapper;
import com.ufoto.dao.dump.UfotoRecommendRedisDumpMapper;
import com.ufoto.dto.DumpUserDto;
import com.ufoto.entity.UfotoRecommendRedisDump;
import com.ufoto.utils.DateUtil;
import com.ufoto.utils.redis.RedisKeyConstant;
import com.ufoto.utils.redis.RedisKeyUtil;
import com.ufoto.utils.redis.RedisService;
import org.apache.commons.lang.math.RandomUtils;
import org.junit.Assert;
import org.junit.Test;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.mock.mockito.MockBean;
import org.springframework.data.redis.core.ZSetOperations;
import org.springframework.transaction.annotation.Transactional;

import java.util.List;
import java.util.Map;
import java.util.Set;
import java.util.stream.Collectors;

import static org.mockito.ArgumentMatchers.any;
import static org.mockito.Mockito.when;

/**
 * Created by echo on 12/12/18.
 */
public class UfotoRecommendRedisDumpServiceImplTest extends BaseUnitTest {

    @Autowired
    UfotoRecommendRedisDumpServiceImpl ufotoRecommendRedisDumpService;

    @Autowired
    UfotoRecommendRedisDumpMapper ufotoRecommendRedisDumpMapper;

    @Autowired
    RedisService redisService;

    @Autowired
    RecommendedBFManager recommendedBFManager;

    @MockBean
    UfotoDayActiveUserRecordMapper ufotoDayActiveUserRecordMapper;


    Long uid = 1L;
    List<String> needDumpHashKeyList = Lists.newArrayList(
            RedisKeyUtil.obtainKey(RedisKeyConstant.REDIS_USER_HASH_KEY, uid),
            RedisKeyUtil.obtainKey(RedisKeyConstant.REDIS_RECOMMENDED_BF_HASH, uid)
    );
    List<String> needDumpSetKeyList = Lists.newArrayList(
            RedisKeyConstant.REDIS_BE_UN_LIKED_SET_KEY_ + uid,
            RedisKeyConstant.REDIS_BE_UN_LIKED_SET_KEY_NEW + uid,
            RedisKeyConstant.REDIS_MY_LIKED_SET_KEY_ + uid,
            RedisKeyConstant.REDIS_BE_LIKED_SET_KEY_ + uid,
            RedisKeyConstant.REDIS_BE_LIKED_TEMP_SET_KEY_ + uid,
            RedisKeyConstant.REDIS_MY_SUPER_LIKED_SET_KEY_ + uid,
            RedisKeyConstant.REDIS_BE_SUPER_LIKED_SET_KEY_ + uid,
            RedisKeyConstant.REDIS_BE_SUPER_LIKED_TEMP_SET_KEY_ + uid
    );
    List<String> needDumpZSetKeyList = Lists.newArrayList(
//            RedisKeyConstant.REDIS_RECOMMENDED_ZSET_KEY_ + uid
    );

    List<String> needDumpStringKeyList = Lists.newLinkedList();


    Map<String, Map<String, String>> hashKeyDataMap;
    Map<String, Set<String>> setKeyDataMap;
    Map<String, Set<ZSetOperations.TypedTuple<String>>> zsetKeyDataMap;
    Map<String, String> stringKeyDataMap;

    Integer lastActTime = null;
    List<UfotoRecommendRedisDump> exceptedRedisDumpList = null;


    //    @Before
    public void set() throws InterruptedException {
        when(ufotoDayActiveUserRecordMapper.selectUidListByDate(0, any()))
                .thenReturn(Lists.newArrayList(new DumpUserDto()));

        needDumpStringKeyList.clear();
        needDumpStringKeyList.addAll(recommendedBFManager.allBFKeyList(uid));

        lastActTime = DateUtil.getCurrentSecondIntValue() - 60 * 60 * 24 * 16;
        byte[] dumpBytes = null;
        exceptedRedisDumpList = Lists.newLinkedList();

        hashKeyDataMap = Maps.newHashMap();
        setKeyDataMap = Maps.newHashMap();
        zsetKeyDataMap = Maps.newHashMap();
        stringKeyDataMap = Maps.newHashMap();
        //HASH
        for (String key : needDumpHashKeyList) {
            Map<String, String> randomData = createRandomNoiseMap(100000);
            redisService.del(key);
            redisService.hMSet(key, randomData);
            //ugly..
            redisService.hset(RedisKeyUtil.obtainKey(RedisKeyConstant.REDIS_USER_HASH_KEY, uid),
                    RedisKeyConstant.REDIS_USER_HASH_ACTIVITY_TIME,
                    String.valueOf(lastActTime));
            Thread.sleep(100);
            hashKeyDataMap.put(key, redisService.hGetAll(key));
            dumpBytes = redisService.dump(key);
            UfotoRecommendRedisDump userHashDump = new UfotoRecommendRedisDump();
            userHashDump.setHasRestored(false);
            userHashDump.setKey(key);
            userHashDump.setUid(uid);
            userHashDump.setDump(ufotoRecommendRedisDumpService.encode(dumpBytes));
            userHashDump.setLastActTime(lastActTime);
            exceptedRedisDumpList.add(userHashDump);
        }

        //SET
        for (String key : needDumpSetKeyList) {
            String[] noiseData = createRandomNoiseArray(100000);
            redisService.del(key);
            redisService.sadd(key, noiseData);
            Thread.sleep(100);
            setKeyDataMap.put(key, redisService.sMember(key));
            dumpBytes = redisService.dump(key);
            UfotoRecommendRedisDump userHashDump = new UfotoRecommendRedisDump();
            userHashDump.setHasRestored(false);
            userHashDump.setKey(key);
            userHashDump.setUid(uid);
            userHashDump.setDump(ufotoRecommendRedisDumpService.encode(dumpBytes));
            userHashDump.setLastActTime(lastActTime);
            exceptedRedisDumpList.add(userHashDump);
        }

        //ZSET
        for (String key : needDumpZSetKeyList) {
            String[] noiseData = createRandomNoiseArray(100000);
            redisService.del(key);
            for (String noise : noiseData) {
                redisService.zadd(key, noise, RandomUtils.nextDouble());
            }
            Thread.sleep(100);
            zsetKeyDataMap.put(key, redisService.zrangeWithScores(key, 0, -1));
            dumpBytes = redisService.dump(key);
            UfotoRecommendRedisDump userHashDump = new UfotoRecommendRedisDump();
            userHashDump.setHasRestored(false);
            userHashDump.setKey(key);
            userHashDump.setUid(uid);
            userHashDump.setDump(ufotoRecommendRedisDumpService.encode(dumpBytes));
            userHashDump.setLastActTime(lastActTime);
            exceptedRedisDumpList.add(userHashDump);
        }

        //STRING
        for (String key : needDumpStringKeyList) {
            redisService.del(key);
            redisService.set(key, String.valueOf(RandomUtils.nextLong()));
            Thread.sleep(100);
            stringKeyDataMap.put(key, redisService.get(key));
            dumpBytes = redisService.dump(key);
            UfotoRecommendRedisDump userStringDump = new UfotoRecommendRedisDump();
            userStringDump.setHasRestored(false);
            userStringDump.setKey(key);
            userStringDump.setUid(uid);
            userStringDump.setDump(ufotoRecommendRedisDumpService.encode(dumpBytes));
            userStringDump.setLastActTime(lastActTime);
            exceptedRedisDumpList.add(userStringDump);
        }

    }

    /**
     * 正常情况
     */
    @Test
    @Transactional(transactionManager = "dumpRedisTransactionManager")
    public void testDump() {
        ufotoRecommendRedisDumpService.dumpExpiredUserRedisData();
        List<UfotoRecommendRedisDump> dumpList = ufotoRecommendRedisDumpMapper.selectForRestoreByUid(uid);
        Assert.assertEquals(Sets.newHashSet(exceptedRedisDumpList), Sets.newHashSet(dumpList));

        List<UfotoRecommendRedisDump> createDumpList = ufotoRecommendRedisDumpService.createDumpKeyList(uid, lastActTime);
        Assert.assertTrue(createDumpList.size() == 0);
    }

    /**
     * 用户没有过期情况
     */
    @Test
    @Transactional(transactionManager = "dumpRedisTransactionManager")
    public void testDumpNoExpire() {
        redisService.hset(RedisKeyUtil.obtainKey(RedisKeyConstant.REDIS_USER_HASH_KEY, uid),
                RedisKeyConstant.REDIS_USER_HASH_ACTIVITY_TIME,
                String.valueOf(DateUtil.getCurrentSecondIntValue()));
        ufotoRecommendRedisDumpService.dumpExpiredUserRedisData();
        List<UfotoRecommendRedisDump> dumpList = ufotoRecommendRedisDumpMapper.selectForRestoreByUid(uid);
        Assert.assertEquals(Sets.newHashSet(), Sets.newHashSet(dumpList));
    }

    /**
     * 正常情况下的Restore
     */
    @Test
    @Transactional(transactionManager = "dumpRedisTransactionManager")
    public void testRestore() {
        ufotoRecommendRedisDumpService.dumpExpiredUserRedisData();
        ufotoRecommendRedisDumpService.restore(uid);
        List<UfotoRecommendRedisDump> dumpList = ufotoRecommendRedisDumpMapper.selectForRestoreByUid(uid);
        Assert.assertTrue(dumpList.size() == 0);

        for (Map.Entry<String, Map<String, String>> entry : hashKeyDataMap.entrySet()) {
            Assert.assertEquals(entry.getValue(), redisService.hGetAll(entry.getKey()));
        }
        for (Map.Entry<String, Set<String>> entry : setKeyDataMap.entrySet()) {
            Assert.assertEquals(entry.getValue(), redisService.sMember(entry.getKey()));
        }
        for (Map.Entry<String, Set<ZSetOperations.TypedTuple<String>>> entry : zsetKeyDataMap.entrySet()) {
            Assert.assertEquals(entry.getValue(), redisService.zrangeWithScores(entry.getKey(), 0, -1));
        }
        for (Map.Entry<String, String> entry : stringKeyDataMap.entrySet()) {
            Assert.assertEquals(entry.getValue(), redisService.get(entry.getKey()));
        }
//        List<UfotoRecommendRedisDump> createDumpList = ufotoRecommendRedisDumpService.createDumpKeyList(uid,lastActTime);
//        Assert.assertEquals(Sets.newHashSet(exceptedRedisDumpList), Sets.newHashSet(createDumpList));
    }


    /**
     * 正常情况下的DumpList
     */
    @Test
    public void testCreateDumpKeyList() {
        List<UfotoRecommendRedisDump> dumpList = ufotoRecommendRedisDumpService.createDumpKeyList(uid, lastActTime);
        Assert.assertEquals(Sets.newHashSet(exceptedRedisDumpList), Sets.newHashSet(dumpList));
    }

    /**
     * 部分内容为空的DumpList
     */
    @Test
    public void testCreateDumpKeyListWithNull() {
        List<String> allKeyList = Lists.newArrayList(needDumpHashKeyList);
        allKeyList.addAll(needDumpSetKeyList);
        allKeyList.addAll(needDumpZSetKeyList);
        allKeyList.addAll(needDumpStringKeyList);
        for (String key : allKeyList) {
            if (RandomUtils.nextBoolean()) {//del it
                redisService.del(key);
                exceptedRedisDumpList = exceptedRedisDumpList.stream()
                        .filter(dump -> !dump.getKey().equals(key))
                        .collect(Collectors.toList());
            }
        }
        List<UfotoRecommendRedisDump> dumpList = ufotoRecommendRedisDumpService.createDumpKeyList(uid, lastActTime);
        Assert.assertEquals(Sets.newHashSet(exceptedRedisDumpList), Sets.newHashSet(dumpList));
    }

    /**
     * 全空的DumpList
     */
    @Test
    public void testCreateDumpKeyListWithAllNull() {
        List<String> allKeyList = Lists.newArrayList(needDumpHashKeyList);
        allKeyList.addAll(needDumpSetKeyList);
        allKeyList.addAll(needDumpZSetKeyList);
        allKeyList.addAll(needDumpStringKeyList);
        exceptedRedisDumpList = Lists.newLinkedList();
        for (String key : allKeyList) {
            redisService.del(key);
        }
        List<UfotoRecommendRedisDump> dumpList = ufotoRecommendRedisDumpService.createDumpKeyList(uid, lastActTime);
        Assert.assertEquals(Sets.newHashSet(exceptedRedisDumpList), Sets.newHashSet(dumpList));
    }

    @Test
    public void testDoDumpAndRestore() {
//        redisService.sadd(RedisKeyConstant.REDIS_BE_UN_LIKED_SET_KEY_ + uid,
//                LongStream.range(100, 200).mapToObj(String::valueOf).toArray(String[]::new));
//        ufotoRecommendRedisDumpService.dumpExpiredUserRedisData();
        ufotoRecommendRedisDumpService.restore(373236319310053377L);
    }
}
