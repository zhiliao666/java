package com.ufoto.business.recommend.filter.userlevel;

import com.google.common.collect.Lists;
import com.google.common.collect.Sets;
import com.ufoto.BaseUnitTest;
import com.ufoto.dto.RecommendAdvanceRequest;
import org.junit.Test;
import org.springframework.beans.factory.annotation.Autowired;

import java.util.Set;

/**
 * <p>
 * Description:
 *
 * </p>
 *
 * @author Chan
 * @date 2020/2/15 13:15
 */
public class HighRiskFilterStrategyTest extends BaseUnitTest {

    @Autowired
    private HighRiskFilterStrategy highRiskFilterStrategy;

    @Test
    public void filter() {
        final Set<String> filter = highRiskFilterStrategy.filter(Sets.newHashSet("100"), Lists.newArrayList(), new RecommendAdvanceRequest());
        System.out.println(filter);
    }
}
