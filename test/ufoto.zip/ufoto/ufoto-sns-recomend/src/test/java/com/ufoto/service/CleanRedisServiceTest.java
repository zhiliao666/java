package com.ufoto.service;

import com.google.common.collect.Lists;
import com.google.common.collect.Sets;
import com.ufoto.BaseUnitTest;
import com.ufoto.business.recommend.filter.recommended.RecommendedBFManager;
import com.ufoto.utils.DateUtil;
import com.ufoto.utils.redis.RedisKeyConstant;
import com.ufoto.utils.redis.RedisKeyUtil;
import com.ufoto.utils.redis.RedisService;
import org.junit.Assert;
import org.junit.Test;
import org.junit.runner.RunWith;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.context.SpringBootTest;
import org.springframework.test.context.junit4.SpringRunner;

import javax.validation.constraints.AssertTrue;
import java.util.List;
import java.util.Set;
import java.util.stream.Collectors;
import java.util.stream.LongStream;

/**
 * Created by echo on 8/14/18.
 */

public class CleanRedisServiceTest extends BaseUnitTest{

    @Autowired
    CleanRedisService cleanRedisService;

    @Autowired
    RedisService redisService;

    @Autowired
    RecommendService recommendService;

    @Autowired
    RecommendedBFManager recommendedBFManager;

    /**
     * 测试超过三天没有活跃的用户，是否会被清除
     */
    @Test
    public void cleanOldNewComeUserSetTestA() {
        Integer current = DateUtil.getCurrentSecondIntValue();
        Long uid = null;

        //7 ,null ,1
        uid = 7L ;
        redisService.sadd(RedisKeyConstant.REDIS_NEW_COME_USER_SET_KEY, String.valueOf(uid));
        recommendService.addRedisUserActivityTimestamp(uid, current - 60 * 60 * 24 * 1);

        //8 ,null ,2
        uid = 8L ;
        redisService.sadd(RedisKeyConstant.REDIS_NEW_COME_USER_SET_KEY, String.valueOf(uid));
        recommendService.addRedisUserActivityTimestamp(uid, current - 60 * 60 * 24 * 2);

        cleanRedisService.cleanOldNewComeUserSet();

        Assert.assertTrue(!redisService.isMember(RedisKeyConstant.REDIS_NEW_COME_USER_SET_KEY, "9527"));

        Assert.assertTrue(!redisService.isMember(RedisKeyConstant.REDIS_NEW_COME_USER_SET_KEY, "9528"));

    }


    /**
     * 测试三天内有活跃的用户，是否会被清除
     */
    @Test
    public void cleanOldNewComeUserSetTestB() {
        Integer current = DateUtil.getCurrentSecondIntValue();

        //7 ,null ,23
        Long uidA = 7L;
        redisService.sadd(RedisKeyConstant.REDIS_NEW_COME_USER_SET_KEY, String.valueOf(uidA));
        recommendService.addRedisUserActivityTimestamp(uidA, current - 60 * 60 * 23 * 1);

        //8 ,null ,22
        Long uidB = 8L;
        redisService.sadd(RedisKeyConstant.REDIS_NEW_COME_USER_SET_KEY, String.valueOf(uidB));
        recommendService.addRedisUserActivityTimestamp(uidB, current - 60 * 60 * 22 * 1);

        //9 ,101 ,0
        Long uidC = 9L;
        redisService.sadd(RedisKeyConstant.REDIS_NEW_COME_USER_SET_KEY, String.valueOf(uidC));
        recommendService.addRedisUserActivityTimestamp(uidC, current - 60 * 60 * 24 * 0);

        cleanRedisService.cleanOldNewComeUserSet();

        Assert.assertTrue(redisService.isMember(RedisKeyConstant.REDIS_NEW_COME_USER_SET_KEY, String.valueOf(uidA)));

        Assert.assertTrue(redisService.isMember(RedisKeyConstant.REDIS_NEW_COME_USER_SET_KEY, String.valueOf(uidB)));

        Assert.assertTrue(redisService.isMember(RedisKeyConstant.REDIS_NEW_COME_USER_SET_KEY, String.valueOf(uidC)));

    }

    @Test
    public void testClearExpired24hAct() throws InterruptedException {
        Integer currentTime = DateUtil.getCurrentSecondIntValue();

        Long uidA = 7L;
        Long uidB = 8L;
        Long uidC = 9L;
        Long uidD = 10L;
        Integer areaId = 25;
        redisService.sremove(RedisKeyConstant.REDIS_ACT_IN_24H_USER_SET_KEY,String.valueOf(uidA));
        redisService.sremove(RedisKeyConstant.REDIS_ACT_IN_24H_USER_SET_KEY,String.valueOf(uidB));
        redisService.sremove(RedisKeyConstant.REDIS_ACT_IN_24H_USER_SET_KEY,String.valueOf(uidC));
        redisService.sremove(RedisKeyConstant.REDIS_ACT_IN_24H_USER_SET_KEY,String.valueOf(uidD));

        redisService.sremove(RedisKeyConstant.REDIS_ACT_IN_24H_OLD_USER_SET_KEY,String.valueOf(uidA));
        redisService.sremove(RedisKeyConstant.REDIS_ACT_IN_24H_OLD_USER_SET_KEY,String.valueOf(uidB));
        redisService.sremove(RedisKeyConstant.REDIS_ACT_IN_24H_OLD_USER_SET_KEY,String.valueOf(uidC));
        redisService.sremove(RedisKeyConstant.REDIS_ACT_IN_24H_OLD_USER_SET_KEY,String.valueOf(uidD));

        redisService.sremove(RedisKeyConstant.REDIS_ACT_IN_24H_NEW_USER_SET_KEY,String.valueOf(uidA));
        redisService.sremove(RedisKeyConstant.REDIS_ACT_IN_24H_NEW_USER_SET_KEY,String.valueOf(uidB));
        redisService.sremove(RedisKeyConstant.REDIS_ACT_IN_24H_NEW_USER_SET_KEY,String.valueOf(uidC));
        redisService.sremove(RedisKeyConstant.REDIS_ACT_IN_24H_NEW_USER_SET_KEY,String.valueOf(uidD));

        redisService.del(RedisKeyUtil.obtainKey(RedisKeyConstant.REDIS_USER_HASH_KEY,uidA));
        redisService.del(RedisKeyUtil.obtainKey(RedisKeyConstant.REDIS_USER_HASH_KEY,uidB));
        redisService.del(RedisKeyUtil.obtainKey(RedisKeyConstant.REDIS_USER_HASH_KEY,uidC));
        redisService.del(RedisKeyUtil.obtainKey(RedisKeyConstant.REDIS_USER_HASH_KEY,uidD));

        redisService.sremove(
                RedisKeyUtil.obtainKey(RedisKeyConstant.REDIS_AREA_ACT_IN_24H_USER_SET_KEY,areaId),
                String.valueOf(uidD));

        //7 ,old user,act now
        currentTime = DateUtil.getCurrentSecondIntValue();
        recommendService.addRedisUserSignUpTimestamp(uidA,currentTime - 2*24*60*60);
        Thread.sleep(1000);
        recommendService.addRedisUserActivityTimestamp(uidA,currentTime);

        Thread.sleep(1000);
        Assert.assertTrue(redisService.isMember(RedisKeyConstant.REDIS_ACT_IN_24H_USER_SET_KEY,String.valueOf(uidA)));
        Assert.assertTrue(redisService.isMember(RedisKeyConstant.REDIS_ACT_IN_24H_OLD_USER_SET_KEY,String.valueOf(uidA)));
        Assert.assertTrue(!redisService.isMember(RedisKeyConstant.REDIS_ACT_IN_24H_NEW_USER_SET_KEY,String.valueOf(uidA)));

        //8 ,new user,act now
        currentTime = DateUtil.getCurrentSecondIntValue();
        recommendService.addRedisUserSignUpTimestamp(uidB,currentTime - 12*60*60);
        Thread.sleep(1000);
        recommendService.addRedisUserActivityTimestamp(uidB,currentTime);

        Thread.sleep(1000);
        Assert.assertTrue(redisService.isMember(RedisKeyConstant.REDIS_ACT_IN_24H_USER_SET_KEY,String.valueOf(uidB)));
        Assert.assertTrue(!redisService.isMember(RedisKeyConstant.REDIS_ACT_IN_24H_OLD_USER_SET_KEY,String.valueOf(uidB)));
        Assert.assertTrue(redisService.isMember(RedisKeyConstant.REDIS_ACT_IN_24H_NEW_USER_SET_KEY,String.valueOf(uidB)));

        //9 ,old user,act yesterday
        currentTime = DateUtil.getCurrentSecondIntValue();
        recommendService.addRedisUserSignUpTimestamp(uidC,currentTime - 2*24*60*60);
        Thread.sleep(1000);
        recommendService.addRedisUserActivityTimestamp(uidC,currentTime - 24*60*60 + 15);

        Thread.sleep(1000);
        Assert.assertTrue(redisService.isMember(RedisKeyConstant.REDIS_ACT_IN_24H_USER_SET_KEY,String.valueOf(uidC)));
        Assert.assertTrue(redisService.isMember(RedisKeyConstant.REDIS_ACT_IN_24H_OLD_USER_SET_KEY,String.valueOf(uidC)));
        Assert.assertTrue(!redisService.isMember(RedisKeyConstant.REDIS_ACT_IN_24H_NEW_USER_SET_KEY,String.valueOf(uidC)));

        //10, old user, act yesterday,with area id
        currentTime = DateUtil.getCurrentSecondIntValue();
        recommendService.addRedisUserSignUpTimestamp(uidD,currentTime - 2*24*60*60);
        recommendService.addRedisRegionUser(uidD,"FuckingSomething....",areaId);
        Thread.sleep(1000);
        recommendService.addRedisUserActivityTimestamp(uidD,currentTime - 24*60*60 + 15);

        Thread.sleep(1000);
        Assert.assertTrue(redisService.isMember(RedisKeyConstant.REDIS_ACT_IN_24H_USER_SET_KEY,String.valueOf(uidD)));
        Assert.assertTrue(redisService.isMember(RedisKeyConstant.REDIS_ACT_IN_24H_OLD_USER_SET_KEY,String.valueOf(uidD)));
        Assert.assertTrue(!redisService.isMember(RedisKeyConstant.REDIS_ACT_IN_24H_NEW_USER_SET_KEY,String.valueOf(uidD)));
        Assert.assertTrue(redisService.isMember(RedisKeyUtil.obtainKey(RedisKeyConstant.REDIS_AREA_ACT_IN_24H_USER_SET_KEY,areaId),String.valueOf(uidD)));


        Thread.sleep(1000*15);

        cleanRedisService.clearExpired24hAct();

        Assert.assertTrue(redisService.isMember(RedisKeyConstant.REDIS_ACT_IN_24H_USER_SET_KEY,String.valueOf(uidA)));
        Assert.assertTrue(redisService.isMember(RedisKeyConstant.REDIS_ACT_IN_24H_OLD_USER_SET_KEY,String.valueOf(uidA)));
        Assert.assertTrue(!redisService.isMember(RedisKeyConstant.REDIS_ACT_IN_24H_NEW_USER_SET_KEY,String.valueOf(uidA)));

        Assert.assertTrue(redisService.isMember(RedisKeyConstant.REDIS_ACT_IN_24H_USER_SET_KEY,String.valueOf(uidB)));
        Assert.assertTrue(!redisService.isMember(RedisKeyConstant.REDIS_ACT_IN_24H_OLD_USER_SET_KEY,String.valueOf(uidB)));
        Assert.assertTrue(redisService.isMember(RedisKeyConstant.REDIS_ACT_IN_24H_NEW_USER_SET_KEY,String.valueOf(uidB)));

        Assert.assertTrue(!redisService.isMember(RedisKeyConstant.REDIS_ACT_IN_24H_USER_SET_KEY,String.valueOf(uidC)));
        Assert.assertTrue(!redisService.isMember(RedisKeyConstant.REDIS_ACT_IN_24H_OLD_USER_SET_KEY,String.valueOf(uidC)));
        Assert.assertTrue(!redisService.isMember(RedisKeyConstant.REDIS_ACT_IN_24H_NEW_USER_SET_KEY,String.valueOf(uidC)));

        Assert.assertTrue(!redisService.isMember(RedisKeyConstant.REDIS_ACT_IN_24H_USER_SET_KEY,String.valueOf(uidD)));
        Assert.assertTrue(!redisService.isMember(RedisKeyConstant.REDIS_ACT_IN_24H_OLD_USER_SET_KEY,String.valueOf(uidD)));
        Assert.assertTrue(!redisService.isMember(RedisKeyConstant.REDIS_ACT_IN_24H_NEW_USER_SET_KEY,String.valueOf(uidD)));
        Assert.assertTrue(!redisService.isMember(RedisKeyUtil.obtainKey(RedisKeyConstant.REDIS_AREA_ACT_IN_24H_USER_SET_KEY,areaId),String.valueOf(uidD)));
    }


    @Test
    public void testCleanExpiredRecommendedBF(){
        Long uid = 2333333L;
        final String hashKey = RedisKeyUtil.obtainKey(RedisKeyConstant.REDIS_RECOMMENDED_BF_HASH, uid);
        redisService.del(RedisKeyConstant.REDIS_ACT_IN_24H_USER_SET_KEY);
        redisService.sadd(RedisKeyConstant.REDIS_ACT_IN_24H_USER_SET_KEY,String.valueOf(uid));
        recommendedBFManager.clean(uid);

        //ugly
        int currentWeek = recommendedBFManager.getCurrentWeek();
        List<String> expiredKey = Lists.newArrayList(
                RedisKeyUtil.obtainKey(RedisKeyConstant.REDIS_RECOMMENDED_BF_WEEKLY_KEY_,uid,currentWeek-4,0),
                RedisKeyUtil.obtainKey(RedisKeyConstant.REDIS_RECOMMENDED_BF_WEEKLY_KEY_,uid,currentWeek-4,1),
                RedisKeyUtil.obtainKey(RedisKeyConstant.REDIS_RECOMMENDED_BF_WEEKLY_KEY_,uid,currentWeek-4,2),
                RedisKeyUtil.obtainKey(RedisKeyConstant.REDIS_RECOMMENDED_BF_WEEKLY_KEY_,uid,currentWeek-5,0),
                RedisKeyUtil.obtainKey(RedisKeyConstant.REDIS_RECOMMENDED_BF_WEEKLY_KEY_,uid,currentWeek-6,0),
                RedisKeyUtil.obtainKey(RedisKeyConstant.REDIS_RECOMMENDED_BF_WEEKLY_KEY_,uid,currentWeek-6,2)
        );
        List<String> notExpiredKey = Lists.newArrayList(
                RedisKeyUtil.obtainKey(RedisKeyConstant.REDIS_RECOMMENDED_BF_WEEKLY_KEY_,uid,currentWeek-0,0),
                RedisKeyUtil.obtainKey(RedisKeyConstant.REDIS_RECOMMENDED_BF_WEEKLY_KEY_,uid,currentWeek-3,0),
                RedisKeyUtil.obtainKey(RedisKeyConstant.REDIS_RECOMMENDED_BF_WEEKLY_KEY_,uid,currentWeek-3,1),
                RedisKeyUtil.obtainKey(RedisKeyConstant.REDIS_RECOMMENDED_BF_WEEKLY_KEY_,uid,currentWeek-3,2),
                RedisKeyUtil.obtainKey(RedisKeyConstant.REDIS_RECOMMENDED_BF_WEEKLY_KEY_,uid,currentWeek-2,0),
                RedisKeyUtil.obtainKey(RedisKeyConstant.REDIS_RECOMMENDED_BF_WEEKLY_KEY_,uid,currentWeek-1,0),
                RedisKeyUtil.obtainKey(RedisKeyConstant.REDIS_RECOMMENDED_BF_WEEKLY_KEY_,uid,currentWeek-1,2)
        );
        expiredKey.forEach(key->redisService.set(key,"FuckingTest"));
        notExpiredKey.forEach(key->redisService.set(key,"FuckingTest"));
        expiredKey.forEach(key->redisService.hIncrBy(hashKey,key,1000L));
        notExpiredKey.forEach(key->redisService.hIncrBy(hashKey,key,1000L));
        redisService.hset(hashKey,RedisKeyConstant.REDIS_RECOMMENDED_BF_HASH_CURRENT_KEY,notExpiredKey.get(0));

        for(String key : expiredKey){
            Assert.assertTrue(redisService.exists(key));
            Assert.assertNotNull(redisService.hget(hashKey,key));
        }
        for(String key : notExpiredKey){
            Assert.assertTrue(redisService.exists(key));
            Assert.assertNotNull(redisService.hget(hashKey,key));
        }


        cleanRedisService.cleanExpiredRecommendedBF();

        for(String key : expiredKey){
            Assert.assertFalse(redisService.exists(key));
            Assert.assertNull(redisService.hget(hashKey,key));
        }
        for(String key : notExpiredKey){
            Assert.assertTrue(redisService.exists(key));
            Assert.assertNotNull(redisService.hget(hashKey,key));
        }

    }

    @Test
    public void testCleanExpiredRecommendedBFAll(){
        Long uid = 2333333L;
        final String hashKey = RedisKeyUtil.obtainKey(RedisKeyConstant.REDIS_RECOMMENDED_BF_HASH, uid);
        redisService.del(RedisKeyConstant.REDIS_ACT_IN_24H_USER_SET_KEY);
        redisService.sadd(RedisKeyConstant.REDIS_ACT_IN_24H_USER_SET_KEY,String.valueOf(uid));
        recommendedBFManager.clean(uid);

        //ugly
        int currentWeek = recommendedBFManager.getCurrentWeek();
        List<String> expiredKey = Lists.newArrayList(
                RedisKeyUtil.obtainKey(RedisKeyConstant.REDIS_RECOMMENDED_BF_WEEKLY_KEY_,uid,currentWeek-4,0),
                RedisKeyUtil.obtainKey(RedisKeyConstant.REDIS_RECOMMENDED_BF_WEEKLY_KEY_,uid,currentWeek-4,1),
                RedisKeyUtil.obtainKey(RedisKeyConstant.REDIS_RECOMMENDED_BF_WEEKLY_KEY_,uid,currentWeek-4,2),
                RedisKeyUtil.obtainKey(RedisKeyConstant.REDIS_RECOMMENDED_BF_WEEKLY_KEY_,uid,currentWeek-5,0),
                RedisKeyUtil.obtainKey(RedisKeyConstant.REDIS_RECOMMENDED_BF_WEEKLY_KEY_,uid,currentWeek-6,0),
                RedisKeyUtil.obtainKey(RedisKeyConstant.REDIS_RECOMMENDED_BF_WEEKLY_KEY_,uid,currentWeek-6,2)
        );
        expiredKey.forEach(key->redisService.set(key,"FuckingTest"));
        expiredKey.forEach(key->redisService.hIncrBy(hashKey,key,1000L));
        redisService.hset(hashKey,RedisKeyConstant.REDIS_RECOMMENDED_BF_HASH_CURRENT_KEY,expiredKey.get(0));

        for(String key : expiredKey){
            Assert.assertTrue(redisService.exists(key));
            Assert.assertNotNull(redisService.hget(hashKey,key));
        }

        cleanRedisService.cleanExpiredRecommendedBF();

        for(String key : expiredKey){
            Assert.assertFalse(redisService.exists(key));
        }
        Assert.assertFalse(redisService.exists(hashKey));

    }
}
