package com.ufoto.business.recommendNG.recall;

import com.google.common.collect.Sets;
import com.ufoto.BaseUnitTest;
import com.ufoto.dto.RecommendAdvanceRequest;
import com.ufoto.utils.redis.RedisKeyConstant;
import com.ufoto.utils.redis.RedisService;
import org.junit.Assert;
import org.junit.Test;
import org.springframework.beans.factory.annotation.Autowired;

import java.util.Set;

import static org.junit.Assert.*;

/**
 * Created by echo on 12/18/18.
 */
public class NGHotRecallTest extends BaseUnitTest{

    @Autowired
    NGHotRecall ngHotRecall;

    @Autowired
    private RedisService redisService;

    RecommendAdvanceRequest recommendAdvanceRequest = new RecommendAdvanceRequest();

    @Test
    public void testRecall(){
        String[] inRecallSetUidArray = new String[]{"1","2","3","4"};
        redisService.del(RedisKeyConstant.REDIS_HOT_USER_SET_KEY);
        redisService.sadd(RedisKeyConstant.REDIS_HOT_USER_SET_KEY,inRecallSetUidArray);

        ngHotRecall.updateCache();

        Set<String> result = ngHotRecall.recall(1,recommendAdvanceRequest);
        Assert.assertEquals(Sets.newHashSet(inRecallSetUidArray),result);

        inRecallSetUidArray = new String[]{"11111","211112","33124123","4123987"};
        redisService.del(RedisKeyConstant.REDIS_HOT_USER_SET_KEY);
        redisService.sadd(RedisKeyConstant.REDIS_HOT_USER_SET_KEY,inRecallSetUidArray);

        ngHotRecall.updateCache();

        result = ngHotRecall.recall(1,recommendAdvanceRequest);
        Assert.assertEquals(Sets.newHashSet(inRecallSetUidArray),result);
    }


}