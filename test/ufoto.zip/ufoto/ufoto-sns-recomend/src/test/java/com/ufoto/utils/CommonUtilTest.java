package com.ufoto.utils;

import com.google.common.collect.Sets;
import org.junit.Assert;
import org.junit.Test;

import java.util.Set;

import static org.junit.Assert.*;

/**
 * Created by echo on 8/28/18.
 */
public class CommonUtilTest {


    @Test
    public void getRandomNItemFromSet() throws Exception {
        Set<String> testSet = Sets.newHashSet("1","2","3","4","5","6","7","8","9","10");
        Set<String> resultSet = CommonUtil.getRandomNItemFromSet(testSet,20);
        Assert.assertEquals(testSet,resultSet);

        testSet = Sets.newHashSet();
        resultSet = CommonUtil.getRandomNItemFromSet(testSet,20);
        Assert.assertEquals(testSet,resultSet);

        testSet = null;
        resultSet = CommonUtil.getRandomNItemFromSet(testSet,20);
        Assert.assertEquals(Sets.newHashSet(),resultSet);

        testSet = Sets.newHashSet("1","2","3","4","5","6","7","8","9","10");
        resultSet = CommonUtil.getRandomNItemFromSet(testSet,10);
        Assert.assertEquals(testSet,resultSet);

        testSet = Sets.newHashSet("1","2","3","4","5","6","7","8","9","10");
        resultSet = CommonUtil.getRandomNItemFromSet(testSet,5);
        Assert.assertTrue(resultSet.size()==5);

        testSet = Sets.newHashSet("1","2","3","4","5","6","7","8","9","10");
        resultSet = CommonUtil.getRandomNItemFromSet(testSet,0);
        Assert.assertTrue(resultSet.size()==0);
    }

}