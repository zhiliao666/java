package com.ufoto.business.recommendNG.invoker;

import com.ufoto.BaseUnitTest;

import static org.junit.Assert.*;

/**
 * Created by echo on 10/26/18.
 */
public class ChainCompositeInvokerTest extends BaseUnitTest{



}