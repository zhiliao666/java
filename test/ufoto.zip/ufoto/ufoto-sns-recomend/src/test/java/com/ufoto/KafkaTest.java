package com.ufoto;

import com.ufoto.constants.EUserLayer;
import com.ufoto.mq.kafka.HighRiskMsg;
import com.ufoto.utils.DateUtil;
import com.ufoto.utils.JSONUtil;
import lombok.extern.slf4j.Slf4j;
import org.apache.commons.lang3.RandomUtils;
import org.apache.kafka.clients.producer.ProducerRecord;
import org.junit.Test;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.kafka.core.KafkaTemplate;
import org.springframework.util.concurrent.ListenableFuture;
import org.springframework.util.concurrent.ListenableFutureCallback;

import java.nio.charset.StandardCharsets;
import java.util.EnumSet;
import java.util.List;
import java.util.stream.Collectors;

/**
 * <p>
 * Description:
 *
 * </p>
 *
 * @author Chan
 * @date 2020/2/17 14:18
 */
@Slf4j
public class KafkaTest extends BaseUnitTest {

    @Autowired
    private KafkaTemplate kafkaTemplate;

    @Test
    public void testKafka() {
        final List<Integer> layList = EnumSet.allOf(EUserLayer.class).stream().map(EUserLayer::getLayer).collect(Collectors.toList());
        HighRiskMsg highRiskMsg = new HighRiskMsg();
        highRiskMsg.setLayered(layList.get(RandomUtils.nextInt(0, layList.size())));
        highRiskMsg.setTimestamp(DateUtil.getCurrentSecondIntValue());
        ProducerRecord<byte[], byte[]> record = new ProducerRecord<>("user_level_high_risk",
                JSONUtil.toJSON(highRiskMsg).getBytes(StandardCharsets.UTF_8));
        final ListenableFuture future = kafkaTemplate.send(record);
        future.addCallback(new ListenableFutureCallback() {
            @Override
            public void onFailure(Throwable ex) {
                log.error(ex.getMessage(), ex);
            }

            @Override
            public void onSuccess(Object result) {
                log.debug("result:{}", result);
            }
        });
    }

}
