package com.ufoto.bloom;

import com.ufoto.BaseUnitTest;
import com.ufoto.utils.DateUtil;
import com.ufoto.utils.redis.RedisKeyConstant;
import com.ufoto.utils.redis.RedisKeyUtil;
import org.junit.Test;
import org.springframework.beans.factory.annotation.Autowired;

import static org.junit.Assert.assertEquals;
import static org.junit.Assert.assertTrue;

/**
 * <p>
 * Author     : Chan
 * CreateDate : 2019/12/4 15:10
 * Description:
 * </p>
 */
public class AbstractRecommendBloomFilterTest extends BaseUnitTest {

    @Autowired
    private RecommendedRecommendBloomFilter recommendedRecommendBloomFilter;

    @Test
    public void getAndUpdateCurrentKey() {
        final String currentKey = recommendedRecommendBloomFilter.getAndUpdateCurrentKey(20L);
        System.out.println(currentKey);
        assertEquals(RedisKeyUtil.obtainKey(RedisKeyConstant.REDIS_RECOMMENDED_BF_WEEKLY_KEY_, 20L, DateUtil.getCurrentSecondIntValue() / (60 * 60 * 24 * 7), 0), currentKey);
    }

    @Test
    public void add() {
        for (int i = 100; i < 1000; i++) {
            recommendedRecommendBloomFilter.add(10L, i + "");
        }
        final long count = recommendedRecommendBloomFilter.count(10L);
        assertEquals(900, count);
    }

    @Test
    public void contains() {
        final boolean contains = recommendedRecommendBloomFilter.contains(20L, 100L + "");
        System.out.println(contains);
        assertTrue(contains);
    }

    @Test
    public void count() {
        final long count = recommendedRecommendBloomFilter.count(10L);
        System.out.println(count);
        assertEquals(1, count);
    }

    @Test
    public void getExpectedInsertions() {
    }

    @Test
    public void getFalseProbability() {
    }

    @Test
    public void getSize() {
    }

    @Test
    public void getHashIterations() {
    }
}
