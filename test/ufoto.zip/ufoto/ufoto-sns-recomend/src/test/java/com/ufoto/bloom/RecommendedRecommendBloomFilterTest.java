package com.ufoto.bloom;

import com.ufoto.BaseUnitTest;
import org.junit.Test;
import org.springframework.beans.factory.annotation.Autowired;

import static org.junit.Assert.*;

/**
 * <p>
 * Description:
 *
 * </p>
 *
 * @author Chan
 * @date 2019/12/30 17:06
 */
public class RecommendedRecommendBloomFilterTest extends BaseUnitTest {

    @Autowired
    private RecommendedRecommendBloomFilter recommendedRecommendBloomFilter;

    @Test
    public void cleanExpireBloomKeys() {
        recommendedRecommendBloomFilter.cleanExpireBloomKeys(100L);
    }
}
