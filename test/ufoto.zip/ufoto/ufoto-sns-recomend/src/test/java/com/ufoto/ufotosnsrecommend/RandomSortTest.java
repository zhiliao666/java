package com.ufoto.ufotosnsrecommend;

import com.google.common.collect.Lists;
import com.ufoto.business.recommend.sort.randomMatch.LimitRandomMatchSortStrategy;
import com.ufoto.entity.UfotoUserChatActivity;
import com.ufoto.utils.DateUtil;
import org.junit.Test;
import org.junit.runner.RunWith;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.context.SpringBootTest;
import org.springframework.test.context.junit4.SpringRunner;

import java.util.List;

/**
 * <p>
 * Author     : Chan
 * CreateDate : 2018/8/2 23:12
 * Description:
 * </p>
 */
@SpringBootTest
@RunWith(SpringRunner.class)
public class RandomSortTest {

    @Autowired
    private LimitRandomMatchSortStrategy limitRandomMatchSortStrategy;

    @Test
    public void testSort() {
        List<UfotoUserChatActivity> activities = Lists.newArrayList();
        UfotoUserChatActivity activity1 = new UfotoUserChatActivity();
        activity1.setUId(1L);
        activity1.setCreateTime(DateUtil.getCurrentSecondIntValue());
//        activity1.setLang("English");

        UfotoUserChatActivity activity2 = new UfotoUserChatActivity();
        activity2.setUId(2L);
        activity2.setCreateTime(DateUtil.getCurrentSecondIntValue() - 3600);
        activity2.setLang("English");
        activities.add(activity1);
        activities.add(activity2);
        List<Long> sort = limitRandomMatchSortStrategy.sort(activities, null);
        System.out.println(sort);
    }

}
