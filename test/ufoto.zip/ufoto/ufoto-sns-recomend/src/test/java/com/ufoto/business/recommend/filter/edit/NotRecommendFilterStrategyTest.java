package com.ufoto.business.recommend.filter.edit;

import com.google.common.collect.Lists;
import com.google.common.collect.Sets;
import com.ufoto.BaseUnitTest;
import com.ufoto.dto.RecommendAdvanceRequest;
import com.ufoto.utils.redis.RedisKeyConstant;
import com.ufoto.utils.redis.RedisService;
import org.junit.Assert;
import org.junit.Test;
import org.springframework.beans.factory.annotation.Autowired;

import java.util.Set;

/**
 * Created by echo on 10/25/18.
 */
public class NotRecommendFilterStrategyTest extends BaseUnitTest{

    @Autowired
    NotRecommendFilterStrategy ngNotRecommendFilterStrategy;

    @Autowired
    RedisService redisService;

    @Test
    public void testFilter(){
        Set<String> noHeadUserSet = Sets.newHashSet("100","101","102");
        Set<String> recallUserSet = Sets.newHashSet("99","100","101");
        Set<String> expectedSet = Sets.newHashSet(recallUserSet);
        expectedSet.removeAll(noHeadUserSet);

        redisService.sadd(RedisKeyConstant.REDIS_NOT_RECOMMENDED_USER_SET_KEY,noHeadUserSet.toArray(new String[]{}));
        ngNotRecommendFilterStrategy.updateCache();
        Set<String> result = ngNotRecommendFilterStrategy.filter(recallUserSet,
                Lists.newLinkedList(),
                new RecommendAdvanceRequest());

        Assert.assertEquals(expectedSet,result);
    }

    @Test
    public void testEmptyRecallFilter(){
        Set<String> noHeadUserSet = Sets.newHashSet("100","101","102");
        Set<String> recallUserSet = Sets.newHashSet();
        Set<String> expectedSet = Sets.newHashSet(recallUserSet);
        expectedSet.removeAll(noHeadUserSet);

        redisService.sadd(RedisKeyConstant.REDIS_NOT_RECOMMENDED_USER_SET_KEY,noHeadUserSet.toArray(new String[]{}));
        Set<String> result = ngNotRecommendFilterStrategy.filter(recallUserSet,
                Lists.newLinkedList(),
                new RecommendAdvanceRequest());

        Assert.assertEquals(expectedSet,result);

        noHeadUserSet = Sets.newHashSet("100","101","102");
        recallUserSet = null;

        redisService.sadd(RedisKeyConstant.REDIS_NO_HEAD_USER_SET_KEY,noHeadUserSet.toArray(new String[]{}));
        ngNotRecommendFilterStrategy.updateCache();
        result = ngNotRecommendFilterStrategy.filter(recallUserSet,
                Lists.newLinkedList(),
                new RecommendAdvanceRequest());

        Assert.assertEquals(Sets.newHashSet(),result);
    }


    /**
     * 测试有like我的用户并且隐藏自己的情况
     */
    @Test
    public void testLikeMeUser(){
        Set<String> needFilterUserSet = Sets.newHashSet("100","101","102");
        Set<String> recallUserSet = Sets.newHashSet("99","100","101");
        String requestUid = "23333";
        RecommendAdvanceRequest request = new RecommendAdvanceRequest();
        request.setUid(Long.valueOf(requestUid));
        Set<String> likedMeUserSet = Sets.newHashSet("100");
        Set<String> superLikedMeUserSet = Sets.newHashSet("101");

        Set<String> expectedSet = Sets.newHashSet(recallUserSet);
        Set<String> tempNeedFilterSet =  Sets.newHashSet(needFilterUserSet);
        tempNeedFilterSet.removeAll(likedMeUserSet);
        tempNeedFilterSet.removeAll(superLikedMeUserSet);
        expectedSet.removeAll(tempNeedFilterSet);

        redisService.del(RedisKeyConstant.REDIS_BE_LIKED_TEMP_SET_KEY_+requestUid);
        redisService.del(RedisKeyConstant.REDIS_BE_SUPER_LIKED_TEMP_SET_KEY_+requestUid);
        for(String uid : likedMeUserSet){
            redisService.sadd(RedisKeyConstant.REDIS_BE_LIKED_TEMP_SET_KEY_+requestUid,uid);
        }
        for(String uid : superLikedMeUserSet){
            redisService.sadd(RedisKeyConstant.REDIS_BE_SUPER_LIKED_TEMP_SET_KEY_+requestUid,uid);
        }
        redisService.sadd(RedisKeyConstant.REDIS_NOT_RECOMMENDED_USER_SET_KEY,needFilterUserSet.toArray(new String[]{}));
        ngNotRecommendFilterStrategy.updateCache();
        Set<String> result = ngNotRecommendFilterStrategy.filter(recallUserSet,
                Lists.newLinkedList(),
                request);

        Assert.assertEquals(expectedSet,result);
    }

}