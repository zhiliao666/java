package com.ufoto.business.recommendNG.core;

import com.ufoto.BaseUnitTest;
import org.junit.Test;

import static org.junit.Assert.*;

/**
 * Created by echo on 12/24/18.
 */
public class NGRecommendCoreImplTest extends BaseUnitTest{

}