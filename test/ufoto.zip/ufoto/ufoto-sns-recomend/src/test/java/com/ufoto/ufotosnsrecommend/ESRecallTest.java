/**
 *
 * @author zhangqh  
 * @date Apr 7, 2020  
 * @version 1.0
 */
package com.ufoto.ufotosnsrecommend;

import java.util.Arrays;
import java.util.Set;

import com.ufoto.business.elasticsearch.dto.ElasticSearchException;
import com.ufoto.business.elasticsearch.dto.UserImageAttrDto;
import com.ufoto.business.recommendNG.recall.NGHighActiveFromESRecall;
import com.ufoto.business.recommendNG.recall.NGLowActiveFromESRecall;
import com.ufoto.business.recommendNG.recall.NGUserLayerFromESRecall;
import org.junit.Test;
import org.junit.runner.RunWith;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.context.SpringBootTest;
import org.springframework.test.context.ActiveProfiles;
import org.springframework.test.context.junit4.SpringRunner;

import com.ufoto.business.recommendNG.recall.NGChatBotV5Recall;
import com.ufoto.constants.ESnsUserLayer;
import com.ufoto.dto.RecommendAdvanceRequest;
import com.ufoto.manager.ElasticSearchManager;
import com.ufoto.utils.json.JSONUtil;

/**
 *
 * @author zhangqh  
 * @date Apr 7, 2020 5:54:36 PM  
 * @version 1.0
 */
@ActiveProfiles("dev")
@RunWith(SpringRunner.class)
@SpringBootTest
public class ESRecallTest {
	
	@Autowired
	private ElasticSearchManager elasticSearchManager;
	
	@Autowired
	private NGChatBotV5Recall ngChatBotV5Recall;

	@Autowired
	private NGUserLayerFromESRecall ngUserLayerFromESRecall;

	@Autowired
	private NGHighActiveFromESRecall ngHighActiveFromESRecall;

	@Autowired
	private NGLowActiveFromESRecall ngLowActiveFromESRecall;

	@Test
	public void testUserLayerRecall() {
		RecommendAdvanceRequest recommendAdvanceRequest = new RecommendAdvanceRequest();
		recommendAdvanceRequest.setUid(16L);
		recommendAdvanceRequest.setStart(0);
		recommendAdvanceRequest.setEnd(1000);
		try {
			ngUserLayerFromESRecall.recall(100, recommendAdvanceRequest);
		} catch (ElasticSearchException e) {

		}
	}

	@Test
	public void testHighUserLayerRecall() {
		RecommendAdvanceRequest recommendAdvanceRequest = new RecommendAdvanceRequest();
		recommendAdvanceRequest.setUid(16L);
		recommendAdvanceRequest.setStart(0);
		recommendAdvanceRequest.setEnd(1000);
		ngHighActiveFromESRecall.recall(100, recommendAdvanceRequest);
	}

	@Test
	public void testLowUserLayerRecall() {
		RecommendAdvanceRequest recommendAdvanceRequest = new RecommendAdvanceRequest();
		recommendAdvanceRequest.setUid(16L);
		recommendAdvanceRequest.setStart(0);
		recommendAdvanceRequest.setEnd(1000);
		ngLowActiveFromESRecall.recall(100, recommendAdvanceRequest);
	}

	@Test
	public void testEsRecall() {
		RecommendAdvanceRequest recommendAdvanceRequest = new RecommendAdvanceRequest();
    	recommendAdvanceRequest.setUid(16L);
    	recommendAdvanceRequest.setStart(0);
    	recommendAdvanceRequest.setEnd(1000);
//    	recommendAdvanceRequest.setGender(2);
//    	recommendAdvanceRequest.setAreaId(22);
    	System.out.println("11111111:"+JSONUtil.toJSON(recommendAdvanceRequest));
    	Set<String> set = elasticSearchManager.queryUserIdsFromESByCondition(16L, recommendAdvanceRequest,Arrays.asList(ESnsUserLayer.LOWFINDFRIENDUSER.getLayer(),ESnsUserLayer.HIGHTFINDFRIENDUSER.getLayer()));
    	System.out.println("召回结果集："+set);
    	System.out.println("222222:"+JSONUtil.toJSON(recommendAdvanceRequest));
    	Set<String> set2 = elasticSearchManager.queryUserIdsFromESByCondition(16L, recommendAdvanceRequest,Arrays.asList(ESnsUserLayer.LOWFINDFRIENDUSER.getLayer(),ESnsUserLayer.HIGHTFINDFRIENDUSER.getLayer()));
    	System.out.println("召回结果集："+set2);
	}

	@Test
	public void testChatEsRecall() {
		RecommendAdvanceRequest recommendAdvanceRequest = new RecommendAdvanceRequest();
		recommendAdvanceRequest.setUid(16L);
		recommendAdvanceRequest.setStart(0);
		recommendAdvanceRequest.setEnd(1000);
		recommendAdvanceRequest.setCp("sweetchat.localdatingtinder.meet");
//    	recommendAdvanceRequest.setGender(2);
//    	recommendAdvanceRequest.setAreaId(22);
		System.out.println("11111111:"+JSONUtil.toJSON(recommendAdvanceRequest));
		Set<String> set = elasticSearchManager.queryUserIdsFromESByCondition(16L, recommendAdvanceRequest,Arrays.asList(ESnsUserLayer.LOWFINDFRIENDUSER.getLayer(),ESnsUserLayer.HIGHTFINDFRIENDUSER.getLayer()));
		System.out.println("召回结果集："+set);
		System.out.println("222222:"+JSONUtil.toJSON(recommendAdvanceRequest));
		Set<String> set2 = elasticSearchManager.queryUserIdsFromESByCondition(16L, recommendAdvanceRequest,Arrays.asList(ESnsUserLayer.LOWFINDFRIENDUSER.getLayer(),ESnsUserLayer.HIGHTFINDFRIENDUSER.getLayer()));
		System.out.println("召回结果集："+set2);
	}
	
	@Test
	public void testNgchatbotRecal() {
		RecommendAdvanceRequest recommendAdvanceRequest = new RecommendAdvanceRequest();
    	recommendAdvanceRequest.setUid(16L);
    	recommendAdvanceRequest.setStart(0);
    	recommendAdvanceRequest.setEnd(1000);
    	recommendAdvanceRequest.setLanguage("pt");
    	recommendAdvanceRequest.setGender(1);
    	Set<String> set =ngChatBotV5Recall.recall(100, recommendAdvanceRequest);
		System.out.println("testNgchatbotRecal 召回结果集："+set);
	}
	
	@Test
	public void testUserlayer() {
		UserImageAttrDto userImageAttrDto = elasticSearchManager.queryUserLayer(403558389071741108L);
		System.out.println("用户分层："+ userImageAttrDto.getActiveLevel() + ",高危级别: " + userImageAttrDto.getRiskLevel());
	}
}
