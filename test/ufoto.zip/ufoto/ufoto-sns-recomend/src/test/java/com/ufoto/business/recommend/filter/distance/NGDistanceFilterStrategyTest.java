package com.ufoto.business.recommend.filter.distance;

import com.google.common.collect.Lists;
import com.google.common.collect.Sets;
import com.ufoto.BaseUnitTest;
import com.ufoto.dto.RecommendAdvanceRequest;
import com.ufoto.service.RecommendService;
import com.ufoto.service.RecommendToolService;
import com.ufoto.utils.redis.RedisService;
import org.junit.Assert;
import org.junit.Before;
import org.junit.Test;
import org.springframework.beans.factory.annotation.Autowired;

import java.util.Set;

import static org.junit.Assert.*;

/**
 * Created by echo on 10/24/18.
 */
public class NGDistanceFilterStrategyTest extends BaseUnitTest{

    @Autowired
    NGDistanceFilterStrategy distanceFilterStrategy;

    @Autowired
    RecommendService recommendService;

    @Before
    public void setUp(){
        recommendService.addRedisUserGeo(99L,0D,0D);
        recommendService.addRedisUserGeo(100L,0.5D,0.5D);
        recommendService.addRedisUserGeo(101L,0.3D,-0.2D);
        recommendService.addRedisUserGeo(102L,-1D,-0.1D);
        recommendService.addRedisUserGeo(103L,-100D,100D);
        System.out.println("===================================SetUp=======================");
    }

    @Test
    public void testFilter(){
        RecommendAdvanceRequest filterRequest = new RecommendAdvanceRequest();
        filterRequest.setUid(99L);
        filterRequest.setLongitude(0D);
        filterRequest.setLatitude(0D);
        filterRequest.setDistance(99D);
        Set<String> recallSet = Sets.newHashSet("100","101","102","103");

        Set<String> result = distanceFilterStrategy.filter(recallSet, Lists.newLinkedList(),filterRequest );
        Assert.assertEquals(Sets.newHashSet("100","101"),result);
    }


    @Test
    public void testBadFilter(){
        RecommendAdvanceRequest filterRequest = new RecommendAdvanceRequest();
        filterRequest.setUid(99L);
        filterRequest.setLongitude(0D);
        filterRequest.setLatitude(0D);
        filterRequest.setDistance(99D);
        Set<String> recallSet = Sets.newHashSet("100","101","102","103","233");

        Set<String> result = distanceFilterStrategy.filter(recallSet, Lists.newLinkedList(),filterRequest );
        Assert.assertEquals(Sets.newHashSet("100","101"),result);
    }

    @Test
    public void testNoPosUserFilter(){
        RecommendAdvanceRequest filterRequest = new RecommendAdvanceRequest();
        filterRequest.setUid(120397L);
        filterRequest.setDistance(99D);
        Set<String> recallSet = Sets.newHashSet("100","101","102","103","233");
        Set<String> result = distanceFilterStrategy.filter(recallSet, Lists.newLinkedList(),filterRequest );
        Assert.assertEquals(recallSet,result);
    }

    @Test
    public void testPosNoParmUserFilter(){
        RecommendAdvanceRequest filterRequest = new RecommendAdvanceRequest();
        filterRequest.setUid(99L);
        filterRequest.setDistance(99D);
        Set<String> recallSet = Sets.newHashSet("100","101","102","103","233");

        Set<String> result = distanceFilterStrategy.filter(recallSet, Lists.newLinkedList(),filterRequest );
        Assert.assertEquals(Sets.newHashSet("100","101"),result);
    }

    @Test
    public void testNoDistanceUserFilter(){
        RecommendAdvanceRequest filterRequest = new RecommendAdvanceRequest();
        filterRequest.setUid(99L);
        Set<String> recallSet = Sets.newHashSet("100","101","102","103","233");

        Set<String> result = distanceFilterStrategy.filter(recallSet, Lists.newLinkedList(),filterRequest );
        Assert.assertEquals(recallSet,result);
    }
}