package com.ufoto.ufotosnsrecommend;

import com.ufoto.dto.RecommendAdvanceRequest;
import com.ufoto.service.RecommendService;
import org.junit.Test;
import org.junit.runner.RunWith;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.context.SpringBootTest;
import org.springframework.test.context.ActiveProfiles;
import org.springframework.test.context.junit4.SpringRunner;

@ActiveProfiles("dev")
@RunWith(SpringRunner.class)
@SpringBootTest
public class RecommendKeyTest {

    @Autowired
    RecommendService recommendService;

    @Test
    public void testChatRecommendKeyRecall() {
        RecommendAdvanceRequest recommendAdvanceRequest = new RecommendAdvanceRequest();
        recommendAdvanceRequest.setUid(10000L);
        recommendAdvanceRequest.setStartAge(0);
        recommendAdvanceRequest.setEndAge(55);
        recommendAdvanceRequest.setCp("sweetchat.localdatingtinder.meet");
        recommendAdvanceRequest.setGender(null);
        recommendAdvanceRequest.setDistance(null);
        recommendService.getRecommendResultKey(recommendAdvanceRequest);
    }

    @Test
    public void testRecommendKeyRecall() {
        recommendService.getRecommendResultKey(10000L, 0, 55,
               null, 1, 200, 2D);
    }

    @Test
    public void testWinkRecommendKeyRecall() {
        recommendService.getWinkRecommendResultKey(10000L, 0, 200,
                1);
    }

}
