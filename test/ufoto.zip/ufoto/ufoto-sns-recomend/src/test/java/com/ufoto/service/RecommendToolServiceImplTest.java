package com.ufoto.service;

import com.google.common.collect.Sets;
import com.ufoto.BaseUnitTest;
import com.ufoto.business.recommend.filter.recommended.RecommendedBFManager;
import com.ufoto.utils.json.JSONUtil;
import com.ufoto.utils.redis.RedisService;
import org.junit.Test;
import org.springframework.beans.factory.annotation.Autowired;

import java.util.Map;

/**
 * <p>
 * Author     : Chan
 * CreateDate : 2018/11/12 21:03
 * Description:
 * </p>
 */
public class RecommendToolServiceImplTest extends BaseUnitTest {

    @Autowired
    RecommendToolService recommendToolService;

    @Autowired
    RedisService redisService;

    @Autowired
    RecommendedBFManager recommendedBFManager;

    @Test
    public void randomFilter() {
        final Map<String, Object> stringSetMap = recommendToolService.randomFilter(20L, Sets.newHashSet("21", "22", "23", "24","1000"));
        System.out.println(JSONUtil.toJSON(stringSetMap));
    }

}
