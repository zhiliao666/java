package com.ufoto.mq;

import com.ufoto.BaseUnitTest;
import com.ufoto.mq.constants.EExchange;
import com.ufoto.mq.constants.ERoutingKey;
import com.ufoto.mq.request.recommend.FirstImgDefaultRequest;
import org.junit.Test;
import org.springframework.beans.factory.annotation.Autowired;

/**
 * <p>
 * Description:
 *
 * </p>
 *
 * @author Chan
 * @date 2019/12/19 19:44
 */
public class RecommendConsumerTest extends BaseUnitTest {
    @Autowired
    private RabbitProducer rabbitProducer;

    @Test
    public void handleFirstImgDefault() throws Exception {
        FirstImgDefaultRequest firstImgDefault = new FirstImgDefaultRequest();
        firstImgDefault.setUid(100L);
        firstImgDefault.setHasDefault(true);
        rabbitProducer.produceByJson(EExchange.SWEETCHAT_DIRECT_RECOMMEND,
                ERoutingKey.ROUTE_KEY_FIRST_IMG_DEFAULT,
                firstImgDefault);
        Thread.sleep(10000);

        firstImgDefault.setHasDefault(false);
        rabbitProducer.produceByJson(EExchange.SWEETCHAT_DIRECT_RECOMMEND,
                ERoutingKey.ROUTE_KEY_FIRST_IMG_DEFAULT,
                firstImgDefault);
        Thread.sleep(10000);
    }
}
