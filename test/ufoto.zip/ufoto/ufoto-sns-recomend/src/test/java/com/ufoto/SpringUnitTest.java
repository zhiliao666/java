package com.ufoto;

import org.junit.runner.RunWith;
import org.springframework.boot.test.context.SpringBootTest;
import org.springframework.test.context.junit4.SpringRunner;

/**
 * <p>
 * Author     : Chan
 * CreateDate : 2018/9/14 11:19
 * Description:
 * </p>
 */
@SpringBootTest
@RunWith(SpringRunner.class)
public class SpringUnitTest {
}
