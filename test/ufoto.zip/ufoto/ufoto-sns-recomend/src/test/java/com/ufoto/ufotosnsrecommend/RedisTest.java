package com.ufoto.ufotosnsrecommend;

import com.ufoto.utils.redis.RedisService;
import org.assertj.core.util.Lists;
import org.junit.Test;
import org.junit.runner.RunWith;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.context.SpringBootTest;
import org.springframework.data.redis.core.HashOperations;
import org.springframework.data.redis.core.RedisTemplate;
import org.springframework.test.context.junit4.SpringRunner;

import java.util.HashMap;
import java.util.Map;

/**
 * <p>
 *
 * </p>
 *
 * @author created by chenzhou at 2018-07-21 11:09
 */
@SpringBootTest
@RunWith(SpringRunner.class)
public class RedisTest {
    @Autowired
    private RedisService redisService;

    @Test
    public void testRedis() {
        Map<String, String> map = new HashMap<>();
        map.put("1", "aa");
        map.put("2", "bb");
        map.put("3", "cc");

        final RedisTemplate<String, String> redisTemplate = redisService.getRedisTemplate();
        final HashOperations<String, String, String> opsForHash = redisTemplate.opsForHash();
        opsForHash.putAll("hashTest", map);

        final Map<String, String> hashTest = opsForHash.entries("hashTest");
        System.out.println(hashTest);

        opsForHash.delete("hashTest", Lists.newArrayList("1", "2", "3").toArray());

        final Map<String, String> hashTest2 = opsForHash.entries("hashTest");
        System.out.println(hashTest2);
    }

    @Test
    public void test22() throws IllegalAccessException, InstantiationException {
        final Map<String, String> stringStringMap = redisService.hGetAll("000");
        System.out.println(stringStringMap);
    }
}
