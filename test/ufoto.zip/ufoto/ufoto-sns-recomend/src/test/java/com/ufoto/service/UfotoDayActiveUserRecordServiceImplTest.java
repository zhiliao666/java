package com.ufoto.service;

import com.ufoto.BaseUnitTest;
import com.ufoto.dto.DumpUserDto;
import org.joda.time.DateTime;
import org.junit.Test;
import org.springframework.beans.factory.annotation.Autowired;

import java.sql.Date;
import java.util.List;

/**
 * <p>
 * Author     : Chan
 * CreateDate : 2019-09-05 16:33
 * Description:
 * </p>
 */
public class UfotoDayActiveUserRecordServiceImplTest extends BaseUnitTest {

    @Autowired
    private UfotoDayActiveUserRecordService ufotoDayActiveUserRecordService;

    @Test
    public void selectUidListByDate() {
        final List<DumpUserDto> longs = ufotoDayActiveUserRecordService.selectUidListByDate(0, new Date(new DateTime(2019, 8, 30, 0, 0).getMillis()));
        System.out.println(longs);
    }

    @Test
    public void deleteUidListByDate() {
        ufotoDayActiveUserRecordService.deleteUidListByDate(0, new java.sql.Date(new DateTime(2019, 6, 24, 0, 0).getMillis()));
    }
}
