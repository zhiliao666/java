package com.ufoto.business.recommend.sort.likeme;

import com.google.common.collect.Lists;
import com.ufoto.BaseUnitTest;
import com.ufoto.business.recommend.bean.SortParamsBean;
import com.ufoto.utils.redis.RedisKeyConstant;
import com.ufoto.utils.redis.RedisService;
import org.junit.Test;
import org.springframework.beans.factory.annotation.Autowired;

import java.util.Map;
import java.util.stream.LongStream;

/**
 * <p>
 * Author     : Chan
 * CreateDate : 2019-08-28 11:30
 * Description:
 * </p>
 */
public class UnLikeMeSortStrategyTest extends BaseUnitTest {

    @Autowired
    private UnLikeMeSortStrategy unLikeMeSortStrategy;

    @Autowired
    private RedisService redisService;

    @Test
    public void getScore() {
        redisService.sadd(RedisKeyConstant.REDIS_BE_UN_LIKED_SET_KEY_ + 20,
                LongStream.range(100, 200).mapToObj(String::valueOf).toArray(String[]::new));
        SortParamsBean sortParamsBean = new SortParamsBean();
        sortParamsBean.setUid(20L);
        final Map<String, Double> score = unLikeMeSortStrategy.getScore(Lists.newArrayList("100", "120", "200"), sortParamsBean);
        System.out.println(score);
    }
}
