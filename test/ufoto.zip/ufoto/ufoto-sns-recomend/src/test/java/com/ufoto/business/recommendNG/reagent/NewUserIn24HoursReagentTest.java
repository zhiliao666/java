package com.ufoto.business.recommendNG.reagent;

import com.google.common.collect.Sets;
import com.ufoto.BaseUnitTest;
import com.ufoto.utils.redis.RedisKeyConstant;
import com.ufoto.utils.redis.RedisService;
import org.junit.Assert;
import org.junit.Test;
import org.junit.runner.RunWith;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.context.SpringBootTest;
import org.springframework.test.context.junit4.SpringRunner;

import java.util.Arrays;
import java.util.Set;

public class NewUserIn24HoursReagentTest extends BaseUnitTest {


    @Autowired
    private NewUserIn24HoursReagent newUserActIn24HoursReagent;

    @Autowired
    private RedisService redisService;

    @Test
    public void testMakeReagent(){
        redisService.del(RedisKeyConstant.REDIS_ACT_IN_24H_NEW_USER_SET_KEY);
        redisService.sadd(RedisKeyConstant.REDIS_ACT_IN_24H_NEW_USER_SET_KEY,"1","2","3");
        Set<String> recalledUidSet = Sets.newHashSet(Arrays.asList("3","4","5","6"));
        newUserActIn24HoursReagent.updateCache();

        Set<String> result = newUserActIn24HoursReagent.makeReagents(null,recalledUidSet);
        Assert.assertEquals(result,Sets.newHashSet(Arrays.asList("3")));
    }

    @Test
    public void testEmptyMakeReagent(){
        newUserActIn24HoursReagent.updateCache();
        Set<String> result = newUserActIn24HoursReagent.makeReagents(null,Sets.newHashSet());
        Assert.assertEquals(result,Sets.newHashSet());
    }

    @Test
    public void testRandomReagents(){
        redisService.del(RedisKeyConstant.REDIS_ACT_IN_24H_NEW_USER_SET_KEY);
        redisService.sadd(RedisKeyConstant.REDIS_ACT_IN_24H_NEW_USER_SET_KEY,"1","2","3");
        newUserActIn24HoursReagent.updateCache();

        Set<String> result = newUserActIn24HoursReagent.randomReagents(null,3);
        Assert.assertEquals(result,Sets.newHashSet(Arrays.asList("1","2","3")));

        redisService.del(RedisKeyConstant.REDIS_ACT_IN_24H_NEW_USER_SET_KEY);
        redisService.sadd(RedisKeyConstant.REDIS_ACT_IN_24H_NEW_USER_SET_KEY,"1","2","3","4","5","6");
        newUserActIn24HoursReagent.updateCache();

        result = newUserActIn24HoursReagent.randomReagents(null,3);
        Assert.assertTrue(result.size()==3);
        Assert.assertTrue(Sets.newHashSet(Arrays.asList("1","2","3","4","5","6")).containsAll(result));
    }
}