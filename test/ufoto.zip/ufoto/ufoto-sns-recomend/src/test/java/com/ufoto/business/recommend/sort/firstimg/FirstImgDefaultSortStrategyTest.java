package com.ufoto.business.recommend.sort.firstimg;

import com.ufoto.BaseUnitTest;
import com.ufoto.business.recommend.bean.SortParamsBean;
import com.ufoto.utils.redis.RedisKeyConstant;
import com.ufoto.utils.redis.RedisServiceObjService;
import org.junit.Test;
import org.springframework.beans.factory.annotation.Autowired;

import java.util.List;
import java.util.Map;
import java.util.stream.Collectors;
import java.util.stream.LongStream;

/**
 * <p>
 * Description:
 *
 * </p>
 *
 * @author Chan
 * @date 2019/12/19 18:24
 */
public class FirstImgDefaultSortStrategyTest extends BaseUnitTest {

    @Autowired
    private FirstImgDefaultSortStrategy firstImgDefaultSortStrategy;

    @Autowired
    private RedisServiceObjService redisServiceObjService;

    @Test
    public void getScore() {
        final List<Long> list = LongStream.range(100, 1000).boxed().collect(Collectors.toList());
        redisServiceObjService.sadd(RedisKeyConstant.REDIS_FIRST_IMG_DEFAULT, list.toArray(new Object[]{}));
        final Map<String, Double> scoreMap = firstImgDefaultSortStrategy.getScore(list.stream().map(Object::toString).collect(Collectors.toList()), new SortParamsBean());
        redisServiceObjService.delete(RedisKeyConstant.REDIS_FIRST_IMG_DEFAULT);
        assert scoreMap.size() == list.size();
    }
}
