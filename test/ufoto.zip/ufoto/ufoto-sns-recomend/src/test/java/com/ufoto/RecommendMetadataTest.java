package com.ufoto;

import com.google.common.collect.Lists;
import com.google.common.collect.Maps;
import com.google.common.collect.Sets;
import com.ufoto.annotation.RecommendMetadata;
import com.ufoto.business.recommend.RecommendFilterStrategy;
import com.ufoto.business.recommendNG.Recall;
import com.ufoto.business.recommendNG.recall.NGRandomRecall;
import com.ufoto.dto.RecommendAdvanceRequest;
import com.ufoto.utils.excel.WriteExcelUtil;
import org.junit.Before;
import org.junit.Test;
import org.springframework.aop.support.AopUtils;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.context.ApplicationContext;

import java.io.File;
import java.io.FileOutputStream;
import java.io.IOException;
import java.util.List;
import java.util.Map;
import java.util.Set;

/**
 * <p>
 * Author     : Chan
 * CreateDate : 2019-07-25 13:47
 * Description:
 * </p>
 */
public class RecommendMetadataTest extends BaseUnitTest {

    @Autowired
    private ApplicationContext applicationContext;

    private static Map<String, Object> beanMap;

    @Before
    public void setUp() {
        beanMap = applicationContext.getBeansWithAnnotation(RecommendMetadata.class);
    }

    @Test
    public void metadata() {
        Map<RecommendMetadata.MetadataType, List<Object[]>> linesMap = Maps.newHashMap();
        beanMap.forEach((k, bean) -> {
            Class<?> targetClass = AopUtils.getTargetClass(bean);
            RecommendMetadata recommendMetadata = targetClass.getAnnotation(RecommendMetadata.class);
            if (recommendMetadata != null) {
                List<Object[]> temp = Lists.newArrayList();
                temp.add(new Object[]{targetClass.getSimpleName() + (recommendMetadata.available() ? "" : "(废弃)"), recommendMetadata.name(), recommendMetadata.description()});
                linesMap.merge(recommendMetadata.metadataType(),
                        temp,
                        (o, n) -> {
                            o.addAll(n);
                            return o;
                        });
            }
        });
        final WriteExcelUtil excel = WriteExcelUtil.newInstance(new String[]{"类名", "策略名", "描述"});
        linesMap.forEach((metadata, lines) -> {
            System.out.println(lines.getClass());
            lines.add(0, new Object[]{metadata, metadata, metadata});
            lines.add(new Object[]{"", "", ""});
            excel.writeExcel(lines);
        });
        File file = new File("RecommendMetadata.xlsx");
        if (!file.exists()) {
            try {
                file.createNewFile();
            } catch (IOException e) {
                e.printStackTrace();
            }
        }
        try {
            excel.getWorkbook().write(new FileOutputStream(file));
        } catch (IOException e) {
            e.printStackTrace();
        }
    }

    @Test
    public void recallTest() {
        List<Recall> recallList = Lists.newArrayList();
        beanMap.forEach((k, bean) -> {
            Class<?> targetClass = AopUtils.getTargetClass(bean);
            RecommendMetadata recommendMetadata = targetClass.getAnnotation(RecommendMetadata.class);
            if (recommendMetadata != null
                    && recommendMetadata.metadataType() == RecommendMetadata.MetadataType.RECALL
                    && Recall.class.isAssignableFrom(targetClass)) {
                Recall recall = (Recall) bean;
                recallList.add(recall);
            }
        });
        int minSize = 250;
        RecommendAdvanceRequest request = new RecommendAdvanceRequest();
        request.setUid(20L);
        Set<String> results = Sets.newHashSet();
        for (Recall recall : recallList) {
            if (recall.getClass().getSimpleName().equalsIgnoreCase(NGRandomRecall.class.getSimpleName())) {
                continue;
            }
            results.addAll(recall.recall(minSize, request));
        }
        System.out.println(results);
    }

    @Test
    public void filterTest() {
        List<RecommendFilterStrategy> filterStrategyList = Lists.newArrayList();
        beanMap.forEach((k, bean) -> {
            Class<?> targetClass = AopUtils.getTargetClass(bean);
            RecommendMetadata recommendMetadata = targetClass.getAnnotation(RecommendMetadata.class);
            if (recommendMetadata != null
                    && recommendMetadata.metadataType() == RecommendMetadata.MetadataType.FILTER
                    && RecommendFilterStrategy.class.isAssignableFrom(targetClass)) {
                RecommendFilterStrategy filterStrategy = (RecommendFilterStrategy) bean;
                filterStrategyList.add(filterStrategy);
            }
        });

        Set<String> recallUids = Sets.newHashSet();
        for (int i = 22; i < 100; i++) {
            recallUids.add(i + "");
        }
        List<String> resultList = Lists.newArrayList();
        RecommendAdvanceRequest request = new RecommendAdvanceRequest();
        request.setUid(20L);

        for (RecommendFilterStrategy filterStrategy : filterStrategyList) {
            recallUids = filterStrategy.filter(recallUids, resultList, request);
        }

        System.out.println(recallUids);
    }
}
