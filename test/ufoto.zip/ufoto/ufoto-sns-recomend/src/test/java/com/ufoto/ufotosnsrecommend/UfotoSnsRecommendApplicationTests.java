package com.ufoto.ufotosnsrecommend;

import org.junit.Test;
import org.junit.runner.RunWith;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.context.SpringBootTest;
import org.springframework.test.context.junit4.SpringRunner;

import com.ufoto.dto.RecommendAdvanceRequest;
import com.ufoto.service.RecommendService;

@RunWith(SpringRunner.class)
@SpringBootTest
public class UfotoSnsRecommendApplicationTests {

    private static Logger logger = LoggerFactory.getLogger(UfotoSnsRecommendApplicationTests.class);

    private static Logger recommendLogger = LoggerFactory.getLogger("recommend.score");
    @Autowired
    private  RecommendService recommendService;

    @Test
    public void contextLoads() {
    }

    @Test
    public void testLogger() {
        logger.trace("THIS IS TRACE");
        logger.debug("THIS IS DEBUG");
        logger.info("THIS IS INFO");
        logger.warn("THIS IS WARN");
        logger.error("THIS IS ERROR");

        recommendLogger.trace("RECOMMEND TRACE");
        recommendLogger.debug("RECOMMEND DEBUG");
        recommendLogger.info("RECOMMEND INFO");
        recommendLogger.warn("RECOMMEND WARN");
        recommendLogger.error("RECOMMEND ERROR");
    }
    
    @Test
    public void testSns() {
    	RecommendAdvanceRequest recommendAdvanceRequest = new RecommendAdvanceRequest();
    	recommendAdvanceRequest.setUid(16L);
    	recommendAdvanceRequest.setStart(0);
    	recommendAdvanceRequest.setEnd(9);
    	recommendAdvanceRequest.setGender(2);
    	recommendAdvanceRequest.setAreaId(22);
    	recommendService.recommendUsers(recommendAdvanceRequest);
    }

}
