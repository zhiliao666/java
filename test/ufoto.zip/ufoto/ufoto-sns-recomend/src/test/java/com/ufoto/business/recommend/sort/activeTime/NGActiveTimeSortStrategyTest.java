package com.ufoto.business.recommend.sort.activeTime;

import com.google.common.collect.Lists;
import com.ufoto.BaseUnitTest;
import com.ufoto.business.recommend.bean.SortParamsBean;
import com.ufoto.utils.DateUtil;
import com.ufoto.utils.redis.RedisKeyConstant;
import com.ufoto.utils.redis.RedisKeyUtil;
import com.ufoto.utils.redis.RedisService;
import org.apache.commons.lang3.RandomUtils;
import org.junit.Test;
import org.springframework.beans.factory.annotation.Autowired;

import java.util.ArrayList;
import java.util.Map;
import java.util.Random;

import static org.junit.Assert.*;

/**
 * <p>
 * Author     : Chan
 * CreateDate : 2019-08-21 13:21
 * Description:
 * </p>
 */
public class NGActiveTimeSortStrategyTest extends BaseUnitTest {

    @Autowired
    private NGActiveTimeSortStrategy ngActiveTimeSortStrategy;

    @Autowired
    private RedisService redisService;

    @Test
    public void getScore() {
        final ArrayList<String> recallUids = Lists.newArrayList();
        for (int i = 0; i < 10; i++) {
            final int uid = RandomUtils.nextInt(10, 1000);
            redisService.hset(RedisKeyUtil.obtainKey(RedisKeyConstant.REDIS_USER_HASH_KEY, uid),
                    RedisKeyConstant.REDIS_USER_HASH_ACTIVITY_TIME,
                    (DateUtil.getCurrentSecondIntValue() - RandomUtils.nextInt(1000, 86400)) + "");
            recallUids.add(uid + "");
        }

        for (int i = 0; i < 5; i++) {
            recallUids.add(RandomUtils.nextInt(10, 10000) + "");
        }

        final Map<String, Double> scoreMap = ngActiveTimeSortStrategy.getScore(recallUids, new SortParamsBean());
        System.out.println(scoreMap);
    }
}
