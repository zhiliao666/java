package com.ufoto.business.recommendNG.reagent;

import com.ufoto.BaseUnitTest;
import com.ufoto.utils.redis.RedisKeyConstant;
import com.ufoto.utils.redis.RedisService;
import org.assertj.core.util.Sets;
import org.junit.Assert;
import org.junit.Test;
import org.junit.runner.RunWith;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.context.SpringBootTest;
import org.springframework.test.context.junit4.SpringRunner;

import java.util.Arrays;
import java.util.Set;

import static org.junit.Assert.*;



public class OldUserActIn24HoursReagentTest extends BaseUnitTest{

    @Autowired
    private OldUserActIn24HoursReagent oldUserActIn24HoursReagent;

    @Autowired
    private RedisService redisService;

    @Test
    public void testMakeReagent(){
        redisService.del(RedisKeyConstant.REDIS_ACT_IN_24H_OLD_USER_SET_KEY);
        redisService.sadd(RedisKeyConstant.REDIS_ACT_IN_24H_OLD_USER_SET_KEY,"1","2","3");
        Set<String> recalledUidSet = Sets.newHashSet(Arrays.asList("3","4","5","6"));
        oldUserActIn24HoursReagent.updateCache();

        Set<String> result = oldUserActIn24HoursReagent.makeReagents(null,recalledUidSet);
        Assert.assertEquals(result,Sets.newHashSet(Arrays.asList("3")));
    }

    @Test
    public void testEmptyMakeReagent(){
        oldUserActIn24HoursReagent.updateCache();
        Set<String> result = oldUserActIn24HoursReagent.makeReagents(null,Sets.newHashSet());
        Assert.assertEquals(result,Sets.newHashSet());
    }

    @Test
    public void testRandomReagents(){
        redisService.del(RedisKeyConstant.REDIS_ACT_IN_24H_OLD_USER_SET_KEY);
        redisService.sadd(RedisKeyConstant.REDIS_ACT_IN_24H_OLD_USER_SET_KEY,"1","2","3");
        oldUserActIn24HoursReagent.updateCache();

        Set<String> result = oldUserActIn24HoursReagent.randomReagents(null,3);
        Assert.assertEquals(result,Sets.newHashSet(Arrays.asList("1","2","3")));

        redisService.del(RedisKeyConstant.REDIS_ACT_IN_24H_OLD_USER_SET_KEY);
        redisService.sadd(RedisKeyConstant.REDIS_ACT_IN_24H_OLD_USER_SET_KEY,"1","2","3","4","5","6");
        oldUserActIn24HoursReagent.updateCache();

        result = oldUserActIn24HoursReagent.randomReagents(null,3);
        Assert.assertTrue(result.size()==3);
        Assert.assertTrue(Sets.newHashSet(Arrays.asList("1","2","3","4","5","6")).containsAll(result));
    }

}