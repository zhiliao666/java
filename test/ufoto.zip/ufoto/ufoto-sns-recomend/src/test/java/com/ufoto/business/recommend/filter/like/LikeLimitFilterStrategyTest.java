package com.ufoto.business.recommend.filter.like;

import com.google.common.collect.Lists;
import com.google.common.collect.Sets;
import com.ufoto.BaseUnitTest;
import com.ufoto.dto.RecommendAdvanceRequest;
import com.ufoto.utils.DateUtil;
import com.ufoto.utils.redis.RedisKeyConstant;
import com.ufoto.utils.redis.RedisKeyUtil;
import com.ufoto.utils.redis.RedisService;
import org.apache.commons.lang.math.RandomUtils;
import org.junit.Assert;
import org.junit.Test;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.core.env.Environment;

import java.util.Set;

/**
 * Created by echo on 11/13/18.
 */
public class LikeLimitFilterStrategyTest extends BaseUnitTest{

//    @Autowired
//    LikeLimitFilterStrategy likeLimitFilterStrategy;
//
//    @Autowired
//    RedisService redisService;
//
//    @Autowired
//    Environment env;
//
//    @Test
//    public void testFilter(){
//        Set<String> needFilterUserSet = Sets.newHashSet("100","101","102");
//        Set<String> recallUserSet = Sets.newHashSet("99","100","101");
//        Set<String> expectedSet = Sets.newHashSet(recallUserSet);
//        expectedSet.removeAll(needFilterUserSet);
//
//        String likeLimitConfig = env.getProperty("recommend.filter.liked.limit");
//        int likeLimit = Integer.parseInt(likeLimitConfig);
//        int currentHour = Integer.valueOf(DateUtil.getCurrentDateStr("HH"));
//        likeLimit *= (currentHour/12)+1; //如果过了12点（北京时间），则曝光上限翻倍
//        String currentDay = DateUtil.getCurrentDateStr("yyyyMMdd");
//
//        for(String uid : needFilterUserSet){
//            redisService.sadd(RedisKeyConstant.REDIS_ACT_IN_24H_USER_SET_KEY,uid);
//            redisService.del(RedisKeyUtil.obtainKey(RedisKeyConstant.REDIS_BE_LIKED_SET_KEY_DAILY, uid, currentDay));
//            redisService.sadd(RedisKeyUtil.obtainKey(RedisKeyConstant.REDIS_BE_LIKED_SET_KEY_DAILY, uid, currentDay),
//                    createRandomUidArray(likeLimit+10).toArray(new String[]{}));
//        }
//        likeLimitFilterStrategy.updateCache();
//        Set<String> result = likeLimitFilterStrategy.filter(recallUserSet,
//                Lists.newLinkedList(),
//                new RecommendAdvanceRequest());
//
//        Assert.assertEquals(expectedSet,result);
//    }
//
//    /**
//     * 测试输入找回结果为空的情况
//     */
//    @Test
//    public void testEmptyRecallFilter(){
//        Set<String> needFilterUserSet = Sets.newHashSet("100","101","102");
//        Set<String> recallUserSet = Sets.newHashSet();
//        Set<String> expectedSet = Sets.newHashSet(recallUserSet);
//        expectedSet.removeAll(needFilterUserSet);
//
//        String likeLimitConfig = env.getProperty("recommend.filter.liked.limit");
//        int likeLimit = Integer.parseInt(likeLimitConfig);
//        int currentHour = Integer.valueOf(DateUtil.getCurrentDateStr("HH"));
//        likeLimit *= (currentHour/12)+1; //如果过了12点（北京时间），则曝光上限翻倍
//        String currentDay = DateUtil.getCurrentDateStr("yyyyMMdd");
//        for(String uid : needFilterUserSet){
//            redisService.del(RedisKeyUtil.obtainKey(RedisKeyConstant.REDIS_BE_LIKED_SET_KEY_DAILY, uid, currentDay));
//            redisService.sadd(RedisKeyUtil.obtainKey(RedisKeyConstant.REDIS_BE_LIKED_SET_KEY_DAILY, uid, currentDay),
//                    createRandomUidArray(likeLimit+10).toArray(new String[]{}));
//        }
//        Set<String> result = likeLimitFilterStrategy.filter(recallUserSet,
//                Lists.newLinkedList(),
//                new RecommendAdvanceRequest());
//
//        Assert.assertEquals(expectedSet,result);
//
//        needFilterUserSet = Sets.newHashSet("100","101","102");
//        recallUserSet = null;
//
//        for(String uid : needFilterUserSet){
//            redisService.del(RedisKeyUtil.obtainKey(RedisKeyConstant.REDIS_BE_LIKED_SET_KEY_DAILY, uid, currentDay));
//            redisService.sadd(RedisKeyUtil.obtainKey(RedisKeyConstant.REDIS_BE_LIKED_SET_KEY_DAILY, uid, currentDay),
//                    createRandomUidArray(likeLimit+10).toArray(new String[]{}));
//        }
//        likeLimitFilterStrategy.updateCache();
//        result = likeLimitFilterStrategy.filter(recallUserSet,
//                Lists.newLinkedList(),
//                new RecommendAdvanceRequest());
//
//        Assert.assertEquals(Sets.newHashSet(),result);
//    }
//
//    /**
//     * 测试有like我的用户曝光达到上限的情况
//     */
//    @Test
//    public void testLikeMeUser(){
//        Set<String> needFilterUserSet = Sets.newHashSet("100","101","102");
//        Set<String> recallUserSet = Sets.newHashSet("99","100","101");
//        String requestUid = "23333";
//        RecommendAdvanceRequest request = new RecommendAdvanceRequest();
//        request.setUid(Long.valueOf(requestUid));
//        Set<String> likedMeUserSet = Sets.newHashSet("100");
//        Set<String> superLikedMeUserSet = Sets.newHashSet("101");
//
//        Set<String> expectedSet = Sets.newHashSet(recallUserSet);
//        Set<String> tempNeedFilterSet =  Sets.newHashSet(needFilterUserSet);
//        tempNeedFilterSet.removeAll(likedMeUserSet);
//        tempNeedFilterSet.removeAll(superLikedMeUserSet);
//        expectedSet.removeAll(tempNeedFilterSet);
//
//        String likeLimitConfig = env.getProperty("recommend.filter.liked.limit");
//        int likeLimit = Integer.parseInt(likeLimitConfig);
//        int currentHour = Integer.valueOf(DateUtil.getCurrentDateStr("HH"));
//        likeLimit *= (currentHour/12)+1; //如果过了12点（北京时间），则曝光上限翻倍
//        String currentDay = DateUtil.getCurrentDateStr("yyyyMMdd");
//
//        redisService.del(RedisKeyConstant.REDIS_BE_LIKED_TEMP_SET_KEY_+requestUid);
//        redisService.del(RedisKeyConstant.REDIS_BE_SUPER_LIKED_TEMP_SET_KEY_+requestUid);
//        for(String uid : likedMeUserSet){
//            redisService.sadd(RedisKeyConstant.REDIS_BE_LIKED_TEMP_SET_KEY_+requestUid,uid);
//        }
//        for(String uid : superLikedMeUserSet){
//            redisService.sadd(RedisKeyConstant.REDIS_BE_SUPER_LIKED_TEMP_SET_KEY_+requestUid,uid);
//        }
//        for(String uid : needFilterUserSet){
//            redisService.sadd(RedisKeyConstant.REDIS_ACT_IN_24H_USER_SET_KEY,uid);
//            redisService.del(RedisKeyUtil.obtainKey(RedisKeyConstant.REDIS_BE_LIKED_SET_KEY_DAILY, uid, currentDay));
//            redisService.sadd(RedisKeyUtil.obtainKey(RedisKeyConstant.REDIS_BE_LIKED_SET_KEY_DAILY, uid, currentDay),
//                    createRandomUidArray(likeLimit+10).toArray(new String[]{}));
//        }
//        likeLimitFilterStrategy.updateCache();
//        Set<String> result = likeLimitFilterStrategy.filter(recallUserSet,
//                Lists.newLinkedList(),
//                request);
//
//        Assert.assertEquals(expectedSet,result);
//    }
//
//
//    private Set<String> createRandomUidArray(int size){
//        Set<String> result = Sets.newHashSet();
//        while (result.size()<size){
//            result.add(String.valueOf(RandomUtils.nextLong()));
//        }
//        return result;
//    }

}
