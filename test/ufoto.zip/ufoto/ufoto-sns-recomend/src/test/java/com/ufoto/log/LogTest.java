package com.ufoto.log;

import com.ufoto.BaseUnitTest;
import com.ufoto.logging.proxy.UfotoLogFactory;
import org.junit.Test;
import org.slf4j.Logger;

/**
 * Created by echo on 12/13/18.
 */
public class LogTest extends BaseUnitTest{

    private static final Logger logger = (Logger) UfotoLogFactory.getLogger(LogTest.class).build();
    @Test
    public void testLog(){
        for(int _=0;_<100;_++){
            logger.info("This is {}","info");
            logger.debug("This is {}","debug");
            logger.warn("This is {}","warn");
            logger.error("This is {}","fucking ERROR!!!");
        }
    }

    @Test
    public void testTopicLog(){
        LogTopicConstant.invokerLogger.info("Come from invoker info");
        LogTopicConstant.invokerLogger.debug("Come from invoker debug");
        LogTopicConstant.invokerLogger.warn("Come from invoker warn");
        LogTopicConstant.invokerLogger.error("Come from invoker error");
    }

}
