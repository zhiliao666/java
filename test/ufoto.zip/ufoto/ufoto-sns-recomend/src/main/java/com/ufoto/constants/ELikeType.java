package com.ufoto.constants;

/**
 * <p>
 * like 的类型
 * </p>
 *
 * @author created by chenzhou at 2018-08-01 13:25
 */
public enum ELikeType {
    LIKE(1, "喜欢"),
    DISLIKE(2, "不喜欢"),
    SUPER_LIKE(3, "超级喜欢");

    private Integer type;
    private String description;

    ELikeType(Integer type, String description) {
        this.type = type;
        this.description = description;
    }

    public Integer getType() {
        return type;
    }

    public String getDescription() {
        return description;
    }
}
