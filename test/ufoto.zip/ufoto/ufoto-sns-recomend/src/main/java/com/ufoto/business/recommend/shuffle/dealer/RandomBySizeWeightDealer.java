package com.ufoto.business.recommend.shuffle.dealer;

import com.ufoto.annotation.RecommendMetadata;
import com.ufoto.business.recommend.shuffle.base.ShuffleDealer;
import org.apache.commons.lang.math.RandomUtils;

import java.util.List;

/**
 * 根据输入每个列表的大小，来决定其出现的权重，然后随机
 */
@RecommendMetadata(
        metadataType = RecommendMetadata.MetadataType.DEALER,
        available = true,
        name = "列表长度权重收集器",
        description = "根据列表长度决定权重,长度越长,越有可能排在前面",
        branch = RecommendMetadata.Branch.NORMAL
)
public class RandomBySizeWeightDealer implements ShuffleDealer {

    @Override
    public String[] shuffleAndDeal(List<List<String>> cutUidList) {
        int totalSize = cutUidList.stream().mapToInt(List::size).sum();
        String[] result = new String[totalSize];
        for (int i = 0; i < totalSize; i++) {
            int rand = RandomUtils.nextInt(totalSize - i);
            int weightSum = 0;
            for (List<String> strings : cutUidList) {
                weightSum += strings.size();
                if (rand < weightSum) {
                    result[i] = strings.get(0);
                    strings.remove(0);
                    break;
                }
            }
        }
        return result;
    }
}
