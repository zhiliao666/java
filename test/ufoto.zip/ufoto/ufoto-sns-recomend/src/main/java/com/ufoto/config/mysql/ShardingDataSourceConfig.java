package com.ufoto.config.mysql;

import com.google.common.collect.Maps;
import com.ufoto.plugins.interceptor.CRUDInterceptor;
import io.shardingjdbc.core.api.ShardingDataSourceFactory;
import io.shardingjdbc.core.api.config.MasterSlaveRuleConfiguration;
import io.shardingjdbc.core.api.config.ShardingRuleConfiguration;
import io.shardingjdbc.core.api.config.TableRuleConfiguration;
import io.shardingjdbc.core.api.config.strategy.InlineShardingStrategyConfiguration;
import lombok.extern.slf4j.Slf4j;
import org.apache.ibatis.plugin.Interceptor;
import org.apache.ibatis.session.SqlSessionFactory;
import org.mybatis.spring.SqlSessionFactoryBean;
import org.mybatis.spring.SqlSessionTemplate;
import org.mybatis.spring.annotation.MapperScan;
import org.springframework.beans.factory.annotation.Qualifier;
import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;
import org.springframework.jdbc.datasource.DataSourceTransactionManager;

import javax.sql.DataSource;
import java.sql.SQLException;
import java.util.Collections;
import java.util.HashMap;
import java.util.Map;
import java.util.Properties;

/**
 * Created by echo on 3/20/18.
 */
@Configuration
@MapperScan(basePackages = "com.ufoto.dao.sharding", sqlSessionTemplateRef = "shardingSqlSessionTemplate")
@Slf4j
public class ShardingDataSourceConfig {

    @Bean(name = "shardingDataSource")
    public DataSource shardingDataSource(@Qualifier("writeDataSource") DataSource writeDataSource,
                                         @Qualifier("readDataSource") DataSource readDataSource) throws SQLException {
        // 配置真实数据源
        Map<String, DataSource> dataSourceMap = new HashMap<>();
        dataSourceMap.put("ds_0_master", writeDataSource);
        dataSourceMap.put("ds_0_slave", readDataSource);

        // 配置分表规则
        TableRuleConfiguration userLikeFromTableRuleConfig = new TableRuleConfiguration();
        userLikeFromTableRuleConfig.setLogicTable("ufoto_user_like_f");
        userLikeFromTableRuleConfig.setActualDataNodes("ds_0.ufoto_user_like_f${0..99}");
        userLikeFromTableRuleConfig.setTableShardingStrategyConfig(
                new InlineShardingStrategyConfiguration("f_u_id", "ufoto_user_like_f${f_u_id % 100}"));

        TableRuleConfiguration userLikeToTableRuleConfig = new TableRuleConfiguration();
        userLikeToTableRuleConfig.setLogicTable("ufoto_user_like_t");
        userLikeToTableRuleConfig.setActualDataNodes("ds_0.ufoto_user_like_t${0..99}");
        userLikeToTableRuleConfig.setTableShardingStrategyConfig(
                new InlineShardingStrategyConfiguration("t_u_id", "ufoto_user_like_t${t_u_id % 100}"));

        MasterSlaveRuleConfiguration masterSlaveRuleConfiguration = new MasterSlaveRuleConfiguration();
        masterSlaveRuleConfiguration.setName("ds_0");
        masterSlaveRuleConfiguration.setMasterDataSourceName("ds_0_master");
        masterSlaveRuleConfiguration.setSlaveDataSourceNames(Collections.singletonList("ds_0_slave"));

        // 配置分片规则
        ShardingRuleConfiguration shardingRuleConfig = new ShardingRuleConfiguration();
        shardingRuleConfig.getTableRuleConfigs().add(userLikeFromTableRuleConfig);
        shardingRuleConfig.getTableRuleConfigs().add(userLikeToTableRuleConfig);
        shardingRuleConfig.getMasterSlaveRuleConfigs().add(masterSlaveRuleConfiguration);

        // 获取数据源对象
        final Properties props = new Properties();
        if (log.isDebugEnabled()) {
            props.setProperty("sql.show", "true");
        }

        return ShardingDataSourceFactory.createDataSource(dataSourceMap, shardingRuleConfig, Maps.newConcurrentMap(), props);
    }

    @Bean(name = "shardingSqlSessionFactory")
    public SqlSessionFactory readSqlSessionFactory(@Qualifier("shardingDataSource") DataSource dataSource) throws Exception {
        SqlSessionFactoryBean bean = new SqlSessionFactoryBean();
        bean.setDataSource(dataSource);
        bean.setPlugins(new Interceptor[]{new CRUDInterceptor()});
        return bean.getObject();
    }

    @Bean(name = "shardingSqlSessionTemplate")
    public SqlSessionTemplate readSqlSessionTemplate(@Qualifier("shardingSqlSessionFactory") SqlSessionFactory sqlSessionFactory) {
        return new SqlSessionTemplate(sqlSessionFactory);
    }

    @Bean(name = "shardingTransactionManager")
    public DataSourceTransactionManager readTransactionManager(@Qualifier("shardingDataSource") DataSource dataSource) {
        return new DataSourceTransactionManager(dataSource);
    }
}
