package com.ufoto.business.usercenter.dto;

import lombok.Data;

import java.io.Serializable;

/**
 * 用户工作信息
 * 对应数据表ufoto_user_work, ufoto_user_work_relation
 *
 * @author luozq
 * @date 2019/3/7/007
 */
@Data
public class UfotoUserWorkDo implements Serializable {

    /**
     * 用户id
     */
    private Long uId;

    /**
     * id
     */
    private String id;
    /**
     * 职位
     */
    private String position = "";
    /**
     * 雇主
     */
    private String employer = "";
}
