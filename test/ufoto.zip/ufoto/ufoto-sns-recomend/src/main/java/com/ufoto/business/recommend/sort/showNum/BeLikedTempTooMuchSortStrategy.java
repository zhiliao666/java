package com.ufoto.business.recommend.sort.showNum;

import com.google.common.collect.Lists;
import com.ufoto.annotation.RecommendMetadata;
import com.ufoto.business.recommend.bean.SortParamsBean;
import com.ufoto.business.recommend.sort.BaseNormalSortStrategy;
import com.ufoto.utils.redis.RedisKeyConstant;
import com.ufoto.utils.redis.RedisService;
import org.springframework.core.env.Environment;
import org.springframework.stereotype.Component;

import java.nio.charset.StandardCharsets;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.stream.Collectors;

/**
 * Created by echo on 5/18/18.
 */
@RecommendMetadata(
        metadataType = RecommendMetadata.MetadataType.SORT,
        available = true,
        name = "未处理的like数量上限排序策略",
        description = "如果用户的未处理被like和被superlike数量超出30,则基础分数为1,否则为0",
        branch = RecommendMetadata.Branch.NORMAL
)
@Component
public class BeLikedTempTooMuchSortStrategy extends BaseNormalSortStrategy {

    private final RedisService redisService;
    private final Environment env;

    public BeLikedTempTooMuchSortStrategy(RedisService redisService, Environment env) {
        this.redisService = redisService;
        this.env = env;
    }

    /**
     * 如果未处理的like数量过多，则返回1
     */
    @Override
    public Map<String, Double> getScore(List<String> recallUids, SortParamsBean sortParamsBean) {
        final int BE_LIKED_TEMP_TOO_MUCH_THRESHOLD = env.getProperty("recommend.sort.beLikedTempTooMuchThreshold", Integer.class, 30);
        final List<Object> objects = redisService.execPipelineForRead(connection -> {
            for (String recallUid : recallUids) {
                connection.sCard((RedisKeyConstant.REDIS_BE_LIKED_TEMP_SET_KEY_ + recallUid).getBytes(StandardCharsets.UTF_8));
                connection.sCard((RedisKeyConstant.REDIS_BE_SUPER_LIKED_TEMP_SET_KEY_ + recallUid).getBytes(StandardCharsets.UTF_8));
            }
            return null;
        });
        final List<Long> beLikedTempNumList = Lists.partition(objects, 2).parallelStream()
                .map(part -> part.stream().mapToLong(o -> (long) o).sum())
                .collect(Collectors.toList());
        final int size = recallUids.size();
        Map<String, Double> scoreMap = new HashMap<>();
        for (int i = 0; i < size; i++) {
            final String recallUid = recallUids.get(i);
            final Long beLikedTempNum = beLikedTempNumList.get(i);
            final int result = beLikedTempNum > BE_LIKED_TEMP_TOO_MUCH_THRESHOLD ? 1 : 0;
            scoreMap.put(recallUid, (double) result);
        }
        return scoreMap;
    }
}
