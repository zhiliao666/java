package com.ufoto.entity;

import com.ufoto.entity.base.BaseUfotoAppCardExample;

/**
 * <p>
 * Author     : Chan
 * CreateDate : 2018/9/15 15:22
 * Description:
 * </p>
 */
public class UfotoAppCardExample extends BaseUfotoAppCardExample {
}
