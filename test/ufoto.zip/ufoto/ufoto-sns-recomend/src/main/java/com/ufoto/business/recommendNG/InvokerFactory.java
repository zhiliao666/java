package com.ufoto.business.recommendNG;

import com.github.benmanes.caffeine.cache.LoadingCache;
import com.google.common.collect.Maps;
import com.ufoto.annotation.RecommendMetadata;
import com.ufoto.business.elasticsearch.dto.UserImageAttrDto;
import com.ufoto.constants.EStrategyCategory;
import com.ufoto.dto.CommonStrategyBean;
import com.ufoto.dto.ConditionRequest;
import com.ufoto.dto.RecommendAdvanceRequest;
import com.ufoto.manager.ElasticSearchManager;
import com.ufoto.runner.RuleEngineManager;
import com.ufoto.utils.BeanUtil;
import com.ufoto.utils.CommonUtil;
import com.ufoto.utils.DirtyCaseUtil;
import com.ufoto.utils.json.JSONUtil;
import com.ufoto.utils.redis.RedisKeyConstant;
import com.ufoto.utils.redis.RedisService;
import com.ufoto.utils.strategy.InvokerUtil;
import com.ufoto.utils.strategy.ParamsConverter;
import com.ufoto.utils.strategy.StrategyPathBeanExpand;
import lombok.RequiredArgsConstructor;
import lombok.extern.slf4j.Slf4j;
import org.springframework.beans.BeanUtils;
import org.springframework.core.env.Environment;
import org.springframework.stereotype.Component;

import java.util.Map;
import java.util.concurrent.TimeUnit;
import java.util.stream.Collectors;

import static com.ufoto.annotation.RecommendMetadata.Branch.DEFAULT;
import static com.ufoto.annotation.RecommendMetadata.Branch.GIFT;
import static com.ufoto.annotation.RecommendMetadata.Branch.High_Risk;

/**
 * <p>
 * Description:
 *
 * </p>
 *
 * @author Chan
 * @date 2020/2/15 21:50
 */
@Slf4j
@RequiredArgsConstructor
@Component
public class InvokerFactory {
    private final DirtyCaseUtil dirtyCaseUtil;
    private final LoadingCache<RecommendMetadata.Branch, Invoker> specialCaseInvokerCache;
    private final ParamsConverter paramsConverter;
    private final RuleEngineManager ruleEngineManager;
    private final InvokerUtil invokerUtil;
    private final RedisService redisService;
    private final Environment env;

    public Invoker obtainInvoker(RecommendAdvanceRequest recommendAdvanceRequest) {

        if (dirtyCaseUtil.ifNeedGiftReceiveCardRequest(recommendAdvanceRequest)) {
            return specialCaseInvokerCache.get(GIFT);
        } else if (dirtyCaseUtil.ifNullForDefaultRequest(recommendAdvanceRequest)) {
            return specialCaseInvokerCache.get(DEFAULT);
        } else if (dirtyCaseUtil.ifHighRiskRequest(recommendAdvanceRequest)) {
            return specialCaseInvokerCache.get(High_Risk);
        } else {
            return createInvokerFromRuleEngine(recommendAdvanceRequest);
        }
    }

    private Invoker createInvokerFromRuleEngine(RecommendAdvanceRequest recommendAdvanceRequest) {
        final ConditionRequest strategyRequest = paramsConverter.obtainStrategyRequest(recommendAdvanceRequest);
        final Map<String, CommonStrategyBean> strategyNG = ruleEngineManager.strategyNG(strategyRequest);
        Invoker invoker = invokerUtil.createInvoker(strategyNG,recommendAdvanceRequest);
        // TODO 以下代码可以考虑删除，目前只用于查推荐日志
        saveStrategyPathToRedis(recommendAdvanceRequest.getUid(), strategyNG);
        return invoker;
    }

    private void saveStrategyPathToRedis(Long uid, Map<String, CommonStrategyBean> strategyBeanMap) {
        //保存用户对应策略的路径
        try {
            final CommonStrategyBean commonStrategyBean = strategyBeanMap.get(EStrategyCategory.INVOKER.getCategory());
            StrategyPathBeanExpand pathBeanExpand = new StrategyPathBeanExpand();
            BeanUtils.copyProperties(commonStrategyBean.getPath(), pathBeanExpand);
            final Integer rpcStrategyId = commonStrategyBean.getId();
            pathBeanExpand.setStrategyId(rpcStrategyId);
            redisService.hMSet(RedisKeyConstant.REDIS_VARIANT_STRATEGY_PATH + uid, CommonUtil.pojo2mapString(pathBeanExpand));
            //设置过期
            redisService.expire(RedisKeyConstant.REDIS_VARIANT_STRATEGY_PATH + uid, env.getProperty("redis-variant-strategy-expire", Long.class, 86400L), TimeUnit.SECONDS);
            final String strategyJson = JSONUtil.toJSON(strategyBeanMap);
            log.debug("uid {},strategyJson {}", uid, strategyJson);
            redisService.hset(RedisKeyConstant.REDIS_STRATEGY_CACHE_KEY + (rpcStrategyId / RedisKeyConstant.HASH_BUCKETS),
                    rpcStrategyId + "", strategyJson);
        } catch (Exception e) {
            log.error(e.getMessage(), e);
        }
    }

}
