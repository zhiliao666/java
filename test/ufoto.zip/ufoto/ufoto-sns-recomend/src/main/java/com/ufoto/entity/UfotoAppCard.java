package com.ufoto.entity;

import com.ufoto.entity.base.BaseUfotoAppCard;

/**
 * <p>
 * Author     : Chan
 * CreateDate : 2018/9/15 15:15
 * Description:
 * </p>
 */
public class UfotoAppCard extends BaseUfotoAppCard {
}
