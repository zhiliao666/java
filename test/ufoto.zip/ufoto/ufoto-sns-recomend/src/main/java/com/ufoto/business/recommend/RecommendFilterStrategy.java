package com.ufoto.business.recommend;

import com.ufoto.dto.RecommendAdvanceRequest;

import java.util.List;
import java.util.Set;

/**
 * Created by echo on 4/2/18.
 */
public interface RecommendFilterStrategy {

    /**
     * @param recallSet     当前推荐策略查询出的推荐列表
     * @param resultList    已有的结果列表
     * @param filterRequest 当前列表需要过滤的参数对象
     * @return 过滤后的结果列表
     */
    Set<String> filter(Set<String> recallSet, List<String> resultList, RecommendAdvanceRequest filterRequest);
}
