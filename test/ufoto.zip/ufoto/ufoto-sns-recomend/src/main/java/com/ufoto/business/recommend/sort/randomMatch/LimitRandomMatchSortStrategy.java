package com.ufoto.business.recommend.sort.randomMatch;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;

/**
 * <p>
 *
 * </p>
 *
 * @author created by chenzhou at 2018-08-02 18:52
 */
@Component
public class LimitRandomMatchSortStrategy extends CompositeRandomMatchSortStrategy {

    @Autowired
    public LimitRandomMatchSortStrategy(LanguageSortStrategy languageSortStrategy,
                                        GenderSortStrategy genderSortStrategy,
                                        JoinDateSortStrategy joinDateSortStrategy) {
        sortStrategyWeightMap.put(languageSortStrategy, 100000D);
        sortStrategyWeightMap.put(genderSortStrategy, 500D);
        sortStrategyWeightMap.put(joinDateSortStrategy, 2D);
    }
}
