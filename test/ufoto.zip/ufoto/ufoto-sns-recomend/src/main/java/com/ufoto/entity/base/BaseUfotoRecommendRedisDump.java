package com.ufoto.entity.base;

import java.io.Serializable;

public class BaseUfotoRecommendRedisDump implements Serializable {
    /**
     * Default value included to remove warning. Remove or modify at will.
     **/
    private static final long serialVersionUID = 1L;

    private java.lang.Integer createTime;
    private java.lang.Boolean hasRestored;
    private java.lang.Long id;
    private java.lang.String key;
    private java.lang.Long uid;
    private java.lang.String dump;
    private java.lang.Integer lastActTime;

    public java.lang.Integer getCreateTime() {
        return createTime;
    }

    public void setCreateTime(java.lang.Integer createTime) {
        this.createTime = createTime;
    }

    public java.lang.Boolean getHasRestored() {
        return hasRestored;
    }

    public void setHasRestored(java.lang.Boolean hasRestored) {
        this.hasRestored = hasRestored;
    }

    public java.lang.Long getId() {
        return id;
    }

    public void setId(java.lang.Long id) {
        this.id = id;
    }

    public java.lang.String getKey() {
        return key;
    }

    public void setKey(java.lang.String key) {
        this.key = key;
    }

    public java.lang.Long getUid() {
        return uid;
    }

    public void setUid(java.lang.Long uid) {
        this.uid = uid;
    }

    public java.lang.String getDump() {
        return dump;
    }

    public void setDump(java.lang.String dump) {
        this.dump = dump;
    }

    public java.lang.Integer getLastActTime() {
        return lastActTime;
    }

    public void setLastActTime(java.lang.Integer lastActTime) {
        this.lastActTime = lastActTime;
    }

    @Override
    public boolean equals(Object o) {
        if (this == o) return true;
        if (o == null || getClass() != o.getClass()) return false;

        BaseUfotoRecommendRedisDump that = (BaseUfotoRecommendRedisDump) o;

        if (!hasRestored.equals(that.hasRestored)) return false;
        if (!key.equals(that.key)) return false;
        if (!uid.equals(that.uid)) return false;
        if (!dump.equals(that.dump)) return false;
        return lastActTime.equals(that.lastActTime);

    }

    @Override
    public int hashCode() {
        int result = hasRestored.hashCode();
        result = 31 * result + key.hashCode();
        result = 31 * result + uid.hashCode();
        result = 31 * result + dump.hashCode();
        result = 31 * result + lastActTime.hashCode();
        return result;
    }

//	@Override
//	public String toString() {
//		return "{ id:" + id + ", name:" + name + ", email:" + email
//				+ ", phone:" + phoneNumber + " }";
//	}
}
