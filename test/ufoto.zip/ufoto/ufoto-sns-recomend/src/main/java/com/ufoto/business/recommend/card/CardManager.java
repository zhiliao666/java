package com.ufoto.business.recommend.card;

import com.google.common.collect.Sets;
import com.ufoto.constants.EApiVersion;
import com.ufoto.dto.RecommendAdvanceRequest;
import com.ufoto.utils.DirtyCaseUtil;
import lombok.extern.slf4j.Slf4j;
import org.apache.commons.lang3.RandomUtils;
import org.springframework.core.env.Environment;
import org.springframework.stereotype.Component;
import org.springframework.util.CollectionUtils;

import java.util.List;
import java.util.Set;

/**
 * Created by echo on 5/22/19.
 * <p>
 * 负责管理推荐列表中出现的各种卡片
 */
@Slf4j
@Component
public class CardManager {

    private final Environment env;
    private final SnapNewUserCardRecallStrategy snapNewUserCardRecallStrategy;
    private final ElementaryCardRecallStrategy cardRecallStrategy;
    private final DirtyCaseUtil dirtyCaseUtil;

    public CardManager(Environment env,
                       SnapNewUserCardRecallStrategy snapNewUserCardRecallStrategy,
                       ElementaryCardRecallStrategy cardRecallStrategy,
                       DirtyCaseUtil dirtyCaseUtil) {
        this.env = env;
        this.snapNewUserCardRecallStrategy = snapNewUserCardRecallStrategy;
        this.cardRecallStrategy = cardRecallStrategy;
        this.dirtyCaseUtil = dirtyCaseUtil;
    }


    public CardDealer createCardDealer(RecommendAdvanceRequest recommendAdvanceRequest) {
        return new CardDealer(recommendAdvanceRequest);
    }


    public class CardDealer {

        RecommendAdvanceRequest recommendAdvanceRequest;

        public CardDealer(RecommendAdvanceRequest recommendAdvanceRequest) {
            this.recommendAdvanceRequest = recommendAdvanceRequest;
        }

        /**
         * 将对应的card筛选出来之后，加入到推荐结果列表的对应位置。
         *
         * @param recommendResult 推荐结果列表
         */
        public void dealCardToList(final List<String> recommendResult) {
            //如果是礼物卡片列表，不需要添加任何其他内容
            if (dirtyCaseUtil.ifNeedGiftReceiveCardRequest(getRecommendAdvanceRequest())) {
                return;
            }
            //随机派发之前问题卡片
            cardRandom(recommendResult);
            //如果是Snap的新用户
            if (dirtyCaseUtil.ifSnapNewUserRequest(getRecommendAdvanceRequest())) {
                snapNewUserCard(recommendResult);
            }
        }

        public RecommendAdvanceRequest getRecommendAdvanceRequest() {
            return recommendAdvanceRequest;
        }

        private void cardRandom(final List<String> sortedResult) {
            if (CollectionUtils.isEmpty(sortedResult)) return;
            RecommendAdvanceRequest recommendAdvanceRequest = getRecommendAdvanceRequest();
            final String apiVersion = recommendAdvanceRequest.getApiVersion();
            boolean cardStrategyOn = env.getProperty("recommend.app.card.open", Boolean.class, false);
            final int totalSize = sortedResult.size();
            final int threeQuarterPoint = (int) Math.floor(totalSize * 0.75);
            if (EApiVersion.ifHandleCard(apiVersion) && cardStrategyOn) {
                final Set<String> cardIds = cardRecallStrategy.recall(0L, 0, recommendAdvanceRequest);
                if (!CollectionUtils.isEmpty(cardIds)) {
                    Set<Integer> randomIndexes = Sets.newHashSet();
                    for (int i = 0; i < cardIds.size(); i++) {
                        final int index = RandomUtils.nextInt(threeQuarterPoint, totalSize);
                        randomIndexes.add(index);
                    }
                    final String[] cardIdArr = cardIds.toArray(new String[]{});
                    final Integer[] randomIndexArr = randomIndexes.toArray(new Integer[]{});
                    for (int i = 0; i < randomIndexArr.length; i++) {
                        sortedResult.add(randomIndexArr[i], cardIdArr[i]);
                    }
                }
            }
        }

        private void snapNewUserCard(final List<String> sortedResult) {
            if (CollectionUtils.isEmpty(sortedResult)) return;
            RecommendAdvanceRequest recommendAdvanceRequest = getRecommendAdvanceRequest();
            boolean snapNewUserCardOn = env.getProperty("recommend.app.card.snapNewUser.open", Boolean.class, true);
            if (snapNewUserCardOn) {
                final Set<String> cardIds = snapNewUserCardRecallStrategy.recall(0L, 0, recommendAdvanceRequest);
                log.debug("snapNewUserCard recall size:" + cardIds.size());
                sortedResult.addAll(0, cardIds);
                log.debug("snapNewUserCard first card id:" + sortedResult.get(0));
            }
        }

    }
}
