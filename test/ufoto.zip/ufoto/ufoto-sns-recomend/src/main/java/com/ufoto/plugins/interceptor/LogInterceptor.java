package com.ufoto.plugins.interceptor;

import com.ufoto.utils.threadlocal.ThreadLocalManager;
import lombok.extern.slf4j.Slf4j;
import org.slf4j.MDC;
import org.springframework.stereotype.Component;
import org.springframework.util.StringUtils;
import org.springframework.web.servlet.handler.HandlerInterceptorAdapter;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import java.util.UUID;

/**
 * Created by echo on 12/13/18.
 */
@Slf4j
@Component
public class LogInterceptor extends HandlerInterceptorAdapter {

    /**
     * 会话sessionid
     */
    public final static String SESSION_KEY = "traceId";

    @Override
    public boolean preHandle(HttpServletRequest request,
                             HttpServletResponse response, Object handler) throws Exception {
        String requestId = request.getHeader("request-id");
        log.debug("globalRequestId:{}", requestId);
        // 设置SessionId
        if (StringUtils.isEmpty(requestId)) {
            requestId = UUID.randomUUID().toString().replace("-", "");
        }
        MDC.put(SESSION_KEY, requestId);
        return true;
    }

    @Override
    public void afterCompletion(HttpServletRequest request, HttpServletResponse response, Object handler,
                                Exception ex) throws Exception {
        // 刪除SessionId
        MDC.remove(SESSION_KEY);
        // 清理线程缓存
        ThreadLocalManager.clear();
    }
}
