package com.ufoto.entity.base;

import java.io.Serializable;

public class BaseSnsActDayUser implements Serializable {
    /**
     * Default value included to remove warning. Remove or modify at will.
     **/
    private static final long serialVersionUID = 1L;

    private java.lang.Integer likeNum;
    private java.lang.Long id;
    private java.lang.Integer queryLikeStat;
    private java.lang.Long uid;
    private java.sql.Timestamp createDate;
    private java.sql.Date statDate;
    private java.lang.Integer superLike;
    private java.lang.Integer rewind;
    private java.sql.Timestamp modifyDate;
    private java.lang.Integer dislike;

    public java.lang.Integer getLikeNum() {
        return likeNum;
    }

    public void setLikeNum(java.lang.Integer likeNum) {
        this.likeNum = likeNum;
    }

    public java.lang.Long getId() {
        return id;
    }

    public void setId(java.lang.Long id) {
        this.id = id;
    }

    public java.lang.Integer getQueryLikeStat() {
        return queryLikeStat;
    }

    public void setQueryLikeStat(java.lang.Integer queryLikeStat) {
        this.queryLikeStat = queryLikeStat;
    }

    public java.lang.Long getUid() {
        return uid;
    }

    public void setUid(java.lang.Long uid) {
        this.uid = uid;
    }

    public java.sql.Timestamp getCreateDate() {
        return createDate;
    }

    public void setCreateDate(java.sql.Timestamp createDate) {
        this.createDate = createDate;
    }

    public java.sql.Date getStatDate() {
        return statDate;
    }

    public void setStatDate(java.sql.Date statDate) {
        this.statDate = statDate;
    }

    public java.lang.Integer getSuperLike() {
        return superLike;
    }

    public void setSuperLike(java.lang.Integer superLike) {
        this.superLike = superLike;
    }

    public java.lang.Integer getRewind() {
        return rewind;
    }

    public void setRewind(java.lang.Integer rewind) {
        this.rewind = rewind;
    }

    public java.sql.Timestamp getModifyDate() {
        return modifyDate;
    }

    public void setModifyDate(java.sql.Timestamp modifyDate) {
        this.modifyDate = modifyDate;
    }

    public java.lang.Integer getDislike() {
        return dislike;
    }

    public void setDislike(java.lang.Integer dislike) {
        this.dislike = dislike;
    }


//	@Override
//	public String toString() {
//		return "{ id:" + id + ", name:" + name + ", email:" + email
//				+ ", phone:" + phoneNumber + " }";
//	}
}
