package com.ufoto.business.recommend;

/**
 * Created by echo on 4/9/18.
 */
public interface RecommendABShardStrategy {

    /**
     * 根据用户id，将用户分配到对应的策略组
     * <p>
     * 0：A
     * 1：B
     *
     * @param uid
     * @return
     */
    int getAbType(Long uid);

    /**
     * 根据用户ID获取对应策略名称（记录日志使用）
     *
     * @param uid
     * @return
     */
    String getAbName(Long uid);

    /**
     * 根据AbType获取对应策略名称（记录日志使用）
     *
     * @param type
     * @return
     */
    String getAbName(int type);

}
