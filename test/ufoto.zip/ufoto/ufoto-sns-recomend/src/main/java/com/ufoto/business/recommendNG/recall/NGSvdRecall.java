package com.ufoto.business.recommendNG.recall;

import com.google.common.collect.Sets;
import com.ufoto.annotation.RecommendMetadata;
import com.ufoto.business.recommendNG.Recall;
import com.ufoto.dao.svd.UfotoSvdUserTopNMapper;
import com.ufoto.dto.RecommendAdvanceRequest;
import org.springframework.core.env.Environment;
import org.springframework.stereotype.Component;
import org.springframework.util.CollectionUtils;

import java.util.List;
import java.util.Objects;
import java.util.Set;
import java.util.stream.Collectors;

/**
 * Created by echo on 5/11/18.
 */
@RecommendMetadata(
        metadataType = RecommendMetadata.MetadataType.RECALL,
        available = true,
        name = "SVD召回策略",
        description = "召回SVD算法中的topN",
        branch = RecommendMetadata.Branch.NORMAL
)
@Component
public class NGSvdRecall implements Recall {

    private final UfotoSvdUserTopNMapper svdUserTopNMapper;
    private final Environment env;

    public NGSvdRecall(UfotoSvdUserTopNMapper svdUserTopNMapper,
                       Environment env) {
        this.svdUserTopNMapper = svdUserTopNMapper;
        this.env = env;
    }

    @Override
    public Set<String> recall(Integer minSize, RecommendAdvanceRequest recallRequest) {
        boolean ifSvdOn = env.getProperty("recommend.recall.ifSvdOn", Boolean.class, true);
        if (!ifSvdOn) return Sets.newHashSet();
        List<Long> recallResultList = svdUserTopNMapper.selectTopNByUid(recallRequest.getUid(), 10000, 0);
        if (CollectionUtils.isEmpty(recallResultList))
            return Sets.newHashSet();
        return recallResultList.stream()
                .filter(Objects::nonNull)
                .map(Object::toString)
                .collect(Collectors.toSet());
    }

    @Override
    public boolean ifRecallOnlyOnce() {
        return true;
    }

    @Override
    public boolean ifNeedThreadLocalCache() {
        return true;
    }

}
