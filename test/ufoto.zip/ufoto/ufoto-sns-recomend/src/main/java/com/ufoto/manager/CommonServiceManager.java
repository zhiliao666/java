package com.ufoto.manager;

import com.google.common.collect.Lists;
import com.google.common.collect.Maps;
import com.ufoto.business.common.ApiCommonInfoBusiness;
import com.ufoto.utils.ApiResult;
import com.ufoto.utils.json.JSONUtil;
import lombok.extern.slf4j.Slf4j;
import org.springframework.boot.CommandLineRunner;
import org.springframework.core.annotation.Order;
import org.springframework.core.env.Environment;
import org.springframework.stereotype.Component;
import org.springframework.util.CollectionUtils;

import java.util.List;
import java.util.Map;
import java.util.Objects;
import java.util.stream.Collectors;
import java.util.stream.IntStream;

/**
 * <p>
 * Author     : Chan
 * CreateDate : 2019-07-17 17:32
 * Description: 启动加载所有大区
 * </p>
 */
@Order(Integer.MAX_VALUE - 100)
@Slf4j
@Component
public class CommonServiceManager implements CommandLineRunner {

    //country <--> areaId mapping
    private final Map<String, Integer> countryAreaMap;
    private final List<Integer> areaList;
    private final ApiCommonInfoBusiness apiCommonInfoBusiness;
    private final Environment env;

    public CommonServiceManager(ApiCommonInfoBusiness apiCommonInfoBusiness,
                                Environment env) {
        this.apiCommonInfoBusiness = apiCommonInfoBusiness;
        this.env = env;
        countryAreaMap = Maps.newHashMap();
        areaList = Lists.newArrayList();
    }

    @Override
    public void run(String... args) {
        try {
            final Boolean areaSwitch = env.getProperty("common.service.country.area.switch", Boolean.class, false);
            if (!areaSwitch) return;
            log.debug("开始加载所有大区...");
            final ApiResult<Map<String, Integer>> apiResult = apiCommonInfoBusiness.areaCountryMap(ApiCommonInfoBusiness.SWEET_CHAT_APP_ID);
            if (!Objects.equals(ApiResult.successCode, apiResult.getC()) || CollectionUtils.isEmpty(apiResult.getD())) {
                throw new RuntimeException("获取大区失败: " + JSONUtil.toJSON(apiResult));
            }
            countryAreaMap.putAll(apiResult.getD());
            areaList.clear();
            areaList.addAll(countryAreaMap.values().stream().distinct().collect(Collectors.toList()));
            log.debug("所有大区加载成功: {}\n{}", areaList, countryAreaMap);
        } catch (Exception e) {
            log.error(e.getMessage());
        }

    }

    //获取所有大区
    public List<Integer> getAreaList() {
        int maxAreaId = env.getProperty("cleanTask.maxAreaId", Integer.class, 100);
        final Boolean areaSwitch = env.getProperty("common.service.country.area.switch", Boolean.class, false);
        List<Integer> _areaList = IntStream.range(0, maxAreaId).boxed().collect(Collectors.toList());
        if (!areaSwitch) {
            return _areaList;
        }
        //重试一次
        if (CollectionUtils.isEmpty(areaList)) {
            run();
        }
        if (CollectionUtils.isEmpty(areaList)) {
            return Lists.newArrayList();
        }
        return areaList;

    }

    //根据国家代码获取大区
    public Integer getAreaId(String countryCode) {
        final Boolean areaSwitch = env.getProperty("common.service.country.area.switch", Boolean.class, false);
        if (!areaSwitch) {
            ApiResult<List<Integer>> apiResult = apiCommonInfoBusiness.getAreaIdByIp(null, countryCode, ApiCommonInfoBusiness.SWEET_CHAT_APP_ID);
            if (apiResult.getC() != ApiResult.successCode) {
                return null;
            }
            List<Integer> areaIdList = apiResult.getD();
            if (CollectionUtils.isEmpty(areaIdList)) {
                return null;
            }
            if (areaIdList.size() != 1) {
                log.warn("apiCommonInfoBusiness get more than one areaId.countryCode:{},areaIdList:{}", countryCode, areaIdList);
                return null;
            }
            return areaIdList.get(0);
        }
        return getCountryAreaMap().get(countryCode);
    }

    //获取所有国家码和大区的映射
    public Map<String, Integer> getCountryAreaMap() {
        //重试一次
        if (CollectionUtils.isEmpty(countryAreaMap)) {
            run();
        }
        if (CollectionUtils.isEmpty(countryAreaMap)) {
            return Maps.newHashMap();
        }
        return countryAreaMap;
    }
}
