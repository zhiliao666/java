package com.ufoto.utils.threadlocal;

import java.util.List;

/**
 * 用于缓存BF在Redis中的内容
 */
public class RawBFListCache {
    private Long uid;//BF对应的用户id
    private List<byte[]> bfList;//对应的多个BF

    public RawBFListCache(Long uid, List<byte[]> bfList) {
        this.uid = uid;
        this.bfList = bfList;
    }

    public Long getUid() {
        return uid;
    }

    public List<byte[]> getBfList() {
        return bfList;
    }
}
