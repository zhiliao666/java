package com.ufoto.business.recommend.filter.result;

import com.ufoto.annotation.RecommendMetadata;
import com.ufoto.business.recommend.RecommendFilterStrategy;
import com.ufoto.dto.RecommendAdvanceRequest;
import org.springframework.stereotype.Component;

import java.util.List;
import java.util.Set;

/**
 * Created by echo on 4/3/18.
 * <p>
 * 将之前的推荐结果过滤
 */
@RecommendMetadata(
        metadataType = RecommendMetadata.MetadataType.FILTER,
        name = "之前的推荐结果过滤策略",
        description = "将之前的推荐结果过滤掉,在使用,不过没啥用",
        branch = {
                RecommendMetadata.Branch.NORMAL,
                RecommendMetadata.Branch.DEFAULT,
                RecommendMetadata.Branch.GIFT,
                RecommendMetadata.Branch.High_Risk
        }
)
@Component
// TODO 好像是空实现是否可以去除
public class ResultFilterStrategy implements RecommendFilterStrategy {
    @Override
    public Set<String> filter(Set<String> recallSet, List<String> resultList, RecommendAdvanceRequest filterRequest) {
        recallSet.removeAll(resultList);
        return recallSet;
    }
}
