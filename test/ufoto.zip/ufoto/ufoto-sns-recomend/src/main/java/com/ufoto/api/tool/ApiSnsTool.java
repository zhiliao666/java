/**
 *
 * @author zhangqh  
 * @date Apr 3, 2020  
 * @version 1.0
 */
package com.ufoto.api.tool;

import java.util.List;

import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;
import com.ufoto.dto.RecommendAdvanceRequest;
import com.ufoto.service.RecommendService;
import lombok.RequiredArgsConstructor;
import lombok.extern.slf4j.Slf4j;

/**
 *
 * @author zhangqh  
 * @date Apr 3, 2020 3:46:11 PM  
 * @version 1.0
 */
@Slf4j
@RestController
@RequestMapping(path = {"/snsTool/"})
@RequiredArgsConstructor
public class ApiSnsTool {
	
	private final RecommendService recommendService;
	
	/**
	 * 测试返回推荐的用户id集合
	 * @param recommendAdvanceRequest
	 * @return
	 */
	@RequestMapping(value = "/recommend")
    public List<String> recommend(RecommendAdvanceRequest recommendAdvanceRequest) {
        return  recommendService.recommendUsers(recommendAdvanceRequest);                           	
     }
}
