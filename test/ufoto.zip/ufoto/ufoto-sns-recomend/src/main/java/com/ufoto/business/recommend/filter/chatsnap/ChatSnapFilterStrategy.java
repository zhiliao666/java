package com.ufoto.business.recommend.filter.chatsnap;

import com.google.common.collect.Lists;
import com.google.common.collect.Maps;
import com.ufoto.annotation.RecommendMetadata;
import com.ufoto.business.recommend.RecommendFilterStrategy;
import com.ufoto.dto.RecommendAdvanceRequest;
import com.ufoto.utils.redis.RedisKeyConstant;
import com.ufoto.utils.redis.RedisKeyUtil;
import com.ufoto.utils.redis.RedisService;
import lombok.extern.slf4j.Slf4j;
import org.springframework.core.env.Environment;
import org.springframework.stereotype.Component;

import java.nio.charset.StandardCharsets;
import java.util.List;
import java.util.Map;
import java.util.Set;
import java.util.stream.Collectors;

/**
 * <p>
 * Author     : Chan
 * CreateDate : 2019-08-29 16:32
 * Description:
 * </p>
 */
@Slf4j
@RecommendMetadata(
        metadataType = RecommendMetadata.MetadataType.FILTER,
        name = "Chat用户过滤Snap用户过滤策略",
        description = "男性的chat用户过滤掉女性的snap用户/snap女性过滤掉chat男性",
        branch = {
                RecommendMetadata.Branch.NORMAL,
                RecommendMetadata.Branch.DEFAULT,
                RecommendMetadata.Branch.GIFT,
                RecommendMetadata.Branch.High_Risk
        }
)
@Component
public class ChatSnapFilterStrategy implements RecommendFilterStrategy {

    private final Environment env;
    private final RedisService redisService;

    public ChatSnapFilterStrategy(Environment env,
                                  RedisService redisService) {
        this.env = env;
        this.redisService = redisService;
    }

    @Override
    public Set<String> filter(Set<String> recallSet, List<String> resultList, RecommendAdvanceRequest filterRequest) {
        final Boolean chatSnapUserSwitch = env.getProperty("chat.snap.user.filter.switch", Boolean.class, true);
        if (!chatSnapUserSwitch) {
            return recallSet;
        }

        final Long uid = filterRequest.getUid();
        final String userFromType = redisService.hget(RedisKeyUtil.obtainKey(RedisKeyConstant.REDIS_USER_HASH_KEY, uid),
                RedisKeyConstant.REDIS_USER_HASH_FROM_TYPE);

        if (!"3".equals(userFromType) && !"10".equals(userFromType)) {
            return recallSet;
        }

        List<String> allUids = Lists.newArrayList(recallSet);
        Map<String, String> fromTypeMap = Maps.newConcurrentMap();
        Lists.partition(allUids, 20).forEach(part -> {
            final List<Object> objects = redisService.execPipelineForRead(connection -> {
                for (String id : part) {
                    connection.hGet(RedisKeyUtil.obtainKey(RedisKeyConstant.REDIS_USER_HASH_KEY, id).getBytes(StandardCharsets.UTF_8),
                            RedisKeyConstant.REDIS_USER_HASH_FROM_TYPE.getBytes(StandardCharsets.UTF_8));
                }
                return null;
            });
            final int size = part.size();
            for (int i = 0; i < size; i++) {
                final String id = part.get(i); // string
                final Object obj = objects.get(i);// obj
                fromTypeMap.put(id, obj == null ? "-1" : obj.toString());
            }
        });
        return recallSet.stream()
                .filter(id -> userFromType.equals(fromTypeMap.getOrDefault(id, "-1")))
                .collect(Collectors.toSet());
    }
}
