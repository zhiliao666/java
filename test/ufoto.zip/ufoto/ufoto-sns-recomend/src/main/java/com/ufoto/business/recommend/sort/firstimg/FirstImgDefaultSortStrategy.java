package com.ufoto.business.recommend.sort.firstimg;

import com.google.common.collect.Maps;
import com.ufoto.annotation.RecommendMetadata;
import com.ufoto.business.recommend.bean.SortParamsBean;
import com.ufoto.business.recommend.sort.BaseNormalSortStrategy;
import com.ufoto.utils.CommonUtil;
import com.ufoto.utils.redis.RedisKeyConstant;
import com.ufoto.utils.redis.RedisService;
import lombok.extern.slf4j.Slf4j;
import org.springframework.core.env.Environment;
import org.springframework.stereotype.Component;
import org.springframework.util.CollectionUtils;

import java.nio.charset.StandardCharsets;
import java.util.List;
import java.util.Map;

/**
 * <p>
 * Description:
 *
 * </p>
 *
 * @author Chan
 * @date 2019/12/19 18:03
 */
@RecommendMetadata(
        metadataType = RecommendMetadata.MetadataType.SORT,
        available = true,
        name = "firstImg是默认图片的排序策略",
        description = "firstImg是默认图片 得分为-1,否则为0",
        branch = RecommendMetadata.Branch.NORMAL
)
@Slf4j
@Component
public class FirstImgDefaultSortStrategy extends BaseNormalSortStrategy {

    private final RedisService redisService;
    private final Environment env;

    public FirstImgDefaultSortStrategy(RedisService redisService,
                                       Environment env) {
        this.redisService = redisService;
        this.env = env;
    }

    @Override
    public Map<String, Double> getScore(List<String> recallUids, SortParamsBean sortParamsBean) {
        if (CollectionUtils.isEmpty(recallUids)
                || !env.getProperty("first.img.default.soft.switch", Boolean.class, true)) {
            return Maps.newHashMap();
        }
        final List<Object> objects = redisService.execPipelineForRead(connection -> {
            for (String recallUid : recallUids) {
                connection.sIsMember(RedisKeyConstant.REDIS_FIRST_IMG_DEFAULT.getBytes(StandardCharsets.UTF_8),
                        recallUid.getBytes(StandardCharsets.UTF_8));
            }
            return null;
        });
        int size = recallUids.size();
        final Map<String, Double> scoreMap = Maps.newHashMap();
        for (int i = 0; i < size; i++) {
            scoreMap.put(recallUids.get(i), CommonUtil.obj2bool(objects.get(i)) ? -1D : 0D);
        }
        log.debug("FirstImgDefault:{}", scoreMap);
        return scoreMap;
    }
}
