package com.ufoto.business.elasticsearch.dto;

import lombok.Data;

import java.io.Serializable;
import java.util.List;

/**
 * @author luozq
 * @date 2019/11/15 15:29
 */
@Data
public class UserActFilterVo implements Serializable {

    /**
     * user id, 当前发起请求的用户id,
     */
    private Long uid;

    /**
     * 用于过滤使用，理论上已经踢出VIP用户，聊天机器人
     */
    private List<Long> uidList;

    /**
     * 指定查询数据的范围,1 like 2 dislike
     */
    private List<Integer> typeList;

    /**
     * 曝光的上限, 默认不超过1w条
     */
    private Integer limit;
}
