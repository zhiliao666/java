package com.ufoto.manager;

import com.ufoto.business.recommend.RecommendCacheUpdater;
import com.ufoto.utils.SpringContextUtil;
import lombok.extern.slf4j.Slf4j;
import org.springframework.boot.CommandLineRunner;
import org.springframework.core.annotation.Order;
import org.springframework.core.env.Environment;
import org.springframework.stereotype.Component;

import java.util.Arrays;

/**
 * <p>
 * Author     : Chan
 * CreateDate : 2019-08-09 11:56
 * Description:
 * </p>
 */
@Slf4j
@Order(Integer.MAX_VALUE - 80)
@Component
public class RecommendCacheUpdaterRunner implements CommandLineRunner {
    private final Environment env;

    public RecommendCacheUpdaterRunner(Environment env) {
        this.env = env;
    }

    @Override
    public void run(String... args) throws Exception {
        if (Arrays.asList(env.getActiveProfiles()).contains("test")) return;
        log.debug("CacheUpdater init start...");
        SpringContextUtil.getBean(RecommendCacheUpdater.class).updateCacheByAnnotation();
        log.debug("CacheUpdater init done...");
    }
}
