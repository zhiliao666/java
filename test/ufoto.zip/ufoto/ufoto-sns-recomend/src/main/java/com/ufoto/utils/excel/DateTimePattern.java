package com.ufoto.utils.excel;

public interface DateTimePattern {
    String DATE_TIME_PATTERN = "yyyy-MM-dd HH:mm:ss";//日期+时间格式
    String DATE_SIMPLE_TIME_PATTERN = "yyyy-MM-dd HH:mm";//日期+时间格式
    String DATE_PATTERN = "yyyy-MM-dd";//日期格式
    String TIME_PATTERN = "HH:mm:ss";//时间格式
}
