package com.ufoto.business.recommend.shuffle;

import com.ufoto.annotation.RecommendMetadata;
import com.ufoto.business.recommend.shuffle.base.BaseShuffleStrategy;
import com.ufoto.business.recommend.shuffle.cutter.GenderCutter;
import com.ufoto.business.recommend.shuffle.dealer.RandomBySizeWeightDealer;
import com.ufoto.utils.redis.RedisService;


@RecommendMetadata(
        metadataType = RecommendMetadata.MetadataType.SHUFFLE,
        available = true,
        name = "性别打散器",
        description = "按照性别分区(GenderCutter),然后根据列表长度决定权重,长度越长,越有可能排在前面(RandomBySizeWeightDealer)",
        branch = RecommendMetadata.Branch.NORMAL
)
public class GenderShuffleStrategy extends BaseShuffleStrategy {

    public GenderShuffleStrategy(RedisService redisService) {
        this.cutter = new GenderCutter(redisService);
        this.dealer = new RandomBySizeWeightDealer();
    }

}
