package com.ufoto.business.recommend.card;

import com.google.common.collect.Sets;
import com.ufoto.annotation.RecommendMetadata;
import com.ufoto.constants.ESupportLanguage;
import com.ufoto.dto.CardParam;
import com.ufoto.dto.RecommendAdvanceRequest;
import com.ufoto.entity.UfotoAppCard;
import com.ufoto.service.UfotoAppCardService;
import com.ufoto.utils.CommonUtil;
import org.apache.commons.lang3.StringUtils;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.core.env.Environment;
import org.springframework.stereotype.Component;
import org.springframework.util.CollectionUtils;

import java.util.Arrays;
import java.util.List;
import java.util.Set;
import java.util.stream.Collectors;

/**
 * <p>
 * Author     : Chan
 * CreateDate : 2018/9/15 14:48
 * Description: 初级卡片召回策略()
 * </p>
 */
@RecommendMetadata(
        metadataType = RecommendMetadata.MetadataType.CARD_RECALL,
        available = true,
        name = "Snap卡片召回策略",
        description = "随机取出一些卡片，保证的当前取出的是之前没看过的，除非全部看过.取出范围通过白名单设置"
)
@Component
public class SnapNewUserCardRecallStrategy {
    private final UfotoAppCardService ufotoAppCardService;
    private final Environment env;

    @Autowired
    public SnapNewUserCardRecallStrategy(UfotoAppCardService ufotoAppCardService,
                                         Environment env) {
        this.ufotoAppCardService = ufotoAppCardService;
        this.env = env;
    }

    public Set<String> recall(Long offset, Integer minSize, RecommendAdvanceRequest recallRequest) {
        CardParam cardParam = new CardParam();
        cardParam.setUid(recallRequest.getUid());
        final String language = recallRequest.getLanguage();
        if (StringUtils.isBlank(language)) {
            cardParam.setLang(ESupportLanguage.EN.getLang());
        } else {
            final Set<String> langs = Arrays.stream(ESupportLanguage.values()).map(ESupportLanguage::getLang).collect(Collectors.toSet());
            boolean in = langs.contains(language.toLowerCase());
            cardParam.setLang(in ? language.toLowerCase() : ESupportLanguage.EN.getLang());
        }
        //考虑到之后这个需求的变化不会太大，其他卡片的使用场景和出现条件会越来越多，对这边卡片使用白名单的方式来做筛选限制
        Set<Integer> cardTypeWhiteList = env.getProperty("recommend.app.card.snapNewUser.whiteList", Set.class, Sets.newHashSet("6"));
        cardParam.setTypeWhiteList(cardTypeWhiteList);
        List<UfotoAppCard> ufotoAppCards = ufotoAppCardService.queryRandomCards(cardParam);
        if (CollectionUtils.isEmpty(ufotoAppCards)) {
            return Sets.newHashSet();
        }
        return ufotoAppCards.stream().map(CommonUtil::getAppCardId).collect(Collectors.toSet());
    }

}
