package com.ufoto.business.recommend.sort.randomMatch;

import com.google.common.collect.Maps;
import com.ufoto.entity.UfotoUserChatActivity;
import com.ufoto.utils.DateUtil;
import org.springframework.stereotype.Component;
import org.springframework.util.CollectionUtils;

import java.util.List;
import java.util.Map;

/**
 * <p>
 *
 * </p>
 *
 * @author created by chenzhou at 2018-08-02 17:48
 */
@Component
public class JoinDateSortStrategy extends BaseNormalRandomMatchSortStrategy {


    @Override
    public Map<Long, Double> getScore(List<UfotoUserChatActivity> activities, UfotoUserChatActivity currentUser) {
        Map<Long, Double> uidScoreMap = Maps.newHashMap();
        if (!CollectionUtils.isEmpty(activities)) {
            Integer timestamp = DateUtil.getCurrentSecondIntValue();
            for (UfotoUserChatActivity activity : activities) {
                uidScoreMap.put(activity.getUId(), (timestamp - activity.getCreateTime()) * 0.01);
            }
        }
        return uidScoreMap;
    }
}
