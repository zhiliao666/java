package com.ufoto.business.common;

import com.ufoto.utils.ApiResult;
import org.springframework.cloud.openfeign.FeignClient;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.ResponseBody;

import java.util.List;
import java.util.Map;

/**
 * 获取公共服务提供的信息
 *
 * @author luyz
 */
@FeignClient(name = "ufoto-common-service", fallbackFactory = ApiCommonInfoBusinessFallbackFactory.class)
public interface ApiCommonInfoBusiness {

    int SWEET_CHAT_APP_ID = 6;

    /**
     * 根据ip获取区域信息
     *
     * @param ip          用户IP，不知道是否支持V6
     * @param countryCode 国家编号，如果传了这个参数，则IP不起作用
     * @param appId       AppID，SweetChat 是 6
     * @return
     */
    @RequestMapping(value = "/country/getAreaIdByIp", method = RequestMethod.GET)
    @ResponseBody
    ApiResult<List<Integer>> getAreaIdByIp(@RequestParam(value = "ip") String ip,
                                           @RequestParam(value = "countryCode") String countryCode,
                                           @RequestParam(value = "appId") Integer appId);

    @RequestMapping(path = "/country/areaMap")
    ApiResult<Map<String, Integer>> areaCountryMap(@RequestParam("appId") Integer appId);
}
