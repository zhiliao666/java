package com.ufoto.utils.redis;

import org.springframework.data.redis.connection.RedisStringCommands;
import org.springframework.data.redis.core.RedisCallback;
import org.springframework.data.redis.core.RedisTemplate;
import org.springframework.data.redis.core.types.Expiration;

public class RedisLock {

    public static boolean tryGetDistributedLock(RedisService redisService, String lockKey, String requestId, long expireTime) {
        final RedisTemplate<String, String> redisTemplate = redisService.getRedisTemplate();
        return (boolean) redisTemplate.execute((RedisCallback) connection -> connection.set(lockKey.getBytes(), requestId.getBytes(),
                Expiration.seconds(expireTime), RedisStringCommands.SetOption.SET_IF_ABSENT));
    }

    //slave优先,执lua有问题
    public static boolean releaseDistributedLock(RedisService redisService, String lockKey, String requestId) {
//        final RedisTemplate<String, String> redisTemplate = redisService.getRedisTemplate();
//        String script = "if redis.call('get', KEYS[1]) == ARGV[1] then return redis.call('del', KEYS[1]) else return 0 end";
//        final long execute = (long) redisTemplate.execute(new DefaultRedisScript(script, Long.class),
//                redisTemplate.getStringSerializer(), redisTemplate.getValueSerializer(),
//                Collections.singletonList(lockKey), new Object[]{requestId});
//        return execute == 1;
        long result = redisService.del(lockKey);
        return result == 1;
    }
}
