package com.ufoto.business.usercenter.dto;

import lombok.Data;

import java.util.List;

/**
 * @author luozq
 * @date 2019/3/13/013
 */
@Data
public class UserAdditionalInfoDo {

    /**
     * 教育程度信息列表
     */
    private List<UfotoUserEducationDo> educations;
    /**
     * 工作信息列表
     */
    private List<UfotoUserWorkDo> works;

    private List<UserLikeTagDo> likes;

    public UserAdditionalInfoDo() {

    }

    public UserAdditionalInfoDo(List<UfotoUserEducationDo> educations,
                                List<UfotoUserWorkDo> works,
                                List<UserLikeTagDo> likes) {
        this.educations = educations;
        this.works = works;
        this.likes = likes;
    }

}
