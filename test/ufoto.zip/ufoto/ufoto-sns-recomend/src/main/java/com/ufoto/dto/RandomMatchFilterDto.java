package com.ufoto.dto;

import lombok.Data;

import java.util.Set;

/**
 * Created by echo on 4/12/19.
 */
@Data
public class RandomMatchFilterDto {

    Long uid;
    Set<String> targetUids;
}
