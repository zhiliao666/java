package com.ufoto.utils;

import com.fasterxml.jackson.core.type.TypeReference;
import com.fasterxml.jackson.databind.ObjectMapper;
import com.google.common.base.Joiner;
import com.google.common.collect.Lists;
import com.google.common.collect.Maps;
import com.google.common.collect.Sets;
import com.ufoto.dto.RecommendAdvanceRequest;
import com.ufoto.entity.UfotoAppCard;
import lombok.extern.slf4j.Slf4j;
import org.apache.commons.lang.math.RandomUtils;
import org.apache.commons.lang3.StringUtils;
import org.springframework.aop.support.AopUtils;

import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.Set;

/**
 * <p>
 * <p>
 * </p>
 *
 * @author created by chenzhou at 2018-05-24 10:57
 */
@Slf4j
public class CommonUtil {
    @SuppressWarnings("unchecked")
    public static Set<String> obj2Set(Object obj) {
        if (obj == null) {
            return Sets.newHashSet();
        }

        if (Set.class.isAssignableFrom(obj.getClass())) {
            return (Set<String>) obj;
        }
        throw new RuntimeException("目标Obj不是Set类型，转换错误");
    }


    @SuppressWarnings("unchecked")
    public static List<String> obj2List(Object obj) {
        if (obj == null) {
            return Lists.newLinkedList();
        }

        if (List.class.isAssignableFrom(obj.getClass())) {
            return (List<String>) obj;
        }
        throw new RuntimeException("目标Obj不是List类型，转换错误");
    }

    @SuppressWarnings("unchecked")
    public static List<Integer> obj2ListInt(Object obj) {
        if (obj == null) {
            return Lists.newLinkedList();
        }

        if (List.class.isAssignableFrom(obj.getClass())) {
            return (List<Integer>) obj;
        }
        throw new RuntimeException("目标Obj不是List类型，转换错误");
    }

    public static List<Double> obj2ListDouble(Object obj) {
        if (obj == null) {
            return Lists.newLinkedList();
        }

        if (List.class.isAssignableFrom(obj.getClass())) {
            return (List<Double>) obj;
        }
        throw new RuntimeException("目标Obj不是List类型，转换错误");
    }


    public static Map<String, String> obj2Map(Object obj) {
        if (obj == null) {
            return Maps.newHashMap();
        }
        if (Map.class.isAssignableFrom(obj.getClass())) {
            return (Map<String, String>) obj;
        }
        throw new RuntimeException("目标Obj不是Map类型，转换错误");
    }

    public static Map<String, Integer> obj2MapInteger(Object obj) {
        if (obj == null) {
            return Maps.newHashMap();
        }
        if (Map.class.isAssignableFrom(obj.getClass())) {
            return (Map<String, Integer>) obj;
        }
        throw new RuntimeException("目标Obj不是Map类型，转换错误");
    }

    public static Map<Integer, Set<String>> obj2MapSet(Object obj) {
        if (obj == null) {
            return Maps.newHashMap();
        }
        if (Map.class.isAssignableFrom(obj.getClass())) {
            return (Map<Integer, Set<String>>) obj;
        }
        throw new RuntimeException("目标Obj不是Map类型，转换错误");
    }

    @SuppressWarnings("unchecked")
    public static Boolean obj2Boolean(Object obj) {
        if (obj == null) {
            return false;
        }

        if (Boolean.class.isAssignableFrom(obj.getClass())) {
            return (Boolean) obj;
        }
        throw new RuntimeException("目标Obj不是Boolean类型，转换错误");
    }

    public static boolean obj2bool(Object obj) {
        if (obj == null) {
            return false;
        }

        if (Boolean.class.isAssignableFrom(obj.getClass())) {
            return (Boolean) obj;
        }
        throw new RuntimeException("目标Obj不是Boolean类型，转换错误");
    }

    public static boolean isInteger(String s) {
        try {
            Integer.parseInt(s);
        } catch (NumberFormatException e) {
            return false;
        } catch (NullPointerException e) {
            return false;
        }
        // only got here if we didn't return false
        return true;
    }

    /**
     * String 转换成 Integer，格式不对返回null
     *
     * @return 可能为null
     */
    public static Integer safeString2Integer(String string) {
        try {
            return Integer.parseInt(string);
        } catch (NumberFormatException e) {
            return null;
        }
    }

    /**
     * String 转换成 Long，格式不对返回null
     *
     * @return 可能为null
     */
    public static Long safeString2Long(String string) {
        try {
            return Long.parseLong(string);
        } catch (NumberFormatException e) {
            return null;
        }
    }

    public static boolean isLong(String s) {
        try {
            Long.parseLong(s);
        } catch (NumberFormatException e) {
            return false;
        } catch (NullPointerException e) {
            return false;
        }
        // only got here if we didn't return false
        return true;
    }

    public static Integer null2Int(Object obj) {
        return obj != null ? ((Number) obj).intValue() : 0;
    }

    public static int string2Int(String str) {
        try {
            return StringUtils.isBlank(str) ? 0 : Integer.parseInt(str);
        } catch (NumberFormatException e) {
            return 0;
        }
    }

    public static Long null2Long(Object obj) {
        return obj != null ? ((Number) obj).longValue() : 0;
    }

    public static Double null2Double(Object obj) {
        return obj != null ? ((Number) obj).doubleValue() : 0;
    }

    /**
     * 为了减少生成对象的开销，这边使用的随机方法不一定足够随机
     *
     * @param inputSet
     * @param n
     * @return
     */
    public static Set<String> getRandomNItemFromSet(Set<String> inputSet, int n) {
        if (inputSet == null || n <= 0) return Sets.newHashSet();
        if (inputSet.size() <= n) return Sets.newHashSet(inputSet);

        Set<String> result = Sets.newHashSet();
        int offset = RandomUtils.nextInt(inputSet.size() - n);

        int i = 0;
        for (String item : inputSet) {
            if (i >= offset) result.add(item);
            i += 1;
            if (i - offset >= n) break;
        }
        return result;
    }

    public static Map<String, Object> pojo2map(Object object) {
        ObjectMapper mapper = new ObjectMapper();
        return mapper.convertValue(object, new TypeReference<Map<String, Object>>() {
        });
    }

    public static Map<String, String> pojo2mapString(Object object) {
        ObjectMapper mapper = new ObjectMapper();
        return mapper.convertValue(object, new TypeReference<Map<String, String>>() {
        });
    }

    public static String getAppCardId(UfotoAppCard appCard) {
        return Joiner.on("_").join(appCard.getId(), appCard.getType(), appCard.getTypeId());
    }

    public static boolean isAppCardId(String id) {
        return id.matches("\\d+_\\d+_\\d+");
    }

    public static boolean isNotAppCardId(String id) {
        return !id.matches("\\d+_\\d+_\\d+");
    }

    public static Map<String, Double> getScoreMapOfLike(List<String> recallUids, List<Object> objects) {
        Map<String, Double> scoreMap = new HashMap<>();
        final int size = recallUids.size();
        for (int i = 0; i < size; i++) {
            final boolean isDisLikedMe = obj2bool(objects.get(i));
            final String recallUid = recallUids.get(i);
            scoreMap.put(recallUid, isDisLikedMe ? 1d : 0d);
        }
        return scoreMap;
    }

    public static String getSimpleNameWithoutEnhancer(Object obj) {
        return AopUtils.getTargetClass(obj).getSimpleName();
    }

    public static Long obj2Long(Object obj) {
        return Long.parseLong(obj.toString());
    }

    /**
     * 判断当前用户的年龄是否在范围内
     *
     * @param age      出生日期时间戳 毫秒
     * @param startAge 开始年龄
     * @param endAge   结束年龄
     * @return true 在范围内   false 不在范围内
     */
    public static boolean judgeAge(Integer age, Integer startAge, Integer endAge) {
        if (age == null) {
            //没有查询到用户的出生日期，默认不再范围内--默认55岁
            age = 55;
        }
        return (startAge == null || startAge <= age) && (endAge == null || endAge >= age);

    }

    public static Integer calcLimit(int limit) {
        int currentHour = Integer.parseInt(DateUtil.getCurrentDateStr("HH"));
        limit *= (currentHour / 12) + 1; //如果过了12点（北京时间），则曝光上限翻倍
        return limit;
    }

    public static void compatibleCP(RecommendAdvanceRequest recommendAdvanceRequest) {
        try {
            final String cp = recommendAdvanceRequest.getCp();
            log.debug("CP: {}", cp);
            if (StringUtils.isNotBlank(cp) && cp.contains(",")) {
                recommendAdvanceRequest.setCp(cp.split(",")[0].trim());
            }
        } catch (Exception e) {
            // ignore exception for cp
        }
    }
}
