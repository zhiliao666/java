package com.ufoto.constants;

/**
 * <p>
 * Author     : Chan
 * CreateDate : 2019-09-17 11:28
 * Description:
 * </p>
 */
public enum EOldNewKey {
    OLD,
    NEW
}
