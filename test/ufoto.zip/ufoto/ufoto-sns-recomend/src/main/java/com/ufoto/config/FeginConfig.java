package com.ufoto.config;

import feign.Request;
import feign.Retryer;
import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;
import org.springframework.context.annotation.Profile;

@Configuration
@Profile("!test")
public class FeginConfig {

    @Bean
    Request.Options feignOptions() {
        return new Request.Options(5000, 10000);
    }

    @Bean
    Retryer feignRetryer() {
        return new Retryer.Default(1000, 100, 3);
    }
}
