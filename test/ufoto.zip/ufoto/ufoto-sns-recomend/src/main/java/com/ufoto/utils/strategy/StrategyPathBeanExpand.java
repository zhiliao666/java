package com.ufoto.utils.strategy;

import com.ufoto.dto.StrategyChainPathDto;
import lombok.Data;
import lombok.EqualsAndHashCode;

/**
 * <p>
 *
 * </p>
 *
 * @author created by chenzhou at 2018-06-22 15:59
 */
@EqualsAndHashCode(callSuper = true)
@Data
public class StrategyPathBeanExpand extends StrategyChainPathDto {
    private Integer strategyId;//特指recall strategy id
}
