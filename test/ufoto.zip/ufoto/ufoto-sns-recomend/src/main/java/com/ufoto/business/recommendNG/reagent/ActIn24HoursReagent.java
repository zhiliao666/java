package com.ufoto.business.recommendNG.reagent;

import com.github.benmanes.caffeine.cache.LoadingCache;
import com.google.common.collect.Sets;
import com.ufoto.annotation.RecommendMetadata;
import com.ufoto.business.recommendNG.Reagent;
import com.ufoto.dto.RecommendAdvanceRequest;
import com.ufoto.utils.CommonUtil;
import com.ufoto.utils.redis.RedisKeyConstant;
import com.ufoto.utils.redis.RedisService;
import org.springframework.stereotype.Component;

import java.util.Set;

/**
 * 这里维护24小时内所有有行为的用户
 * <p>
 * Created by echo on 10/18/18.
 */
@RecommendMetadata(
        metadataType = RecommendMetadata.MetadataType.REAGENT,
        available = true,
        updateCache = true,
        name = "24小时活跃用户的保留集",
        description = "与24小时活跃用户的全集做交集",
        branch = {RecommendMetadata.Branch.NORMAL, RecommendMetadata.Branch.DEFAULT}
)
@Component
public class ActIn24HoursReagent implements Reagent {

    private final RedisService redisService;
    private final LoadingCache<Class<?>, Object> recommendLoadingCache;

    public ActIn24HoursReagent(RedisService redisService,
                               LoadingCache<Class<?>, Object> recommendLoadingCache) {
        this.redisService = redisService;
        this.recommendLoadingCache = recommendLoadingCache;
    }

    @Override
    public Set<String> makeReagents(RecommendAdvanceRequest request, Set<String> uidCollection) {
        uidCollection.retainAll(CommonUtil.obj2Set(recommendLoadingCache.get(this.getClass())));
        return uidCollection;
    }

    @Override
    public Set<String> randomReagents(RecommendAdvanceRequest request, Integer size) {
        return CommonUtil.getRandomNItemFromSet(CommonUtil.obj2Set(recommendLoadingCache.get(this.getClass())), size);
    }

    public Set<String> updateCache() {
        Set<String> result = redisService.sMember(RedisKeyConstant.REDIS_ACT_IN_24H_USER_SET_KEY, true);
        if (result == null) result = Sets.newHashSet();
        return result;
    }
}
