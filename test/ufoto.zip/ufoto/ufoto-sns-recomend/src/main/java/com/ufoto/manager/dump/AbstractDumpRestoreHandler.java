package com.ufoto.manager.dump;

import com.ufoto.constants.EOldNewKey;
import com.ufoto.entity.UfotoRecommendRedisDump;
import com.ufoto.utils.redis.RedisService;
import com.ufoto.utils.redis.RedisServiceObjService;
import lombok.extern.slf4j.Slf4j;
import org.springframework.core.env.Environment;
import org.springframework.util.CollectionUtils;

import java.util.Base64;
import java.util.Map;
import java.util.Set;

/**
 * <p>
 * Author     : Chan
 * CreateDate : 2019-09-17 11:18
 * Description:
 * </p>
 */
@Slf4j
public abstract class AbstractDumpRestoreHandler {
    private final RedisService redisService;
    private final Environment env;
    private final RedisServiceObjService redisServiceObjService;
    //表示是否是当前处理的key  如果是之前处理过了 那么为false
    private final boolean current;

    public AbstractDumpRestoreHandler(RedisService redisService, Environment env,
                                      RedisServiceObjService redisServiceObjService,
                                      boolean current) {
        this.redisService = redisService;
        this.env = env;
        this.redisServiceObjService = redisServiceObjService;
        this.current = current;
    }

    public abstract void doRestoreDiff(Long uid, Map<String, UfotoRecommendRedisDump> dumpMap);

    void handleDumpKey(Long uid, Map<String, UfotoRecommendRedisDump> dumpMap, Map<EOldNewKey, String> oldNewKey) {
        /*
            如果存在新key，则以新key为准，元素累加
            如果不存在新key，则以老key为准，元素累加，再将全部元素添加到新key中
            删除数据库中存在的新key数据
            同步执行过restore的用户及对比后不一致的用户数据
         */
        final Boolean transformSwitchOld = env.getProperty("redis.value.transform.switch.old", Boolean.class, true);
        if (!CollectionUtils.isEmpty(dumpMap)) {
            final UfotoRecommendRedisDump newDump = dumpMap.get(oldNewKey.get(EOldNewKey.NEW) + uid);
            final UfotoRecommendRedisDump oldDump = dumpMap.get(oldNewKey.get(EOldNewKey.OLD) + uid);
            log.warn("restoreDumpMap uid:{}, new:{}, old:{}",
                    uid, newDump == null ? null : newDump.getId(), oldDump == null ? null : oldDump.getId());
            if (newDump != null) {
                handleNew(newDump);
            }
            handleOld(transformSwitchOld, oldDump, oldNewKey);
            //如果老key关闭,删除老key
            if (!current || !transformSwitchOld) {
                redisService.del(oldNewKey.get(EOldNewKey.OLD) + uid);
            }
        }
    }

    private void handleOld(Boolean transformSwitchOld, UfotoRecommendRedisDump oldDump, Map<EOldNewKey, String> oldNewKey) {
        if (oldDump != null) {
            //取出已存在的数据
            Set<String> oldDislikedSet = redisService.sMember(oldDump.getKey(), true);
            //使用dump数据覆盖已存在的数据
            redisService.restore(oldDump.getKey(), decode(oldDump.getDump()), true);
            //取出全部数据
            final Set<String> allMembers = redisService.sMember(oldDump.getKey(), true);
            //主从同步数据延迟
            if (CollectionUtils.isEmpty(allMembers)) {
                try {
                    log.warn("restoreReadOldMembers is empty {}", oldDump.getUid());
                    Thread.sleep(10);
                    allMembers.addAll(redisService.sMember(oldDump.getKey(), true));
                } catch (InterruptedException e) {
                    e.printStackTrace();
                }
            }
            if (CollectionUtils.isEmpty(allMembers)) {
                allMembers.addAll(redisService.sMember(oldDump.getKey(), true));
            }
            if (!CollectionUtils.isEmpty(oldDislikedSet)) {
                allMembers.addAll(oldDislikedSet);
                //如果老的key的开关打开 写入之前已存在数据
                if (current && transformSwitchOld) {
                    redisService.sadd(oldDump.getKey(), oldDislikedSet.toArray(new String[]{}));
                }
            }
            //全部数据写入新的key
            redisServiceObjService.sadd(oldNewKey.get(EOldNewKey.NEW) + oldDump.getUid(),
                    allMembers.stream().map(Long::valueOf).toArray(Object[]::new));
        }
    }

    private void handleNew(UfotoRecommendRedisDump newDump) {
        //已存在的数据
        Set<Long> newDislikedSet = redisServiceObjService.smembers(newDump.getKey(), true);
        //使用dump数据覆盖已存在的数据
        redisService.restore(newDump.getKey(), decode(newDump.getDump()), true);
        if (!CollectionUtils.isEmpty(newDislikedSet)) {
            //全部添加到新key中
            redisServiceObjService.sadd(newDump.getKey(), newDislikedSet.toArray(new Object[]{}));
        }
    }

    private byte[] decode(String data) {
        return Base64.getDecoder().decode(data);
    }
}
