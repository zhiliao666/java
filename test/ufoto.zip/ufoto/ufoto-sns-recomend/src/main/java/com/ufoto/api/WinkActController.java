package com.ufoto.api;

import com.google.common.collect.Lists;
import com.ufoto.config.disruptor.event.AsyncEvent;
import com.ufoto.constants.ESnsFromType;
import com.ufoto.dto.RecommendAdvanceRequest;
import com.ufoto.dto.sns.WinkRecommendDto;
import com.ufoto.lmax.LMaxDisruptor;
import com.ufoto.manager.CommonServiceManager;
import com.ufoto.plugins.interceptor.LogInterceptor;
import com.ufoto.service.RecommendService;
import com.ufoto.service.UfotoAppUserService;
import com.ufoto.service.UfotoRecommendRedisDumpService;
import com.ufoto.utils.ApiResult;
import com.ufoto.utils.CommonUtil;
import com.ufoto.utils.json.JSONUtil;
import com.ufoto.utils.redis.RedisService;
import com.ufoto.utils.threadlocal.ThreadLocalManager;

import lombok.RequiredArgsConstructor;
import lombok.extern.slf4j.Slf4j;
import org.slf4j.MDC;
import org.springframework.core.env.Environment;
import org.springframework.util.CollectionUtils;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RestController;

import java.util.List;
import java.util.Objects;

/**
 * 
 *
 * @author zhangqh  
 * @date Apr 11, 2020 6:07:53 PM  
 * @version 1.0
 */
@Slf4j
@RestController
@RequestMapping("/{v}/wink")
@RequiredArgsConstructor
public class WinkActController {
    private final RedisService redisService;
    private final RecommendService recommendService;
    private final UfotoAppUserService ufotoAppUserService;
    private final UfotoRecommendRedisDumpService ufotoRecommendRedisDumpService;
    private final Environment environment;
    private final CommonServiceManager commonServiceManager;
    private final LMaxDisruptor<AsyncEvent> recommendCalculateAsyncEventLMaxDisruptor;
    
    @RequestMapping(value = "/{uid}/recommend", method = RequestMethod.POST)
    public ApiResult<WinkRecommendDto> recommend(@PathVariable Long uid,
                                                @RequestBody RecommendAdvanceRequest recommendAdvanceRequest) {
    	
    	log.debug("wink-recall  uid：{} , 参数：{}",uid,JSONUtil.toJSON(recommendAdvanceRequest));
    	// 设置推荐使用来源，规则引擎会根据该值选择具体某一个规则
    	recommendAdvanceRequest.setFromType(ESnsFromType.WINK.getType());
    	recommendAdvanceRequest.setUid(uid);
        String countryCode = recommendAdvanceRequest.getCountryCode();
        Integer areaId = recommendAdvanceRequest.getAreaId();
        if(Objects.isNull(areaId)) {
        	areaId = commonServiceManager.getAreaId(countryCode);
        }
        recommendAdvanceRequest.setAreaId(areaId);
        CommonUtil.compatibleCP(recommendAdvanceRequest);
        
        // 设置需要的用户数
        Integer limit = recommendAdvanceRequest.getLimit();
        if (limit == null || limit < 1) {
            recommendAdvanceRequest.setLimit(2);;
        }
        
        if (recommendAdvanceRequest.getGender() == null ) {
            recommendAdvanceRequest.setGender(0);
        }
        // limit不能超过10
        limit = limit >10?10:limit;
        // 返回结果
        WinkRecommendDto recommendMap = new WinkRecommendDto();
        
        //召回-过滤-排序最终得到的uid list
        List<String> recommendUidList = recommendService.recommendWinkUsers(recommendAdvanceRequest);
        
        boolean needMore;
        int loopCount = 0;
        do {
        	loopCount++;
        	needMore = recommendUidList.size() < limit;
        	if(needMore) {
        		log.warn("WinkRecommendNeedMore loopCount:{},traceId:{},request:{},recommendUidList:{}",loopCount,
                        MDC.get(LogInterceptor.SESSION_KEY),
                        JSONUtil.toJSON(recommendAdvanceRequest),recommendUidList);
        		recommendAdvanceRequest.setLastRecallTime(ThreadLocalManager.getESACTIVETIMEThreadLocal());
        		recommendUidList = recommendService.recommendWinkUsers(recommendAdvanceRequest);
        	}
        	if (loopCount >= 3) { // 超过3次还召回不到人则退出循环
                break;
            }
			
		} while (needMore);
        
        if (CollectionUtils.isEmpty(recommendUidList)) {
            recommendMap.setUids(Lists.newArrayList());
            return new ApiResult<WinkRecommendDto>().setResult(recommendMap);
        }
        
        recommendMap.setUids(recommendUidList);
        
        final String recommendResultKey = recommendService.getWinkRecommendResultKey(recommendAdvanceRequest);
        redisService.ltrim(recommendResultKey, limit, -1);
        return new ApiResult<WinkRecommendDto>().setResult(recommendMap);
    }
}
