/**
 * <p>
 * Author     : Chan
 * CreateDate : 2019-07-25 12:49
 * Description:
 * </p>
 */
package com.ufoto.business.recommend.sort.randomMatch;

/*
 * 临时匹配用到的排序策略 不参与正常的排序流程
 */
