package com.ufoto.utils.excel;

import org.apache.poi.openxml4j.exceptions.InvalidFormatException;
import org.apache.poi.ss.usermodel.*;
import org.apache.poi.xssf.streaming.SXSSFWorkbook;

import java.io.File;
import java.io.FileOutputStream;
import java.io.IOException;
import java.util.ArrayList;
import java.util.List;

/**
 * 最多能导出104w条记录
 */
public class WriteExcelUtil {
    private static final int MAX_FLUSH_COUNT = 3000;//内存中最多保持多少列
    private Workbook workbook;
    private Sheet sheet;
    private CellStyle dataStyle;

    public static WriteExcelUtil newInstance(String[] title) {
        if (title == null || title.length == 0) {
            throw new RuntimeException("title is empty.");
        }
        WriteExcelUtil e = new WriteExcelUtil();
        Workbook wb = new SXSSFWorkbook(MAX_FLUSH_COUNT / title.length);//在内存中最多保持记录数，多余的会写入临时文件中disk
        Sheet sheet = wb.createSheet();
        CellStyle dataStyle = createStyle(wb, createDataFont(wb));
        // 设置excel头
        CellStyle titleStyle = createStyle(wb, createTitleFont(wb));
        Row row = sheet.createRow(0);
        for (short i = 0; i < title.length; i++) {
            createCell(row, i, title[i], titleStyle);
        }
        e.setWorkbook(wb);
        e.setSheet(sheet);
        e.setDataStyle(dataStyle);
        return e;
    }

    /**
     * 创建单元格并设置样式,值
     *
     * @param row
     * @param column
     * @param value
     */
    private static void createCell(Row row, int column, String value, CellStyle cellStyle) {
        Cell cell = row.createCell(column);
        cell.setCellValue(value);
        cell.setCellStyle(cellStyle);
    }

    private static CellStyle createStyle(Workbook workbook, Font font) {
        CellStyle cellStyle = workbook.createCellStyle();
        cellStyle.setAlignment(CellStyle.ALIGN_CENTER);
        cellStyle.setVerticalAlignment(CellStyle.VERTICAL_BOTTOM);
        cellStyle.setFont(font);
        return cellStyle;
    }

    /**
     * 设置内容字体
     *
     * @param wb
     * @return
     */
    private static Font createDataFont(Workbook wb) {
        Font font = wb.createFont();
        font.setFontName("宋体");
        font.setBoldweight(Font.BOLDWEIGHT_NORMAL);
        font.setItalic(false);
        font.setFontHeight((short) 200);
        return font;
    }

    /**
     * 设置Title字体
     *
     * @param wb
     * @return
     */
    private static Font createTitleFont(Workbook wb) {
        Font font = wb.createFont();
        font.setFontName("宋体");
        font.setBoldweight(Font.BOLDWEIGHT_BOLD);
        font.setItalic(false);
        font.setFontHeight((short) 200);
        return font;
    }

    public static void main(String[] args) throws IOException,
            InvalidFormatException {
        File file = new File("d:/dd.xlsx");
        if (!file.exists()) {
            final boolean newFile = file.createNewFile();
            if (!newFile) {
                throw new RuntimeException("create file not successfully");
            }
        }
        //写excel
        List<Object[]> datas = new ArrayList<Object[]>();
        for (int i = 0; i < 2; i++) {
            datas.add(new String[]{"341221198508209074", "2", "3", "4", "5"});
        }
        WriteExcelUtil eu = WriteExcelUtil.newInstance(new String[]{"a", "b", "c", "d", "e"});
        for (int i = 0; i < 100; i++) {
            eu.writeExcel(datas);
        }
        eu.getWorkbook().write(new FileOutputStream(file));
    }

    @SuppressWarnings("unused")
    private void ExcelUtil() {
    }

    /**
     * 将数据列表追加到excel中
     *
     * @param data 数据
     */
    public WriteExcelUtil writeExcel(List<Object[]> data) {
        try {
            if (data != null) {
                int rowNum = sheet.getLastRowNum();
                for (int i = 0, le = data.size(); i < le; i++) {
                    Row row = sheet.createRow(rowNum + i + 1);
                    Object[] rowData = data.get(i);
                    for (int j = 0, len = rowData.length; j < len; j++) {
                        String value = rowData[j] != null ? rowData[j].toString() : "";
                        createCell(row, j, value, dataStyle);
                    }
                }
            }
            return this;
        } catch (Exception e) {
            e.printStackTrace();
            throw new RuntimeException(e);
        }
    }

    public Workbook getWorkbook() {
        return workbook;
    }

    public void setWorkbook(Workbook workbook) {
        this.workbook = workbook;
    }

    public void setSheet(Sheet sheet) {
        this.sheet = sheet;
    }

    public void setDataStyle(CellStyle dataStyle) {
        this.dataStyle = dataStyle;
    }
}
