package com.ufoto.dto.sns;

import org.springframework.web.multipart.MultipartFile;

/**
 * Created by echo on 12/26/17.
 */
public class SnsUserEditImgDto {

    private MultipartFile file_1;
    private MultipartFile file_2;
    private MultipartFile file_3;
    private MultipartFile file_4;
    private MultipartFile file_5;
    private MultipartFile file_6;
    private String del;

    public MultipartFile getFile_1() {
        return file_1;
    }

    public void setFile_1(MultipartFile file_1) {
        this.file_1 = file_1;
    }

    public MultipartFile getFile_2() {
        return file_2;
    }

    public void setFile_2(MultipartFile file_2) {
        this.file_2 = file_2;
    }

    public MultipartFile getFile_3() {
        return file_3;
    }

    public void setFile_3(MultipartFile file_3) {
        this.file_3 = file_3;
    }

    public MultipartFile getFile_4() {
        return file_4;
    }

    public void setFile_4(MultipartFile file_4) {
        this.file_4 = file_4;
    }

    public MultipartFile getFile_5() {
        return file_5;
    }

    public void setFile_5(MultipartFile file_5) {
        this.file_5 = file_5;
    }

    public MultipartFile getFile_6() {
        return file_6;
    }

    public void setFile_6(MultipartFile file_6) {
        this.file_6 = file_6;
    }

    public String getDel() {
        return del;
    }

    public void setDel(String del) {
        this.del = del;
    }
}
