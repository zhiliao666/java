package com.ufoto.business.recommendNG.recall;

import com.github.benmanes.caffeine.cache.LoadingCache;
import com.google.common.collect.Lists;
import com.google.common.collect.Sets;
import com.ufoto.annotation.RecommendMetadata;
import com.ufoto.business.recommendNG.Recall;
import com.ufoto.dto.RecommendAdvanceRequest;
import com.ufoto.manager.ElasticSearchManager;
import com.ufoto.utils.CommonUtil;
import com.ufoto.utils.redis.RedisKeyConstant;
import com.ufoto.utils.redis.RedisServiceObjService;
import lombok.RequiredArgsConstructor;
import org.springframework.core.env.Environment;
import org.springframework.stereotype.Component;
import org.springframework.util.CollectionUtils;

import java.util.*;
import java.util.stream.Collectors;

/**
 * <p>
 * Description:
 *
 * </p>
 *
 * @author Chan
 * @date 2020/2/15 11:28
 */
@RecommendMetadata(
        metadataType = RecommendMetadata.MetadataType.RECALL,
        available = true,
        updateCache = true,
        name = "高危用户召回策略",
        description = "适用高危用户,",
        branch = RecommendMetadata.Branch.High_Risk
)
@RequiredArgsConstructor
@Component
public class NGHighRiskRecall implements Recall {

    private final Environment env;
    private final LoadingCache<Class<?>, Object> recommendLoadingCache;
    private final RedisServiceObjService redisServiceObjService;
    private final ElasticSearchManager elasticSearchManager;

    @Override
    public Set<String> recall(Integer minSize, RecommendAdvanceRequest recallRequest) {
        return elasticSearchManager.queryHighRiskByCondition(recallRequest.getUid(), recallRequest);
    }

    @Override
    public boolean ifRecallOnlyOnce() {
        return true;
    }

    @Override
    public boolean ifNeedThreadLocalCache() {
        return true;
    }

    public Set<String> updateCache() {
        final Set<Long> members = redisServiceObjService.smembers(RedisKeyConstant.REDIS_HIGH_RISK_USER, true);
        if (CollectionUtils.isEmpty(members)) {
            return Sets.newHashSet();
        }
        return members.stream().map(String::valueOf).collect(Collectors.toSet());
    }
}
