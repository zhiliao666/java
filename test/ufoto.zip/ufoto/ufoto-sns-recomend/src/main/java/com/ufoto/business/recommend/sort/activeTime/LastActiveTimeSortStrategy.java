package com.ufoto.business.recommend.sort.activeTime;

import com.ufoto.annotation.RecommendMetadata;
import com.ufoto.business.recommend.bean.SortParamsBean;
import com.ufoto.business.recommend.sort.BaseNormalSortStrategy;
import com.ufoto.utils.DateUtil;
import com.ufoto.utils.KeyTransitionUtil;
import com.ufoto.utils.redis.RedisService;
import lombok.extern.slf4j.Slf4j;
import org.springframework.stereotype.Component;

import java.util.HashMap;
import java.util.List;
import java.util.Map;

/**
 * Created by echo on 4/8/18.
 */
@RecommendMetadata(
        metadataType = RecommendMetadata.MetadataType.SORT,
        available = true,
        name = "活跃时间排序策略",
        description = "根据用户的活跃时间和当前时间的差值的绝对值作为基础分数",
        branch = RecommendMetadata.Branch.NORMAL
)
@Slf4j
@Component
public class LastActiveTimeSortStrategy extends BaseNormalSortStrategy {

    private final RedisService redisService;

    public LastActiveTimeSortStrategy(RedisService redisService) {
        this.redisService = redisService;
    }

    /**
     * 返回对应用户最近活跃时间和当前时间的差距，单位秒
     */
    @Override
    public Map<String, Double> getScore(List<String> recallUids, SortParamsBean sortParamsBean) {
        Integer currentTime = DateUtil.getCurrentSecondIntValue();
        final Map<String, String> actMap = KeyTransitionUtil.activityTimeList(redisService, recallUids);
        Map<String, Double> scoreMap = new HashMap<>();
        final int size = recallUids.size();
        for (int i = 0; i < size; i++) {
            final String recallUid = recallUids.get(i);
            String activityTime = actMap.get(recallUid);
            if (activityTime == null) {
                scoreMap.put(recallUid, 0d);
                continue;
            }
            try {
                Double activityTimeDouble = Double.valueOf(activityTime);
                scoreMap.put(recallUid, Math.abs(currentTime - activityTimeDouble));
            } catch (NumberFormatException e) {
                log.error("activity time format error:user_" + recallUids + ",userBirthTimeStr_" + activityTime);
            }
        }
        return scoreMap;
    }
}
