package com.ufoto.business.recommendNG.reagent;

import com.github.benmanes.caffeine.cache.LoadingCache;
import com.google.common.collect.Maps;
import com.google.common.collect.Sets;
import com.ufoto.annotation.RecommendMetadata;
import com.ufoto.business.recommendNG.Reagent;
import com.ufoto.dto.RecommendAdvanceRequest;
import com.ufoto.manager.CommonServiceManager;
import com.ufoto.utils.CommonUtil;
import com.ufoto.utils.redis.RedisKeyConstant;
import com.ufoto.utils.redis.RedisKeyUtil;
import com.ufoto.utils.redis.RedisService;
import org.springframework.stereotype.Component;

import java.util.List;
import java.util.Map;
import java.util.Set;

/**
 * 这里维护24小时内所有有行为的用户
 * <p>
 * Created by echo on 10/18/18.
 */
@RecommendMetadata(
        metadataType = RecommendMetadata.MetadataType.REAGENT,
        available = true,
        updateCache = true,
        name = "分大区的24小时活跃用户的保留集",
        description = "与分大区的24小时活跃用户的全集做交集",
        branch = RecommendMetadata.Branch.NORMAL
)
@Component
public class AreaActIn24HoursReagent implements Reagent {

    private final RedisService redisService;
    private final CommonServiceManager commonServiceManager;
    private final LoadingCache<Class<?>, Object> recommendLoadingCache;

    public AreaActIn24HoursReagent(RedisService redisService,
                                   CommonServiceManager commonServiceManager,
                                   LoadingCache<Class<?>, Object> recommendLoadingCache) {
        this.redisService = redisService;
        this.commonServiceManager = commonServiceManager;
        this.recommendLoadingCache = recommendLoadingCache;
    }

    @Override
    public Set<String> makeReagents(RecommendAdvanceRequest request, Set<String> uidCollection) {
        Set<String> reagentSet = getReagentSet(request);
        if (reagentSet == null) reagentSet = Sets.newHashSet();
        uidCollection.retainAll(reagentSet);
        return uidCollection;
    }

    @Override
    public Set<String> randomReagents(RecommendAdvanceRequest request, Integer size) {
        Set<String> reagentSet = getReagentSet(request);
        if (reagentSet == null) return Sets.newHashSet();
        return CommonUtil.getRandomNItemFromSet(reagentSet, size);
    }

    private Set<String> getReagentSet(RecommendAdvanceRequest request) {
        Integer areaId = request.getAreaId();
        if (areaId == null) areaId = -1;
        final Map<Integer, Set<String>> updateCacheField = CommonUtil.obj2MapSet(recommendLoadingCache.get(this.getClass()));
        return updateCacheField.get(areaId);
    }

    public Map<Integer, Set<String>> updateCache() {
        final Map<Integer, Set<String>> updateCacheField = Maps.newConcurrentMap();
        final List<Integer> areaList = commonServiceManager.getAreaList();
        for (Integer areaId : areaList) {
            Set<String> reagentSet = redisService.sMember(
                    RedisKeyUtil.obtainKey(RedisKeyConstant.REDIS_AREA_ACT_IN_24H_USER_SET_KEY, areaId), true);
            if (reagentSet == null) reagentSet = Sets.newHashSet();
            updateCacheField.put(areaId, reagentSet);
        }
        Set<String> allReagentSet = redisService.sMember(RedisKeyConstant.REDIS_ACT_IN_24H_USER_SET_KEY, true);
        if (allReagentSet == null) {
            updateCacheField.put(-1, Sets.newHashSet());
        } else {
            updateCacheField.values().forEach(allReagentSet::removeAll);
            updateCacheField.put(-1, allReagentSet);
        }
        return updateCacheField;
    }
}
