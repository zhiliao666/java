package com.ufoto.business.recommend.sort.gender;

import com.ufoto.annotation.RecommendMetadata;
import com.ufoto.business.recommend.bean.SortParamsBean;
import com.ufoto.business.recommend.sort.BaseNormalSortStrategy;
import com.ufoto.utils.CommonUtil;
import com.ufoto.utils.redis.RedisKeyConstant;
import com.ufoto.utils.redis.RedisKeyUtil;
import com.ufoto.utils.redis.RedisService;
import lombok.extern.slf4j.Slf4j;
import org.springframework.data.redis.core.RedisTemplate;
import org.springframework.data.redis.serializer.RedisSerializer;
import org.springframework.stereotype.Component;

import java.nio.charset.StandardCharsets;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

/**
 * <p>
 * Author     : Chan
 * CreateDate : 2018/9/14 10:06
 * Description: 按用户所传性别优先排序 性取向
 * </p>
 */
@RecommendMetadata(
        metadataType = RecommendMetadata.MetadataType.SORT,
        available = true,
        name = "性取向排序策略",
        description = "如果当前用户没有设置性别取向,每个召回集中的用户分数默认为0.此外,若召回集中的用户与当前用户的性取向相同,则分数为1,否则为-1",
        branch = RecommendMetadata.Branch.NORMAL
)
@Slf4j
@Component
public class SexualOrientationSortStrategy extends BaseNormalSortStrategy {

    private final RedisService redisService;

    public SexualOrientationSortStrategy(RedisService redisService) {
        this.redisService = redisService;
    }

    @Override
    public Map<String, Double> getScore(List<String> recallUids, SortParamsBean sortParamsBean) {
        final Long uid = sortParamsBean.getUid();
        String sexOrientationStr = redisService.hget(
                RedisKeyUtil.obtainKey(RedisKeyConstant.REDIS_USER_HASH_KEY, uid),
                RedisKeyConstant.REDIS_USER_HASH_GENDER);
        int sexOrientation = CommonUtil.isInteger(sexOrientationStr) ? Integer.parseInt(sexOrientationStr) : 0;

        Map<String, Double> scoreMap = new HashMap<>();
        if (sexOrientation > 2 || sexOrientation <= 0) {
            //如果没有设置性取向,召回集中的用户的分数都相同
            for (String currentUid : recallUids) {
                scoreMap.put(currentUid, 0d);
            }
            return scoreMap;
        }

        final RedisTemplate<String, String> redisTemplate = redisService.getRedisTemplate();
        final RedisSerializer<String> redisSerializer = redisTemplate.getStringSerializer();
        List<Object> showMeGenderList = redisService.execPipelineForRead(connection -> {
            for (String id : recallUids) {
                redisSerializer.deserialize(
                        connection.hGet(
                                RedisKeyUtil.obtainKey(RedisKeyConstant.REDIS_USER_HASH_KEY, id).getBytes(StandardCharsets.UTF_8),
                                RedisKeyConstant.REDIS_USER_HASH_SHOW_ME_GENDER.getBytes(StandardCharsets.UTF_8)
                        )
                );
            }
            return null;
        });
        final int size = recallUids.size();
        for (int i = 0; i < size; i++) {
            final Object showMeGender = showMeGenderList.get(i);
            final String recallUid = recallUids.get(i);
            if (showMeGender == null || sexOrientationStr.equals(showMeGender)) {
                scoreMap.put(recallUid, 1d);
            } else {
                scoreMap.put(recallUid, -1d);
            }
        }
        return scoreMap;
    }

}
