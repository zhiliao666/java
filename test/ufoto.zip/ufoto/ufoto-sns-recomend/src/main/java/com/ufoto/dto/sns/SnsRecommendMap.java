package com.ufoto.dto.sns;

import lombok.Data;

import java.io.Serializable;
import java.util.List;

/**
 * <p>
 * Description:
 *
 * </p>
 *
 * @author Chan
 * @date 2019/12/26 09:48
 */
@Data
public class SnsRecommendMap implements Serializable {
    private List<SnsRecommendV2> list;
    private Long countdown;
}
