package com.ufoto.business.recommendNG.invoker;

import lombok.Builder;
import lombok.Data;

import java.io.Serializable;

/**
 * Created by echo on 10/18/18.
 */
@Data
@Builder
public class InvokerEnvConfig implements Serializable {

    private int maxRecallTime;//5
    private int recallSizeIncreaseRate;// 2
}
