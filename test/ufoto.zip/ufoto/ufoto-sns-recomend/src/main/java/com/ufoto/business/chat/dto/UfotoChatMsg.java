package com.ufoto.business.chat.dto;

import java.io.Serializable;


public class UfotoChatMsg implements Serializable {

    private static final long serialVersionUID = 1L;

    private Integer createTime;
    private String msg;
    private Long tuid;
    private Integer msgType;
    private Long fuid;
    private Integer isRead;// 0 未读 1 已读


    /**
     * @return the isRead
     */
    public Integer getIsRead() {
        return isRead;
    }

    /**
     * @param isRead the isRead to set
     */
    public void setIsRead(Integer isRead) {
        this.isRead = isRead;
    }

    /**
     * @return the createTime
     */
    public Integer getCreateTime() {
        return createTime;
    }

    /**
     * @param createTime the createTime to set
     */
    public void setCreateTime(Integer createTime) {
        this.createTime = createTime;
    }

    /**
     * @return the msg
     */
    public String getMsg() {
        return msg;
    }

    /**
     * @param msg the msg to set
     */
    public void setMsg(String msg) {
        this.msg = msg;
    }

    /**
     * @return the tUId
     */
    public Long gettuid() {
        return tuid;
    }

    /**
     * @param tUId the tUId to set
     */
    public void settuid(Long tuid) {
        this.tuid = tuid;
    }

    /**
     * @return the msgType
     */
    public Integer getMsgType() {
        return msgType;
    }

    /**
     * @param msgType the msgType to set
     */
    public void setMsgType(Integer msgType) {
        this.msgType = msgType;
    }

    /**
     * @return the fUId
     */
    public Long getfuid() {
        return fuid;
    }

    /**
     * @param fUId the fUId to set
     */
    public void setfuid(Long fuid) {
        this.fuid = fuid;
    }


}
