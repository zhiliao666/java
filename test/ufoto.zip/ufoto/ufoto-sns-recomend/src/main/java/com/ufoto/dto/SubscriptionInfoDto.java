package com.ufoto.dto;

import lombok.Data;

/**
 * <p>
 * Author     : Chan
 * CreateDate : 2018/11/14 17:03
 * Description:
 * </p>
 */
@Data
public class SubscriptionInfoDto {
    private Long uid;
    private Long total;
}
