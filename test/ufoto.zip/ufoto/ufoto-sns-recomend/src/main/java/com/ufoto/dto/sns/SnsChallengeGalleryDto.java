package com.ufoto.dto.sns;

import java.util.List;

/**
 * Created by echo on 12/26/17.
 */
public class SnsChallengeGalleryDto {

    private Integer id;
    private String title;
    private Byte isEnable;
    private List<String> gallery;

    public Integer getId() {
        return id;
    }

    public void setId(Integer id) {
        this.id = id;
    }

    public String getTitle() {
        return title;
    }

    public void setTitle(String title) {
        this.title = title;
    }

    public Byte getIsEnable() {
        return isEnable;
    }

    public void setIsEnable(Byte isEnable) {
        this.isEnable = isEnable;
    }

    public List<String> getGallery() {
        return gallery;
    }

    public void setGallery(List<String> gallery) {
        this.gallery = gallery;
    }
}
