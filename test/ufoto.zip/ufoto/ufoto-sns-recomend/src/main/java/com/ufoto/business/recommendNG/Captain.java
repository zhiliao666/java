package com.ufoto.business.recommendNG;

import com.ufoto.dto.RecommendAdvanceRequest;

import java.util.List;

/**
 * Created by echo on 10/10/18.
 * <p>
 * 将多个队列的随从按照规则合并为一列
 */
public interface Captain {

    List<String> assemble(RecommendAdvanceRequest recallRequest, List<List<String>> subUidList, List<Integer> assembleWeightList);

}
