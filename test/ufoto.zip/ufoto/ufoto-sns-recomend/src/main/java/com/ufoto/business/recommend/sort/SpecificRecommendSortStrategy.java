package com.ufoto.business.recommend.sort;

import com.ufoto.business.recommend.bean.SortParamsBean;

import java.util.List;
import java.util.Map;

/**
 * Created by echo on 1/2/18.
 */
public interface SpecificRecommendSortStrategy {


    /**
     * 根据权重，将uidScoreMap中对应的uid加上相应的分数
     *
     * @param uidScoreMap
     * @param weight
     * @return
     */
    Map<String, Double> addScoreBatch(Map<String, Double> uidScoreMap, Double weight, SortParamsBean sortParamsBean);

    /**
     * 获取对应用户的分数（不含权重）
     *
     * @param recallUids
     * @return
     */
    Map<String, Double> getScore(List<String> recallUids, SortParamsBean sortParamsBean);
}
