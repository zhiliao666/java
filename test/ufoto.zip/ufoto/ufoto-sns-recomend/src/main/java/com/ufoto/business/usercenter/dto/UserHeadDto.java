package com.ufoto.business.usercenter.dto;

import lombok.Data;

/**
 * <p>
 * Author     : Chan
 * CreateDate : 2018/10/17 14:04
 * Description:
 * </p>
 */
@Data
public class UserHeadDto {
    private String headImg;
    private int index;
    private int status;
    private Long uid;
}
