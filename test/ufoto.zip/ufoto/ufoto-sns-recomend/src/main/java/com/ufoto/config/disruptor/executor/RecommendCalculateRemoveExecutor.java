package com.ufoto.config.disruptor.executor;

import com.ufoto.config.disruptor.data.AsyncData;
import com.ufoto.config.disruptor.data.RecommendCalculatedAsyncData;
import com.ufoto.service.RecommendService;
import com.ufoto.utils.TryCatchExecutor;
import com.ufoto.utils.redis.RedisKeyUtil;
import com.ufoto.utils.redis.RedisService;
import lombok.extern.slf4j.Slf4j;
import org.springframework.stereotype.Component;
import org.springframework.util.CollectionUtils;

import java.nio.charset.StandardCharsets;
import java.util.Collection;
import java.util.List;
import java.util.stream.Collectors;
import java.util.stream.Stream;

/**
 * <p>
 * Description:
 *
 * </p>
 *
 * @author Chan
 * @date 2019/12/21 17:55
 */
@Slf4j
@Component
public class RecommendCalculateRemoveExecutor extends RecommendCalculateExecutor {

    private final RecommendService recommendService;
    private final RedisService redisService;

    public RecommendCalculateRemoveExecutor(RecommendService recommendService,
                                            RedisService redisService) {
        this.recommendService = recommendService;
        this.redisService = redisService;
    }

    @Override
    public void execute(AsyncData asyncData) {
        RecommendCalculatedAsyncData recommendCalculatedAsyncData = dataCheckAndConverter(asyncData);
        if (recommendCalculatedAsyncData == null) {
            return;
        }
        final String recommendResultKey = recommendCalculatedAsyncData.getRecommendResultKey();
        final byte[] resultKeyBytes = recommendResultKey.getBytes(StandardCharsets.UTF_8);
        final List<String> calculatedList = recommendCalculatedAsyncData.getCalculatedList();
        final List<String> illList = recommendCalculatedAsyncData.getIllList();

        redisService.execPipelineForWrite(connection -> {
            for (String id : Stream.of(calculatedList, illList).flatMap(Collection::stream).collect(Collectors.toList())) {
                connection.lRem(resultKeyBytes, 1, RedisKeyUtil.serializeUid(id).getBytes(StandardCharsets.UTF_8));
            }
            return null;
        });

        final List<String> recommendNoUserList = recommendCalculatedAsyncData.getRecommendNoUserList();
        if (!CollectionUtils.isEmpty(recommendNoUserList)) {
            TryCatchExecutor.execute(() -> recommendService.handRecommendNoUser(recommendNoUserList));
        }

        log.debug("recommendResultKey:{} remove done...", recommendResultKey);
    }
}
