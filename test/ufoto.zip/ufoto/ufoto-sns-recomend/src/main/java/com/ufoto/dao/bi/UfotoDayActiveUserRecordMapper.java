package com.ufoto.dao.bi;

import com.ufoto.dto.DumpUserDto;
import org.apache.ibatis.annotations.Delete;
import org.apache.ibatis.annotations.Mapper;
import org.apache.ibatis.annotations.Param;
import org.apache.ibatis.annotations.Select;

import java.sql.Date;
import java.util.List;

@Mapper
public interface UfotoDayActiveUserRecordMapper {

    @Select("SELECT id,uid FROM ufoto_day_active_user_record WHERE id>#{maxId} and stat_date = #{date}  order by id asc limit 2000")
    List<DumpUserDto> selectUidListByDate(@Param("maxId") long maxId, @Param("date") Date date);

    @Delete("DELETE FROM ufoto_day_active_user_record WHERE id<=#{maxId} and stat_date <= #{date}")
    void deleteUidListByDate(@Param("maxId") long maxId, @Param("date") Date date);
}
