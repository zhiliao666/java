package com.ufoto.bloom;

import com.ufoto.utils.DateUtil;
import com.ufoto.utils.redis.RedisKeyConstant;
import com.ufoto.utils.redis.RedisKeyUtil;
import com.ufoto.utils.redis.RedisService;
import lombok.extern.slf4j.Slf4j;
import org.springframework.util.CollectionUtils;
import org.springframework.util.StringUtils;

import java.util.List;
import java.util.Map;
import java.util.Objects;
import java.util.Set;
import java.util.stream.Collectors;

/**
 * <p>
 * Author     : Chan
 * CreateDate : 2019/12/6 13:19
 * Description:
 * </p>
 */
@Slf4j
public class RecommendedRecommendBloomFilter extends AbstractRecommendBloomFilter<Long, String> {

    private final static String keyTemplate = RedisKeyConstant.REDIS_RECOMMENDED_BF_WEEKLY_KEY_;
    private final static String keyContainerTemplate = RedisKeyConstant.REDIS_RECOMMENDED_BF_HASH;
    private final static String currentKeyField = RedisKeyConstant.REDIS_RECOMMENDED_BF_HASH_CURRENT_KEY;
    private final static String keyPrefix = keyTemplate.substring(0, keyTemplate.indexOf(":"));
    private final static int BF_EXPIRE = 4;

    private final RedisService redisService;

    public RecommendedRecommendBloomFilter(RedisService redisService) {
        super(redisService);
        this.redisService = redisService;
    }

    public RecommendedRecommendBloomFilter(RedisService redisService, int expectedInsertions, double falseProbability) {
        super(redisService, expectedInsertions, falseProbability);
        this.redisService = redisService;
    }

    @Override
    public String getCurrentKeyField() {
        return currentKeyField;
    }

    @Override
    public String getAndUpdateCurrentKey(Long user) {
        final String hashKey = this.getKeyContainerKey(user);
        String currentBFKey = redisService.hget(hashKey, currentKeyField);

        if (StringUtils.isEmpty(currentBFKey)
                || !Objects.equals(currentBFKey.split(":")[2],
                currentWeek() + "")) {
            currentBFKey = createAndUpdateCurrentKey(hashKey, user, 0);
        }
        return currentBFKey;
    }

    private int currentWeek() {
        return DateUtil.getCurrentSecondIntValue() / (60 * 60 * 24 * 7);
    }

    public String createAndUpdateCurrentKey(String hashKey, Long user, int index) {
        String currentBFKey = createCurrentKey(user, index);
        redisService.hset(hashKey, currentKeyField, currentBFKey);
        return currentBFKey;
    }

    @Override
    public String getKeyContainerKey(Long user) {
        return RedisKeyUtil.obtainKey(keyContainerTemplate, user);
    }

    @Override
    public boolean ifBloomFilterKey(String key) {
        return StringUtils.hasText(key) && key.startsWith(keyPrefix);
    }

    @Override
    public void dynamicExpansion(Long user, String currentKey) throws Exception {
        final long count = this.bitSetCount(currentKey);
        if (count > this.getExpectedInsertions()) {
            log.debug("BloomNewKey {},{}", currentKey, count);
            //如果当前BF当中的元素数量已经超过了预设上限，则进行扩容
            final String hashKey = this.getKeyContainerKey(user);
            redisService.hIncrBy(hashKey, currentKey, count);
            final String[] split = currentKey.split(":");
            String currentBFKey = createCurrentKey(Long.parseLong(split[1]), Integer.parseInt(split[3]) + 1);
            redisService.hset(hashKey, currentKeyField, currentBFKey);
        }
    }

    /**
     * 创建当前的key
     *
     * @param user  user identify
     * @param index index
     * @return 创建新的key
     */
    public String createCurrentKey(Long user, int index) {
        return RedisKeyUtil.obtainKey(keyTemplate, user, currentWeek(), index);
    }

    @Override
    public void cleanExpireBloomKeys(Long user) {
        final String keyContainerKey = this.getKeyContainerKey(user);

        final Map<String, String> map = redisService.hGetAll(keyContainerKey);
        if (CollectionUtils.isEmpty(map)) {
            return;
        }
        final String cur = map.get(currentKeyField);
        if (StringUtils.hasText(cur)) {
            map.put(cur, "0");
        }
        final Set<String> keys = map.keySet();
        final int currentWeek = this.currentWeek();
        final List<String> expireKeys = keys.stream()
                .filter(key -> !Objects.equals(key, currentKeyField))
                .filter(key -> currentWeek - Integer.parseInt(key.split(":")[2]) >= BF_EXPIRE)
                .collect(Collectors.toList());

        if (!CollectionUtils.isEmpty(expireKeys)) {
            //keys至少比expireKeys多一个
            if (keys.size() - expireKeys.size() > 1) {
                redisService.hDel(keyContainerKey, expireKeys.toArray(new String[]{}));
            } else {
                //说明容器内只剩下当前key--也即是所有的key都过期了,删除掉当前容器
                expireKeys.add(keyContainerKey);
            }
            redisService.del(expireKeys.toArray(new String[]{}));
        }
        //error in prod ,yyy
//            redisService.execPipelineForWrite(connection -> {
//                connection.del(expireKeys);
//                connection.hDel(keyContainerKey.getBytes(StandardCharsets.UTF_8), expireKeys);
//                return null;
//            });
    }
}
