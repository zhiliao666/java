package com.ufoto.entity.base;

import java.io.Serializable;

public class BaseUfotoUserChatActivity implements Serializable {
    /**
     * Default value included to remove warning. Remove or modify at will.
     **/
    private static final long serialVersionUID = 1L;

    private java.lang.Integer createTime;
    private java.lang.Long id;
    private java.lang.String lang;
    private java.lang.Integer expireTime;
    private java.lang.Integer status;
    private java.lang.Long uId;

    public java.lang.Integer getCreateTime() {
        return createTime;
    }

    public void setCreateTime(java.lang.Integer createTime) {
        this.createTime = createTime;
    }

    public java.lang.Long getId() {
        return id;
    }

    public void setId(java.lang.Long id) {
        this.id = id;
    }

    public java.lang.String getLang() {
        return lang;
    }

    public void setLang(java.lang.String lang) {
        this.lang = lang;
    }

    public java.lang.Integer getExpireTime() {
        return expireTime;
    }

    public void setExpireTime(java.lang.Integer expireTime) {
        this.expireTime = expireTime;
    }

    public java.lang.Integer getStatus() {
        return status;
    }

    public void setStatus(java.lang.Integer status) {
        this.status = status;
    }

    public java.lang.Long getUId() {
        return uId;
    }

    public void setUId(java.lang.Long uId) {
        this.uId = uId;
    }


//	@Override
//	public String toString() {
//		return "{ id:" + id + ", name:" + name + ", email:" + email
//				+ ", phone:" + phoneNumber + " }";
//	}
}
