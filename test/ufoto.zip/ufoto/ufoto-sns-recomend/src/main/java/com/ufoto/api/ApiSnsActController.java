package com.ufoto.api;

import com.google.common.collect.Lists;
import com.ufoto.config.disruptor.constants.EventType;
import com.ufoto.config.disruptor.data.RecommendCalculatedAsyncData;
import com.ufoto.config.disruptor.event.AsyncEvent;
import com.ufoto.constants.ERecommendUserType;
import com.ufoto.constants.ESnsFromType;
import com.ufoto.constants.ESupportLanguage;
import com.ufoto.dto.RecommendAdvanceRequest;
import com.ufoto.dto.RecommendListRequest;
import com.ufoto.dto.sns.SnsRecommendExpandDto;
import com.ufoto.dto.sns.SnsRecommendV1;
import com.ufoto.entity.UfotoAppUser;
import com.ufoto.lmax.LMaxDisruptor;
import com.ufoto.manager.CommonServiceManager;
import com.ufoto.plugins.interceptor.LogInterceptor;
import com.ufoto.service.RecommendService;
import com.ufoto.service.UfotoAppUserService;
import com.ufoto.service.UfotoRecommendRedisDumpService;
import com.ufoto.utils.ApiResult;
import com.ufoto.utils.BeanUtil;
import com.ufoto.utils.CommonUtil;
import com.ufoto.utils.DateUtil;
import com.ufoto.utils.DirtyCaseUtil;
import com.ufoto.utils.json.JSONUtil;
import com.ufoto.utils.redis.RedisKeyConstant;
import com.ufoto.utils.redis.RedisService;
import com.ufoto.utils.threadlocal.ThreadLocalManager;
import lombok.RequiredArgsConstructor;
import lombok.extern.slf4j.Slf4j;
import org.apache.commons.lang3.StringUtils;
import org.slf4j.MDC;
import org.springframework.core.env.Environment;
import org.springframework.util.CollectionUtils;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.ResponseBody;
import org.springframework.web.bind.annotation.RestController;

import java.util.Arrays;
import java.util.LinkedList;
import java.util.List;
import java.util.stream.Collectors;

/**
 * Created by echo on 12/26/17.
 */
@Slf4j
@RestController
@RequestMapping(path = {"/snsActApi", "sns"})
@RequiredArgsConstructor
public class ApiSnsActController {

    private final RedisService redisService;
    private final RecommendService recommendService;
    private final UfotoAppUserService ufotoAppUserService;
    private final UfotoRecommendRedisDumpService ufotoRecommendRedisDumpService;
    private final DirtyCaseUtil dirtyCaseUtil;
    private final Environment environment;
    private final CommonServiceManager commonServiceManager;
    private final LMaxDisruptor<AsyncEvent> recommendCalculateAsyncEventLMaxDisruptor;

    @RequestMapping(value = "/recommend", method = RequestMethod.GET)
    public @ResponseBody
    ApiResult<List<SnsRecommendV1>> recommend(Long uid, String sign,
                                              Integer page, Integer pageSize,
                                              Double longitude, Double latitude,
                                              String countryCode,
                                              String cp,
                                              Boolean withScore) {
        RecommendAdvanceRequest recommendAdvanceRequest = new RecommendAdvanceRequest();
        recommendAdvanceRequest.setUid(uid);
        recommendAdvanceRequest.setSign(sign);
        recommendAdvanceRequest.setPage(page);
        recommendAdvanceRequest.setPageSize(pageSize);
        recommendAdvanceRequest.setLongitude(longitude);
        recommendAdvanceRequest.setLatitude(latitude);
        recommendAdvanceRequest.setCountryCode(countryCode);
        recommendAdvanceRequest.setWithScore(withScore);
        recommendAdvanceRequest.setCp(cp);
     // 设置推荐使用来源，规则引擎会根据该值选择具体某一个规则
    	recommendAdvanceRequest.setFromType(ESnsFromType.SLIDE.getType());
        return recommend(recommendAdvanceRequest);
    }

    @RequestMapping(value = "/recommend", method = RequestMethod.POST)
    @ResponseBody
    public ApiResult<List<SnsRecommendV1>> recommend(@RequestBody RecommendAdvanceRequest recommendAdvanceRequest) {
    	// 设置推荐使用来源，规则引擎会根据该值选择具体某一个规则
    	recommendAdvanceRequest.setFromType(ESnsFromType.SLIDE.getType());
    	Long uid = recommendAdvanceRequest.getUid();
        recommendAdvanceRequest.setPage(0);
        Integer page = recommendAdvanceRequest.getPage();
        Integer pageSize = recommendAdvanceRequest.getPageSize();
        Double longitude = recommendAdvanceRequest.getLongitude();
        Double latitude = recommendAdvanceRequest.getLatitude();
        String countryCode = recommendAdvanceRequest.getCountryCode();
        recommendAdvanceRequest.setAreaId(commonServiceManager.getAreaId(countryCode));
        CommonUtil.compatibleCP(recommendAdvanceRequest);
        //判断是否需要从MySQL中将之前DUMP的数据拉回来
        ufotoRecommendRedisDumpService.restore(uid);

        if (page == null || page < 0) {
            page = 0;
        }
        if (pageSize == null || pageSize < 1) {
            pageSize = 10;
            recommendAdvanceRequest.setPageSize(10);
        }
        int start = page * pageSize;
        int end = (page + 1) * pageSize - 1;

        recommendAdvanceRequest.setStart(start);
        recommendAdvanceRequest.setEnd(end);

        if (uid != null && redisService.sCard(RedisKeyConstant.REDIS_MY_LIKED_SET_KEY_NEW + uid) > 0) {//只有有过成功Like的用户才会加入到Redis中
            recommendService.addRedisRegionUser(uid, countryCode, recommendAdvanceRequest.getAreaId());
            recommendService.addRedisUserGeo(uid, longitude, latitude);
        }

        //获取推荐结果的UID列表
        //不符合条件的uid
        List<String> removedUidList = new LinkedList<>();
        //最终的结果list
        List<SnsRecommendExpandDto> result = new LinkedList<>();
        List<String> resultList = new LinkedList<>();
        List<String> needDeleteFromRedisList = Lists.newArrayList();
        List<String> recommendNoUserList = Lists.newArrayList();
        //召回-过滤-排序最终得到的uid list
        List<String> recommendUidList = recommendService.recommendUsers(recommendAdvanceRequest);
        if (CollectionUtils.isEmpty(recommendUidList)) {
            return new ApiResult<List<SnsRecommendV1>>().setResult(new LinkedList<>());
        }
        //通过UID列表拼装返回的具体数据结果
        boolean needMore;
        final UfotoAppUser ufotoAppUser = ufotoAppUserService.selectOneById(uid);
        int loopCount = 0;
        do {
            loopCount++;
            removedUidList.clear();
            RecommendListRequest recommendListRequest = new RecommendListRequest();
            recommendListRequest.setUids(recommendUidList);
            recommendListRequest.setApiVersion(recommendAdvanceRequest.getApiVersion());
            recommendListRequest.setLang(recommendAdvanceRequest.getLanguage());
            List<SnsRecommendExpandDto> snsRecommendDtoList = ufotoAppUserService.selectRecommendDtoBySortedUidList(recommendListRequest);

            for (SnsRecommendExpandDto snsRecommendDto : snsRecommendDtoList) {
                final String recallUid = snsRecommendDto.getUid();
                recommendUidList.remove(recallUid);
                //没有头像的判断基于firstImg
                if (StringUtils.isBlank(snsRecommendDto.getHeadImg())) {//如果用户没有头像，从最终的推荐列表中剔除
                    removedUidList.add(recallUid);
                    continue;
                }
                final boolean appCardId = CommonUtil.isAppCardId(recallUid);
                if (!appCardId) {
                    handleRecommendDto(uid, longitude, latitude, snsRecommendDto);
                } else {
                    if (ufotoAppUser != null) {
                        snsRecommendDto.setLocation(ufotoAppUser.getLocation());
                    }
                }

                //如果是。。。特殊情况，连注释都没力气写了
                if (dirtyCaseUtil.ifNeedGiftReceiveCardRequest(recommendAdvanceRequest)) {
                    snsRecommendDto.setUserType(ERecommendUserType.GIFT_RECEIVE.getType());
                    snsRecommendDto.setGiftNum(
                            recommendService.getGiftNum(CommonUtil.safeString2Long(snsRecommendDto.getUid()))
                    );
                    snsRecommendDto.setDescription(getGiftReceiveDescription(recommendAdvanceRequest));
                }
                result.add(snsRecommendDto);
                resultList.add(snsRecommendDto.getUid());
            }

            //如果有因为各种原因在这一层面剔除过筛选结果，那么需要重新在推荐服务那边获取更多的用户
            needMore = removedUidList.size() > 0 || recommendUidList.size() > 0;
            //由于不能保证用户中心是否正常返回，没有找到对应uid的DTO暂时不做处理
//            needMore = removedUidList.size() > 0;
            if (removedUidList.size() > 0) {
                recommendService.removeNoHeadUsers(uid, removedUidList.stream()
                        .filter(CommonUtil::isNotAppCardId).collect(Collectors.toList()));
            }
            if (recommendUidList.size() > 0) {
                recommendNoUserList.addAll(recommendUidList);
            }
            if (needMore) {
                if (!CollectionUtils.isEmpty(removedUidList)) {
                    needDeleteFromRedisList.addAll(removedUidList);
                }
                if (!CollectionUtils.isEmpty(recommendUidList)) {
                    needDeleteFromRedisList.addAll(recommendUidList);
                }
                //需要拿更多的数据的数量
                int lostCount = removedUidList.size() + recommendUidList.size();
                //trick
                final int newStart = recommendAdvanceRequest.getEnd() + 1;
                final int newEnd = newStart + lostCount - 1;
                recommendAdvanceRequest.setStart(newStart);
                recommendAdvanceRequest.setEnd(newEnd);
                log.warn("RecommendNeedMore traceId:{},request:{}. removedUidList:{},recommendUidList:{}",
                        MDC.get(LogInterceptor.SESSION_KEY),
                        JSONUtil.toJSON(recommendAdvanceRequest),
                        removedUidList, recommendUidList);
                recommendAdvanceRequest.setLastRecallTime(ThreadLocalManager.getESACTIVETIMEThreadLocal());
                recommendUidList = recommendService.recommendUsers(recommendAdvanceRequest);
                //防止意外情况拉取到空,默认先不校验,跳出循环已loopCount为准.如果result已经够数量 自动跳出循环
                final Boolean emptyFlag = environment.getProperty("recommend.recall.procedure.empty", Boolean.class, true);
                if (emptyFlag && CollectionUtils.isEmpty(recommendUidList)) {
                    //太难了!!!!!
                    break;
                }
            }
            if (loopCount >= 3) {
                //以防不测,so crazy!!!!!!!!!
                break;
            }
        } while (needMore);
        if (!CollectionUtils.isEmpty(needDeleteFromRedisList) || !CollectionUtils.isEmpty(resultList)) {
            recommendCalculateAsyncEventLMaxDisruptor.send(AsyncEvent.builder()
                    .eventType(EventType.RECOMMEND_CALCULATE_REMOVE)
                    .asyncData(RecommendCalculatedAsyncData.builder()
                            .recommendAdvanceRequest(recommendAdvanceRequest)
                            .calculatedList(resultList)
                            .illList(needDeleteFromRedisList)
                            .recommendNoUserList(recommendNoUserList)
                            .recommendResultKey(recommendService.getRecommendResultKey(recommendAdvanceRequest))
                            .build())
                    .build());
        }
        return new ApiResult<List<SnsRecommendV1>>().setResult(
                result.stream()
                        .map(snsRecommendExpandDto -> BeanUtil.copyPropertiesByNotNull(snsRecommendExpandDto, new SnsRecommendV1()))
                        .collect(Collectors.toList())
        );
    }

    private void handleRecommendDto(Long uid, Double longitude, Double latitude, SnsRecommendExpandDto snsRecommendDto) {
        //获取用户相对距离
        Double distance;
        Long _recallUid = Long.valueOf(snsRecommendDto.getUid());
        if (uid != null)
            distance = recommendService.getDistance(uid, _recallUid);
        else
            distance = recommendService.getDistance(longitude, latitude, _recallUid);
        if (distance == null) distance = -1d;
        snsRecommendDto.setDistance(distance.intValue());

        //对方是否有like过我
        byte likeState = 0;
        if (recommendService.isUserBeSuperLiked(uid, _recallUid)) {
            likeState = 2;
        } else if (recommendService.isUserBeLiked(uid, _recallUid)) {
            likeState = 1;
        }
        snsRecommendDto.setLikeState(likeState);

        //对方的最近在线时间
        Integer afterLastActTime = recommendService.getRedisUserActivityTimestamp(_recallUid);
        if (afterLastActTime != null) {
            afterLastActTime = DateUtil.getCurrentSecondIntValue() - afterLastActTime;
            snsRecommendDto.setAfterLastActTime(afterLastActTime);
        }
    }


    /**
     * 针对独立出来针对未登录用户的推荐接口，
     * 目前的逻辑实现还是在recommend方法中，
     * 方便之后的处理。
     */
    @RequestMapping(value = "/recommendForGuest", method = RequestMethod.POST)
    @ResponseBody
    public ApiResult<List<SnsRecommendV1>> recommendForGuest(@RequestBody RecommendAdvanceRequest recommendAdvanceRequest) {
        return recommend(recommendAdvanceRequest);
    }

    private String getGiftReceiveDescription(RecommendAdvanceRequest recommendAdvanceRequest) {
        String language = recommendAdvanceRequest.getLanguage();
        if (StringUtils.isBlank(language)) {
            language = ESupportLanguage.EN.getLang();
        } else {
            String finalLanguage = language;
            language = Arrays.stream(ESupportLanguage.values())
                    .map(ESupportLanguage::getLang)
                    .filter(s -> s.equalsIgnoreCase(finalLanguage))
                    .findFirst().orElseGet(ESupportLanguage.EN::getLang);
        }
        return environment.getProperty("recommend.dc.giftReceive.description." + language, String.class);
    }
}
