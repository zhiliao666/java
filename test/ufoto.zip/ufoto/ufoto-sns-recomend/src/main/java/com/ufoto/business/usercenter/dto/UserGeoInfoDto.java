package com.ufoto.business.usercenter.dto;

import lombok.Data;

import java.io.Serializable;

/**
 * <p>
 * Author     : Chan
 * CreateDate : 2019-04-16 10:28
 * Description:
 * </p>
 */
@Data
public class UserGeoInfoDto implements Serializable {
    private double longitude;
    private double latitude;
    private long id;
}
