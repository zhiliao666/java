package com.ufoto.business.common;

import com.ufoto.business.common.hystrix.ApiCommonInfoBusinessHystrix;
import com.ufoto.infrastructrue.statistics.AbstractFallbackFactory;
import org.springframework.stereotype.Component;

/**
 * Created by echo on 11/1/18.
 */
@Component
public class ApiCommonInfoBusinessFallbackFactory extends AbstractFallbackFactory<ApiCommonInfoBusinessHystrix> {

    private final ApiCommonInfoBusinessHystrix strategyBusinessHystrix;

    public ApiCommonInfoBusinessFallbackFactory(ApiCommonInfoBusinessHystrix strategyBusinessHystrix) {
        this.strategyBusinessHystrix = strategyBusinessHystrix;
    }

    @Override
    protected ApiCommonInfoBusinessHystrix doCreate() {
        return strategyBusinessHystrix;
    }
}
