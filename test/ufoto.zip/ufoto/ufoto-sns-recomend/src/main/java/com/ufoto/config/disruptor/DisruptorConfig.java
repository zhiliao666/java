package com.ufoto.config.disruptor;

import com.lmax.disruptor.TimeoutBlockingWaitStrategy;
import com.ufoto.config.disruptor.constants.ConsumerId;
import com.ufoto.config.disruptor.consumer.AsyncConsumer;
import com.ufoto.config.disruptor.consumer.RecommendCalculateBloomConsumer;
import com.ufoto.config.disruptor.consumer.RecommendCalculatePrepareTriggerConsumer;
import com.ufoto.config.disruptor.consumer.RecommendCalculateRemoveConsumer;
import com.ufoto.config.disruptor.event.AsyncEvent;
import com.ufoto.config.disruptor.exception.RecommendCalculateExceptionHandler;
import com.ufoto.lmax.LMaxDisruptor;
import com.ufoto.lmax.consumers.CustomizerExecuteConsumer;
import com.ufoto.lmax.consumers.OnlyOneExecuteConsumer;
import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;

import java.util.concurrent.TimeUnit;

/**
 * <p>
 * Description:
 *
 * </p>
 *
 * @author Chan
 * @date 2019/12/21 14:52
 */
@Configuration
public class DisruptorConfig {

    @Bean(initMethod = "startDisruptor", destroyMethod = "shutdown")
    public LMaxDisruptor<AsyncEvent> asyncEventLMaxDisruptor() {
        LMaxDisruptor<AsyncEvent> disruptor = LMaxDisruptor.<AsyncEvent>builder()
                .waitStrategy(new TimeoutBlockingWaitStrategy(3, TimeUnit.SECONDS))
                .consumer(OnlyOneExecuteConsumer.class)
                .threadFactory(new RecThreadFactory("disruptor-async"))
                .build();
        disruptor.subscribeConsumer(
                new AsyncConsumer(ConsumerId.CONSUMER_ASYNC + ":1"),
                new AsyncConsumer(ConsumerId.CONSUMER_ASYNC + ":2"),
                new AsyncConsumer(ConsumerId.CONSUMER_ASYNC + ":3")
        );
        return disruptor;
    }

    @Bean(initMethod = "startDisruptor", destroyMethod = "shutdown")
    public LMaxDisruptor<AsyncEvent> recommendCalculateAsyncEventLMaxDisruptor(
            RecommendCalculateRemoveConsumer recommendCalculateRemoveConsumer,
            RecommendCalculateBloomConsumer recommendCalculateBloomConsumer,
            RecommendCalculatePrepareTriggerConsumer recommendCalculatePrepareTriggerConsumer
    ) {
        LMaxDisruptor<AsyncEvent> disruptor = LMaxDisruptor.<AsyncEvent>builder()
                //可超时
                .waitStrategy(new TimeoutBlockingWaitStrategy(3, TimeUnit.SECONDS))
                .consumer(CustomizerExecuteConsumer.class)
                .exceptionHandler(new RecommendCalculateExceptionHandler())
                .threadFactory(new RecThreadFactory("disruptor-recommend"))
                .build();
        disruptor.subscribeCustomizer(
                dis -> dis
                        .handleEventsWithWorkerPool(
                                recommendCalculateRemoveConsumer,
                                recommendCalculateRemoveConsumer,
                                recommendCalculateRemoveConsumer)
                        .handleEventsWithWorkerPool(
                                recommendCalculateBloomConsumer,
                                recommendCalculateBloomConsumer,
                                recommendCalculateBloomConsumer)
                        //最后一个执行
                        .thenHandleEventsWithWorkerPool(
                                recommendCalculatePrepareTriggerConsumer,
                                recommendCalculatePrepareTriggerConsumer,
                                recommendCalculatePrepareTriggerConsumer)
        );
        return disruptor;
    }

}
