package com.ufoto.business.recommend.shuffle.cutter;

import com.ufoto.annotation.RecommendMetadata;
import com.ufoto.business.recommend.shuffle.base.ShuffleCutter;
import com.ufoto.constants.EGender;
import com.ufoto.utils.KeyTransitionUtil;
import com.ufoto.utils.redis.RedisService;

import java.util.*;

/**
 * Created by echo on 7/11/18.
 */
@RecommendMetadata(
        metadataType = RecommendMetadata.MetadataType.CUTTER,
        available = true,
        name = "性别分区器",
        description = "按照性别分区",
        branch = RecommendMetadata.Branch.NORMAL
)
public class GenderCutter implements ShuffleCutter {

    RedisService redisService;

    public GenderCutter(RedisService redisService) {
        this.redisService = redisService;
    }

    @Override
    public List<List<String>> cut(String[] uidArray) {
        List<List<String>> result = new LinkedList<>();
        result.add(new LinkedList<>());//女
        result.add(new LinkedList<>());//男
        result.add(new LinkedList<>());//未知

        final Map<Long, Integer> genderMap = KeyTransitionUtil.selectGenders(redisService, Arrays.asList(uidArray));
        for (String s : uidArray) {
            final Integer gender = genderMap.get(Long.valueOf(s));
            if (Objects.equals(EGender.FEMALE.getType(), gender)) {//if female
                result.get(0).add(s);
            } else if (Objects.equals(EGender.MALE.getType(), gender)) { // if male
                result.get(1).add(s);
            } else { // if null
                result.get(2).add(s);
            }
        }
        return result;
    }
}
