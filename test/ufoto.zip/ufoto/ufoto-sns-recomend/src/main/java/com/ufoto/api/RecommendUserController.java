package com.ufoto.api;

import com.github.benmanes.caffeine.cache.LoadingCache;
import com.google.common.collect.Sets;
import com.ufoto.business.recommendNG.recall.NGChatFreeRecall;
import com.ufoto.utils.ApiResult;
import com.ufoto.utils.CommonUtil;
import com.ufoto.utils.redis.RedisKeyConstant;
import com.ufoto.utils.redis.RedisService;
import lombok.RequiredArgsConstructor;
import lombok.extern.slf4j.Slf4j;
import org.springframework.web.bind.annotation.*;

import java.util.List;
import java.util.Set;
import java.util.stream.Collectors;

/**
 * @author tangyd
 */
@Slf4j
@RestController
@RequiredArgsConstructor
public class RecommendUserController {

    private final RedisService redisService;
    private final LoadingCache<Class<?>, Object> middleFrequencyLoadingCache;

    @RequestMapping(path = "/v1/chatfree/{operate}", method = RequestMethod.POST)
    public ApiResult<Boolean> chatFree(@PathVariable Integer operate,  @RequestBody List<Long> uids) {
        log.warn("chat free uids changed, url: v1/chatfree/, operate: {}, uids: {}", operate, uids);
        String[] array = uids.stream().map(String::valueOf).toArray(String[]::new);
        if(operate == 1) {
            redisService.sadd(RedisKeyConstant.REDIS_CHAT_FREE_SET_KEY, array);
        } else {
            redisService.sremove(RedisKeyConstant.REDIS_CHAT_FREE_SET_KEY, array);
        }
        middleFrequencyLoadingCache.refresh(NGChatFreeRecall.class);
        return new ApiResult<Boolean>().setResult(true);
    }

}
