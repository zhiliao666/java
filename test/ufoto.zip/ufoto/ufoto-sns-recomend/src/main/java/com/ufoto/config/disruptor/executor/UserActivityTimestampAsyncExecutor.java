package com.ufoto.config.disruptor.executor;

import com.ufoto.config.disruptor.data.AsyncData;
import com.ufoto.config.disruptor.data.UserActivityTimestampAsyncData;
import com.ufoto.service.RecommendService;
import lombok.extern.slf4j.Slf4j;
import org.springframework.stereotype.Component;

/**
 * <p>
 * Description:
 *
 * </p>
 *
 * @author Chan
 * @date 2019/12/21 15:44
 */
@Slf4j
@Component
public class UserActivityTimestampAsyncExecutor implements AsyncExecutor {
    private final RecommendService recommendService;

    public UserActivityTimestampAsyncExecutor(RecommendService recommendService) {
        this.recommendService = recommendService;
    }

    @Override
    public void execute(AsyncData asyncData) {
        log.debug("UserActivityTimestampAsyncData:{}", asyncData);
        if (!(asyncData instanceof UserActivityTimestampAsyncData)) {
            log.warn("UserActivityTimestampWarn:{},data type error", asyncData);
            return;
        }
        UserActivityTimestampAsyncData userActivityTimestampAsyncData = (UserActivityTimestampAsyncData) asyncData;
        recommendService.addRedisUserActivityTimestamp(
                userActivityTimestampAsyncData.getUid(),
                userActivityTimestampAsyncData.getTimestamp()
        );
    }
}
