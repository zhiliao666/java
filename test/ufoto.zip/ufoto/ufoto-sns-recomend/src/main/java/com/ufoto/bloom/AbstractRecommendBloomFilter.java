package com.ufoto.bloom;

import com.google.common.collect.Lists;
import com.google.common.collect.Sets;
import com.google.common.hash.Hashing;
import com.ufoto.utils.BloomFilterUtil;
import com.ufoto.utils.json.JSONUtil;
import com.ufoto.utils.redis.RedisService;
import lombok.extern.slf4j.Slf4j;
import org.springframework.data.redis.connection.RedisConnection;
import org.springframework.data.redis.core.RedisCallback;
import org.springframework.util.CollectionUtils;
import org.springframework.util.StringUtils;

import java.nio.charset.StandardCharsets;
import java.util.List;
import java.util.Map;
import java.util.Objects;
import java.util.Set;
import java.util.concurrent.locks.ReentrantLock;
import java.util.stream.Collectors;

/**
 * <p>
 * Author     : Chan
 * CreateDate : 2019/12/4 11:32
 * Description:
 * </p>
 */
@Slf4j
public abstract class AbstractRecommendBloomFilter<U, T> implements RecommendBloomFilter<U, T> {

    private static final int EXPECTED_INSERTIONS = 1000;
    private static final double FALSE_PROBABILITY = 0.0005;
    private static final boolean ENSURE_CAPACITY = true;
    private final RedisService redisService;
    private final ReentrantLock lock;
    private int expectedInsertions;
    private double falseProbability;
    private volatile long size;
    private volatile int hashIterations;
    private boolean ensureCapacity;
    private ThreadLocal<RawBloomFilterCache<U>> threadLocal;

    public AbstractRecommendBloomFilter(RedisService redisService) {
        this(redisService, EXPECTED_INSERTIONS, FALSE_PROBABILITY, ENSURE_CAPACITY);
    }

    public AbstractRecommendBloomFilter(RedisService redisService,
                                        int expectedInsertions,
                                        double falseProbability) {
        this(redisService, expectedInsertions, falseProbability, ENSURE_CAPACITY);
    }

    public AbstractRecommendBloomFilter(RedisService redisService,
                                        int expectedInsertions,
                                        double falseProbability,
                                        boolean ensureCapacity) {
        this.redisService = redisService;
        this.expectedInsertions = expectedInsertions;
        this.falseProbability = falseProbability;
        this.lock = new ReentrantLock();
        this.ensureCapacity = ensureCapacity;
        this.tryInit(this.expectedInsertions, this.falseProbability);
    }

    /**
     * 获取容器中存放当前key的field
     */
    public abstract String getCurrentKeyField();

    /**
     * 获取当前的key
     *
     * @param user user identify
     * @return 用户所有的分段key中当前在用的key
     */
    public abstract String getAndUpdateCurrentKey(U user);

    /**
     * key是分段的 该方法指的是每一个分段的key应该存入的地方 格式为hash value为每一个分段key的长度
     *
     * @param user user
     * @return 获取存放分段key的容器key
     */
    public abstract String getKeyContainerKey(U user);

    /**
     * 判断key是否是BF的key 目的在于容器key中保留有c_k 代指当前key 需要过滤掉
     *
     * @param key key
     * @return true for yes
     */
    public abstract boolean ifBloomFilterKey(String key);

    /**
     * 动态扩容方式
     */
    public void dynamicExpansion(U user, String currentKey) throws Exception {

    }

    @Override
    public void cleanExpireBloomKeys(U user) {

    }

    public void expireCurrentBFKey(RedisConnection connection, String currentBFKey, String currentContainer) {

    }

    @Override
    public boolean add(U user, T item) {
        //计算偏移量
        long[] hashes = hash(item);
        try {
            lock.lock();
            //获取当前key
            final boolean contains = contains(user, item);
            if (!contains) {
                String currentBFKey = getAndUpdateCurrentKey(user);
                String currentContainer = getKeyContainerKey(user);
                //设置当前key的值
                redisService.execPipelineForWrite(connection -> {
                    for (long offset : hashes) {
                        connection.setBit(currentBFKey.getBytes(StandardCharsets.UTF_8), offset, true);
                    }
                    expireCurrentBFKey(connection, currentBFKey, currentContainer);
                    return null;
                });

                //如果是新的数据插入 那么更新当前key的数量 如果已经超出长度 重新生成当前key
                try {
                    if (ensureCapacity) {
                        dynamicExpansion(user, currentBFKey);
                    }
                } catch (Exception e) {
                    log.error(e.getMessage(), e);
                }
            }
            return true;
        } finally {
            lock.unlock();
        }
    }

    public boolean addBatch(U user, Set<T> items) {
        if (CollectionUtils.isEmpty(items)) {
            return false;
        }
        return items.stream().map(item -> add(user, item)).reduce((a, b) -> a & b).orElse(false);
    }

    /**
     * 获取当前用户所有的分段BF key
     */
    public List<String> allBFKeys(U user) {
        final String keyContainerKey = this.getKeyContainerKey(user);
        Map<String, String> recommendedBFMap = redisService.hGetAll(keyContainerKey);
        if (CollectionUtils.isEmpty(recommendedBFMap)) {
            return Lists.newLinkedList();
        }
        final String currentKey = redisService.hget(keyContainerKey, getCurrentKeyField());
        if (StringUtils.hasText(currentKey)) {
            recommendedBFMap.putIfAbsent(currentKey, "0");
        }
        return recommendedBFMap.keySet().stream().filter(this::ifBloomFilterKey).collect(Collectors.toList());
    }

    /**
     * 获取每一个key对应的bit数据
     */
    private List<byte[]> getByteArrayList(U user, List<String> allBFKeys) {
        final ThreadLocal<RawBloomFilterCache<U>> threadLocal = this.getThreadLocal();
        if (threadLocal != null) {
            final RawBloomFilterCache<U> bloomFilterCache = threadLocal.get();
            if (bloomFilterCache != null
                    && Objects.equals(bloomFilterCache.getUser(), user)
                    && bloomFilterCache.getBfList() != null) {
                //说明缓存存在
                return bloomFilterCache.getBfList();
            }
        }
        final List<Object> objects = redisService.getRedisTemplate().executePipelined((RedisCallback<Object>) connection -> {
            for (String key : allBFKeys) {
                connection.get(key.getBytes(StandardCharsets.UTF_8));
            }
            return null;
        }, null);
        final List<byte[]> result = objects.stream().map(b -> (byte[]) b).collect(Collectors.toList());
        //放入缓存
        if (threadLocal != null) {
            threadLocal.set(RawBloomFilterCache.<U>builder().user(user).bfList(result).build());
        }
        return result;
    }

    @Override
    public boolean contains(U user, T item) {
        final List<String> allBFKeys = allBFKeys(user);
        if (CollectionUtils.isEmpty(allBFKeys)) return false;
        List<byte[]> bfResult = getByteArrayList(user, allBFKeys);
        if (CollectionUtils.isEmpty(bfResult)) {
            return false;
        }
        return ifItemInRawBFList(item, bfResult);
    }

    @Override
    public Set<T> filter(U user, Set<T> items) {
        final List<String> allBFKeys = allBFKeys(user);
        if (CollectionUtils.isEmpty(allBFKeys)) return items;
        List<byte[]> bfResult = getByteArrayList(user, allBFKeys);
        if (CollectionUtils.isEmpty(bfResult)) {
            return items;
        }
        return items.stream().filter(item -> !ifItemInRawBFList(item, bfResult)).collect(Collectors.toSet());
    }

    /**
     * 判断对应的元素是否在BloomFilter当中
     *
     * @param rawBFList BF的裸数据，大端。例如：
     *                  BF   ： 00010000 01000000
     *                  rawBF:  16       64
     */
    private boolean ifItemInRawBFList(T item, List<byte[]> rawBFList) {
        if (CollectionUtils.isEmpty(rawBFList) || StringUtils.isEmpty(item)) return false;
        long hash64 = Hashing.murmur3_128().hashBytes(JSONUtil.toJSON(item).getBytes(StandardCharsets.UTF_8)).asLong();
        int hash1 = (int) hash64;
        int hash2 = (int) (hash64 >>> 32);

        long combinedHash = hash1;
        List<byte[]> currentRoundBFList = rawBFList;
        List<byte[]> nextRoundBFList = Lists.newArrayListWithCapacity(rawBFList.size());
        for (int i = 0; i < hashIterations; i++) {
            long offsets = (combinedHash & Long.MAX_VALUE) % size;
            long index = offsets >> 3;//除以8,我也不知道有没有性能上的优势
            for (byte[] rawBF : currentRoundBFList) {
                if (rawBF == null || index >= rawBF.length) continue;
                byte rest = (byte) (128 >> (offsets & 7)); //除以8取余数,并转化成对应的byte
                if ((rest & rawBF[(int) index]) == 0) continue;
                nextRoundBFList.add(rawBF);
            }
            if (nextRoundBFList.size() == 0) return false;
            currentRoundBFList = nextRoundBFList;
            nextRoundBFList = Lists.newArrayListWithCapacity(rawBFList.size());
            combinedHash += hash2;
        }
        return true;
    }

    @Override
    public long count(U user) {
        final List<String> allBFKeys = allBFKeys(user);
        if (CollectionUtils.isEmpty(allBFKeys)) {
            return 0;
        }
        return allBFKeys.stream().mapToLong(this::bitSetCount).sum();
    }

    @Override
    public boolean tryInit(long expectedInsertions, double falseProbability) {
        if (falseProbability > 1) {
            throw new IllegalArgumentException("Bloom filter false probability can't be greater than 1");
        }
        if (falseProbability < 0) {
            throw new IllegalArgumentException("Bloom filter false probability can't be negative");
        }

        size = BloomFilterUtil.optimalNumOfBits(expectedInsertions, falseProbability);
        if (size == 0) {
            throw new IllegalArgumentException("Bloom filter calculated size is " + size);
        }
        if (size > getMaxSize()) {
            throw new IllegalArgumentException("Bloom filter size can't be greater than " + getMaxSize() + ". But calculated size is " + size);
        }
        hashIterations = BloomFilterUtil.optimalNumOfHashFunctions(expectedInsertions, size);
        return true;
    }

    @Override
    public long getExpectedInsertions() {
        return this.expectedInsertions;
    }

    @Override
    public double getFalseProbability() {
        return this.falseProbability;
    }

    @Override
    public long getSize() {
        return this.size;
    }

    @Override
    public int getHashIterations() {
        return this.hashIterations;
    }

    @Override
    public void clear(U user) {
        final List<String> keys = this.allBFKeys(user);
        keys.add(this.getKeyContainerKey(user));
        redisService.delSet(Sets.newHashSet(keys));
    }

    long bitSetCount(long bitSize) {
        return Math.round(-size / ((double) hashIterations) * Math.log(1 - bitSize / ((double) size)));
    }

    long bitSetCount(String currentBFKey) {
        //noinspection ConstantConditions
        return (long) redisService.getRedisTemplate()
                .execute((RedisCallback<Object>) connection ->
                        bitSetCount(connection.bitCount(currentBFKey.getBytes(StandardCharsets.UTF_8))));
    }

    private long getMaxSize() {
        return Integer.MAX_VALUE * 2L;
    }

    public long[] hash(T object) {
        long hash64 = Hashing.murmur3_128().hashBytes(JSONUtil.toJSON(object).getBytes(StandardCharsets.UTF_8)).asLong();
        int hash1 = (int) hash64;
        int hash2 = (int) (hash64 >>> 32);

        long combinedHash = hash1;
        long[] offsets = new long[hashIterations];
        for (int i = 0; i < hashIterations; i++) {
            offsets[i] = (combinedHash & Long.MAX_VALUE) % size;
            combinedHash += hash2;
        }
        return offsets;
    }

    protected ThreadLocal<RawBloomFilterCache<U>> getThreadLocal() {
        return this.threadLocal;
    }

    public void setThreadLocal(ThreadLocal<RawBloomFilterCache<U>> threadLocal) {
        this.threadLocal = threadLocal;
    }
}
