package com.ufoto.business.chat;


import com.ufoto.business.chat.dto.UfotoChatMsg;
import com.ufoto.utils.ApiResult;
import org.springframework.cloud.openfeign.FeignClient;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.ResponseBody;

import java.util.List;


@FeignClient(value = "UFOTO-CLOUD-CHAT", fallback = MsgChatBusinessHystrix.class)
public interface MsgChatBusiness {

    /**
     * 发送消息
     *
     * @param fromUid
     * @param toUid
     * @param msg
     * @param msgType  1 聊天文本消息 2 surper like推送 3 配对成功推送 4 图片消息（msg对应的为图片地址）6 语音消息  默认值 1
     * @param chatType 0 正常消息（默认）1 临时消息
     * @return
     */
    @RequestMapping(value = "/fcmMsg/sendMsg", method = RequestMethod.GET)
    @ResponseBody
    ApiResult<String> sendMsg(@RequestParam(value = "fromUid") Long fromUid, @RequestParam(value = "toUid") Long toUid,
                              @RequestParam(value = "msg") String msg, @RequestParam(value = "msgType") Integer msgType, @RequestParam(value = "chatType") Integer chatType);

    /**
     * 根据两个聊天用户id获取聊天消息列表
     *
     * @param fromUid  用户id A
     * @param toUid    用户id B
     * @param page     第一页
     * @param pageSize 每页条数
     * @return
     */
    @RequestMapping(value = "/fcmMsg/listChatMsg", method = RequestMethod.GET)
    @ResponseBody
    ApiResult<List<UfotoChatMsg>> listChatMsg(@RequestParam(value = "fromUid") Long fromUid, @RequestParam(value = "toUid") Long toUid,
                                              @RequestParam(value = "page") Integer page, @RequestParam(value = "pageSize") Integer pageSize);


    /**
     * 根据两个聊天用户id获取聊天消息列表
     *
     * @param fromUid   用户id A
     * @param toUid     用户id B
     * @param startTime 开始时间
     * @param endTime   结束时间
     * @return
     */
    @RequestMapping(value = "/fcmMsg/listChatMsgByTime", method = RequestMethod.GET)
    @ResponseBody
    ApiResult<List<UfotoChatMsg>> listChatMsgByTime(@RequestParam(value = "fromUid") Long fromUid, @RequestParam(value = "toUid") Long toUid,
                                                    @RequestParam(value = "startTime") Integer startTime, @RequestParam(value = "endTime") Integer endTime);


    /**
     * 保存用户聊天消息的最后读取时间
     *
     * @param fid
     * @param uid
     * @param msgTime 最后一条消息时间
     * @return
     */
    @RequestMapping(value = "/fcmMsg/msgRead", method = RequestMethod.GET)
    @ResponseBody
    ApiResult<String> msgRead(@RequestParam(value = "fid") Long fid, @RequestParam(value = "uid") Long uid,
                              @RequestParam(value = "msgTime") Integer msgTime);

}
