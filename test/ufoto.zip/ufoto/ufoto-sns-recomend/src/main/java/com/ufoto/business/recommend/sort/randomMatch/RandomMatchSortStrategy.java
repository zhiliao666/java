package com.ufoto.business.recommend.sort.randomMatch;

import com.ufoto.entity.UfotoUserChatActivity;

import java.util.List;

/**
 * <p>
 *
 * </p>
 *
 * @author created by chenzhou at 2018-08-02 18:41
 */
public interface RandomMatchSortStrategy {

    List<Long> sort(List<UfotoUserChatActivity> activities, UfotoUserChatActivity currentUser);

}
