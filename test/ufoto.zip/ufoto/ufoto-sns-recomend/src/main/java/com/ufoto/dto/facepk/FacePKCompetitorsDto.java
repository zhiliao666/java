package com.ufoto.dto.facepk;

import lombok.Data;

/**
 * Created by echo on 6/3/19.
 */
@Data
public class FacePKCompetitorsDto {
    Long uid;
    Integer gender;
    String headImg;
    String userName;
}
