package com.ufoto.utils.quartz;

import com.ufoto.service.UfotoAppUserService;
import com.ufoto.utils.json.JSONUtil;
import com.ufoto.utils.SpringContextUtil;
import org.quartz.Job;
import org.quartz.JobDetail;
import org.quartz.JobExecutionContext;
import org.quartz.JobExecutionException;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.core.env.Environment;
import org.springframework.stereotype.Component;

@Component
public class QuartzDemo implements Job {

    Logger logger = LoggerFactory.getLogger(QuartzDemo.class);

    @Override
    public void execute(JobExecutionContext context) throws JobExecutionException {
        final UfotoAppUserService ufotoAppUserService = SpringContextUtil.getBean("ufotoAppUserServiceImpl", UfotoAppUserService.class);
        Environment env = SpringContextUtil.getBean("environment", Environment.class);
        System.out.println(ufotoAppUserService + ":" + env);
        final JobDetail jobDetail = context.getJobDetail();
        logger.info("测试定时任务执行  job:" + JSONUtil.toJSON(jobDetail));
        logger.info("key:{}:{}", jobDetail.getKey().getName(), jobDetail.getKey().getGroup());

    }

}
