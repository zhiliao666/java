package com.ufoto.constants;

/**
 * <p>
 * Author     : Chan
 * CreateDate : 2018/9/15 10:17
 * Description: the type of card
 * this is an enum for UfotoAppCard's type
 * </p>
 */
public enum EAppCardType {
    NORMAL(0),
    INTEREST_TAG(1),
    INTEREST_CATEGORY(2),
    HINT(3),
    ADVERTISEMENT(4),
    APP_SETTING(5);

    private int type;

    EAppCardType(int type) {
        this.type = type;
    }

    public int getType() {
        return type;
    }
}
