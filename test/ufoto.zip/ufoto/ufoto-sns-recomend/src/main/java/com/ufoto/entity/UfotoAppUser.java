package com.ufoto.entity;

import com.ufoto.entity.base.BaseUfotoAppUser;

public class UfotoAppUser extends BaseUfotoAppUser {

    private static final long serialVersionUID = 1L;
    private String token; //聊天需要token

    /**
     * @return the token
     */
    public String getToken() {
        return token;
    }

    /**
     * @param token the token to set
     */
    public void setToken(String token) {
        this.token = token;
    }

}
