package com.ufoto.manager;

import com.google.common.collect.Lists;
import com.ufoto.business.usercenter.UserInfoBusiness;
import com.ufoto.business.usercenter.dto.FirstImgStateVo;
import com.ufoto.business.usercenter.dto.UfotoUserImageDo;
import com.ufoto.business.usercenter.dto.UserBaseInfoDto;
import com.ufoto.converter.UserCenterConverter;
import com.ufoto.dto.RecommendListUserCenterRequest;
import com.ufoto.dto.sns.SnsRecommendDto;
import com.ufoto.entity.UfotoAppUser;
import com.ufoto.utils.ApiResult;
import com.ufoto.utils.json.JSONUtil;
import lombok.extern.slf4j.Slf4j;
import org.springframework.core.env.Environment;
import org.springframework.stereotype.Component;
import org.springframework.util.CollectionUtils;

import java.util.Collection;
import java.util.List;
import java.util.Objects;
import java.util.stream.Collectors;

/**
 * <p>
 * Author     : Chan
 * CreateDate : 2019-04-12 10:33
 * Description:
 * </p>
 */
@Slf4j
@Component
public class UserManager {

    private final static String USER_CENTER_WARN_TAG = "UserCenterWarn ";
    private final static String USER_CENTER_DEBUG_TAG = "UserCenterDebug ";
    private final UserInfoBusiness userInfoBusiness;
    private final Environment env;

    public UserManager(UserInfoBusiness userInfoBusiness,
                       Environment env) {
        this.userInfoBusiness = userInfoBusiness;
        this.env = env;
    }

    /**
     * 查询单个用户
     *
     * @param uid 用户id
     * @return 用户
     */
    public UfotoAppUser queryUserOne(Long uid) {
        final ApiResult<UserBaseInfoDto> userBaseInfo = userInfoBusiness.getUserBaseInfo(uid);
        log.debug(USER_CENTER_DEBUG_TAG + "#userInfoBusiness.getUserBaseInfo({})#ApiResult({})", uid, JSONUtil.toJSON(userBaseInfo));
        if (!Objects.equals(userBaseInfo.getC(), ApiResult.successCode)) {
            log.warn(USER_CENTER_WARN_TAG + "#userInfoBusiness.getUserBaseInfo({})#ApiResult({})", uid, JSONUtil.toJSON(userBaseInfo));
            return null;
        }
        if (userBaseInfo.getD() == null) return null;
        return UserCenterConverter.userBaseInfo2UfotoAppUser(userBaseInfo.getD());
    }

    public List<SnsRecommendDto> recommendList(RecommendListUserCenterRequest centerRequest) {
        if (CollectionUtils.isEmpty(centerRequest.getUids())) return Lists.newArrayList();
        final ApiResult<List<SnsRecommendDto>> recommendList = userInfoBusiness.recommendList(centerRequest);
        log.debug(USER_CENTER_DEBUG_TAG + "#userInfoBusiness.recommendList({})#ApiResult({})", JSONUtil.toJSON(centerRequest), JSONUtil.toJSON(recommendList));
        if (!Objects.equals(recommendList.getC(), ApiResult.successCode)) {
            log.warn(USER_CENTER_WARN_TAG + "#userInfoBusiness.updateGeoInfo({})#ApiResult({})", JSONUtil.toJSON(centerRequest), JSONUtil.toJSON(recommendList));
            return Lists.newArrayList();
        }
        if (CollectionUtils.isEmpty(recommendList.getD())) return Lists.newArrayList();
        return recommendList.getD();
    }

    /**
     * 查询用户列表
     *
     * @param uids 用户id
     * @return 列表
     */
    public List<UfotoAppUser> queryUsers(List<Long> uids) {
        if (CollectionUtils.isEmpty(uids)) return Lists.newArrayList();
        final Integer batchSize = env.getProperty("user.batch.query", Integer.class, 2000);
        if (uids.size() < batchSize) {
            return queryUsersUnderLimit(uids);
        }
        return Lists.partition(uids, batchSize)
                .parallelStream()
                .map(this::queryUsersUnderLimit)
                .filter(lst -> !CollectionUtils.isEmpty(lst))
                .flatMap(Collection::stream)
                .collect(Collectors.toList());
    }

    /**
     * 批量查询小于一个批次
     *
     * @param uids 用户id
     * @return 列表
     */
    private List<UfotoAppUser> queryUsersUnderLimit(List<Long> uids) {
        final ApiResult<List<UserBaseInfoDto>> userBaseInfoList = userInfoBusiness.getUserBaseInfoList(uids);
        log.debug(USER_CENTER_DEBUG_TAG + "#userInfoBusiness.getUserBaseInfoList({})#ApiResult({})", uids, JSONUtil.toJSON(userBaseInfoList));
        if (!Objects.equals(userBaseInfoList.getC(), ApiResult.successCode)) {
            log.warn(USER_CENTER_WARN_TAG + "#userInfoBusiness.getUserBaseInfoList({})#ApiResult({})", uids, JSONUtil.toJSON(userBaseInfoList));
            return Lists.newArrayList();
        }
        return UserCenterConverter.userBaseInfos2UfotoAppUsers(userBaseInfoList.getD());
    }

    public List<UfotoUserImageDo> userFeedImages(Long uid) {
        FirstImgStateVo stateVo = new FirstImgStateVo();
        stateVo.setIdList(Lists.newArrayList(uid));
        final ApiResult<List<UfotoUserImageDo>> apiResult = userInfoBusiness.getUserImageByIdList(stateVo);
        if (!Objects.equals(apiResult.getC(), ApiResult.successCode)) {
            log.warn(USER_CENTER_WARN_TAG + "#userInfoBusiness.getUserImageByIdList({})#ApiResult({})", stateVo, JSONUtil.toJSON(apiResult));
            return Lists.newArrayList();
        }
        return apiResult.getD();
    }

}
