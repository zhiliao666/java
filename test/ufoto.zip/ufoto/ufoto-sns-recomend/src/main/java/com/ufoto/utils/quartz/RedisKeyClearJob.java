package com.ufoto.utils.quartz;

import com.ufoto.utils.DateUtil;
import com.ufoto.utils.SpringContextUtil;
import com.ufoto.utils.redis.RedisKeyConstant;
import com.ufoto.utils.redis.RedisService;
import lombok.extern.slf4j.Slf4j;
import org.joda.time.DateTime;
import org.joda.time.DateTimeZone;
import org.quartz.DisallowConcurrentExecution;
import org.quartz.Job;
import org.quartz.JobExecutionContext;
import org.quartz.JobExecutionException;

/**
 * <p>
 * Author     : Chan
 * CreateDate : 2019-07-26 10:43
 * Description: 目前特指daily_act_num,或者执行计划俱在北京时间零点的定时任务
 * </p>
 */
@Slf4j
@DisallowConcurrentExecution
public class RedisKeyClearJob implements Job {
    @Override
    public void execute(JobExecutionContext context) throws JobExecutionException {
        try {
            log.debug("dailyActNumStart...");
            final RedisService redisService = SpringContextUtil.getBean(RedisService.class);
            String prefix = RedisKeyConstant.REDIS_DAILY_ACT_NUM_ZSET_KEY_; // 保留七天
            DateTime today = DateTime.now(DateTimeZone.forTimeZone(DateUtil.DEFAULT_TIMEZONE));
            DateTime _7before = today.minusDays(7);
            while (true) {
                String key = prefix + _7before.toString("yyyyMMdd");
                _7before = _7before.minusDays(1);
                final long del = redisService.del(key);
                if (del <= 0) {
                    break;
                }
            }
            log.debug("dailyActNumEnd...");
        } catch (Exception e) {
            log.error(e.getMessage(), e);
        }
    }
}
