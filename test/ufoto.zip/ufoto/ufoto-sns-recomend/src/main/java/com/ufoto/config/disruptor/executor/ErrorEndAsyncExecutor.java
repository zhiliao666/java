package com.ufoto.config.disruptor.executor;

import com.ufoto.config.disruptor.constants.EventType;
import com.ufoto.config.disruptor.data.AsyncData;
import lombok.extern.slf4j.Slf4j;
import org.springframework.stereotype.Component;

/**
 * <p>
 * Description:
 *
 * </p>
 *
 * @author Chan
 * @date 2019/12/23 19:33
 */
@Slf4j
@Component
public class ErrorEndAsyncExecutor implements AsyncExecutor {
    @Override
    public void execute(AsyncData asyncData) {
        log.error("EventError: type:{}, data:{}", EventType.ASYNC_ERROR_END, asyncData);
    }
}
