package com.ufoto.utils;

import lombok.extern.slf4j.Slf4j;

/**
 * <p>
 * Description:
 *
 * </p>
 *
 * @author Chan
 * @date 2019/12/23 19:47
 */
@Slf4j
public class TryCatchExecutor {

    public static void execute(Runnable run) {
        try {
            run.run();
        } catch (Exception e) {
            log.error(e.getMessage(), e);
        }
    }

}
