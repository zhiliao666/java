package com.ufoto.config.disruptor.event;

import com.ufoto.config.disruptor.constants.EventType;
import com.ufoto.config.disruptor.data.AsyncData;
import com.ufoto.lmax.event.Event;
import lombok.Builder;
import lombok.Data;
import lombok.EqualsAndHashCode;

/**
 * <p>
 * Description:
 *
 * </p>
 *
 * @author Chan
 * @date 2019/12/21 14:57
 */
@EqualsAndHashCode(callSuper = true)
@Data
@Builder
public class AsyncEvent extends Event {

    private EventType eventType;
    private AsyncData asyncData;
}
