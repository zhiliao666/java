package com.ufoto.utils.quartz;

import com.ufoto.utils.ApiResult;
import com.ufoto.utils.quartz.service.QuartzService;
import org.quartz.Job;
import org.quartz.SchedulerException;
import org.quartz.Trigger;
import org.quartz.TriggerKey;
import org.springframework.beans.BeanUtils;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;

/**
 * <p>
 * Author     : Chan
 * CreateDate : 2018/11/20 13:30
 * Description:
 * </p>
 */
public class BaseJobController {
    private final QuartzService quartzService;
    private final String groupName;
    private final String jobName;
    private final String defaultCron;
    private final Class<? extends Job> jobClass;
    private final String description;

    public BaseJobController(QuartzService quartzService, String groupName, String jobName,
                             String cron, Class<? extends Job> jobClass, String description) {
        this.quartzService = quartzService;
        this.groupName = groupName;
        this.jobName = jobName;
        this.jobClass = jobClass;
        this.description = description;
        defaultCron = cron;
    }

    @RequestMapping("/executeJob")
    public ApiResult executeJob() throws SchedulerException {
        final Job job = BeanUtils.instantiateClass(jobClass);
        job.execute(null);
        return new ApiResult();
    }

    @RequestMapping("/start")
    public ApiResult start() throws SchedulerException {
        final boolean exists = quartzService.checkExists(new TriggerKey(jobName, groupName));
        if (!exists) {//不存在 添加  存在 忽略
            QuartzTaskInfo info = new QuartzTaskInfo(groupName, jobName, description, jobClass.getName(), defaultCron);
            quartzService.addJob(info);
        }
        return new ApiResult();
    }

    @RequestMapping("/edit")
    public ApiResult edit(@RequestParam String cron) throws SchedulerException {
        final boolean exists = quartzService.checkExists(new TriggerKey(jobName, groupName));
        if (exists) {
            QuartzTaskInfo info = new QuartzTaskInfo(groupName, jobName, description, jobClass.getName(), cron);
            quartzService.edit(info);
            return new ApiResult();
        }
        return new ApiResult().setError(ApiResult.errorCode500, "任务不存在，不能编辑");
    }

    @RequestMapping("/pause")
    public ApiResult pauseRandomMatchJob() {
        quartzService.pause(jobName, groupName);
        return new ApiResult();
    }

    @RequestMapping("/resume")
    public ApiResult resumeRandomMatchJob() {
        quartzService.resume(jobName, groupName);
        return new ApiResult();
    }

    @RequestMapping("/remove")
    public ApiResult removeRandomMatchJob() {
        quartzService.delete(jobName, groupName);
        return new ApiResult();
    }


    /**
     * 查询任务状态
     *
     * @return
     * @throws SchedulerException
     */
    @RequestMapping("/checkState")
    public ApiResult<Trigger.TriggerState> checkState() throws SchedulerException {
        return new ApiResult<Trigger.TriggerState>().setResult(quartzService.checkTriggerState(jobName, groupName));
    }
}
