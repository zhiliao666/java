package com.ufoto.annotation;

import java.lang.annotation.Documented;
import java.lang.annotation.ElementType;
import java.lang.annotation.Retention;
import java.lang.annotation.RetentionPolicy;
import java.lang.annotation.Target;

/**
 * 标识当前项目中 与recommend接口相关的所有基础策略
 */
@Target(ElementType.TYPE)
@Retention(RetentionPolicy.RUNTIME)
@Documented
public @interface RecommendMetadata {

    /**
     * 元数据的类型
     *
     * @return type
     */
    MetadataType metadataType() default MetadataType.None;

    /**
     * 是否在用
     * 需要明确指定,特殊情况下可通过其值依赖注入
     *
     * @return true for available
     */
    boolean available() default false;

    /**
     * 是否默认更新当前策略的缓存
     * 需要明确指定 确定当前策略是否需要加载本地缓存
     *
     * @return true for update
     */
    boolean updateCache() default false;

    /**
     * 策略名称
     *
     * @return name
     */
    String name() default "";

    /**
     * 元素据描述信息
     *
     * @return description
     */
    String description() default "";

    /**
     * 当前策略隶属于哪个分支
     * 一般用于推荐入口的策略判定  哪些策略可以在当前入口处使用
     *
     * @return 默认每个分支都可以使用
     */
    Branch[] branch() default {Branch.NORMAL, Branch.DEFAULT, Branch.GIFT, Branch.High_Risk};

    /**
     * AB测试, 当前策略应属于A/B策略.
     * 默认不区分
     *
     * @return A/B
     */
    ABTest abTest() default ABTest.None;

    enum MetadataType {
        None,
        RECALL,
        FILTER,
        SORT,
        INVOKER,
        REAGENT,
        SHUFFLE,
        CUTTER,
        DEALER,
        CAPTAIN,
        CARD_RECALL
    }

    enum Branch {
        NORMAL,//正常的 用户可以使用
        USERLAYER,//用户分层分支
        DEFAULT,//默认的--
        GIFT,//礼物--
        High_Risk,//高危用户--
        WINK//WINK --
    }

    enum ABTest {
        None,
        A,
        B
    }

}
