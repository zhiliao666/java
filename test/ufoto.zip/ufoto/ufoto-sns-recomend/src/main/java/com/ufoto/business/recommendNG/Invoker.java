package com.ufoto.business.recommendNG;

import com.fasterxml.jackson.core.type.TypeReference;
import com.fasterxml.jackson.databind.ObjectMapper;
import com.ufoto.dto.RecommendAdvanceRequest;
import com.ufoto.log.LogTopicConstant;
import com.ufoto.utils.json.JSONUtil;

import java.util.List;
import java.util.Map;
import java.util.Set;

/**
 * If you have ever played DOTA, maybe you should know Kael.
 * <p>
 * Created by echo on 10/10/18.
 */
public interface Invoker {


    /**
     * @param minSize       最少需要返回多少内容
     * @param recallRequest 客户端发起请求的所有参数
     * @param invokedUidSet 之前缓存的召回内容
     * @return
     */
    List<String> invoke(Integer minSize,
                        RecommendAdvanceRequest recallRequest,
                        Set<String> invokedUidSet);

    /**
     * 目前的线上策略配置会对相同的Invoker调用多次，
     * 为了提高性能会以ThreadLocal的形式保存对应Invoker的计算结果。
     * 由于线程复用，需要在每次开始之前调用此方法，清理之前的缓存结果。
     */
    void cleanThreadLocalCache();

    default void invokerLog(Integer minSize, RecommendAdvanceRequest request, List<String> result, String type) {
        ObjectMapper mapper = new ObjectMapper();
        Map<String, Object> info = mapper.convertValue(request, new TypeReference<Map<String, Object>>() {
        });
        info.put("className", this.toString());
        info.put("result", result);
        info.put("type", type);
        info.put("category", "invoker");
        info.put("minSize", minSize);
        info.put("timestamp", System.currentTimeMillis());
        LogTopicConstant.invokerLogger.info(JSONUtil.toJSON(info));
    }
}
