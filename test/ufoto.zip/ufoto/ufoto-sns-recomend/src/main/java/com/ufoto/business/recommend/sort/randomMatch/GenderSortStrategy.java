package com.ufoto.business.recommend.sort.randomMatch;

import com.google.common.collect.Maps;
import com.ufoto.constants.EGender;
import com.ufoto.entity.UfotoUserChatActivity;
import com.ufoto.utils.KeyTransitionUtil;
import com.ufoto.utils.redis.RedisService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;
import org.springframework.util.CollectionUtils;

import java.util.List;
import java.util.Map;
import java.util.Objects;
import java.util.stream.Collectors;

/**
 * <p>
 *
 * </p>
 *
 * @author created by chenzhou at 2018-08-02 17:47
 */
@Component
public class GenderSortStrategy extends BaseNormalRandomMatchSortStrategy {
    @Autowired
    private RedisService redisService;

    @Override
    public Map<Long, Double> getScore(List<UfotoUserChatActivity> activities, UfotoUserChatActivity currentUser) {
        Map<Long, Double> uidScoreMap = Maps.newHashMap();
        if (!CollectionUtils.isEmpty(activities)) {
            List<Long> uids = activities.stream().map(UfotoUserChatActivity::getUId).collect(Collectors.toList());
            uids.add(currentUser.getUId());
            final Map<Long, Integer> genderMap = KeyTransitionUtil.selectGenders(redisService, uids.stream().map(String::valueOf).collect(Collectors.toList()));
            final Integer currentGender = genderMap.get(currentUser.getUId());
            //移除自己
            uids.remove(currentUser.getUId());
            for (Long uid : uids) {
                final Integer gender = genderMap.get(uid);
                if (currentGender == null || currentGender == EGender.OTHER.getType()) {
                    uidScoreMap.put(uid, gender != null ? 1D : 0);
                } else {
                    if (gender == null || gender == EGender.OTHER.getType()) {
                        uidScoreMap.put(uid, 0D);
                    } else {
                        if (Objects.equals(gender, currentGender)) {
                            uidScoreMap.put(uid, 1D);
                        } else {
                            uidScoreMap.put(uid, 2D);
                        }
                    }
                }
            }
        }
        return uidScoreMap;
    }
}
