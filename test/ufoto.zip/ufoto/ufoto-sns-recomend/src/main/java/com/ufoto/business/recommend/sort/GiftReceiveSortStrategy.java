package com.ufoto.business.recommend.sort;

import com.ufoto.business.recommend.sort.random.RandomSortStrategy;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;

/**
 * Created by echo on 5/24/19.
 */
//gift
@Component
public class GiftReceiveSortStrategy extends CompositeRecommendSortStrategy {

    @Autowired
    public GiftReceiveSortStrategy(
            RandomSortStrategy randomSortStrategy
    ) {
        this.sortStrategyWeightMap.put(randomSortStrategy, 1d);
    }
}
