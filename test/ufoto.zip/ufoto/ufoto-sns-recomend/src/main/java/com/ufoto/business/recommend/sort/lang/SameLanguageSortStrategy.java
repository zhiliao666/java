package com.ufoto.business.recommend.sort.lang;

import com.google.common.collect.Sets;
import com.ufoto.annotation.RecommendMetadata;
import com.ufoto.business.recommend.bean.SortParamsBean;
import com.ufoto.business.recommend.sort.BaseNormalSortStrategy;
import com.ufoto.utils.redis.RedisKeyConstant;
import com.ufoto.utils.redis.RedisKeyUtil;
import com.ufoto.utils.redis.RedisService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;

import java.nio.charset.StandardCharsets;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.Set;

/**
 * Created by echo on 4/8/18.
 */
@RecommendMetadata(
        metadataType = RecommendMetadata.MetadataType.SORT,
        name = "相同语言排序策略",
        description = "语言相同分数为1,反之为0,已废弃"
)
@Component
@Deprecated
public class SameLanguageSortStrategy extends BaseNormalSortStrategy {

    @Autowired
    private RedisService redisService;

    /**
     * 返回对应用户是否和我语言相同
     *
     * @param recallUids
     * @return
     */
    @Override
    public Map<String, Double> getScore(List<String> recallUids, SortParamsBean sortParamsBean) {
        Set<String> sameLanguageUidSet = getSameLanguageUidSet(sortParamsBean, recallUids);
        Map<String, Double> scoreMap = new HashMap<>();
        for (final String recallUid : recallUids) {
            final boolean isSameLanguage = sameLanguageUidSet.contains(recallUid);
            scoreMap.put(recallUid, isSameLanguage ? 1d : 0d);
        }
        return scoreMap;
    }

    /**
     * 获取和当前请求用户相同语言的ID
     * <p>
     * 20180905：
     * 第一版，为了快速上线验证效果，只判断是否是BR的用户,来确定语言是否相同
     * 后续考虑将所有用户的语言都存入Redis或者数据库,然后直接按照语言来进行匹配
     *
     * @param sortParamsBean
     * @param recallUids
     * @return
     */
    private Set<String> getSameLanguageUidSet(SortParamsBean sortParamsBean, List<String> recallUids) {
        Set<String> result = Sets.newHashSet();
        String countryCode = sortParamsBean.getCountryCode();
        final List<Object> objects = redisService.execPipelineForRead(connection -> {
            for (String recallUid : recallUids) {
                connection.sIsMember((RedisKeyConstant.REDIS_REGION_USERS_SET_KEY_ + "BR").getBytes(StandardCharsets.UTF_8),
                        RedisKeyUtil.serializeUid(recallUid).getBytes(StandardCharsets.UTF_8));
            }
            return null;
        });
        boolean ifUserFromBR = countryCode != null && countryCode.equals("BR");

        final int size = recallUids.size();
        for (int i = 0; i < size; i++) {
            final Boolean ifBR = (Boolean) objects.get(i);
            if (ifUserFromBR && ifBR) {//如果发起请求的用户，和召回的内容都是BR的，则加入返回结果
                result.add(recallUids.get(i));
            } else if (!ifUserFromBR && !ifBR) {//如果发起请求的用户，和召回的内容都 不不不 是BR的，则加入返回结果
                result.add(recallUids.get(i));
            }
        }

        return result;
    }
}
