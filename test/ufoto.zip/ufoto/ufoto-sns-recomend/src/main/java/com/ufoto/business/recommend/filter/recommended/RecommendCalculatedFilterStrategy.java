package com.ufoto.business.recommend.filter.recommended;

import com.google.common.collect.Sets;
import com.ufoto.annotation.RecommendMetadata;
import com.ufoto.bloom.RecommendCalculatedBloomFilter;
import com.ufoto.business.recommend.RecommendFilterStrategy;
import com.ufoto.business.recommend.filter.FilterUtil;
import com.ufoto.dto.RecommendAdvanceRequest;
import com.ufoto.utils.DirtyCaseUtil;
import lombok.extern.slf4j.Slf4j;
import org.springframework.stereotype.Component;
import org.springframework.util.CollectionUtils;

import java.util.HashSet;
import java.util.List;
import java.util.Set;

/**
 * <p>
 * Description:
 *
 * </p>
 *
 * @author Chan
 * @date 2019/12/21 13:30
 */
@Slf4j
@RecommendMetadata(
        metadataType = RecommendMetadata.MetadataType.FILTER,
        available = true,
        name = "推荐计算过的用户过滤策略",
        description = "推荐计算过的用户指的是推荐列表已经推给客户端的用户,当天有效,并保留like过当前用户的用户",
        branch = {
                RecommendMetadata.Branch.NORMAL,
                RecommendMetadata.Branch.DEFAULT,
                RecommendMetadata.Branch.High_Risk,
                RecommendMetadata.Branch.USERLAYER
        }
)
@Component
public class RecommendCalculatedFilterStrategy implements RecommendFilterStrategy {

    private final RecommendCalculatedBloomFilter recommendCalculatedBloomFilter;
    private final DirtyCaseUtil dirtyCaseUtil;
    private final FilterUtil filterUtil;

    public RecommendCalculatedFilterStrategy(RecommendCalculatedBloomFilter recommendCalculatedBloomFilter,
                                             DirtyCaseUtil dirtyCaseUtil,
                                             FilterUtil filterUtil) {
        this.recommendCalculatedBloomFilter = recommendCalculatedBloomFilter;
        this.dirtyCaseUtil = dirtyCaseUtil;
        this.filterUtil = filterUtil;
    }

    @Override
    public Set<String> filter(Set<String> recallSet, List<String> resultList, RecommendAdvanceRequest filterRequest) {
        if (CollectionUtils.isEmpty(recallSet)) {
            return Sets.newHashSet();
        }
        return filterByBF(recallSet, filterRequest);
    }

    private Set<String> filterByBF(Set<String> recallSet, RecommendAdvanceRequest filterRequest) {
        Long uid = filterRequest.getUid();
        if (uid == null) return recallSet;
        Set<String> result = new HashSet<>(recallSet);
        result = recommendCalculatedBloomFilter.filter(uid, result);
        log.debug("RecommendCalculated uid:{},recallSet:{},result:{}",
                filterRequest.getUid(), recallSet, result);
        	// 非snap用户无需过滤推荐过的用户
        	
//            final Set<String> whoLikedMe = filterUtil.whoLikedMe(filterRequest);
//            //当前set中当前用户未读的like
//            final Sets.SetView<String> intersection = Sets.intersection(result, whoLikedMe);
//            //过滤条推荐已经计算过的用户
//            result = recommendCalculatedBloomFilter.filter(uid, result);
//            //用户未读的like添加到当前的set
//            result.addAll(intersection);
//            log.debug("RecommendCalculated uid:{},recallSet:{},intersection:{},result:{}",
//                    filterRequest.getUid(), recallSet, intersection, result);
        return result;
    }
}
