package com.ufoto.business.recommend.shuffle.dealer;

import com.ufoto.annotation.RecommendMetadata;
import com.ufoto.business.recommend.shuffle.base.ShuffleDealer;
import org.apache.commons.lang.math.RandomUtils;
import org.springframework.util.CollectionUtils;

import java.security.InvalidParameterException;
import java.util.List;

/**
 * 规定，
 * list 1 是chatbot
 * list 2 是其他
 */
@RecommendMetadata(
        metadataType = RecommendMetadata.MetadataType.DEALER,
        available = true,
        name = "聊天机器人收集器",
        description = "随机取指定数量的聊天机器人,合并list,非聊天机器人不足20,聊天机器人直接放在最后,否则随机插入在非聊天机器人中",
        branch = RecommendMetadata.Branch.NORMAL
)
public class DealChatBotDealer implements ShuffleDealer {

    private final static int MAX_CHAT_BOT_INDEX = 20;

    private int minChatBotCount;
    private int maxChatBotCount;

    public DealChatBotDealer(int minChatBotCount, int maxChatBotCount) {
        this.minChatBotCount = minChatBotCount;
        this.maxChatBotCount = maxChatBotCount;
        if (this.minChatBotCount > this.maxChatBotCount) {
            this.minChatBotCount = maxChatBotCount;
            this.maxChatBotCount = minChatBotCount;
        }
    }

    @Override
    public String[] shuffleAndDeal(List<List<String>> cutUidList) {
        if (cutUidList.size() != 2)
            throw new InvalidParameterException("DealChatBotDealer input size error:" + cutUidList.size());
        List<String> chatBotList = cutUidList.get(0);
        List<String> otherList = cutUidList.get(1);
        if (CollectionUtils.isEmpty(chatBotList)) return otherList.toArray(new String[0]);
        if (otherList.size() <= MAX_CHAT_BOT_INDEX) {
            otherList.addAll(chatBotList);
            return otherList.toArray(new String[0]);
        }

        int chatBotCount = RandomUtils.nextInt(maxChatBotCount - minChatBotCount + 1) + minChatBotCount;
        final int finalChatBotCount = chatBotCount > chatBotList.size() ? chatBotList.size() : chatBotCount;
        for (int _ = 0; _ < finalChatBotCount; _++) {
            int chatBotIndex = RandomUtils.nextInt(MAX_CHAT_BOT_INDEX);
            otherList.add(chatBotIndex, chatBotList.get(0));
            chatBotList.remove(0);
        }
        otherList.addAll(chatBotList);
        return otherList.toArray(new String[0]);
    }

}
