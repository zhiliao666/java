package com.ufoto.business.recommend.shuffle.base;

import com.google.common.collect.Maps;
import com.ufoto.business.recommend.RecommendShuffleStrategy;

import java.util.Map;

/**
 * Created by echo on 7/11/18.
 */
public class BaseShuffleStrategy implements RecommendShuffleStrategy {

    protected ShuffleCutter cutter;
    protected ShuffleDealer dealer;

    @Override
    public String[] shuffle(String[] uidArray) {
        String[] result = dealer.shuffleAndDeal(cutter.cut(uidArray));

        Map<String, Object> info = Maps.newHashMap();
        String className = this.getClass().toString();
        info.put("className", className);
        info.put("result", result);
        info.put("type", "shuffle");

        return result;
    }

}
