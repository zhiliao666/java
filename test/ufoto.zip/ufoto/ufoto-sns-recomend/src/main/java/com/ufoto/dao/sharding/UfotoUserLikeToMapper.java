package com.ufoto.dao.sharding;

import com.ufoto.dao.base.BaseUfotoUserLikeToMapper;
import org.apache.ibatis.annotations.Mapper;
import org.apache.ibatis.annotations.Select;

import java.util.List;

@Mapper
public interface UfotoUserLikeToMapper extends BaseUfotoUserLikeToMapper {

    @Select("SELECT f_u_id FROM ufoto_user_like_t WHERE t_u_id = #{uid} order by create_time desc")
    List<String> selectLikeByTUidOrdered(Long uid);
}
