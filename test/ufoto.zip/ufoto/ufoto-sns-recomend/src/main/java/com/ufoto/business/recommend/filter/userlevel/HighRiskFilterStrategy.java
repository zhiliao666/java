package com.ufoto.business.recommend.filter.userlevel;

import com.google.common.collect.Sets;
import com.ufoto.annotation.RecommendMetadata;
import com.ufoto.business.recommend.RecommendFilterStrategy;
import com.ufoto.business.recommend.filter.FilterUtil;
import com.ufoto.dto.RecommendAdvanceRequest;
import com.ufoto.utils.redis.RedisKeyConstant;
import com.ufoto.utils.redis.RedisServiceObjService;
import lombok.RequiredArgsConstructor;
import lombok.extern.slf4j.Slf4j;
import org.springframework.stereotype.Component;
import org.springframework.util.CollectionUtils;

import java.util.List;
import java.util.Set;
import java.util.stream.Collectors;

/**
 * <p>
 * Description:
 *
 * </p>
 *
 * @author Chan
 * @date 2020/2/14 09:39
 */
@RecommendMetadata(
        metadataType = RecommendMetadata.MetadataType.FILTER,
        available = true,
        updateCache = true,
        name = "高危用户过滤策略",
        description = "过滤用户分层后的高危用户",
        branch = {
                RecommendMetadata.Branch.NORMAL,
                RecommendMetadata.Branch.DEFAULT,
                RecommendMetadata.Branch.GIFT,
                RecommendMetadata.Branch.USERLAYER,
                RecommendMetadata.Branch.WINK
        }
)
@Slf4j
@RequiredArgsConstructor
@Component
public class HighRiskFilterStrategy implements RecommendFilterStrategy {

    private final RedisServiceObjService redisServiceObjService;
    private final FilterUtil filterUtil;

    @Override
    public Set<String> filter(Set<String> recallSet, List<String> resultList, RecommendAdvanceRequest filterRequest) {
        // 过滤高危用户
        // 1. 高危状态写入用户画像
        // 2. 获取用户画像中的高危状态
        return filterUtil.filter(recallSet, this.getClass());
    }

    public Set<String> updateCache() {
        final Set<Long> members = redisServiceObjService.smembers(RedisKeyConstant.REDIS_HIGH_RISK_USER, true);
        if (CollectionUtils.isEmpty(members)) {
            return Sets.newHashSet();
        }
        return members.stream().map(String::valueOf).collect(Collectors.toSet());
    }
}
