package com.ufoto.business.recommend.sort.likeme;

import com.ufoto.annotation.RecommendMetadata;
import com.ufoto.business.recommend.bean.SortParamsBean;
import com.ufoto.business.recommend.sort.BaseNormalSortStrategy;
import com.ufoto.utils.redis.RedisKeyConstant;
import com.ufoto.utils.redis.RedisKeyUtil;
import com.ufoto.utils.redis.RedisService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;

import java.nio.charset.StandardCharsets;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

/**
 * Created by echo on 4/8/18.
 */
@RecommendMetadata(
        metadataType = RecommendMetadata.MetadataType.SORT,
        name = "superlike排序策略",
        description = "superlike当前用户,分数为1,反之为0,已废弃."
)
@Component
@Deprecated
public class SuperLikedMeSortStrategy extends BaseNormalSortStrategy {

    @Autowired
    private RedisService redisService;

    /**
     * 返回这个用户是否SuperLike 我
     *
     * @param recallUids
     * @return
     */
    @Override
    public Map<String, Double> getScore(List<String> recallUids, SortParamsBean sortParamsBean) {
        final Long uid = sortParamsBean.getUid();
        final List<Object> scores = redisService.execPipelineForRead(connection -> {
            for (String recallUid : recallUids) {
                connection.sIsMember((RedisKeyConstant.REDIS_BE_SUPER_LIKED_SET_KEY_ + uid).getBytes(StandardCharsets.UTF_8),
                        RedisKeyUtil.serializeUid(recallUid).getBytes(StandardCharsets.UTF_8));
            }
            return null;
        });
        //recall id score 对应 map
        Map<String, Double> scoreMap = new HashMap<>();
        //logging score detail
        Map<String, Map<String, String>> scoreDetail = new HashMap<>();
        final int size = recallUids.size();
        for (int i = 0; i < size; i++) {
            boolean isLikeMe = (boolean) scores.get(i);
            scoreMap.put(recallUids.get(i), isLikeMe ? 1d : 0d);
            Map<String, String> map = new HashMap<>();
            map.put("SUPER_LIKED_ME", Boolean.toString(isLikeMe));
            scoreDetail.put(recallUids.get(i), map);
        }
        return scoreMap;
    }
}
