package com.ufoto.config.mysql;

import com.zaxxer.hikari.HikariDataSource;
import io.shardingjdbc.core.api.ShardingDataSourceFactory;
import io.shardingjdbc.core.api.config.ShardingRuleConfiguration;
import io.shardingjdbc.core.api.config.TableRuleConfiguration;
import io.shardingjdbc.core.api.config.strategy.InlineShardingStrategyConfiguration;
import lombok.extern.slf4j.Slf4j;
import org.apache.ibatis.session.SqlSessionFactory;
import org.mybatis.spring.SqlSessionFactoryBean;
import org.mybatis.spring.SqlSessionTemplate;
import org.mybatis.spring.annotation.MapperScan;
import org.springframework.beans.BeanUtils;
import org.springframework.beans.factory.annotation.Qualifier;
import org.springframework.boot.context.properties.ConfigurationProperties;
import org.springframework.boot.jdbc.DataSourceBuilder;
import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;
import org.springframework.jdbc.datasource.DataSourceTransactionManager;

import javax.sql.DataSource;
import java.sql.SQLException;
import java.util.HashMap;
import java.util.Map;
import java.util.Properties;
import java.util.concurrent.ConcurrentHashMap;

/**
 * Created by echo on 3/20/18.
 */
@Slf4j
@Configuration
@MapperScan(basePackages = "com.ufoto.dao.svd", sqlSessionTemplateRef = "svdSqlSessionTemplate")
public class SvdDataSourceConfig {

    @Bean(name = "svdDataSource00")
    @ConfigurationProperties(prefix = "spring.datasource.svd.ds0")
    public HikariDataSource svdDataSource00(Hikari hikari) {
        final HikariDataSource dataSource = DataSourceBuilder.create().type(HikariDataSource.class).build();
        BeanUtils.copyProperties(hikari, dataSource);
        return dataSource;
    }

    @Bean
    @Qualifier("svdDataSource")
    public DataSource svdDataSource(@Qualifier("svdDataSource00") DataSource svdDataSource00) throws SQLException {
        // 配置真实数据源
        Map<String, DataSource> dataSourceMap = new HashMap<>();
        dataSourceMap.put("ds0", svdDataSource00);

        // 配置分表规则
        // SVD表
        TableRuleConfiguration orderTableRuleConfig = new TableRuleConfiguration();
        orderTableRuleConfig.setLogicTable("ufoto_svd_user_top_n");
        orderTableRuleConfig.setActualDataNodes("ds0.ufoto_svd_user_top_n_${0..9}");
        orderTableRuleConfig.setTableShardingStrategyConfig(
                new InlineShardingStrategyConfiguration("u_id", "ufoto_svd_user_top_n_${u_id % 10}"));

        // AreaSVD表
        TableRuleConfiguration orderAreaTableRuleConfig = new TableRuleConfiguration();
        orderAreaTableRuleConfig.setLogicTable("ufoto_area_svd_user_top_n");
        orderAreaTableRuleConfig.setActualDataNodes("ds0.ufoto_area_svd_user_top_n_${0..9}");
        orderAreaTableRuleConfig.setTableShardingStrategyConfig(
                new InlineShardingStrategyConfiguration("u_id", "ufoto_area_svd_user_top_n_${u_id % 10}"));

        // AreaSVD2表
        TableRuleConfiguration orderArea2TableRuleConfig = new TableRuleConfiguration();
        orderArea2TableRuleConfig.setLogicTable("ufoto_area_svd_2_user_top_n");
        orderArea2TableRuleConfig.setActualDataNodes("ds0.ufoto_area_svd_2_user_top_n_${0..9}");
        orderArea2TableRuleConfig.setTableShardingStrategyConfig(
                new InlineShardingStrategyConfiguration("u_id", "ufoto_area_svd_2_user_top_n_${u_id % 10}"));

        // TwoSide SVD表
        TableRuleConfiguration orderTwoSideTableRuleConfig = new TableRuleConfiguration();
        orderTwoSideTableRuleConfig.setLogicTable("ufoto_svd_user_top_n_match");
        orderTwoSideTableRuleConfig.setActualDataNodes("ds0.ufoto_svd_user_top_n_match_${0..9}");
        orderTwoSideTableRuleConfig.setTableShardingStrategyConfig(
                new InlineShardingStrategyConfiguration("u_id", "ufoto_svd_user_top_n_match_${u_id % 10}"));

        // TwoSide SVD2表
        TableRuleConfiguration orderTwoSide2TableRuleConfig = new TableRuleConfiguration();
        orderTwoSide2TableRuleConfig.setLogicTable("ufoto_svd_2_user_top_n_match");
        orderTwoSide2TableRuleConfig.setActualDataNodes("ds0.ufoto_svd_2_user_top_n_match_${0..9}");
        orderTwoSide2TableRuleConfig.setTableShardingStrategyConfig(
                new InlineShardingStrategyConfiguration("u_id", "ufoto_svd_2_user_top_n_match_${u_id % 10}"));
        // 配置分片规则
        ShardingRuleConfiguration shardingRuleConfig = new ShardingRuleConfiguration();
        shardingRuleConfig.getTableRuleConfigs().add(orderTableRuleConfig);
        shardingRuleConfig.getTableRuleConfigs().add(orderAreaTableRuleConfig);
        shardingRuleConfig.getTableRuleConfigs().add(orderTwoSideTableRuleConfig);
        shardingRuleConfig.getTableRuleConfigs().add(orderArea2TableRuleConfig);
        shardingRuleConfig.getTableRuleConfigs().add(orderTwoSide2TableRuleConfig);
        // 获取数据源对象
        final Properties props = new Properties();
        if (log.isDebugEnabled()) {
            props.setProperty("sql.show", "true");
        }
        return ShardingDataSourceFactory.createDataSource(dataSourceMap, shardingRuleConfig, new ConcurrentHashMap<>(), props);
    }

    @Bean(name = "svdSqlSessionFactory")
    public SqlSessionFactory svdSqlSessionFactory(@Qualifier("svdDataSource") DataSource dataSource) throws Exception {
        SqlSessionFactoryBean bean = new SqlSessionFactoryBean();
        bean.setDataSource(dataSource);
        return bean.getObject();
    }

    @Bean(name = "svdSqlSessionTemplate")
    public SqlSessionTemplate svdSqlSessionTemplate(@Qualifier("svdSqlSessionFactory") SqlSessionFactory sqlSessionFactory) throws Exception {
        return new SqlSessionTemplate(sqlSessionFactory);
    }

    @Bean(name = "svdTransactionManager")
    public DataSourceTransactionManager svdTransactionManager(@Qualifier("svdDataSource") DataSource dataSource) {
        return new DataSourceTransactionManager(dataSource);
    }
}
