package com.ufoto.constants;

/**
 * <p>
 * Author     : Chan
 * CreateDate : 2018/10/9 15:53
 * Description:
 * </p>
 */
public enum EAppCardTypeSub {
    LANGUAGE(0),
    SPORT(1),
    MUSIC(2),
    FOOD(3),
    MOVIE(4),
    BOOK(5),
    CITY(6);

    private int typeSub;

    EAppCardTypeSub(int typeSub) {
        this.typeSub = typeSub;
    }

    public int getTypeSub() {
        return typeSub;
    }
}
