package com.ufoto.business.recommend.sort;

import com.ufoto.business.recommend.RecommendSortStrategy;
import com.ufoto.business.recommend.bean.SortParamsBean;
import lombok.extern.slf4j.Slf4j;

import java.util.*;
import java.util.stream.Collectors;

/**
 * Created by echo on 4/3/18.
 */
@Slf4j
public abstract class CompositeRecommendSortStrategy implements RecommendSortStrategy, SpecificRecommendSortStrategy {

    protected Map<SpecificRecommendSortStrategy, Double> sortStrategyWeightMap = new HashMap<>();

    /**
     * 新版排序策略：20180402
     *
     * @param recallSet 召回的用户ID集合
     * @return
     */
    @Override
    public String[] sort(Set<String> recallSet, SortParamsBean sortParamsBean) {
    	
        Map<String, Double> uidScoreMap = new LinkedHashMap<>();
        
        // 如果存在无需排序的排序策略则直接返回原结果也就是不排序
        for (Map.Entry<SpecificRecommendSortStrategy, Double> entry : sortStrategyWeightMap.entrySet()) {
        	SpecificRecommendSortStrategy sort = entry.getKey();
        	if(sort instanceof NoSortStrategy) {
        		return recallSet.stream().collect(Collectors.toList()).toArray(new String[]{});
        	}
        }
        
        for (String recallUid : recallSet) {
            uidScoreMap.put(recallUid, 0D);
        }

        for (Map.Entry<SpecificRecommendSortStrategy, Double> entry : sortStrategyWeightMap.entrySet()) {
            uidScoreMap = entry.getKey().addScoreBatch(uidScoreMap, entry.getValue(), sortParamsBean);
            log.debug("recallFilterSortShuffleResult->sort->{}::{}", entry.getKey().getClass().getSimpleName(), uidScoreMap);
        }

        List<Map.Entry<String, Double>> list = getSortedMapList(uidScoreMap);
        if (log.isDebugEnabled()) {
            list.forEach(stringDoubleEntry -> log.debug(stringDoubleEntry.getKey() + "-score:" + stringDoubleEntry.getValue()));
        }
        return list.parallelStream().map(Map.Entry::getKey).collect(Collectors.toList()).toArray(new String[]{});
    }

    private List<Map.Entry<String, Double>> getSortedMapList(Map<String, Double> finalScoreMap) {
        List<Map.Entry<String, Double>> list = new LinkedList<>(finalScoreMap.entrySet());
        list.sort((o1, o2) -> -1 * (o1.getValue()).compareTo(o2.getValue()));
        return list;
    }

    @Override
    public Map<String, Double> addScoreBatch(Map<String, Double> uidScoreMap, Double weight, SortParamsBean sortParamsBean) {
        for (Map.Entry<SpecificRecommendSortStrategy, Double> entry : sortStrategyWeightMap.entrySet()) {
            uidScoreMap = entry.getKey().addScoreBatch(uidScoreMap, entry.getValue(), sortParamsBean);
        }
        return uidScoreMap;
    }

    @Override
    public Map<String, Double> getScore(List<String> recallUids, SortParamsBean sortParamsBean) {
        Map<String, Double> scoreResultMap = new HashMap<>();
        for (Map.Entry<SpecificRecommendSortStrategy, Double> entry : sortStrategyWeightMap.entrySet()) {
            final Map<String, Double> scoreMap = entry.getKey().getScore(recallUids, sortParamsBean);
            scoreMap.forEach((recallId, score) -> scoreResultMap.merge(recallId, score * entry.getValue(), Double::sum));
        }
        return scoreResultMap;
    }

    public Map<SpecificRecommendSortStrategy, Double> getSortStrategyWeightMap() {
        return sortStrategyWeightMap;
    }

    public void setSortStrategyWeightMap(Map<SpecificRecommendSortStrategy, Double> sortStrategyWeightMap) {
        this.sortStrategyWeightMap = sortStrategyWeightMap;
    }
}
