package com.ufoto.entity;

import com.ufoto.entity.base.BaseUfotoSvdUserTopN;

public class UfotoSvdUserTopN extends BaseUfotoSvdUserTopN {

    private static final long serialVersionUID = 1L;

}
