package com.ufoto.config.disruptor.exception;


import com.lmax.disruptor.ExceptionHandler;
import com.ufoto.config.disruptor.constants.EventType;
import com.ufoto.config.disruptor.event.AsyncEvent;
import com.ufoto.lmax.ContextEvent;
import lombok.extern.slf4j.Slf4j;

/**
 * 推荐计算的异常处理类
 */
@Slf4j
public class RecommendCalculateExceptionHandler implements ExceptionHandler<ContextEvent<AsyncEvent>> {

    @Override
    public void handleEventException(Throwable ex, long sequence, ContextEvent<AsyncEvent> event) {
        event.getContext().setEventType(EventType.ASYNC_ERROR_END);
        log.error(String.format("sequence=%d,event=%s", sequence, event), ex);
    }

    @Override
    public void handleOnStartException(Throwable ex) {
        log.error(ex.getMessage(), ex);
    }

    @Override
    public void handleOnShutdownException(Throwable ex) {
        log.error(ex.getMessage(), ex);
    }
}
