package com.ufoto.business.elasticsearch;

import com.ufoto.business.elasticsearch.dto.*;
import com.ufoto.utils.ApiResult;
import com.ufoto.utils.json.JSONUtil;
import org.springframework.stereotype.Component;
import org.springframework.validation.annotation.Validated;
import org.springframework.web.bind.annotation.RequestBody;

import java.util.List;

/**
 * <p>
 * Author     : Chan
 * CreateDate : 2019-09-05 17:31
 * Description:
 * </p>
 */
@Component
public class ElasticSearchBusinessHystrix implements ElasticSearchBusiness {
    @Override
    public ApiResult<FriendSearchDto> checkUserFriend(long uid, FriendSearchVo searchVo) {
        return new ApiResult<FriendSearchDto>().setError(ApiResult.errorCode500, "Hystrix");
    }

    @Override
    public ApiResult<List<Long>> searchUserActByParam(Long uid, UserActSearchVo searchVo) {
        return new ApiResult<List<Long>>().setError(ApiResult.errorCode500, "Hystrix: "
                + String.format("uid=%s,params=%s", uid, JSONUtil.toJSON(searchVo)));
    }

    @Override
    public ApiResult<List<Long>> filterActLimit(Long uid, UserActFilterVo filterVo) {
        return new ApiResult<List<Long>>().setError(ApiResult.errorCode500, "Hystrix: "
                + String.format("uid=%s,params=%s", uid, JSONUtil.toJSON(filterVo)));
    }

    @Override
    public ApiResult<List<Long>> filterActRecommended(Long uid, UserRecommendedFilterVo filterVo) {
        return new ApiResult<List<Long>>().setError(ApiResult.errorCode500, "Hystrix: "
                + String.format("uid=%s,params=%s", uid, JSONUtil.toJSON(filterVo)));
    }

	@Override
	public ApiResult<UserImageAttrDto> getUserInfoByUid(Long uid) {
		return new ApiResult<UserImageAttrDto>().setError(ApiResult.errorCode500, "Hystrix: "
                + String.format("uid=%s", uid));
	}

	@Override
	public ApiResult<ImageReCallDto> reCallByCondition(Long uid,ImageCallConditionVo conditionVo) {
		return new ApiResult<ImageReCallDto>().setError(ApiResult.errorCode500, "Hystrix: "
                + String.format("uid=%s,params=%s", uid, JSONUtil.toJSON(conditionVo)));
	}

    @Override
    public ApiResult<ImageReCallDto> reCallHighRisk(Long uid, HighRiskCallVO highRiskCallVO) {
        return new ApiResult<ImageReCallDto>().setError(ApiResult.errorCode500, "Hystrix: "
                + String.format("uid=%s,params=%s", uid, JSONUtil.toJSON(highRiskCallVO)));
    }
}
