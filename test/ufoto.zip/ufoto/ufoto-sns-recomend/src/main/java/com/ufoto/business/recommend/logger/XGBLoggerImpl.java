package com.ufoto.business.recommend.logger;

import com.google.common.collect.Maps;
import com.ufoto.log.layout.AppMdcEncoderLayout;
import com.ufoto.logging.proxy.UfotoLogFactory;
import com.ufoto.utils.DateUtil;
import com.ufoto.utils.json.JSONUtil;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.stereotype.Component;

import java.util.List;
import java.util.Map;

/**
 * Created by echo on 12/4/18.
 */
@Component
public class XGBLoggerImpl implements XGBLogger {
    //todo:

    private final static Logger xgbLogger = UfotoLogFactory.getLogger("recommend.xgb.log")
            .enableCustomStatus()
            .withFileName("xgb/xgb_log")
            .withLayout(new AppMdcEncoderLayout(null))
            .build();
    private final static Logger xgbErrorLogger = UfotoLogFactory.getLogger("recommend.xgb.error")
            .enableCustomStatus()
            .withFileName("xgb/xgb_error_log")
            .withLayout(new AppMdcEncoderLayout(null))
            .build();

    private static Logger logger = LoggerFactory.getLogger(RecommendRedisLogger.class);

    @Override
    public void log(List<Map<String, Float>> dataFrame, float[][] result, Long aUid, List<Long> bUidList) {
        try {
            for (int i = 0; i < dataFrame.size(); i++) {
                Map<String, Object> logEntity = Maps.newHashMap();
                logEntity.put("sessionId", "shutUpAndTakeMyMoney");
                logEntity.put("timestamp", DateUtil.getCurrentSecondIntValue());
                logEntity.put("topic", "xgb_log");

                Map<String, Object> message = Maps.newHashMap();
                message.put("data", dataFrame.get(i));
                message.put("result", result[i][0]);
                message.put("uid_a", aUid);
                message.put("uid_b", bUidList.get(i));
                logEntity.put("message", message);

                xgbLogger.info(JSONUtil.toJSON(logEntity));
            }
        } catch (Exception e) {
            logger.error("fuck off..." + e.getMessage(), e);
        }
    }

    @Override
    public void error(List<String> recallUids, Long uid, String m) {
        try {
            Map<String, Object> logEntity = Maps.newHashMap();
            logEntity.put("sessionId", "YouShallNotPasssssss");
            logEntity.put("timestamp", DateUtil.getCurrentSecondIntValue());
            logEntity.put("topic", "xgb_error_log");

            Map<String, Object> message = Maps.newHashMap();
            message.put("recallUids", recallUids);
            message.put("uid", uid);
            message.put("m", m);
            logEntity.put("message", message);

            xgbErrorLogger.info(JSONUtil.toJSON(logEntity));
        } catch (Exception e) {
            logger.error("log error fuck off..." + e.getMessage(), e);
        }
    }

}
