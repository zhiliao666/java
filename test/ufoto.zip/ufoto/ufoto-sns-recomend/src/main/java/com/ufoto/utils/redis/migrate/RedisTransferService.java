package com.ufoto.utils.redis.migrate;

import org.springframework.data.geo.*;
import org.springframework.data.redis.connection.RedisGeoCommands.GeoLocation;
import org.springframework.data.redis.core.Cursor;
import org.springframework.data.redis.core.RedisTemplate;
import org.springframework.data.redis.core.ScanOptions;
import org.springframework.data.redis.core.ZSetOperations.TypedTuple;

import java.util.Collection;
import java.util.List;
import java.util.Map;
import java.util.Set;
import java.util.concurrent.TimeUnit;

/**
 * <p>
 *
 * </p>
 *
 * @author created by chenzhou at 2018-08-21 10:34
 */
public interface RedisTransferService {
    /**
     * 通过key删除
     *
     * @param keys
     */
    long del(String... keys);

    /**
     * 通过set 删除
     *
     * @param sets
     */
    void delSet(Set<String> sets);

    /**
     * 添加key value 并且设置存活时间
     *
     * @param key
     * @param value
     * @param liveTime 单位秒
     */
    void set(String key, String value, long liveTime);

    /**
     * 添加key value
     *
     * @param key
     * @param value
     */
    void set(String key, String value);

    /**
     * 添加key value
     *
     * @param key
     * @param value
     */
    boolean setnx(String key, String value, long livetime);

    /**
     * 获取redis value (String)
     *
     * @param key
     * @return
     */
    String get(String key);

    /**
     * 通过正则匹配keys
     *
     * @param pattern
     * @return
     */
    Set<String> keys(String pattern);

    /**
     * 检查key是否已经存在
     *
     * @param key
     * @return
     */
    boolean exists(String key);

    /**
     * 清空redis 所有数据
     *
     * @return
     */
    void flushDB();

    /**
     * 查看redis里有多少数据
     */
    long dbSize();

    /**
     * 计数器
     *
     * @param key
     */
    Long increment(String key);

    Long decrement(String key);

    /*******************  hash  *********************/

    void hMSet(String key, Map<String, String> map);

    Map<String, String> hGetAll(String key);

    void hDel(String key, String... obj);

    /*******************  list *********************/

    /**
     * List 获取列表
     *
     * @param key
     * @param start
     * @param end
     */
    List<String> lrange(String key, long start, long end);

    /**
     * list  右侧push元素
     *
     * @param key
     * @param memebers
     */
    Long rpush(String key, String... memebers);

    /**
     * 获取list长度
     *
     * @param key
     * @return
     */
    Long lsize(String key);

    Long lrem(String key, long count, String value);


    /*******************  zset ********************/

    /**
     * 新增一个zset值
     *
     * @param key   键值
     * @param value 内容
     * @param score 分值
     * @return
     */
    boolean zadd(String key, String value, double score);

    /**
     * 从有序集合中移除一个或者多个元素
     *
     * @param key
     * @param value
     * @return
     */
    Long zremove(String key, Object... value);

    /**
     * 移除指定索引位置的成员，其中有序集成员按分数值递增(从小到大)顺序排列
     *
     * @param key
     * @param start
     * @param end
     * @return
     */
    Long zremoveRange(String key, long start, long end);

    /**
     * 根据指定的score值得范围来移除成员
     *
     * @param key
     * @param min
     * @param max
     * @return
     */
    Long zremoveRangeByScore(String key, double min, double max);

    /**
     * 增加元素的score值，并返回增加后的值
     *
     * @param key
     * @param value
     * @param delta
     * @return
     */
    Double zincrementScore(String key, String value, double delta);

    /**
     * 获取有序集中指定成员的排名，其中有序集成员按分数值递增(从小到大)顺序排列
     *
     * @param key
     * @param value
     * @return
     */
    Long zrank(String key, Object value);

    /**
     * 有序集中指定成员的排名，其中有序集成员按分数值递减(从大到小)顺序排列
     *
     * @param key
     * @param value
     * @return
     */
    Long zreverseRank(String key, Object value);

    /**
     * 通过索引区间返回有序集合成指定区间内的成员，其中有序集成员按分数值递增(从小到大)顺序排列
     *
     * @param key
     * @param start
     * @param end
     * @return
     */
    Set<String> zrange(String key, long start, long end);

    /**
     * 通过索引区间返回有序集合成指定区间内的成员，其中有序集成员按分数值递增(从大到小)顺序排列
     *
     * @param key
     * @param start
     * @param end
     * @return
     */
    Set<String> zrevrange(String key, long start, long end);

    /**
     * 通过索引区间返回有序集合成指定区间内的成员对象，其中有序集成员按分数值递增(从小到大)顺序排列
     *
     * @param key
     * @param start
     * @param end
     * @return
     */
    Set<TypedTuple<String>> zrangeWithScores(String key, long start, long end);

    /**
     * 通过索引区间返回有序集合成指定区间内的成员对象，其中有序集成员按分数值递减(从大到小)顺序排列
     *
     * @param key
     * @param start
     * @param end
     * @return
     */
    Set<TypedTuple<String>> reverseRangeWithScores(String key, long start, long end);

    /**
     * 通过分数返回有序集合指定区间内的成员，其中有序集成员按分数值递增(从小到大)顺序排列
     *
     * @param key
     * @param min
     * @param max
     * @return
     */
    Set<String> zrangeByScore(String key, double min, double max);

    /**
     * 通过分数返回有序集合指定区间内的成员对象，其中有序集成员按分数值递增(从小到大)顺序排列
     *
     * @param key
     * @param min
     * @param max
     * @return
     */
    Set<TypedTuple<String>> zrangeByScoreWithScores(String key, double min, double max);

    /**
     * 通过分数返回有序集合指定区间内的成员个数
     *
     * @param key
     * @param min
     * @param max
     * @return
     */
    Long zcount(String key, double min, double max);

    /**
     * 获取有序集合的成员数，内部调用的就是zCard方法
     *
     * @param key
     * @return
     */
    Long zsize(String key);

    /**
     * 获取有序集合的成员数
     *
     * @param key
     * @return
     */
    Long zCard(String key);

    /**
     * 获取指定成员的score值
     *
     * @param key
     * @param value
     * @return
     */
    Double zscore(String key, String value);

    /**
     * 将多个Zset 并集并且相加score
     *
     * @param key
     * @return
     */
    Long zUnionAndStore(String key, Collection<String> keys, String target);

    /*******************  set ********************/

    /**
     * 无序集合中添加元素，返回添加个数
     *
     * @param key
     * @param values
     * @return
     */
    Long sadd(String key, String... values);

    /**
     * 无序集合中元素个数
     *
     * @param key
     * @return
     */
    Long sCard(String key);

    /**
     * 移除集合中一个或多个成员
     *
     * @param key
     * @param values
     * @return
     */
    Long sremove(String key, String... values);

    /**
     * 随机获取key无序集合中的一个元素
     *
     * @param key
     * @return
     */
    String srandomMember(String key);

    /**
     * 获取key无序集合中的所有元素
     *
     * @param key
     * @return
     */
    Set<String> sMember(String key);

    /**
     * 获取多个key无序集合中的元素（去重），count表示个数
     *
     * @param key
     * @param count
     * @return
     */
    Set<String> sdistinctRandomMembers(String key, long count);

    /**
     * 获取多个key无序集合中的元素，count表示个数
     *
     * @param key
     * @param count
     * @return
     */
    List<String> srandomMembers(String key, long count);

    /**
     * 遍历set
     *
     * @param key
     * @param options
     * @return
     */
    Cursor<String> scan(String key, ScanOptions options);

    /**
     * SET 并集
     *
     * @param key
     * @param keys
     * @return
     */
    Set<String> sUnion(String key, Collection<String> keys);


    /**
     * SET 并集后保存在target
     *
     * @param key
     * @param keys
     * @param target
     * @return
     */
    Long sUnionAndStore(String key, Collection<String> keys, String target);

    /**
     * SET 交集
     *
     * @param key
     * @param keys
     * @return
     */
    Set<String> sInter(String key, Collection<String> keys);

    /**
     * SET 交集后保存在target
     *
     * @param key
     * @param keys
     * @return
     */
    Long sInterAndStore(String key, Collection<String> keys, String target);

    /**
     * SET 差集
     *
     * @param key
     * @param keys
     * @return
     */
    Set<String> sDiff(String key, Collection<String> keys);

    /**
     * SET 差集后保存在target
     *
     * @param key
     * @param keys
     * @return
     */
    Long sDiffAndStore(String key, Collection<String> keys, String target);

    /**
     * 设置过期时间
     *
     * @param key
     * @param timeout
     * @param unit
     * @return
     */
    boolean expire(String key, long timeout, TimeUnit unit);

    /**
     * 判断set中元素是否存在
     *
     * @param key
     * @param o
     * @return
     */
    Boolean isMember(String key, String o);

    /*******************  geo ********************/

    /**
     * 增加geo
     *
     * @param key
     * @param point  new Point(X,Y)
     * @param member 具体成员
     * @return
     */
    Long geoAdd(String key, Point point, String member);

    /**
     * Get Geohash representation of the position for one or more {@literal member}s
     *
     * @param key
     * @param members
     * @return
     */
    List<String> geoHash(String key, String... members);

    /**
     * Get the {@literal member}s within the boundaries of a given {@link Circle}
     *
     * @param key
     * @param within
     * @return
     */
    GeoResults<GeoLocation<String>> geoRadius(String key, Circle within);

    /**
     * Get the {@literal member}s within the circle defined by the {@literal members} coordinates and given
     * {@literal radius} applying {@link Metric}.
     *
     * @param key
     * @param member
     * @param distance
     * @return
     */
    GeoResults<GeoLocation<String>> geoRadius(String key, String member, Distance distance);


    /**
     * 返回两个member之间的距离
     *
     * @param key
     * @param member1
     * @param member2
     * @return
     */
    Distance geoDistance(String key, String member1, String member2);

    /**
     * 返回两个member之间的距离
     *
     * @param key
     * @param member1
     * @param member2
     * @return
     */
    Distance geoDistance(String key, String member1, String member2, Metric metric);


    /**
     * 返回member和坐标之间的距离
     *
     * @param key
     * @param member
     * @param longitude
     * @param latitude
     * @return
     */
    Distance geoDistance(String key, String member, Double longitude, Double latitude, Metric metric);

    /**
     * 返回member的位置
     *
     * @param key
     * @param members
     */
    List<Point> geoPos(String key, String... members);

    /**
     * 批量获取key对应的string
     *
     * @param keys
     * @return
     */
    List<String> mget(List<String> keys);

    RedisTemplate<String, String> getRedisTemplate();

    String hget(String key, String field);

    void hset(String key, String field, String value);

}
