package com.ufoto.utils.redis.migrate;

import com.google.common.collect.Maps;
import com.ufoto.utils.ApiResult;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Qualifier;
import org.springframework.data.redis.connection.RedisServerCommands;
import org.springframework.data.redis.core.RedisCallback;
import org.springframework.data.redis.core.RedisTemplate;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import java.util.Map;

/**
 * <p>
 *
 * </p>
 *
 * @author created by chenzhou at 2018-08-21 16:22
 */
@RestController
@RequestMapping("/redisMigrate")
public class RedisMigrateController {

    private static Logger logger = LoggerFactory.getLogger("RedisMigrateController");

    /*@Autowired
    @Qualifier("transferRedisTemplate")
    private RedisTemplate<String, String> transferRedisTemplate;*/

    @Autowired
    @Qualifier("redisTemplate")
    private RedisTemplate<String, String> clusterRedisTemplate;

//    @Autowired
//    @Qualifier("oldRedisTemplate")
//    private RedisTemplate<String, String> oldRedisTemplate;
/*
    private final static Charset CHARSET = StandardCharsets.UTF_8;

    @RequestMapping("/transfer2Cluster")
    public ApiResult<Object> transfer2Cluster() {
        logger.info("start transfer2Cluster");
        final HashSet<String> systemKeys = getSystemKeys();
        final Set<String> keys = transferRedisTemplate.keys("*");
        if (CollectionUtils.isEmpty(keys)) {
            return new ApiResult<>().setResult("no keys");
        }
        keys.stream().filter(key -> isSystemKey(systemKeys, key)).forEach(key -> {
            final DataType dataType = transferRedisTemplate.type(key);
            final Object ttlObj = transferRedisTemplate.execute((RedisCallback<Object>) connection -> connection.pTtl(key.getBytes(CHARSET)));
            if (dataType != null) {
                switch (dataType) {
                    case STRING:
                        handleString(key, ttlObj);
                        break;
                    case NONE:
                        break;
                    case SET:
                        handleSet(key, ttlObj);
                        break;
                    case HASH:
                        handleHash(key, ttlObj);
                        break;
                    case LIST:
                        handleList(key, ttlObj);
                        break;
                    case ZSET:
                        handleZSet(key, ttlObj);
                        break;
                }
            }
        });
        return new ApiResult<>();
    }

    private HashSet<String> getSystemKeys() {
        RedisKeyConstant constant = new RedisKeyConstant();
        final Class<RedisKeyConstant> keyConstantClass = RedisKeyConstant.class;
        final Field[] fields = keyConstantClass.getFields();
        return (HashSet<String>) Arrays.stream(fields).map(field -> {
            try {
                return field.get(constant);
            } catch (IllegalAccessException e) {
                return null;
            }
        }).map(String::valueOf).collect(Collectors.toSet());
    }

    private boolean isSystemKey(HashSet<String> systemKeys, String key) {
        return systemKeys.stream().anyMatch(key::contains)
                || key.startsWith("random_match_set_result")
                || key.startsWith("new_come_user_set")
                || key.startsWith("recommend_user_source");
    }

    private String getConverter(Object obj) {
        return obj == null ? null : String.valueOf(obj);
    }

    private void handleString(String key, Object ttlObj) {
        logger.info("handleString({},{})", key, ttlObj);
        final String value = getConverter(transferRedisTemplate.opsForValue().get(key));
        if (StringUtils.isBlank(value)) {
            return;
        }
        final ValueOperations<String, String> clusterValueOperations = clusterRedisTemplate.opsForValue();
        if (ttlObj == null || Long.valueOf(String.valueOf(ttlObj)) == -1) {
            clusterValueOperations.set(key, value);
        } else {
            clusterValueOperations.set(key, value, Long.valueOf(String.valueOf(ttlObj)), TimeUnit.MICROSECONDS);
        }
    }

    private void handleZSet(String key, Object ttlObj) {
        logger.info("handleZSet({},{})", key, ttlObj);
        final Set<ZSetOperations.TypedTuple<String>> tuples = transferRedisTemplate.opsForZSet().rangeWithScores(key, 0, -1);
        if (CollectionUtils.isEmpty(tuples)) {
            return;
        }
        if (ttlObj == null || Long.valueOf(String.valueOf(ttlObj)) == -1) {
            clusterRedisTemplate.opsForZSet().add(key, tuples);
        } else {
            clusterRedisTemplate.opsForZSet().add(key, tuples);
            clusterRedisTemplate.expire(key, Long.valueOf(String.valueOf(ttlObj)), TimeUnit.MICROSECONDS);
        }
    }

    private void handleList(String key, Object ttlObj) {
        logger.info("handleList({},{})", key, ttlObj);
        final List<String> list = transferRedisTemplate.opsForList().range(key, 0, -1);
        if (CollectionUtils.isEmpty(list)) {
            return;
        }
        final ListOperations<String, String> listOperations = clusterRedisTemplate.opsForList();
        if (ttlObj == null || Long.valueOf(String.valueOf(ttlObj)) == -1) {
            listOperations.leftPushAll(key, list);
        } else {
            listOperations.leftPushAll(key, list);
            clusterRedisTemplate.expire(key, Long.valueOf(String.valueOf(ttlObj)), TimeUnit.MICROSECONDS);
        }
    }

    private void handleHash(String key, Object ttlObj) {
        logger.info("handleHash({},{})", key, ttlObj);
        final Map<Object, Object> entries = transferRedisTemplate.opsForHash().entries(key);
        if (CollectionUtils.isEmpty(entries)) {
            return;
        }
        if (ttlObj == null || Long.valueOf(String.valueOf(ttlObj)) == -1) {
            clusterRedisTemplate.opsForHash().putAll(key, entries);
        } else {
            clusterRedisTemplate.opsForHash().putAll(key, entries);
            clusterRedisTemplate.expire(key, Long.valueOf(String.valueOf(ttlObj)), TimeUnit.MICROSECONDS);
        }
    }

    private void handleSet(String key, Object ttlObj) {
        logger.info("handleSet({},{})", key, ttlObj);
        final Set<String> members = transferRedisTemplate.opsForSet().members(key);
        if (CollectionUtils.isEmpty(members)) {
            return;
        }
        if (ttlObj == null || Long.valueOf(String.valueOf(ttlObj)) == -1) {
            clusterRedisTemplate.opsForSet().add(key, members.toArray(new String[]{}));
        } else {
            clusterRedisTemplate.opsForSet().add(key, members.toArray(new String[]{}));
            clusterRedisTemplate.expire(key, Long.valueOf(String.valueOf(ttlObj)), TimeUnit.MICROSECONDS);
        }
    }*/

    @RequestMapping("/check")
    public ApiResult<Object> check() {
        Map<String, Object> resultMap = Maps.newHashMap();
       /* final Object transferSize = transferRedisTemplate.execute((RedisCallback<Object>) RedisServerCommands::dbSize);
        resultMap.put("transferSize", transferSize);*/

        final Object clusterSize = clusterRedisTemplate.execute((RedisCallback<Object>) RedisServerCommands::dbSize);
        resultMap.put("clusterSize", clusterSize);

//        final Object oldSize = oldRedisTemplate.execute((RedisCallback<Object>) RedisServerCommands::dbSize);
//        resultMap.put("originSize", oldSize);
        return new ApiResult<>().setResult(resultMap);
    }

}
