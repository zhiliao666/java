package com.ufoto.dao.svd;

import com.ufoto.dao.base.BaseUfotoSvdItemSimilarityTopNMapper;
import org.apache.ibatis.annotations.Mapper;
import org.apache.ibatis.annotations.Param;
import org.apache.ibatis.annotations.Select;

import java.util.List;

@Mapper
public interface UfotoSvdItemSimilarityMapper extends BaseUfotoSvdItemSimilarityTopNMapper {


    @Select({"<script>" +
            "SELECT s_i_id FROM ufoto_svd_item_similarity_top_n " +
            "WHERE i_id IN (0 " +
            "<foreach item='item' index='index' collection='iids' separator=',' open=','> " +
            "#{item}" +
            "</foreach>" +
            ") " +
            "</script>"})
    List<Long> selectTopNSimilarityByIids(@Param("iids") List<Long> iids);


    @Select({"<script>" +
            "SELECT s_i_id FROM ufoto_svd_item_similarity_2_top_n " +
            "WHERE i_id IN (0 " +
            "<foreach item='item' index='index' collection='iids' separator=',' open=','> " +
            "#{item}" +
            "</foreach>" +
            ") " +
            "</script>"})
    List<Long> selectTopNSimilarity2ByIids(@Param("iids") List<Long> iids);

    @Select({"<script>" +
            "SELECT s_i_id FROM ufoto_svd_user_similarity_top_n " +
            "WHERE i_id IN (0 " +
            "<foreach item='item' index='index' collection='iids' separator=',' open=','> " +
            "#{item}" +
            "</foreach>" +
            ") " +
            "</script>"})
    List<Long> selectTopNSimilarityFollowerByIids(@Param("iids") List<Long> iids);


    @Select({"<script>" +
            "SELECT count(DISTINCT s_i_id) FROM ufoto_svd_item_similarity_top_n " +
            "WHERE i_id IN (0" +
            "<foreach item='item' index='index' collection='iids' separator=',' open=','> " +
            "#{item}" +
            "</foreach>" +
            ") " +
            "</script>"})
    Integer selectTopNCountSimilarityByIids(@Param("iids") List<Long> iids);

}
