package com.ufoto.dto;

import lombok.Data;

import java.io.Serializable;

/**
 * <p>
 * 封装 推荐策略请求参数
 * </p>
 *
 * @author created by chenzhou at 2018-05-10 14:42
 */
@Data
public class RecommendAdvanceRequest implements Serializable {
    //开始索引
    private Integer start;
    //结束索引
    private Integer end;
    //用户id
    private Long uid;
    //客户端token
    private String sign;
    //分页起始页
    private Integer page;
    //分页大小
    private Integer pageSize;
    //经度
    private Double longitude;
    //纬度
    private Double latitude;
    //--以上是用户自己的信息
    //--以下是用户设置的信息
    //开始年龄
    private Integer startAge;
    //结束年龄
    private Integer endAge;
    //性别
    private Integer gender;
    //国家代码
    private String countryCode;
    //离用户当前位置的距离
    private Double distance;
    //国家大区ID
    private Integer areaId;
    //api version
    private String apiVersion;
    //分数--测试用
    private Boolean withScore;
    //客户语言
    private String language;
    //客户端包名
    private String cp;
    //DirtyCase. 1获取収礼卡片
    private Integer dc;
    // 用户分层 100 新用户 200 浏览用 300 低寻友 400 高寻友
    private Integer userLayer;
    // 用户高危程度 100 普通用户 200 监控用户 300 高危用户
    private Integer riskLevel;
    // 上次拉取从es中召回的用户的最晚活跃时间
    private Integer lastRecallTime;
    
    // 推荐来源 1 slide(滑动页面) 2 wink
    private Integer fromType;
    private Integer limit;//想要获取多少用户
    private Integer firstRequest;// 是否第一次请求wink 1 是 2 不是
    private Integer platform;
    private Integer vipStatus;
}
