package com.ufoto.entity.base;

import java.io.Serializable;

public class BaseUfotoSvdItemSimilarityTopN implements Serializable {
    /**
     * Default value included to remove warning. Remove or modify at will.
     **/
    private static final long serialVersionUID = 1L;

    private java.lang.Integer createTime;
    private java.lang.Long sIId;
    private java.lang.Integer rank;
    private java.lang.Long id;
    private java.lang.Long iId;

    public java.lang.Integer getCreateTime() {
        return createTime;
    }

    public void setCreateTime(java.lang.Integer createTime) {
        this.createTime = createTime;
    }

    public java.lang.Long getSIId() {
        return sIId;
    }

    public void setSIId(java.lang.Long sIId) {
        this.sIId = sIId;
    }

    public java.lang.Integer getRank() {
        return rank;
    }

    public void setRank(java.lang.Integer rank) {
        this.rank = rank;
    }

    public java.lang.Long getId() {
        return id;
    }

    public void setId(java.lang.Long id) {
        this.id = id;
    }

    public java.lang.Long getIId() {
        return iId;
    }

    public void setIId(java.lang.Long iId) {
        this.iId = iId;
    }


//	@Override
//	public String toString() {
//		return "{ id:" + id + ", name:" + name + ", email:" + email
//				+ ", phone:" + phoneNumber + " }";
//	}
}
