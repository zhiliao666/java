package com.ufoto.config.disruptor.executor;

import com.ufoto.config.disruptor.data.AsyncData;

/**
 * <p>
 * Description:
 *
 * </p>
 *
 * @author Chan
 * @date 2019/12/21 15:07
 */
public interface AsyncExecutor {
    void execute(AsyncData asyncData);
}
