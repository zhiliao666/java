package com.ufoto.business.recommendNG.recall;

import com.ufoto.annotation.RecommendMetadata;
import com.ufoto.business.recommendNG.Recall;
import com.ufoto.dto.RecommendAdvanceRequest;
import com.ufoto.utils.DateUtil;
import com.ufoto.utils.redis.RedisKeyConstant;
import com.ufoto.utils.redis.RedisService;
import org.springframework.core.env.Environment;
import org.springframework.stereotype.Component;

import java.util.Set;

/**
 * Created by echo on 4/3/19.
 */
@RecommendMetadata(
        metadataType = RecommendMetadata.MetadataType.RECALL,
        available = true,
        name = "活跃用户召回策略",
        description = "召回指定时间段内活跃的所有用户",
        branch = RecommendMetadata.Branch.NORMAL
)
@Component
public class NGOnlineRecall implements Recall {

    private final RedisService redisService;
    private final Environment environment;

    public NGOnlineRecall(RedisService redisService,
                          Environment environment) {
        this.redisService = redisService;
        this.environment = environment;
    }

    @Override
    public Set<String> recall(Integer minSize, RecommendAdvanceRequest recallRequest) {
        //判定多少分钟以内有活跃的用户是在线用户
        Long onlineTimeWindow = environment.getProperty("recall.NGOnlineRecall.onlineTimeWindow", Long.class, 5L);
        long start = DateUtil.getCurrentSecondIntValue().longValue() - onlineTimeWindow * 60;
        return redisService.zrangeByScore(RedisKeyConstant.REDIS_ACT_IN_24H_USER_ZSET_KEY, start, Double.MAX_VALUE);
    }

    @Override
    public boolean ifRecallOnlyOnce() {
        return true;
    }

    @Override
    public boolean ifNeedThreadLocalCache() {
        return false;
    }
}
