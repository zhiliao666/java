package com.ufoto.business.usercenter;

import com.ufoto.business.usercenter.dto.*;
import com.ufoto.dto.RecommendListUserCenterRequest;
import com.ufoto.dto.sns.SnsRecommendDto;
import com.ufoto.utils.ApiResult;
import org.springframework.cloud.openfeign.FeignClient;
import org.springframework.web.bind.annotation.*;

import java.util.List;
import java.util.Map;

/**
 * <p>
 * Author     : Chan
 * CreateDate : 2019-03-19 10:05
 * Description:
 * </p>
 */
@FeignClient(name = "UFOTO-USER-CENTER", fallbackFactory = UserInfoBusinessFallback.class)
public interface UserInfoBusiness {

    @GetMapping("/v1/user/{uid}/getUserBaseInfo")
    ApiResult<UserBaseInfoDto> getUserBaseInfo(@PathVariable(value = "uid") Long uid);

    /**
     * 根据用户id列表获取用户基本信息
     *
     * @param idList 用户id列表
     * @return 用户列表信息
     */
    @PostMapping("/v1/user/getUserBaseInfoList")
    ApiResult<List<UserBaseInfoDto>> getUserBaseInfoList(@RequestBody List<Long> idList);

    /**
     * 根据用户id查询用户所有信息
     *
     * @param uid 用户id
     * @return 用户信息查询结果
     */
    @PostMapping("/v1/user/{uid}/getUserInfo")
    ApiResult<UserInfoDto> getUserInfo(@PathVariable(value = "uid") Long uid);

    /**
     * 根据用户uuid查询用户基本信息
     *
     * @param uuid 用户uuid
     * @return 获取基本信息
     */
    @GetMapping("/v1/user/getUserBaseInfoByUUid")
    ApiResult<UserBaseInfoDto> getUserBaseInfoByUUid(@RequestParam(value = "uuid", required = false) String uuid);

    /**
     * 获取机器人列表
     *
     * @return 机器人
     */
    @PostMapping("/v1/user/conditions")
    ApiResult<List<UserBaseInfoDto>> conditionLists(@RequestBody UserConditionDto userConditionDto);

    @GetMapping("/v1/user/{uid}/gender")
    ApiResult<Integer> getGender(@PathVariable Long uid);

    @PostMapping("/v1/user/heads")
    ApiResult<List<UserHeadDto>> conditionHeads(@RequestBody UserHeadConditionDto conditionDto);

    /**
     * 更新用户地理位置信息
     *
     * @param geos
     * @return
     */
    @PutMapping("/v1/user/geos")
    ApiResult<Integer> updateGeoInfo(@RequestBody List<UserGeoInfoDto> geos);

    @PostMapping("/v2/user/recommendList")
    ApiResult<List<SnsRecommendDto>> recommendList(@RequestBody RecommendListUserCenterRequest centerRequest);

    @PostMapping("/v1/user/feed/image/list")
    ApiResult<List<UfotoUserImageDo>> getUserImageByIdList(@RequestBody FirstImgStateVo stateVo);

    @PostMapping("/v1/user/feed/firstImg/state")
    ApiResult<Map<Long, Integer>> checkFirstImageState(@RequestBody List<Long> idList);
}
