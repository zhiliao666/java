package com.ufoto.business.recommend.sort.match;

import com.ufoto.annotation.RecommendMetadata;
import com.ufoto.business.recommend.bean.SortParamsBean;
import com.ufoto.business.recommend.sort.BaseNormalSortStrategy;
import com.ufoto.utils.KeyTransitionUtil;
import com.ufoto.utils.redis.RedisService;
import org.springframework.stereotype.Component;

import java.util.List;
import java.util.Map;

/**
 * Created by echo on 4/8/18.
 */
@RecommendMetadata(
        metadataType = RecommendMetadata.MetadataType.SORT,
        available = true,
        name = "匹配数量排序策略",
        description = "基础分数为用户的匹配数量,如果没有,则为0",
        branch = RecommendMetadata.Branch.NORMAL
)
@Component
public class MatchNumSortStrategy extends BaseNormalSortStrategy {

    private final RedisService redisService;

    public MatchNumSortStrategy(RedisService redisService) {
        this.redisService = redisService;
    }

    /**
     * 返回用户所有匹配数量
     */
    @Override
    public Map<String, Double> getScore(List<String> recallUids, SortParamsBean sortParamsBean) {
        return KeyTransitionUtil.userMatchNumMap(redisService, recallUids);
    }
}
