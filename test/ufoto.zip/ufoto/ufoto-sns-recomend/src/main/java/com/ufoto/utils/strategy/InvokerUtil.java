package com.ufoto.utils.strategy;

import com.google.common.collect.Lists;
import com.google.common.collect.Maps;
import com.google.common.hash.Hashing;
import com.ufoto.annotation.RecommendMetadata;
import com.ufoto.business.recommend.RecommendSortStrategy;
import com.ufoto.business.recommend.sort.HotSortStrategy;
import com.ufoto.business.recommendNG.Invoker;
import com.ufoto.business.recommendNG.Reagent;
import com.ufoto.business.recommendNG.Recall;
import com.ufoto.business.recommendNG.captain.NGDefaultCaptain;
import com.ufoto.business.recommendNG.invoker.BaseInvoker;
import com.ufoto.business.recommendNG.invoker.ChainCompositeInvoker;
import com.ufoto.business.recommendNG.invoker.InvokerEnvConfig;
import com.ufoto.business.recommendNG.invoker.WeightCompositeInvoker;
import com.ufoto.business.recommendNG.reagent.ActIn24HoursReagent;
import com.ufoto.business.recommendNG.reagent.IWantItAllReagent;
import com.ufoto.business.recommendNG.recall.NGGiftReceiveRecall;
import com.ufoto.business.recommendNG.recall.NGHighRiskRecall;
import com.ufoto.business.recommendNG.recall.NGHotRecall;
import com.ufoto.business.recommendNG.recall.NGRandomRecall;
import com.ufoto.constants.ESnsFromType;
import com.ufoto.constants.EStrategyCategory;
import com.ufoto.domain.UfotoVariant;
import com.ufoto.dto.CommonStrategyBean;
import com.ufoto.dto.RecommendAdvanceRequest;
import com.ufoto.manager.RecommendStrategyRegister;
import com.ufoto.runner.RuleCacheManager;
import com.ufoto.utils.UidHashUtil;
import com.ufoto.utils.json.JSONUtil;
import com.ufoto.utils.redis.RedisService;
import lombok.RequiredArgsConstructor;
import lombok.extern.slf4j.Slf4j;
import org.springframework.beans.factory.InitializingBean;
import org.springframework.beans.factory.config.AutowireCapableBeanFactory;
import org.springframework.context.ApplicationContext;
import org.springframework.core.env.Environment;
import org.springframework.stereotype.Component;

import java.util.Collections;
import java.util.List;
import java.util.Map;
import java.util.stream.Collectors;

/**
 * Created by echo on 10/17/18.
 */
@Slf4j
@RequiredArgsConstructor
@Component
public class InvokerUtil implements InitializingBean {

    private InvokerEnvConfig invokerEnvConfig;
    private Map<Integer, Invoker> strategyIdInvokerMap = Maps.newConcurrentMap();

    private final Environment env;
    private final ApplicationContext context;
    private final SortStrategyUtil sortStrategyUtil;
    private final RecallStrategyUtil recallStrategyUtil;
    private final RedisService redisService;
    private final NGDefaultCaptain ngDefaultCaptain;
    private final RecommendStrategyRegister recommendStrategyRegister;
    private final NGHighRiskRecall ngHighRiskRecall;

    //special
    private final NGHotRecall ngHotRecall;
    private final IWantItAllReagent iWantItAllReagent;
    private final HotSortStrategy hotSortStrategy;
    private final NGRandomRecall ngRandomRecall;
    private final ActIn24HoursReagent actIn24HoursReagent;
    private final NGGiftReceiveRecall ngGiftReceiveRecall;
    private final RuleCacheManager ruleCacheManager;

    @Override
    public void afterPropertiesSet() throws Exception {
        this.invokerEnvConfig = InvokerEnvConfig.builder()
                .maxRecallTime(env.getProperty("recommend.ng.invoker.maxRecallTime", Integer.class, 1))
                .recallSizeIncreaseRate(env.getProperty("recommend.ng.invoker.recallSizeIncreaseRate", Integer.class, 5))
                .build();
    }

    //normal
    public Invoker createInvoker(Map<String, CommonStrategyBean> strategyBeanMap,RecommendAdvanceRequest recommendAdvanceRequest) {
        RecommendSortStrategy sortStrategy = sortStrategyUtil.strategy(strategyBeanMap.get(EStrategyCategory.SORT.getCategory()));
        CommonStrategyBean rootInvokerStrategyBean = strategyBeanMap.get(EStrategyCategory.INVOKER.getCategory());
        return createInvoker(rootInvokerStrategyBean, sortStrategy,recommendAdvanceRequest);
    }

    private Invoker createInvoker(CommonStrategyBean commonStrategyBean, RecommendSortStrategy recommendSortStrategy,RecommendAdvanceRequest recommendAdvanceRequest) {
        if (commonStrategyBean == null)
            throw new RuntimeException("Fail to create invoker.Common strategy bean is none");
        Invoker result = null;

        Integer strategyId = commonStrategyBean.getId();
        if (strategyId != null) {
            result = strategyIdInvokerMap.get(strategyId);
        } else {
            log.warn("createInvoker strategy bean id is null.");
        }

        if (result != null) return result;

        String type = commonStrategyBean.getType();
        switch (type) {
            case "composite"://组合invoker
                result = createChainCompositeInvoker(commonStrategyBean, recommendSortStrategy,recommendAdvanceRequest);
                break;
            case "weight"://权重组合invoker
                result = createWeightCompositeInvoker(commonStrategyBean, recommendSortStrategy,recommendAdvanceRequest);
                break;
            case "baseInvoker"://基础节点
                result = createBaseInvoker(commonStrategyBean, recommendSortStrategy,recommendAdvanceRequest);
                break;
            default:
                throw new RuntimeException("Fail to create invoker.Type error");
        }

        if (strategyId != null) {
            strategyIdInvokerMap.put(strategyId, result);
        }
        return result;
    }

    private ChainCompositeInvoker createChainCompositeInvoker(CommonStrategyBean commonStrategyBean, RecommendSortStrategy recommendSortStrategy,RecommendAdvanceRequest recommendAdvanceRequest) {
        List<CommonStrategyBean> childrenStrategyBeanList = commonStrategyBean.getChildren();
        if (childrenStrategyBeanList.size() == 0)
            throw new RuntimeException("createChainCompositeInvoker:no children." + JSONUtil.toJSON(commonStrategyBean));
        List<Invoker> children = childrenStrategyBeanList.stream()
                .map(bean -> this.createInvoker(bean, recommendSortStrategy,recommendAdvanceRequest))
                .collect(Collectors.toList());
        return new ChainCompositeInvoker(children);
    }

    private WeightCompositeInvoker createWeightCompositeInvoker(CommonStrategyBean commonStrategyBean, RecommendSortStrategy recommendSortStrategy,RecommendAdvanceRequest recommendAdvanceRequest) {
        List<CommonStrategyBean> childrenStrategyBeanList = commonStrategyBean.getChildren();
        List<Invoker> children = Lists.newLinkedList();
        List<Float> weightList = Lists.newLinkedList();
        List<Integer> assembleWeightList = Lists.newLinkedList();

        for (CommonStrategyBean childrenStrategyBean : childrenStrategyBeanList) {
            Invoker child = createInvoker(childrenStrategyBean, recommendSortStrategy,recommendAdvanceRequest);
            Float weight = childrenStrategyBean.getWeight();
            Integer assembleWeight = childrenStrategyBean.getAssembleWeight();
            if (weight == null || weight < 0)
                throw new RuntimeException("createWeightCompositeInvoker Fail!weight is invalid!" + JSONUtil.toJSON(commonStrategyBean));
            if (assembleWeight == null || assembleWeight <= 0)
                throw new RuntimeException("createWeightCompositeInvoker Fail!assembleWeight is invalid!" + JSONUtil.toJSON(commonStrategyBean));

            children.add(child);
            weightList.add(weight);
            assembleWeightList.add(assembleWeight);
        }

        return new WeightCompositeInvoker(children, weightList, assembleWeightList, ngDefaultCaptain);
    }

    private Invoker createBaseInvoker(CommonStrategyBean commonStrategyBean, RecommendSortStrategy recommendSortStrategy,RecommendAdvanceRequest recommendAdvanceRequest) {
        Recall recallStrategy = null;
        List<Reagent> reagentList = Lists.newLinkedList();

        List<CommonStrategyBean> childrenStrategyBeanList = commonStrategyBean.getChildren();
        for (CommonStrategyBean childStrategy : childrenStrategyBeanList) {
            if (childStrategy.getCategory().equals(EStrategyCategory.RECALL.getCategory())) {
                recallStrategy = recallStrategyUtil.ngStrategy(childStrategy);
            } else if (childStrategy.getCategory().equals(EStrategyCategory.REAGENT.getCategory())) {
                reagentList.add(createReagent(childStrategy));
            }
        }

        if (recallStrategy == null)
            throw new RuntimeException("Create base invoker fail!No RECALL!" + JSONUtil.toJSON(commonStrategyBean));
        if (reagentList.size() == 0)
            throw new RuntimeException("Create base invoker fail!No REAGENT!" + JSONUtil.toJSON(commonStrategyBean));
        
        // TODO 用来判断过滤策略走不同的分支逻辑，非常恶心，正常应该通过erp实现配置话
        if(recommendAdvanceRequest != null) {
	        UfotoVariant variant = ruleCacheManager.getHashVariantName(recommendAdvanceRequest.getUid());
	        // 名字包含用户分层的分支，过滤策略使用元数据中标有USERLAYER的过滤策略
	        if(variant != null && variant.getName().contains("用户分层")) {
	        	if(ESnsFromType.WINK.getType() == recommendAdvanceRequest.getFromType()) {
	        		return new BaseInvoker(recallStrategy, reagentList,
		                    recommendStrategyRegister.getFilterStrategyMap().get(RecommendMetadata.Branch.WINK), recommendSortStrategy,
		                    invokerEnvConfig, redisService);
	        	}
	        	return new BaseInvoker(recallStrategy, reagentList,
	                    recommendStrategyRegister.getFilterStrategyMap().get(RecommendMetadata.Branch.USERLAYER), recommendSortStrategy,
	                    invokerEnvConfig, redisService);
	        }
        }

        return new BaseInvoker(recallStrategy, reagentList,
                recommendStrategyRegister.getFilterStrategyMap().get(RecommendMetadata.Branch.NORMAL), recommendSortStrategy,
                invokerEnvConfig, redisService);
    }
    
   
    private Reagent createReagent(CommonStrategyBean commonStrategyBean) {
        try {
            String strategy = commonStrategyBean.getStrategy();
            Class<?> aClass = Class.forName(strategy);
            return (Reagent) context.getAutowireCapableBeanFactory().createBean(aClass,
                    AutowireCapableBeanFactory.AUTOWIRE_BY_TYPE, true);
        } catch (ClassNotFoundException e) {
            throw new RuntimeException(e);
        }
    }

    //Gift
    public Invoker createGiftBaseInvokerForGift() {
        return new BaseInvoker(ngGiftReceiveRecall,
                Collections.singletonList(iWantItAllReagent),
                recommendStrategyRegister.getFilterStrategyMap().get(RecommendMetadata.Branch.GIFT),
                hotSortStrategy,
                invokerEnvConfig,
                redisService);
    }

    //Default
    public Invoker createDefaultInvoker() {
        return new ChainCompositeInvoker(Lists.newArrayList(
                new BaseInvoker(ngHotRecall,
                        Collections.singletonList(iWantItAllReagent),
                        recommendStrategyRegister.getFilterStrategyMap().get(RecommendMetadata.Branch.DEFAULT),
                        hotSortStrategy,
                        invokerEnvConfig,
                        redisService),
                new BaseInvoker(ngRandomRecall,
                        Collections.singletonList(actIn24HoursReagent),
                        recommendStrategyRegister.getFilterStrategyMap().get(RecommendMetadata.Branch.DEFAULT),
                        hotSortStrategy,
                        invokerEnvConfig,
                        redisService)
        ));
    }

    //HighRisk
    public Invoker createHighRiskInvoker() {
        return new BaseInvoker(ngHighRiskRecall,
                Collections.singletonList(iWantItAllReagent),
                recommendStrategyRegister.getFilterStrategyMap().get(RecommendMetadata.Branch.High_Risk),
                hotSortStrategy,
                invokerEnvConfig,
                redisService);
    }

}
