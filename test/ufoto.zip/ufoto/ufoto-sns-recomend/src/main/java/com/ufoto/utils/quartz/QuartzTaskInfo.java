package com.ufoto.utils.quartz;

import org.quartz.JobDataMap;

import java.io.Serializable;

public class QuartzTaskInfo implements Serializable {
    private static final long serialVersionUID = -8054692082716173379L;
    private int id = 0;

    /**
     * 任务名称
     */
    private String jobName;

    /**
     * 任务调用类名，包名+类名，通过类反射调用
     */
    private String jobClass;

    /**
     * 任务分组
     */
    private String jobGroup;

    /**
     * 任务描述
     */
    private String jobDescription;

    /**
     * 任务状态
     */
    private String jobStatus;

    /**
     * 任务表达式
     */
    private String cronExpression;

    private String createTime;

    private JobDataMap dataMap;

    public QuartzTaskInfo() {

    }

    public QuartzTaskInfo(String jobGroup, String jobName, String jobDescription, String jobClass, String cronExpression) {
        this.jobGroup = jobGroup;
        this.jobName = jobName;
        this.jobDescription = jobDescription;
        this.jobClass = jobClass;
        this.cronExpression = cronExpression;
    }

    public QuartzTaskInfo(String jobGroup, String jobName, String jobDescription, String jobClass, String cronExpression, JobDataMap dataMap) {
        this.jobGroup = jobGroup;
        this.jobName = jobName;
        this.jobDescription = jobDescription;
        this.jobClass = jobClass;
        this.cronExpression = cronExpression;
        this.dataMap = dataMap;
    }


    public String getJobClass() {
        return jobClass;
    }

    public void setJobClass(String jobClass) {
        this.jobClass = jobClass;
    }

    public String getJobName() {
        return jobName;
    }

    public void setJobName(String jobName) {
        this.jobName = jobName;
    }

    public String getJobGroup() {
        return jobGroup;
    }

    public void setJobGroup(String jobGroup) {
        this.jobGroup = jobGroup;
    }

    public String getJobDescription() {
        return jobDescription;
    }

    public void setJobDescription(String jobDescription) {
        this.jobDescription = jobDescription;
    }

    public String getJobStatus() {
        return jobStatus;
    }

    public void setJobStatus(String jobStatus) {
        this.jobStatus = jobStatus;
    }

    public String getCronExpression() {
        return cronExpression;
    }

    public void setCronExpression(String cronExpression) {
        this.cronExpression = cronExpression;
    }

    public String getCreateTime() {
        return createTime;
    }

    public void setCreateTime(String createTime) {
        this.createTime = createTime;
    }

    public int getId() {
        return id;
    }

    public void setId(int id) {
        this.id = id;
    }

    public JobDataMap getDataMap() {
        return dataMap == null ? new JobDataMap() : dataMap;
    }

    public void setDataMap(JobDataMap dataMap) {
        this.dataMap = dataMap;
    }
}