package com.ufoto.business.recommend.filter.gender;

import com.google.common.collect.Lists;
import com.ufoto.annotation.RecommendMetadata;
import com.ufoto.business.recommend.RecommendFilterStrategy;
import com.ufoto.dto.RecommendAdvanceRequest;
import com.ufoto.utils.KeyTransitionUtil;
import com.ufoto.utils.redis.RedisKeyConstant;
import com.ufoto.utils.redis.RedisKeyUtil;
import com.ufoto.utils.redis.RedisService;
import com.ufoto.utils.threadlocal.ThreadLocalManager;
import org.springframework.stereotype.Component;
import org.springframework.util.CollectionUtils;

import java.util.List;
import java.util.Map;
import java.util.Objects;
import java.util.Set;
import java.util.stream.Collectors;

/**
 * Created by echo on 4/3/18.
 */
@RecommendMetadata(
        metadataType = RecommendMetadata.MetadataType.FILTER,
        available = true,
        name = "性别过滤策略",
        description = "根据uid设置的目标性别过滤用户，如果没设置，默认取异性.如果性别不明确，不过滤",
        branch = {
                RecommendMetadata.Branch.NORMAL,
                RecommendMetadata.Branch.DEFAULT,
                RecommendMetadata.Branch.GIFT,
                RecommendMetadata.Branch.High_Risk
        }
)
@Component
public class GenderFilterStrategy implements RecommendFilterStrategy {

    private final RedisService redisService;

    public GenderFilterStrategy(RedisService redisService) {
        this.redisService = redisService;
    }

    @Override
    public Set<String> filter(Set<String> recallSet, List<String> resultList, RecommendAdvanceRequest filterRequest) {
        if (CollectionUtils.isEmpty(recallSet)) {
            return recallSet;
        }
        Long uid = filterRequest.getUid();
        //如果uid为空 默认不过滤
        if (uid == null) {
            return recallSet;
        }
        Integer targetGender = filterRequest.getGender();//需要留下什么性别的用户
        //如果当前所需性别
        if (!Objects.equals(targetGender, 0) //不是0
                && !Objects.equals(targetGender, 1) //不是1
                && !Objects.equals(targetGender, 2)) { // 不是2
            //用户需求的目标性别没有设置或者不正确
            String userGender = redisService.hget(RedisKeyUtil.obtainKey(RedisKeyConstant.REDIS_USER_HASH_KEY, uid), RedisKeyConstant.REDIS_USER_HASH_GENDER);
            if (Objects.equals("1", userGender)) {
                targetGender = 2;
            } else if (Objects.equals("2", userGender)) {
                targetGender = 1;
            } else {
                targetGender = 0;
            }
        }
        ThreadLocalManager.needGenderThreadLocal(targetGender);
        if (Objects.equals(targetGender, 0)) return recallSet;

        final Map<Long, Integer> genderMap = KeyTransitionUtil.selectGenders(redisService, Lists.newArrayList(recallSet));
        Integer finalTargetGender = targetGender;
        return genderMap.entrySet().stream()
                .filter(entry -> Objects.equals(finalTargetGender, entry.getValue()))
                .map(Map.Entry::getKey)
                .map(String::valueOf)
                .collect(Collectors.toSet());
    }
}
