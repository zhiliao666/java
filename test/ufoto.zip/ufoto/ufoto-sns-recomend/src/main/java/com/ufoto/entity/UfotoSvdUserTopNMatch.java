package com.ufoto.entity;

import com.ufoto.entity.base.BaseUfotoSvdUserTopNMatch;

public class UfotoSvdUserTopNMatch extends BaseUfotoSvdUserTopNMatch {

    private static final long serialVersionUID = 1L;

}
