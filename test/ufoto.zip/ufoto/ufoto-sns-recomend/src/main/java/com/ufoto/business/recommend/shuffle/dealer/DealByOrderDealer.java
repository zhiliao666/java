package com.ufoto.business.recommend.shuffle.dealer;

import com.ufoto.annotation.RecommendMetadata;
import com.ufoto.business.recommend.shuffle.base.ShuffleDealer;

import java.util.Collection;
import java.util.List;

@RecommendMetadata(
        metadataType = RecommendMetadata.MetadataType.DEALER,
        available = true,
        name = "顺序收集器",
        description = "按照list的顺序合并list",
        branch = RecommendMetadata.Branch.NORMAL
)
public class DealByOrderDealer implements ShuffleDealer {

    @Override
    public String[] shuffleAndDeal(List<List<String>> cutUidList) {
        return cutUidList.stream().flatMap(Collection::stream).toArray(String[]::new);
    }

}
