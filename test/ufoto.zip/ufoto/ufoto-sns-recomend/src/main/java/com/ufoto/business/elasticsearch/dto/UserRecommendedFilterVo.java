package com.ufoto.business.elasticsearch.dto;

import lombok.Data;

import java.io.Serializable;
import java.util.List;

/**
 * @author luozq
 * @date 2019/11/15 15:29
 */
@Data
public class UserRecommendedFilterVo implements Serializable {

    /**
     * user id, 当前发起请求的用户id,
     */
    private Long uid;

    /**
     * 用于过滤使用，
     */
    private List<Long> uidList;

    /**
     * 行为的起始时间
     */
    private Integer createTime;

}
