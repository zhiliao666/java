package com.ufoto.utils.quartz;

import com.ufoto.service.CleanRedisService;
import com.ufoto.utils.SpringContextUtil;
import lombok.extern.slf4j.Slf4j;
import org.quartz.DisallowConcurrentExecution;
import org.quartz.Job;
import org.quartz.JobExecutionContext;
import org.quartz.JobExecutionException;

/**
 * <p>
 * Author     : Chan
 * CreateDate : 2019-08-12 14:01
 * Description: 低曝光用户清理任务--活跃时间大于24小时的
 * </p>
 */
@Slf4j
@DisallowConcurrentExecution
public class NewComeUserClearJob implements Job {
    @Override
    public void execute(JobExecutionContext context) throws JobExecutionException {
        try {
            log.debug("newComeUserClear start...");
            final CleanRedisService cleanRedisService = SpringContextUtil.getBean(CleanRedisService.class);
            cleanRedisService.cleanOldNewComeUserSet();
            log.debug("newComeUserClear done...");
        } catch (Exception e) {
            log.error(e.getMessage(), e);
        }
    }
}
