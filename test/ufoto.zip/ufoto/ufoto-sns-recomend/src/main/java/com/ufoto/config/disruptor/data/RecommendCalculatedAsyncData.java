package com.ufoto.config.disruptor.data;

import com.ufoto.dto.RecommendAdvanceRequest;
import lombok.Builder;
import lombok.Data;
import lombok.EqualsAndHashCode;

import java.util.List;

/**
 * <p>
 * Description:
 *
 * </p>
 *
 * @author Chan
 * @date 2019/12/21 15:12
 */
@EqualsAndHashCode(callSuper = true)
@Data
@Builder
public class RecommendCalculatedAsyncData extends AsyncData {
    private RecommendAdvanceRequest recommendAdvanceRequest;
    private String recommendResultKey;
    private List<String> calculatedList;
    private List<String> illList;
    private List<String> recommendNoUserList;

}
