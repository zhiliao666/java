package com.ufoto.business.recommend.shuffle;

import com.ufoto.annotation.RecommendMetadata;
import com.ufoto.business.recommend.shuffle.base.BaseShuffleStrategy;
import com.ufoto.business.recommend.shuffle.cutter.LikeMeCutter;
import com.ufoto.business.recommend.shuffle.dealer.RandomByRateDealer;
import com.ufoto.utils.redis.RedisService;

@RecommendMetadata(
        metadataType = RecommendMetadata.MetadataType.SHUFFLE,
        available = true,
        name = "lik打散区器",
        description = "根据是否是like我分区(LikeMeCutter),然后按照指定的比例,将第一个list中的元素插入到第二个list中(RandomByRateDealer)",
        branch = RecommendMetadata.Branch.NORMAL
)
public class LikeMeShuffleStrategy extends BaseShuffleStrategy {

    public LikeMeShuffleStrategy(RedisService redisService, float rate, long uid) {
        this.cutter = new LikeMeCutter(uid, redisService);
        this.dealer = new RandomByRateDealer(rate);
    }

}
