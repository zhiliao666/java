package com.ufoto.dao.write;

import com.ufoto.dao.base.BaseUfotoAppCardMapper;

/**
 * <p>
 * Author     : Chan
 * CreateDate : 2018/9/15 10:15
 * Description:
 * </p>
 */
public interface WriteUfotoAppCardMapper extends BaseUfotoAppCardMapper {
}
