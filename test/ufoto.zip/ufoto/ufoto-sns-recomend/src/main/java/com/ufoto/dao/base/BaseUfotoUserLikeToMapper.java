package com.ufoto.dao.base;

import com.ufoto.entity.UfotoUserLike;
import org.apache.ibatis.annotations.*;
import org.apache.ibatis.jdbc.SQL;

import java.util.List;

public interface BaseUfotoUserLikeToMapper {

    @Results({
            @Result(property = "id", column = "id"),
            @Result(property = "fUId", column = "f_u_id"),
            @Result(property = "tUId", column = "t_u_id"),
            @Result(property = "type", column = "type"),
            @Result(property = "createTime", column = "create_time"),
    })
    @Select("SELECT * FROM ufoto_user_like_t")
    List<UfotoUserLike> list();

    @Select("SELECT count(*) FROM ufoto_user_like_t")
    int count();

    @Results({
            @Result(property = "id", column = "id"),
            @Result(property = "fUId", column = "f_u_id"),
            @Result(property = "tUId", column = "t_u_id"),
            @Result(property = "type", column = "type"),
            @Result(property = "createTime", column = "create_time"),
    })
    @Select("SELECT * FROM ufoto_user_like_t WHERE id = #{id}")
    UfotoUserLike selectOneById(@Param("id") Long id);

    @Delete("DELETE FROM ufoto_user_like_t WHERE id = #{id}")
    int delete(Long id);

    @Insert("INSERT INTO ufoto_user_like_t(f_u_id,t_u_id,type,create_time) VALUES(#{fUId},#{tUId},#{type},#{createTime})")
    @Options(useGeneratedKeys = true, keyProperty = "id")
    int insert(UfotoUserLike ufotoUserLike);

    @UpdateProvider(type = ProviderSqlBuilder.class, method = "updateById")
    int update(UfotoUserLike ufotoUserLike);

    @Delete("delete from ufoto_user_like_t where f_u_id=#{fUId} and t_u_id=#{tUId}")
    void deleteByFTUid(UfotoUserLike ufotoUserLike);

    class ProviderSqlBuilder {
        public String updateById(final UfotoUserLike ufotoUserLike) {
            return new SQL() {
                {
                    UPDATE("ufoto_user_like_t");
                    if (ufotoUserLike.getId() != null) {
                        SET("id = #{id}");
                    }
                    if (ufotoUserLike.getFUId() != null) {
                        SET("f_u_id = #{fUId}");
                    }
                    if (ufotoUserLike.getTUId() != null) {
                        SET("t_u_id = #{tUId}");
                    }
                    if (ufotoUserLike.getType() != null) {
                        SET("type = #{type}");
                    }
                    if (ufotoUserLike.getCreateTime() != null) {
                        SET("create_time = #{createTime}");
                    }
                    WHERE("id = #{id}");
                }
            }.toString();
        }
    }
}
