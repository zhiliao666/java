package com.ufoto.dto;

import lombok.Builder;
import lombok.Data;

import java.io.Serializable;
import java.util.Set;

/**
 * <p>
 * Author     : Chan
 * CreateDate : 2019-08-09 11:26
 * Description:
 * </p>
 */
@Data
@Builder
public class FilterRequestDto implements Serializable {
    private RecommendAdvanceRequest request;
    private Set<String> recallUids;
    private Integer type;
}
