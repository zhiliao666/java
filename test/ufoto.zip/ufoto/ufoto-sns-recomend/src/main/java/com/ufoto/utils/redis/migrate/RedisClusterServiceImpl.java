package com.ufoto.utils.redis.migrate;

import com.google.common.collect.Lists;
import com.google.common.collect.Maps;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Qualifier;
import org.springframework.data.geo.*;
import org.springframework.data.redis.connection.RedisGeoCommands.GeoLocation;
import org.springframework.data.redis.connection.RedisServerCommands;
import org.springframework.data.redis.core.*;
import org.springframework.data.redis.core.ZSetOperations.TypedTuple;
import org.springframework.util.CollectionUtils;

import java.util.*;
import java.util.concurrent.TimeUnit;

/**
 * <p>
 *
 * </p>
 *
 * @author created by chenzhou at 2018-08-21 10:35
 */
//@Component
public class RedisClusterServiceImpl implements RedisClusterService {

    /*
    修改redisTemplate 两边写入 从原先的redis写入 不读
    cluster 写入 读取
     */
    @Autowired
    @Qualifier("redisTemplate")
    private RedisTemplate<String, String> redisTemplate;

    @Override
    public long del(final String... keys) {
        final List<String> list = Arrays.asList(keys);
        final Long delete = redisTemplate.delete(list);
        return delete == null ? 0 : delete;
    }

    @Override
    public void delSet(Set<String> keys) {
        redisTemplate.delete(keys);
    }

    @Override
    public void set(String key, String value, long liveTime) {
        redisTemplate.opsForValue().set(key, value, liveTime, TimeUnit.SECONDS);
    }

    @Override
    public void set(String key, String value) {
        redisTemplate.opsForValue().set(key, value);
    }

    @Override
    public boolean setnx(String key, String value, long livetime) {
        this.set(key, value, livetime);
        return true;
    }

    @Override
    public String get(final String key) {
        return getConverter(redisTemplate.opsForValue().get(key));
    }

    private String getConverter(Object obj) {
        return obj == null ? null : String.valueOf(obj);
    }

    @Override
    public Set<String> keys(String pattern) {
        return redisTemplate.keys(pattern);

    }

    @Override
    public boolean exists(final String key) {
        final Boolean hasKey = redisTemplate.hasKey(key);
        return hasKey == null ? false : hasKey;
    }

    @Override
    public void flushDB() {
        redisTemplate.execute((RedisCallback<Object>) connection -> {
            connection.flushDb();
            return null;
        });
    }

    @Override
    public long dbSize() {
        final Long execute = redisTemplate.execute(RedisServerCommands::dbSize);
        return execute == null ? 0 : execute;
    }

    @Override
    public Long increment(String key) {
        return redisTemplate.opsForValue().increment(key, 1);
    }

    @Override
    public Long decrement(String key) {
        return redisTemplate.opsForValue().increment(key, -1);
    }

    @Override
    public void hMSet(String key, Map<String, String> map) {
        redisTemplate.opsForHash().putAll(key, map);
    }

    @Override
    public Map<String, String> hGetAll(String key) {
        final HashOperations<String, String, String> hash = redisTemplate.opsForHash();
        final Map<String, String> entries = hash.entries(key);
        if (CollectionUtils.isEmpty(entries)) {
            return Maps.newHashMap();
        }
        return entries;
    }

    @Override
    public void hDel(String key, String... obj) {
        redisTemplate.opsForHash().delete(key, Arrays.stream(obj).map(o -> (Object) o).toArray());
    }

    @Override
    public List<String> lrange(String key, long start, long end) {
        return redisTemplate.opsForList().range(key, start, end);
    }

    @Override
    public Long rpush(String key, String... members) {
        return redisTemplate.opsForList().rightPushAll(key, members);
    }

    @Override
    public Long lsize(String key) {
        return redisTemplate.opsForList().size(key);
    }

    @Override
    public Long lrem(String key, long count, String value) {
        return redisTemplate.opsForList().remove(key, count, value);
    }

    @Override
    public boolean zadd(String key, String value, double score) {
        final Boolean add = redisTemplate.opsForZSet().add(key, value, score);
        return add != null ? add : false;
    }

    @Override
    public Long zremove(String key, Object... values) {
        return redisTemplate.opsForZSet().remove(key, values);
    }

    @Override
    public Double zincrementScore(String key, String value, double delta) {
        return redisTemplate.opsForZSet().incrementScore(key, value, delta);
    }

    @Override
    public Long zrank(String key, Object value) {
        return redisTemplate.opsForZSet().rank(key, value);
    }

    @Override
    public Long zreverseRank(String key, Object value) {
        return redisTemplate.opsForZSet().reverseRank(key, value);
    }

    @Override
    public Long zremoveRange(String key, long start, long end) {
        return redisTemplate.opsForZSet().removeRange(key, start, end);
    }


    @Override
    public Long zremoveRangeByScore(String key, double min, double max) {
        return redisTemplate.opsForZSet().removeRangeByScore(key, min, max);
    }

    @Override
    public Set<String> zrange(String key, long start, long end) {
        return redisTemplate.opsForZSet().range(key, start, end);
    }

    @Override
    public Set<TypedTuple<String>> zrangeWithScores(String key, long start,
                                                    long end) {
        return redisTemplate.opsForZSet().rangeWithScores(key, start, end);
    }

    @Override
    public Set<String> zrangeByScore(String key, double min, double max) {
        return redisTemplate.opsForZSet().rangeByScore(key, min, max);
    }

    @Override
    public Set<TypedTuple<String>> zrangeByScoreWithScores(String key,
                                                           double min, double max) {
        return redisTemplate.opsForZSet().rangeByScoreWithScores(key, min, max);
    }

    @Override
    public Long zcount(String key, double min, double max) {
        return redisTemplate.opsForZSet().count(key, min, max);
    }

    @Override
    public Long zsize(String key) {
        return redisTemplate.opsForZSet().size(key);
    }

    @Override
    public Long zCard(String key) {
        return redisTemplate.opsForZSet().zCard(key);
    }

    @Override
    public Double zscore(String key, String value) {
        return redisTemplate.opsForZSet().score(key, value);
    }


    @Override
    public Long zUnionAndStore(String key, Collection<String> keys, String target) {
        return redisTemplate.opsForZSet().unionAndStore(key, keys, target);
    }

    @Override
    public Set<String> zrevrange(String key, long start, long end) {
        return redisTemplate.opsForZSet().reverseRange(key, start, end);
    }

    @Override
    public Set<TypedTuple<String>> reverseRangeWithScores(String key,
                                                          long start, long end) {
        return redisTemplate.opsForZSet().reverseRangeWithScores(key, start, end);
    }

    @Override
    public Long sadd(String key, String... values) {
        return redisTemplate.opsForSet().add(key, values);
    }

    @Override
    public Long sCard(String key) {
        return redisTemplate.opsForSet().size(key);
    }


    @Override
    public Long sremove(String key, String... values) {
        return redisTemplate.opsForSet().remove(key, Arrays.stream(values).map(o -> (Object) o).toArray());
    }

    @Override
    public String srandomMember(String key) {
        return redisTemplate.opsForSet().randomMember(key);
    }

    @Override
    public Set<String> sMember(String key) {
        return redisTemplate.opsForSet().members(key);
    }

    @Override
    public Set<String> sdistinctRandomMembers(String key, long count) {
        return redisTemplate.opsForSet().distinctRandomMembers(key, count);
    }

    @Override
    public List<String> srandomMembers(String key, long count) {
        return redisTemplate.opsForSet().randomMembers(key, count);
    }

    @Override
    public Cursor<String> scan(String key, ScanOptions options) {
        return redisTemplate.opsForSet().scan(key, options);
    }

    @Override
    public Set<String> sUnion(String key, Collection<String> keys) {
        return redisTemplate.opsForSet().union(key, keys);
    }


    @Override
    public Long sUnionAndStore(String key, Collection<String> keys, String target) {
        return redisTemplate.opsForSet().unionAndStore(key, keys, target);
    }

    @Override
    public Set<String> sInter(String key, Collection<String> keys) {
        return redisTemplate.opsForSet().intersect(key, keys);
    }


    @Override
    public Long sInterAndStore(String key, Collection<String> keys, String target) {
        return redisTemplate.opsForSet().intersectAndStore(key, keys, target);
    }

    @Override
    public Set<String> sDiff(String key, Collection<String> keys) {
        return redisTemplate.opsForSet().difference(key, keys);
    }


    @Override
    public Long sDiffAndStore(String key, Collection<String> keys, String target) {
        return redisTemplate.opsForSet().differenceAndStore(key, keys, target);
    }


    @Override
    public boolean expire(String key, long timeout, TimeUnit unit) {
        final Boolean expire = redisTemplate.expire(key, timeout, unit);
        return expire == null ? false : expire;
    }

    @Override
    public Boolean isMember(String key, String o) {
        final Boolean member = redisTemplate.opsForSet().isMember(key, o);
        return member == null ? Boolean.FALSE : member;
    }


    @Override
    public Long geoAdd(String key, Point point, String member) {
        return redisTemplate.opsForGeo().add(key, point, member);
    }

    @Override
    public List<String> geoHash(String key, String... members) {
        try {
            return redisTemplate.opsForGeo().hash(key, members);
        } catch (Exception e) {
            return Lists.newArrayList();
        }
    }

    @Override
    public GeoResults<GeoLocation<String>> geoRadius(String key, Circle within) {
        try {
            return redisTemplate.opsForGeo().radius(key, within);
        } catch (Exception e) {
            return new GeoResults<>(Lists.newArrayList());
        }
    }

    @Override
    public GeoResults<GeoLocation<String>> geoRadius(String key, String member, Distance distance) {
        try {
            return redisTemplate.opsForGeo().radius(key, member, distance);
        } catch (Exception e) {
            return new GeoResults<>(Lists.newArrayList());
        }
    }

    @Override
    public Distance geoDistance(String key, String member1, String member2) {
        try {
            return redisTemplate.opsForGeo().distance(key, member1, member2);
        } catch (Exception e) {
            return null;
        }
    }

    @Override
    public Distance geoDistance(String key, String member1, String member2, Metric metric) {
        try {
            return redisTemplate.opsForGeo().distance(key, member1, member2, metric);
        } catch (Exception e) {
            return null;
        }
    }

    @Override
    public Distance geoDistance(final String key, final String member,
                                final Double longitude, final Double latitude,
                                final Metric metric) {

        Object execute = redisTemplate.execute((RedisCallback<Object>) connection -> {
            String tempGeoMember = "\"getDistance:" + UUID.randomUUID() + "\"";
            String serilizedMember = "\"" + member + "\"";
            Point point = new Point(longitude, latitude);
            connection.geoAdd(key.getBytes(), point, tempGeoMember.getBytes());
            Distance result;
            try {
                result = connection.geoDist(key.getBytes(), tempGeoMember.getBytes(), serilizedMember.getBytes(), metric);
            } catch (Exception e) {
                result = new Distance(0d);
            }
            connection.zRem(key.getBytes(), tempGeoMember.getBytes());
            return result;
        });
        return (Distance) execute;
    }

    @Override
    public List<Point> geoPos(String key, String... members) {
        try {
            return redisTemplate.opsForGeo().position(key, members);
        } catch (Exception e) {
            return Lists.newArrayList();
        }
    }

    @Override
    public List<String> mget(List<String> keys) {
        return redisTemplate.opsForValue().multiGet(keys);
    }

    @Override
    public RedisTemplate<String, String> getRedisTemplate() {
        return redisTemplate;
    }

    @Override
    public String hget(String key, String field) {
        final Object o = redisTemplate.opsForHash().get(key, field);
        if (o == null) return null;
        return o.toString();
    }

    @Override
    public void hset(String key, String field, String value) {
        redisTemplate.opsForHash().put(key, field, value);
    }

    @Override
    public List<Object> execPipelineForWrite(RedisCallback<Object> redisCallback) {
        return redisTemplate.executePipelined(redisCallback);
    }
}
