package com.ufoto.constants;

/**
 * <p>
 * Description:
 *
 * </p>
 *
 * @author Chan
 * @date 2020/2/17 15:08
 */
public enum EUserLayer {
    COMMON(100),
    MONITOR(200),
    DANGEROUS(300);

    private Integer layer;

    EUserLayer(Integer layer) {
        this.layer = layer;
    }

    public Integer getLayer() {
        return layer;
    }
}
