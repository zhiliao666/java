package com.ufoto.business.recommend.filter.illegal;

import com.ufoto.annotation.RecommendMetadata;
import com.ufoto.business.recommend.RecommendFilterStrategy;
import com.ufoto.business.recommend.filter.FilterUtil;
import com.ufoto.dto.RecommendAdvanceRequest;
import com.ufoto.utils.redis.RedisKeyConstant;
import com.ufoto.utils.redis.RedisService;
import org.springframework.core.env.Environment;
import org.springframework.stereotype.Component;

import java.util.HashSet;
import java.util.List;
import java.util.Optional;
import java.util.Set;

/**
 * Created by echo on 4/3/18.
 * <p>
 * 过滤已经非法的用户
 */
@RecommendMetadata(
        metadataType = RecommendMetadata.MetadataType.FILTER,
        available = true,
        updateCache = true,
        name = "头像非法过滤策略",
        description = "过滤头像非法的用户，目前特指第一张头像非法，非法用户可以通过ERP处理",
        branch = {
                RecommendMetadata.Branch.NORMAL,
                RecommendMetadata.Branch.DEFAULT,
                RecommendMetadata.Branch.GIFT,
                RecommendMetadata.Branch.High_Risk,
                RecommendMetadata.Branch.USERLAYER,
                RecommendMetadata.Branch.WINK
        }
)
@Component
public class IllegalFilterStrategy implements RecommendFilterStrategy {
    private final RedisService redisService;
    private final Environment env;
    private final FilterUtil filterUtil;

    public IllegalFilterStrategy(RedisService redisService,
                                 Environment env,
                                 FilterUtil filterUtil) {
        this.redisService = redisService;
        this.env = env;
        this.filterUtil = filterUtil;
    }

    @Override
    public Set<String> filter(Set<String> recallSet, List<String> resultList, RecommendAdvanceRequest filterRequest) {
        return filterUtil.filter(recallSet, this.getClass());
    }

    public Set<String> updateCache() {
        final Boolean openFirstIllegal = env.getProperty("filter.illegal.first.head", Boolean.class, Boolean.FALSE);
        final String key = openFirstIllegal ? RedisKeyConstant.REDIS_HEAD_FIRST_ILLEGAL_USER_SET_KEY : RedisKeyConstant.REDIS_HEAD_ILLEGAL_USER_SET_KEY;
        return Optional.ofNullable(redisService.sMember(key, true)).orElse(new HashSet<>());
    }
}
