package com.ufoto.business.chatbot;

import com.ufoto.utils.redis.RedisKeyConstant;
import com.ufoto.utils.redis.RedisService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;

/**
 * Created by echo on 3/19/19.
 */
@Component
public class ChatBotUtil {

    @Autowired
    RedisService redisService;

    public boolean ifChatBotUid(Long uid) {
        return ifChatBotUid(String.valueOf(uid));
    }

    public boolean ifChatBotUid(String uid) {
        return redisService.isMember(RedisKeyConstant.REDIS_CHAT_BOT_UID_SET_KEY, uid);
    }
}
