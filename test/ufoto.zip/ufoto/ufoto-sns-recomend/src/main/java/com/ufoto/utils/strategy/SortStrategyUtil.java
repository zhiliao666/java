package com.ufoto.utils.strategy;

import com.google.common.collect.Maps;
import com.ufoto.business.recommend.RecommendSortStrategy;
import com.ufoto.business.recommend.sort.CompositeRecommendSortStrategy;
import com.ufoto.business.recommend.sort.SpecificRecommendSortStrategy;
import com.ufoto.dto.CommonStrategyBean;
import com.ufoto.utils.redis.RedisService;
import org.springframework.beans.factory.config.AutowireCapableBeanFactory;
import org.springframework.context.ApplicationContext;
import org.springframework.stereotype.Component;
import org.springframework.util.CollectionUtils;
import org.springframework.util.ReflectionUtils;

import java.lang.reflect.Field;
import java.util.List;
import java.util.Map;

/**
 * <p>
 *
 * </p>
 *
 * @author created by chenzhou at 2018-06-11 10:36
 */
@Component
public class SortStrategyUtil {
    private final ApplicationContext context;
    private final RedisService redisService;

    public SortStrategyUtil(ApplicationContext context,
                            RedisService redisService) {
        this.context = context;
        this.redisService = redisService;
    }

    public RecommendSortStrategy strategy(CommonStrategyBean commonStrategyBean) {
        try {
            if (commonStrategyBean == null) {
                throw new RuntimeException("策略bean为空");
            }
            String type = commonStrategyBean.getType();
            if (!"weight".equals(type)) {
                throw new RuntimeException("排序策略配置错误");
            }
            CompositeRecommendSortStrategy sortStrategy = new CompositeRecommendSortStrategy() {
            };
            List<CommonStrategyBean> strategies = commonStrategyBean.getChildren();
            if (!CollectionUtils.isEmpty(strategies)) {
                Map<SpecificRecommendSortStrategy, Double> tempMap = Maps.newHashMap();
                for (CommonStrategyBean strategy : strategies) {
                    final String childType = strategy.getType();
                    if (!"base".equals(childType)) {
                        throw new RuntimeException("排序策略配置错误");
                    }
                    tempMap.put(getBaseSortStrategy(strategy), Double.valueOf(strategy.getWeight()));
                }
                Field sortStrategyWeightMapField = ReflectionUtils.findField(CompositeRecommendSortStrategy.class, "sortStrategyWeightMap");
                if (sortStrategyWeightMapField != null) {
                    sortStrategyWeightMapField.setAccessible(true);
                    sortStrategyWeightMapField.set(sortStrategy, tempMap);
                }
                final Field redisServiceField = ReflectionUtils.findField(CompositeRecommendSortStrategy.class, "redisService");
                if (redisServiceField != null) {
                    redisServiceField.setAccessible(true);
                    redisServiceField.set(sortStrategy, redisService);
                }

            }
            return sortStrategy;
        } catch (Exception e) {
            throw new RuntimeException(e);
        }
    }

    public SpecificRecommendSortStrategy getBaseSortStrategy(CommonStrategyBean commonStrategyBean) throws Exception {
        String strategy = commonStrategyBean.getStrategy();
        Class<?> aClass = Class.forName(strategy);
        return (SpecificRecommendSortStrategy) context.getAutowireCapableBeanFactory().createBean(aClass,
                AutowireCapableBeanFactory.AUTOWIRE_BY_TYPE, true);
    }

}
