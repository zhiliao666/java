package com.ufoto.config.disruptor.data;

import lombok.Builder;
import lombok.Data;
import lombok.EqualsAndHashCode;

/**
 * <p>
 * Description:
 *
 * </p>
 *
 * @author Chan
 * @date 2019/12/21 15:44
 */
@EqualsAndHashCode(callSuper = true)
@Data
@Builder
public class UserActivityTimestampAsyncData extends AsyncData {
    private Long uid;
    private Integer timestamp;
}
