package com.ufoto.entity;

import com.ufoto.entity.base.BaseUfotoSvdItemSimilarityTopN;

public class UfotoSvdItemSimilarityTopN extends BaseUfotoSvdItemSimilarityTopN {

    private static final long serialVersionUID = 1L;

}
