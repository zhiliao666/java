package com.ufoto.utils.strategy;

import com.google.common.collect.Lists;
import com.ufoto.business.recommend.RecommendFilterStrategy;
import com.ufoto.business.recommend.filter.CompositeRecommendFilterStrategy;
import com.ufoto.dto.CommonStrategyBean;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.config.AutowireCapableBeanFactory;
import org.springframework.context.ApplicationContext;
import org.springframework.stereotype.Component;
import org.springframework.util.CollectionUtils;
import org.springframework.util.ReflectionUtils;

import java.lang.reflect.Field;
import java.util.List;

/**
 * <p>
 *
 * </p>
 *
 * @author created by chenzhou at 2018-06-11 10:36
 */
@Component
public class FilterStrategyUtil {

    @Autowired
    private ApplicationContext context;

    public RecommendFilterStrategy strategy(CommonStrategyBean commonStrategyBean) {
        try {
            if (commonStrategyBean == null) {
                throw new RuntimeException("策略bean为空");
            }
            String type = commonStrategyBean.getType();
            if ("composite".equals(type)) {
                return getCompositeFilterStrategy(commonStrategyBean);
            } else if ("weight".equals(type)) {
                //默认不会走
                throw new RuntimeException("过滤策略配置错误");
            } else if ("base".equals(type)) {
                return getBaseFilterStrategy(commonStrategyBean);
            }
            return null;
        } catch (Exception e) {
            throw new RuntimeException(e);
        }
    }

    public RecommendFilterStrategy getCompositeFilterStrategy(CommonStrategyBean commonStrategyBean) throws Exception {
        CompositeRecommendFilterStrategy filterStrategy = new CompositeRecommendFilterStrategy() {
        };

        List<CommonStrategyBean> strategies = commonStrategyBean.getChildren();
        if (!CollectionUtils.isEmpty(strategies)) {
            List<RecommendFilterStrategy> tempStrategies = Lists.newArrayList();
            for (CommonStrategyBean strategy : strategies) {
                tempStrategies.add(strategy(strategy));
            }
            Field filterStrategyListField = ReflectionUtils.findField(CompositeRecommendFilterStrategy.class, "filterStrategyList");
            if (filterStrategyListField != null) {
                filterStrategyListField.setAccessible(true);
                filterStrategyListField.set(filterStrategy, tempStrategies);
            }
        }
        return filterStrategy;
    }

    public RecommendFilterStrategy getBaseFilterStrategy(CommonStrategyBean commonStrategyBean) throws Exception {
        String strategy = commonStrategyBean.getStrategy();
        Class<?> aClass = Class.forName(strategy);
        return (RecommendFilterStrategy) context.getAutowireCapableBeanFactory().createBean(aClass,
                AutowireCapableBeanFactory.AUTOWIRE_BY_TYPE, true);
    }
}
