package com.ufoto.utils;

import lombok.extern.slf4j.Slf4j;
import org.joda.time.DateTime;
import org.joda.time.DateTimeZone;

import java.text.DateFormat;
import java.text.SimpleDateFormat;
import java.util.Calendar;
import java.util.Date;
import java.util.TimeZone;

/**
 * Created by Administrator on 2015/6/30.
 */
@Slf4j
public class DateUtil {
    public static final String DEFAULT_TIMEZONE_ID = "Asia/Shanghai";
    public static final TimeZone DEFAULT_TIMEZONE = TimeZone.getTimeZone(DEFAULT_TIMEZONE_ID);

    public static String getCurrentDateStr(String format) {
        DateFormat dateFormat = new SimpleDateFormat(format);
        dateFormat.setTimeZone(DEFAULT_TIMEZONE);
        return dateFormat.format(Calendar.getInstance().getTime());
    }

    public static Date nextChinaZero() {
        return DateTime.now(DateTimeZone.forTimeZone(DEFAULT_TIMEZONE)).plusDays(1)
                .withHourOfDay(0)
                .withMinuteOfHour(0)
                .withSecondOfMinute(0)
                .withMillisOfSecond(0)
                .toDate();
    }

    public static String getDateString(String format, Long millionSecond) {
        DateFormat dateFormat = new SimpleDateFormat(format);
        dateFormat.setTimeZone(DEFAULT_TIMEZONE);
        return dateFormat.format(millionSecond);
    }

    public static Integer getCurrentSecondIntValue() {
        return Math.toIntExact(System.currentTimeMillis() / 1000);
    }

    private static Date getOffsetDate(Integer offsetDays, Integer offsetMonths, Integer offsetYears) {
        final Calendar cal = Calendar.getInstance(DEFAULT_TIMEZONE);
        if (offsetDays != null) {
            cal.add(Calendar.DATE, offsetDays);
        }
        if (offsetMonths != null) {
            cal.add(Calendar.MONTH, offsetMonths);
        }
        if (offsetYears != null) {
            cal.add(Calendar.YEAR, offsetYears);
        }
        return cal.getTime();
    }

    public static String getOffsetDateString(Integer offsetDays, Integer offsetMonths,
                                             Integer offsetYears, String format) {
        Date date = getOffsetDate(offsetDays, offsetMonths, offsetYears);
        DateFormat dateFormat = new SimpleDateFormat(format);
        dateFormat.setTimeZone(DEFAULT_TIMEZONE);
        return dateFormat.format(date);
    }

    public static int getAge(String birthTimestamp) {
        Date dateOfBirth = new Date(Long.parseLong(birthTimestamp));
        Calendar born = Calendar.getInstance(DEFAULT_TIMEZONE);
        Calendar now = Calendar.getInstance(DEFAULT_TIMEZONE);
        now.setTime(new Date());
        born.setTime(dateOfBirth);
        if (born.after(now)) {
            return -1;
        }
        int age = now.get(Calendar.YEAR) - born.get(Calendar.YEAR);
        int nowDayOfYear = now.get(Calendar.DAY_OF_YEAR);
        int bornDayOfYear = born.get(Calendar.DAY_OF_YEAR);
        if (nowDayOfYear < bornDayOfYear) {
            age -= 1;
        }
        return age;
    }

    public static Integer getOneDaySecond() {
        return 86400;
    }

    public static Long getYearsoldTimestamp(int yearsold) {
        DateTime dateTime = DateTime.now();
        dateTime = dateTime.minusYears(yearsold);
        return dateTime.toDate().getTime();
    }

    public static long nextTwoZeroTimestamp() {
        return DateTime.now().plusDays(2)
                .withHourOfDay(0).withMinuteOfHour(0).withSecondOfMinute(0).withMillisOfSecond(0)
                .getMillis() / 1000;
    }

    public static Date nextTwoZero() {
        return DateTime.now().plusDays(2)
                .withHourOfDay(0).withMinuteOfHour(0).withSecondOfMinute(0).withMillisOfSecond(0).toDate();
    }
}
