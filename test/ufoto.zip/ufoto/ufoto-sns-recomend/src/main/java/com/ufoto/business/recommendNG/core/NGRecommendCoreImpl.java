package com.ufoto.business.recommendNG.core;

import com.google.common.collect.Lists;
import com.google.common.collect.Sets;
import com.ufoto.business.recommend.RecommendCore;
import com.ufoto.business.recommend.RecommendShuffleStrategy;
import com.ufoto.business.recommend.shuffle.ChatBotShuffleStrategy;
import com.ufoto.business.recommend.shuffle.FreeChatShuffleStrategy;
import com.ufoto.business.recommend.shuffle.GenderShuffleStrategy;
import com.ufoto.business.recommend.shuffle.LikeMeShuffleStrategy;
import com.ufoto.business.recommend.shuffle.NewComeShuffleStrategy;
import com.ufoto.business.recommend.shuffle.SuperLikeMeShuffleStrategy;
import com.ufoto.business.recommendNG.Invoker;
import com.ufoto.business.recommendNG.InvokerFactory;
import com.ufoto.dto.RecommendAdvanceRequest;
import com.ufoto.utils.redis.RedisKeyUtil;
import com.ufoto.utils.redis.RedisService;
import lombok.RequiredArgsConstructor;
import lombok.extern.slf4j.Slf4j;
import org.springframework.beans.factory.annotation.Qualifier;
import org.springframework.context.annotation.Primary;
import org.springframework.core.env.Environment;
import org.springframework.stereotype.Component;
import org.springframework.util.CollectionUtils;

import java.nio.charset.Charset;
import java.nio.charset.StandardCharsets;
import java.util.Arrays;
import java.util.List;
import java.util.Set;

/**
 * Created by echo on 10/13/18.
 */
@Slf4j
@Primary
@Qualifier("NG")
@Component
@RequiredArgsConstructor
public class NGRecommendCoreImpl implements RecommendCore {

    private final Environment env;
    private final RedisService redisService;
    private final InvokerFactory invokerFactory;

    @Override
    public void doRecommend(String resultListKey, RecommendAdvanceRequest recommendAdvanceRequest) {
        Long uid = recommendAdvanceRequest.getUid();
        int MIN_RECOMMEND_SIZE = env.getProperty("recommend.core.minRecommendSize", Integer.class, 20);
        int MIN_RECALL_SIZE = env.getProperty("recommend.core.minRecallSize", Integer.class, 250);

        //获取缓存中已经保存的内容
        List<String> resultList = redisService.lrange(resultListKey, 0, -1);
        Set<String> recalledUidSet = Sets.newHashSet();
        if (resultList != null)
            recalledUidSet.addAll(resultList);

        //获取对应的召回者
        Invoker invoker = invokerFactory.obtainInvoker(recommendAdvanceRequest);

        //开始召回、过滤、排序
        invoker.cleanThreadLocalCache();
        List<String> uidList = invoker.invoke(MIN_RECALL_SIZE, recommendAdvanceRequest, recalledUidSet);
        if (CollectionUtils.isEmpty(uidList)) {
            return;
        }
        String[] uidStringArray = uidList.toArray(new String[]{});

        //打散
        List<RecommendShuffleStrategy> shuffleStrategyList = createDefaultShuffle(uid);
        for (RecommendShuffleStrategy shuffleStrategy : shuffleStrategyList) {
            uidStringArray = shuffleStrategy.shuffle(uidStringArray);
        }

        String[] finalResult = null;
        if (uidStringArray != null && uidStringArray.length > 0) {
            //获取数组的前 N 个内容
            finalResult = MIN_RECOMMEND_SIZE < uidStringArray.length ?
                    Arrays.copyOfRange(uidStringArray, 0, MIN_RECOMMEND_SIZE) :
                    uidStringArray;
        }
        String[] finalResult1 = finalResult;
        redisService.execPipelineForWrite(redisConnection -> {
            Charset charset = StandardCharsets.UTF_8;
            if (finalResult1 != null) {
                redisConnection.rPush(resultListKey.getBytes(charset), Arrays.stream(finalResult1).map(id -> RedisKeyUtil.serializeUid(id).getBytes(charset)).toArray(byte[][]::new));
            }
            return null;
        });

    }
    
    @Override
    public void doWinkRecommend(String resultListKey, RecommendAdvanceRequest recommendAdvanceRequest) {
        int MIN_RECOMMEND_SIZE = env.getProperty("recommend.wink.core.minRecommendSize", Integer.class, 5);
        int MIN_RECALL_SIZE = env.getProperty("recommend.wink.core.minRecallSize", Integer.class, 50);

        //获取缓存中已经保存的内容
        List<String> resultList = redisService.lrange(resultListKey, 0, -1);
        Set<String> recalledUidSet = Sets.newHashSet();
        if (resultList != null)
            recalledUidSet.addAll(resultList);

        //获取对应的召回者
        Invoker invoker = invokerFactory.obtainInvoker(recommendAdvanceRequest);

        //开始召回、过滤、排序
        invoker.cleanThreadLocalCache();
        List<String> uidList = invoker.invoke(MIN_RECALL_SIZE, recommendAdvanceRequest, recalledUidSet);
        if (CollectionUtils.isEmpty(uidList)) {
            return;
        }
        String[] uidStringArray = uidList.toArray(new String[]{});
        
        //打散
        List<RecommendShuffleStrategy> shuffleStrategyList = createWinkShuffle(recommendAdvanceRequest.getUid());
        for (RecommendShuffleStrategy shuffleStrategy : shuffleStrategyList) {
            uidStringArray = shuffleStrategy.shuffle(uidStringArray);
        }

        String[] finalResult = null;
        if (uidStringArray != null && uidStringArray.length > 0) {
            //获取数组的前 N 个内容
            finalResult = MIN_RECOMMEND_SIZE < uidStringArray.length ?
                    Arrays.copyOfRange(uidStringArray, 0, MIN_RECOMMEND_SIZE) :
                    uidStringArray;
        }
        String[] finalResult1 = finalResult;
        redisService.execPipelineForWrite(redisConnection -> {
            Charset charset = StandardCharsets.UTF_8;
            if (finalResult1 != null) {
                redisConnection.rPush(resultListKey.getBytes(charset), Arrays.stream(finalResult1).map(id -> RedisKeyUtil.serializeUid(id).getBytes(charset)).toArray(byte[][]::new));
            }
            return null;
        });

    }

    @Override
    public List<String> doRecommendAndGetResult(String resultListKey, RecommendAdvanceRequest recommendAdvanceRequest, int start, int end) {
        doRecommend(resultListKey, recommendAdvanceRequest);
        List<String> result = redisService.lrange(resultListKey, start, end);
        if (CollectionUtils.isEmpty(result)) {
            //可能由于读写分离导致的数据不一致，通过延迟访问的方式来等待数据同步。
            try {
                Thread.sleep(10);
            } catch (InterruptedException e) {
                e.printStackTrace();
            }
            result = redisService.lrange(resultListKey, start, end);
        }
        return result;
    }
    
    @Override
    public List<String> doWinkRecommendAndGetResult(String resultListKey, RecommendAdvanceRequest recommendAdvanceRequest) {
    	doWinkRecommend(resultListKey, recommendAdvanceRequest);
        List<String> result = redisService.lrange(resultListKey, 0, recommendAdvanceRequest.getLimit()-1);
        if (CollectionUtils.isEmpty(result)) {
            //可能由于读写分离导致的数据不一致，通过延迟访问的方式来等待数据同步。
            try {
                Thread.sleep(10);
            } catch (InterruptedException e) {
                e.printStackTrace();
            }
            result = redisService.lrange(resultListKey, 0, recommendAdvanceRequest.getLimit()-1);
        }
        return result;
    }
    
    private List<RecommendShuffleStrategy> createWinkShuffle(Long uid) {
        if (uid == null) return Lists.newLinkedList();

        float freeChatRate = env.getProperty("recommend.shuffle.freeChatRate", Float.class, 1f);
        boolean freeChatShuffleOn = env.getProperty("recommend.shuffle.freeChatShuffleOn",Boolean.class,true);

        List<RecommendShuffleStrategy> result = Lists.newLinkedList();
        if(freeChatShuffleOn) {
        	FreeChatShuffleStrategy freeChatShuffleStrategy = new FreeChatShuffleStrategy(redisService, freeChatRate, uid);
            result.add(freeChatShuffleStrategy);
        }
        return result;
    }
    
    private List<RecommendShuffleStrategy> createDefaultShuffle(Long uid) {
        if (uid == null) return Lists.newLinkedList();

        float likeMeRate = env.getProperty("recommend.shuffle.likeMeRate", Float.class, 0.6f);
        boolean genderShuffleOn = Boolean.parseBoolean(env.getProperty("recommend.shuffle.genderShuffleOn"));
        boolean newComeShuffleOn = Boolean.parseBoolean(env.getProperty("recommend.shuffle.newComeShuffleOn"));
        boolean likeMeShuffleOn = Boolean.parseBoolean(env.getProperty("recommend.shuffle.likeMeShuffleOn"));

        List<RecommendShuffleStrategy> result = Lists.newLinkedList();
        if (genderShuffleOn) {
            GenderShuffleStrategy genderShuffleStrategy = new GenderShuffleStrategy(redisService);
            result.add(genderShuffleStrategy);
        }

        if (newComeShuffleOn) {
            NewComeShuffleStrategy newComeShuffleStrategy = new NewComeShuffleStrategy(redisService);
            result.add(newComeShuffleStrategy);
        }

        if (likeMeShuffleOn) {
            LikeMeShuffleStrategy likeMeShuffleStrategy = new LikeMeShuffleStrategy(redisService, likeMeRate, uid);
            result.add(likeMeShuffleStrategy);
        }

        int minChatBotCount = env.getProperty("recommend.shuffle.minChatBotCount", Integer.class, 2);
        int maxChatBotCount = env.getProperty("recommend.shuffle.maxChatBotCount", Integer.class, 2);
        ChatBotShuffleStrategy chatBotShuffleStrategy = new ChatBotShuffleStrategy(redisService, minChatBotCount, maxChatBotCount);
        result.add(chatBotShuffleStrategy);

        SuperLikeMeShuffleStrategy superLikeMeShuffleStrategy = new SuperLikeMeShuffleStrategy(redisService, uid);
        result.add(superLikeMeShuffleStrategy);

        return result;
    }
}
