package com.ufoto.business.recommend.filter.delete;

import org.springframework.stereotype.Component;

/**
 * 备用，以后如果发现性能问题就改成这个
 * <p>
 * Created by echo on 1/16/19.
 * <p>
 * 管理所有和DeletedUser的BloomFilter的操作,以及Redis中对应的数据结构
 * 提供方法如下：
 * put
 * mightContain
 * multiPut
 * filter
 * <p>
 * Redis中的数据结构：
 * deleted_user_bf:{index}
 * 默认大小为10000000,如果超过大小则进行扩容（新增index）
 * deleted_user_bf_hash
 * 记录所有的bf的key，以及对应key当中的元素个数
 * 另外有个特殊的field: current_bf, 记录当前正在使用的是哪个key
 * deleted_user_bf:0    10000000
 * deleted_user_bf:1    5009
 * current_key          deleted_user_bf:1
 */
@Component
public class DeleteBFManager {

//    Logger logger = UfotoLogFactory.getLogger(DeleteBFManager.class).build();
//
//
//    @Autowired
//    RedisService redisService;
//
//
//    /**
//     * 向BloomFilter当中添加元素
//     * @param uid
//     * @param itemId
//     */
//    public void BFPut(Long uid, Long itemId) {
//        if (itemId == null) {
//            logger.info("BFPut long itemId null. Uid:" + uid);
//            return;
//        }
//        BFPut(uid, String.valueOf(itemId));
//    }
//
//    /**
//     * 向BloomFilter当中添加元素
//     * @param uid
//     * @param item
//     */
//    public void BFPut(Long uid, String item) {
//        if ((uid == null) || StringUtils.isEmpty(item)) {
//            logger.warn("BFPut input null:", uid, item);
//            return;
//        }
//        String currentBFKey = getAndUpdateCurrentKey(uid);
//
//        long[] offsetArray = hashStringToOffsetArray(item);
//
//        List<Object> result = redisService.execPipelineForWrite(connection -> {
//            for (long offset : offsetArray)
//                connection.setBit(currentBFKey.getBytes(StandardCharsets.UTF_8), offset, true);
//            return null;
//        });
//
//        //判断对象是否已经存在于BF中
//        boolean ifOld = (Boolean) result.stream().reduce((a,b) -> (Boolean)a & (Boolean)b).get();
//        if(ifOld) return;
//
//        final String hashKey = RedisKeyUtil.obtainKey(RedisKeyConstant.REDIS_RECOMMENDED_BF_HASH, uid);
//        Long itemSize = redisService.hIncrBy(hashKey,currentBFKey,1L);
//        if(itemSize>TOTAL){
//            //如果当前BF当中的元素数量已经超过了预设上限，则进行扩容
//            int newIndex = Integer.valueOf(currentBFKey.split(":")[3])+1;
//            final String currentKeyField = RedisKeyConstant.REDIS_RECOMMENDED_BF_HASH_CURRENT_KEY;
//            String newCurrentKey = createNewCurrentKey(uid,newIndex);
//            redisService.hset(hashKey,currentKeyField,newCurrentKey);
//        }
//
//        //让缓存失效
//        createRawBFListCacheMap.remove(uid);
//    }
//
//    /**
//     * 向BloomFilter当中添加多个元素
//     * 由于目前并没有同步的调用，所以先以低性能的方式实现
//     *
//     * @param uid
//     * @param items
//     */
//    public void BFMultiPut(Long uid, Collection<String> items) {
//        if (uid==null || CollectionUtils.isEmpty(items)) {
//            logger.warn("BFMultiPut input null:", uid, items);
//            return;
//        }
//
//
//        final String[] itemArray = items.toArray(new String[]{});
//        final String hashKey = RedisKeyUtil.obtainKey(RedisKeyConstant.REDIS_RECOMMENDED_BF_HASH, uid);
//        int index = 0;
//        while(index<items.size()){
//            String currentBFKey = getAndUpdateCurrentKey(uid);
//            Long currentItemSize = redisService.hIncrBy(hashKey,currentBFKey,0L);
//            if(TOTAL<currentItemSize){//可能会存在这种竞争关系
//                logger.warn("BFMultiPut total<itemSize.index:"+index+",uid:"+uid+",item:"+itemArray[index]);
//                BFPut(uid,itemArray[index]);
//                index+=1;
//                continue;
//            }
//            long currentStep = TOTAL-currentItemSize+1;
//            if(currentStep + index >= items.size()) currentStep = items.size()-index;
//            List<Long> needInputOffsetList = Lists.newLinkedList();
//            for(int i=0;i<currentStep;i++){
//                for(long offset : hashStringToOffsetArray(itemArray[i+index])){
//                    needInputOffsetList.add(offset);
//                }
//            }
//            index+=currentStep;
//
//            redisService.execPipelineForWrite(connection -> {
//                for (long offset : needInputOffsetList)
//                    connection.setBit(currentBFKey.getBytes(StandardCharsets.UTF_8), offset, true);
//                return null;
//            });
//
//            currentItemSize = redisService.hIncrBy(hashKey,currentBFKey,currentStep);
//            if(currentItemSize>TOTAL){
//                //如果当前BF当中的元素数量已经超过了预设上限，则进行扩容
//                int newIndex = Integer.valueOf(currentBFKey.split(":")[3])+1;
//                final String currentKeyField = RedisKeyConstant.REDIS_RECOMMENDED_BF_HASH_CURRENT_KEY;
//                String newCurrentKey = createNewCurrentKey(uid,newIndex);
//                redisService.hset(hashKey,currentKeyField,newCurrentKey);
//            }
//        }
//
//        //让缓存失效
//        createRawBFListCacheMap.remove(uid);
//    }
//
//    /**
//     * 将itemSet存在于BF当中的元素集合过滤
//     * @param uid
//     * @param itemSet
//     * @return
//     */
//    public Set<String> BFFilter(Long uid, Set<String> itemSet) {
//        if (uid==null || CollectionUtils.isEmpty(itemSet)) {
//            logger.warn("BFFilter input null:", uid, itemSet);
//            return Sets.newHashSet();
//        }
//
//        final List<byte[]> rawBFList = createRawBFList(uid);
//        if(CollectionUtils.isEmpty(rawBFList)) return itemSet;
//
//        Set<String> result = Sets.newHashSet();
//        result.addAll(itemSet.stream().filter(item -> !ifItemInRawBFList(item, rawBFList)).collect(Collectors.toList()));
//        return result;
//    }
//
//    /**
//     * @param uid
//     * @param item
//     * @return
//     */
//    public boolean BFMightContain(Long uid, String item) {
//        if (uid ==null || StringUtils.isEmpty(item)) {
//            logger.warn("BFMightContain input null:", uid, item);
//            return false;
//        }
//
//        final List<byte[]> rawBFList = createRawBFList(uid);
//        if(CollectionUtils.isEmpty(rawBFList)) return false;
//
//        return ifItemInRawBFList(item, rawBFList);
//    }
//
//    /**
//     * 返回对应用户所有的BF Key
//     * @param uid
//     * @return
//     */
//    public List<String> allBFKeyList(Long uid){
//        final String hashKey = RedisKeyUtil.obtainKey(RedisKeyConstant.REDIS_RECOMMENDED_BF_HASH, uid);
//        Map<String, String> recommendedBFMap = redisService.hGetAll(hashKey);
//        if(CollectionUtils.isEmpty(recommendedBFMap)) return Lists.newLinkedList();
//
//        List<String> BFKeyList = recommendedBFMap.keySet().stream().filter(x->ifRecommendedBFKey(x)).collect(Collectors.toList());
//        return BFKeyList;
//    }
//
//    /**
//     * 清空所有BF
//     *
//     * @param uid
//     */
//    public void clean(Long uid){
//        createRawBFListCacheMap.remove(uid);
//        List<String> BFKeyList = allBFKeyList(uid);
//        if(CollectionUtils.isEmpty(BFKeyList)) return;
//
//        for(String key : BFKeyList){
//            redisService.del(key);
//        }
//
//        final String hashKey = RedisKeyUtil.obtainKey(RedisKeyConstant.REDIS_RECOMMENDED_BF_HASH, uid);
//        redisService.del(hashKey);
//    }
//
//    /**
//     * 清理对应用户已经过期了的BF
//     *
//     * @param uid
//     */
//    public void cleanExpiredBF(Long uid){
//        List<String> BFKeyList = allBFKeyList(uid);
//        List<String> expiredKeyList = BFKeyList.stream().filter(x->ifRecommendedBFKeyExpired(x)).collect(Collectors.toList());
//        final String hashKey = RedisKeyUtil.obtainKey(RedisKeyConstant.REDIS_RECOMMENDED_BF_HASH, uid);
//        for(String expiredKey : expiredKeyList){
//            redisService.del(expiredKey);
//            redisService.hDel(hashKey,expiredKey);
//        }
//        if(expiredKeyList.size() == BFKeyList.size()){
//            redisService.del(hashKey);
//        }
//    }
//
//
//    @VisibleForTesting
//    static long optimalNumOfBits(long n, double p) {
//        if (p == 0.0D) {
//            p = 4.9E-324D;
//        }
//
//        return (long) ((double) (-n) * Math.log(p) / (Math.log(2.0D) * Math.log(2.0D)));
//    }
//
//    @VisibleForTesting
//    static int optimalNumOfHashFunctions(long n, long m) {
//        return Math.max(1, (int) Math.round((double) m / (double) n * Math.log(2.0D)));
//    }
//
//    private static final int TOTAL = 10000000;
//    private static final double FPP = 0.00001;
//
//    private static final long BF_BITS_SIZE = optimalNumOfBits(TOTAL, FPP);
//    private static final int BF_HASH_FUNC_NUM = optimalNumOfHashFunctions(TOTAL, BF_BITS_SIZE);
//
//    long[] hashStringToOffsetArray(String string) {
//        if (string == null) throw new NullPointerException("Input string can not be null.");
//
//        long hash64 = Hashing.murmur3_128().hashString(string, Charsets.UTF_8).asLong();
//        int hash1 = (int) hash64;
//        int hash2 = (int) (hash64 >>> 32);
//
//        long combinedHash = hash1;
//        long[] offsets = new long[BF_HASH_FUNC_NUM];
//        for (int i = 0; i < BF_HASH_FUNC_NUM; i++) {
//            offsets[i] = (combinedHash & Long.MAX_VALUE) % BF_BITS_SIZE;
//            combinedHash += hash2;
//        }
//
//        return offsets;
//    }
//
//    /**
//     * 判断对应的元素是否在BloomFilter当中
//     *
//     * @param item
//     * @param rawBFList BF的裸数据，大端。例如：
//     *              BF   ： 00010000 01000000
//     *              rawBF:  16       64
//     * @return
//     */
//    boolean ifItemInRawBFList(String item, List<byte[]> rawBFList) {
//        if (CollectionUtils.isEmpty(rawBFList) || StringUtils.isEmpty(item)) return false;
//
//        long hash64 = Hashing.murmur3_128().hashString(item, Charsets.UTF_8).asLong();
//        int hash1 = (int) hash64;
//        int hash2 = (int) (hash64 >>> 32);
//
//        long combinedHash = hash1;
//        List<byte[]> currentRoundBFList = rawBFList;
//        List<byte[]> nextRoundBFList = Lists.newArrayListWithCapacity(rawBFList.size());
//        for (int i = 0; i < BF_HASH_FUNC_NUM; i++) {
//            long offsets = (combinedHash & Long.MAX_VALUE) % BF_BITS_SIZE;
//            long index = offsets >> 3;//除以8,我也不知道有没有性能上的优势
//            for(byte[] rawBF : currentRoundBFList){
//                if (rawBF==null || index >= rawBF.length) continue;
//                byte rest = (byte) (128 >> (offsets & 7)); //除以8取余数,并转化成对应的byte
//                if ((rest & rawBF[(int) index]) == 0) continue;
//                nextRoundBFList.add(rawBF);
//            }
//            if(nextRoundBFList.size()==0) return false;
//            currentRoundBFList = nextRoundBFList;
//            nextRoundBFList = Lists.newArrayListWithCapacity(rawBFList.size());
//            combinedHash += hash2;
//        }
//
//        return true;
//    }
//
//
//    private String getAndUpdateCurrentKey(Long uid) {
//        final String hashKey = RedisKeyConstant.REDIS_DELETED_USER_BF_HASH;
//        final String currentKeyField = RedisKeyConstant.REDIS_DELETED_USER_BF_HASH_CURRENT_KEY;
//        String currentBFKey = redisService.hget(hashKey, currentKeyField);
//        if (!StringUtils.isEmpty(currentBFKey)) {
//              return currentBFKey;
//        }
//        currentBFKey = createNewCurrentKey(uid,0);
//        redisService.hset(hashKey,currentKeyField,currentBFKey);
//        return currentBFKey;
//    }
//
//    private String createNewCurrentKey(Long uid,int index) {
//        String keyTemplate = RedisKeyConstant.REDIS_DELETED_USER_BF_KEY_;
//        String key = RedisKeyUtil.obtainKey(keyTemplate, index);
//        return key;
//    }
//
//    private List<byte[]> createRawBFList(Long uid){
//        List<byte[]> rawBFList = createRawBFListCacheMap.get(uid);
//        if(!CollectionUtils.isEmpty(rawBFList))
//            return rawBFList;
//        List<String> BFKeyList = allBFKeyList(uid);
//        if(CollectionUtils.isEmpty(BFKeyList)) return null;
//
//        final List<Object> objects = redisService.getRedisTemplate().executePipelined((RedisCallback<Object>) connection -> {
//            for(String key : BFKeyList){
//                connection.get(key.getBytes(StandardCharsets.UTF_8));
//            }
//            return null;
//        },null);
//        List<byte[]> bfResult = objects.stream().map(x->(byte[])x).collect(Collectors.toList());
//        createRawBFListCacheMap.put(uid,bfResult);
//        return bfResult;
//    }
//
//    /**
//     * 判断是否是一个RecommendedBF的Key
//     * @return
//     */
//    private static final String RECOMMENDED_BF_KEY_PREFIX = "recommended_bf:";
//    private boolean ifRecommendedBFKey(String key){
//        return key.startsWith(RECOMMENDED_BF_KEY_PREFIX);
//    }
//
//    private static final int BF_KEY_EXPIRE_WEEKS = 4;
//    private boolean ifRecommendedBFKeyExpired(String key){
//        int currentWeek = getCurrentWeek();
//        return currentWeek - Integer.valueOf(key.split(":")[2]) >= BF_KEY_EXPIRE_WEEKS;
//    }
}
