package com.ufoto.business.usercenter.dto;

import lombok.Data;

import java.io.Serializable;

/**
 * 用户基本信息
 *
 * @author luozq
 * @date 2019/3/12/012
 */
@Data
public class UserBaseInfoDto extends UfotoAppUserDo implements Serializable {


}
