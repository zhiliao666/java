package com.ufoto.business.recommend.sort.likeme;

import com.ufoto.annotation.RecommendMetadata;
import com.ufoto.business.recommend.bean.SortParamsBean;
import com.ufoto.business.recommend.sort.BaseNormalSortStrategy;
import com.ufoto.utils.CommonUtil;
import com.ufoto.utils.redis.RedisKeyConstant;
import com.ufoto.utils.redis.RedisKeyUtil;
import com.ufoto.utils.redis.RedisService;
import org.springframework.stereotype.Component;

import java.nio.charset.StandardCharsets;
import java.util.List;
import java.util.Map;

/**
 * Created by echo on 4/8/18.
 */
@RecommendMetadata(
        metadataType = RecommendMetadata.MetadataType.SORT,
        available = true,
        name = "like我排序策略",
        description = "like我,基础分数为1,此外为0"
)
@Component
public class LikeMeSortStrategy extends BaseNormalSortStrategy {

    private final RedisService redisService;

    public LikeMeSortStrategy(RedisService redisService) {
        this.redisService = redisService;
    }

    /**
     * 返回对应用户是否like我
     */
    @Override
    public Map<String, Double> getScore(List<String> recallUids, SortParamsBean sortParamsBean) {
        final Long uid = sortParamsBean.getUid();
        final List<Object> objects = redisService.execPipelineForRead(connection -> {
            for (String recallUid : recallUids) {
                connection.sIsMember((RedisKeyConstant.REDIS_BE_LIKED_SET_KEY_ + uid).getBytes(StandardCharsets.UTF_8),
                        RedisKeyUtil.serializeUid(recallUid).getBytes(StandardCharsets.UTF_8));
            }
            return null;
        });
        return CommonUtil.getScoreMapOfLike(recallUids, objects);
    }
}
