package com.ufoto.dto.sns;

import lombok.Data;

import java.io.Serializable;

/**
 * <p>
 * Description:
 *
 * </p>
 *
 * @author Chan
 * @date 2019/12/24 17:12
 */
@Data
public class FeedImgInfo implements Serializable {

    private String url;
    private Integer width;
    private Integer height;
    private Double duration;
    private Long size;
    private String videoUrl;
    //默认 0 feed图片， 1 gif， 2 video
    private Integer fileType = 0;
}
