package com.ufoto.utils.redis.migrate;

import org.aspectj.lang.JoinPoint;
import org.aspectj.lang.annotation.AfterReturning;
import org.aspectj.lang.reflect.MethodSignature;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;

import java.lang.reflect.InvocationTargetException;

/**
 * <p>
 * 单写 只使用集群 interceptor 完成了自己的使命
 * </p>
 *
 * @author created by chenzhou at 2018-08-21 10:12
 */
//@Aspect
//@Component
public class RedisMigrateInterceptor {

    private static Logger logger = LoggerFactory.getLogger("RedisMigrateInterceptor");

    @Autowired
    private RedisClusterService redisClusterService;

    @AfterReturning(value = "@annotation(com.ufoto.utils.redis.migrate.RedisMigrate) ", returning = "re")
    public void doRecallAfter(JoinPoint joinPoint, Object re) {
        MethodSignature signature = (MethodSignature) joinPoint.getSignature();
        final Object target = joinPoint.getTarget();
        final Object[] args = joinPoint.getArgs();
        //final String type = env.getProperty("redis.migrate.type", RedisMigrate.MigrateType.TRANSFER.name());
        handleSyncWrite(target, signature, args);
    }

    private void handleSyncWrite(Object target, MethodSignature signature, Object[] args) {
        try {
            redisClusterService.getClass().getMethod(signature.getName(), signature.getParameterTypes())
                    .invoke(redisClusterService, args);
        } catch (NoSuchMethodException | IllegalAccessException | InvocationTargetException e) {
            logger.error("同步写入redis错误,src:{},dest:{},method:{},args:{},error:{}",
                    target.getClass().getName(), redisClusterService.getClass().getName(), signature.getName(), args, e.getMessage());
        }
    }
}
