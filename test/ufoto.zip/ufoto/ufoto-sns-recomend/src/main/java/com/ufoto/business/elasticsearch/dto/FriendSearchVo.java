package com.ufoto.business.elasticsearch.dto;

import com.fasterxml.jackson.annotation.JsonProperty;
import lombok.Builder;
import lombok.Data;

import java.util.List;

@Builder
@Data
public class FriendSearchVo {

    /**
     * uid
     */
    @JsonProperty("uid")
    private Long uid;
    /**
     * friend id list, may contains id that is not a friend
     */
    @JsonProperty("friend_id_list")
    private List<Long> friendIdList;
}
