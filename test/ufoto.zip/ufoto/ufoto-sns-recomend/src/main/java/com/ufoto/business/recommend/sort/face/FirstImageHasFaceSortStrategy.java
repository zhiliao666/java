package com.ufoto.business.recommend.sort.face;

import com.google.common.collect.Maps;
import com.ufoto.annotation.RecommendMetadata;
import com.ufoto.business.recommend.bean.SortParamsBean;
import com.ufoto.business.recommend.sort.BaseNormalSortStrategy;
import com.ufoto.utils.redis.RedisKeyConstant;
import com.ufoto.utils.redis.RedisKeyUtil;
import com.ufoto.utils.redis.RedisService;
import org.springframework.stereotype.Component;
import org.springframework.util.CollectionUtils;
import org.springframework.util.StringUtils;

import java.nio.charset.StandardCharsets;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.stream.Collectors;

@RecommendMetadata(
        metadataType = RecommendMetadata.MetadataType.SORT,
        available = true,
        name = "人脸has排序策略",
        description = "头图中是否有人脸,有则分数为1,没有为0.人脸检测准确度不高,权重慎重调解",
        branch = RecommendMetadata.Branch.NORMAL
)
@Component
public class FirstImageHasFaceSortStrategy extends BaseNormalSortStrategy {

    private final RedisService redisService;

    public FirstImageHasFaceSortStrategy(RedisService redisService) {
        this.redisService = redisService;
    }

    /**
     * 根据用户第一章图片是否有人脸进行排序。
     * 有人脸分数为1,无人脸分数为0。
     * 由于人脸检测准确度并没有保证，所以请酌情调节权重
     */
    @Override
    public Map<String, Double> getScore(List<String> recallUids, SortParamsBean sortParamsBean) {
        List<Long> uids = recallUids.stream().filter(StringUtils::hasText).map(Long::valueOf).collect(Collectors.toList());
        if (CollectionUtils.isEmpty(uids)) {
            return Maps.newHashMap();
        }
        List<Object> resultList = redisService.execPipelineForRead(connection -> {
            for (String id : recallUids) {
                connection.hGet(
                        RedisKeyUtil.obtainKey(RedisKeyConstant.REDIS_USER_HASH_KEY, id).getBytes(StandardCharsets.UTF_8),
                        RedisKeyConstant.REDIS_USER_FIRST_IMAGE_HAS_FACE.getBytes(StandardCharsets.UTF_8)
                );
            }
            return null;
        });

        Map<String, Double> scoreMap = new HashMap<>();
        final int size = recallUids.size();
        for (int i = 0; i < size; i++) {
            final Integer firstImageHasFace = (Integer) resultList.get(i);
            final String recallUid = recallUids.get(i);
            double score = firstImageHasFace == null ? 0 : firstImageHasFace.doubleValue();
            scoreMap.put(recallUid, score);
        }
        return scoreMap;
    }

}
