package com.ufoto.dto.sns;

public class SnsLikeStatusDto {

    private boolean ifLike;
    private boolean ifBeLiked;
    private boolean ifMatch;
    private boolean ifDislike;
    private boolean ifDisliked;

    public boolean isIfDislike() {
        return ifDislike;
    }

    public void setIfDislike(boolean ifDislike) {
        this.ifDislike = ifDislike;
    }

    public boolean isIfDisliked() {
        return ifDisliked;
    }

    public void setIfDisliked(boolean ifDisliked) {
        this.ifDisliked = ifDisliked;
    }

    public boolean isIfLike() {
        return ifLike;
    }

    public void setIfLike(boolean ifLike) {
        this.ifLike = ifLike;
    }

    public boolean isIfBeLiked() {
        return ifBeLiked;
    }

    public void setIfBeLiked(boolean ifBeLiked) {
        this.ifBeLiked = ifBeLiked;
    }

    public boolean isIfMatch() {
        return ifMatch;
    }

    public void setIfMatch(boolean ifMatch) {
        this.ifMatch = ifMatch;
    }
}