package com.ufoto.utils.quartz;

import com.ufoto.service.CleanRedisService;
import com.ufoto.utils.SpringContextUtil;
import lombok.extern.slf4j.Slf4j;
import org.quartz.DisallowConcurrentExecution;
import org.quartz.Job;
import org.quartz.JobExecutionContext;
import org.quartz.JobExecutionException;

/**
 * <p>
 * Author     : Chan
 * CreateDate : 2019-08-12 14:17
 * Description: 清理24小时活跃用户中已经过期的看过的用户的BF
 * </p>
 */
@Slf4j
@DisallowConcurrentExecution
public class RecommendedUserClearJob implements Job {
    @Override
    public void execute(JobExecutionContext context) throws JobExecutionException {
        try {
            log.debug("recommendedUser start...");
            final CleanRedisService cleanRedisService = SpringContextUtil.getBean(CleanRedisService.class);
            cleanRedisService.cleanExpiredRecommendedBF();
            log.debug("recommendedUser done...");
        } catch (Exception e) {
            log.error(e.getMessage(), e);
        }
    }
}
