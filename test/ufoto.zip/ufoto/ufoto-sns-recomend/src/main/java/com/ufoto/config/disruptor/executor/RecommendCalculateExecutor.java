package com.ufoto.config.disruptor.executor;

import com.ufoto.config.disruptor.data.AsyncData;
import com.ufoto.config.disruptor.data.RecommendCalculatedAsyncData;
import lombok.extern.slf4j.Slf4j;

/**
 * <p>
 * Description:
 *
 * </p>
 *
 * @author Chan
 * @date 2019/12/21 15:05
 */
@Slf4j
public abstract class RecommendCalculateExecutor implements AsyncExecutor {

    public RecommendCalculatedAsyncData dataCheckAndConverter(AsyncData asyncData) {
        if (!(asyncData instanceof RecommendCalculatedAsyncData)) {
            log.warn("RecommendCalculatedWarn:{},data type error", asyncData);
            return null;
        }
        return (RecommendCalculatedAsyncData) asyncData;
    }
}
