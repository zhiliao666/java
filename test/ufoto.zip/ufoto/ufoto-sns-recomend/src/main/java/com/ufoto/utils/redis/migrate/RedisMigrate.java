package com.ufoto.utils.redis.migrate;

import java.lang.annotation.*;

/**
 * <p>
 * redis迁移
 * </p>
 *
 * @author created by chenzhou at 2018-08-21 10:14
 */
@Target(ElementType.METHOD)
@Retention(RetentionPolicy.RUNTIME)
@Documented
public @interface RedisMigrate {

    //迁移-当前类型
    enum MigrateType {
        TRANSFER,//写入redis和redis中转站
        CLUSTER//同步写入redis和redis cluster
    }

}
