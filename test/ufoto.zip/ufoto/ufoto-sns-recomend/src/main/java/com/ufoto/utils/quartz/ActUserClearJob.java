package com.ufoto.utils.quartz;

import com.ufoto.service.CleanRedisService;
import com.ufoto.utils.SpringContextUtil;
import lombok.extern.slf4j.Slf4j;
import org.quartz.DisallowConcurrentExecution;
import org.quartz.Job;
import org.quartz.JobExecutionContext;
import org.quartz.JobExecutionException;

/**
 * <p>
 * Author     : Chan
 * CreateDate : 2019-08-12 14:10
 * Description: 清理24h活跃用户的相关数据
 * </p>
 */
@Slf4j
@DisallowConcurrentExecution
public class ActUserClearJob implements Job {
    @Override
    public void execute(JobExecutionContext context) throws JobExecutionException {
        try {
            log.debug("actUserClear start...");
            final CleanRedisService cleanRedisService = SpringContextUtil.getBean(CleanRedisService.class);
            cleanRedisService.clearExpired24hAct();
            log.debug("actUserClear done...");
        } catch (Exception e) {
            log.error(e.getMessage(), e);
        }
    }
}
