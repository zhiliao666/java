package com.ufoto.business.elasticsearch.dto;

import lombok.Data;

import javax.validation.constraints.Max;

/**
 * @author tangyd
 */
@Data
public class HighRiskCallVO {

    @Max(value = 1000, message = "最大查询 1000 条, 请减小查询数量.")
    private Integer limit = 10;

    private Integer lastActiveTime = null;

}
