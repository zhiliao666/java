package com.ufoto.config.disruptor.constants;

import com.ufoto.config.disruptor.executor.*;

/**
 * <p>
 * Description:
 *
 * </p>
 *
 * @author Chan
 * @date 2019/12/21 14:58
 */
public enum EventType {
    ASYNC_ERROR_END(ErrorEndAsyncExecutor.class),
    RECOMMEND_CALCULATE_REMOVE(RecommendCalculateRemoveExecutor.class),
    RECOMMEND_CALCULATE_BLOOM(RecommendCalculateBloomExecutor.class),
    RECOMMEND_CALCULATE_PREPARE_TRIGGER(RecommendCalculatePrepareTriggerExecutor.class),
    USER_ACTIVITY_TIMESTAMP(UserActivityTimestampAsyncExecutor.class);

    private Class<? extends AsyncExecutor> asyncExecutorClass;

    EventType(Class<? extends AsyncExecutor> asyncExecutorClass) {
        this.asyncExecutorClass = asyncExecutorClass;
    }

    public Class<? extends AsyncExecutor> getAsyncExecutorClass() {
        return asyncExecutorClass;
    }
}
