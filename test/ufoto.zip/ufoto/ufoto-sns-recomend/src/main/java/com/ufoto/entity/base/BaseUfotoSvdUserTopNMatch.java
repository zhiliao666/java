package com.ufoto.entity.base;

import java.io.Serializable;

public class BaseUfotoSvdUserTopNMatch implements Serializable {
    /**
     * Default value included to remove warning. Remove or modify at will.
     **/
    private static final long serialVersionUID = 1L;

    private java.lang.Integer createTime;
    private java.lang.Integer rank;
    private java.lang.Integer id;
    private java.lang.Long uId;
    private java.lang.Long iId;

    public java.lang.Integer getCreateTime() {
        return createTime;
    }

    public void setCreateTime(java.lang.Integer createTime) {
        this.createTime = createTime;
    }

    public java.lang.Integer getRank() {
        return rank;
    }

    public void setRank(java.lang.Integer rank) {
        this.rank = rank;
    }

    public java.lang.Integer getId() {
        return id;
    }

    public void setId(java.lang.Integer id) {
        this.id = id;
    }

    public java.lang.Long getUId() {
        return uId;
    }

    public void setUId(java.lang.Long uId) {
        this.uId = uId;
    }

    public java.lang.Long getIId() {
        return iId;
    }

    public void setIId(java.lang.Long iId) {
        this.iId = iId;
    }


//	@Override
//	public String toString() {
//		return "{ id:" + id + ", name:" + name + ", email:" + email
//				+ ", phone:" + phoneNumber + " }";
//	}
}
