package com.ufoto.config.disruptor.consumer;

import com.ufoto.config.disruptor.constants.ConsumerId;
import org.springframework.stereotype.Component;

/**
 * <p>
 * Description:
 * 最后一个执行  清除event
 * </p>
 *
 * @author Chan
 * @date 2019/12/21 17:50
 */
@Component
public class RecommendCalculatePrepareTriggerConsumer extends AsyncConsumer {
    public RecommendCalculatePrepareTriggerConsumer() {
        super(ConsumerId.CONSUMER_RECOMMEND_CALCULATE_PREPARE_TRIGGER);
    }

    @Override
    public boolean clear() {
        return true;
    }
}
