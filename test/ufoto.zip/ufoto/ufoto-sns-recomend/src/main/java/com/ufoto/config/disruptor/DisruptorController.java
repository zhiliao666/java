package com.ufoto.config.disruptor;

import com.ufoto.utils.ApiResult;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RestController;

/**
 * <p>
 * Author     : Chan
 * CreateDate : 2019/11/20 18:13
 * Description:
 * </p>
 */
@RestController
@RequestMapping("/disruptor")
public class DisruptorController {

    private final DisruptorStatistics disruptorStatistics;

    public DisruptorController(DisruptorStatistics disruptorStatistics) {
        this.disruptorStatistics = disruptorStatistics;
    }

    @RequestMapping(path = "/statistics", method = RequestMethod.GET)
    public ApiResult measure() {
        return new ApiResult<>().setResult(disruptorStatistics.logStatistics());
    }

}
