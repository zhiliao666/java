package com.ufoto.business.recommend.sort.showNum;

import com.google.common.collect.Lists;
import com.ufoto.annotation.RecommendMetadata;
import com.ufoto.business.recommend.bean.SortParamsBean;
import com.ufoto.business.recommend.sort.BaseNormalSortStrategy;
import com.ufoto.utils.redis.RedisKeyConstant;
import com.ufoto.utils.redis.RedisService;
import org.springframework.stereotype.Component;

import java.nio.charset.StandardCharsets;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.stream.Collectors;

/**
 * Created by echo on 5/18/18.
 */
@RecommendMetadata(
        metadataType = RecommendMetadata.MetadataType.SORT,
        available = true,
        name = "未处理的like数量排序策略",
        description = "基础分数为未处理的被like和被superlike数量",
        branch = RecommendMetadata.Branch.NORMAL
)
@Component
public class ShowNumSortStrategy extends BaseNormalSortStrategy {

    private final RedisService redisService;

    public ShowNumSortStrategy(RedisService redisService) {
        this.redisService = redisService;
    }

    /**
     * 返回对应用户被展示的次数
     */
    @Override
    public Map<String, Double> getScore(List<String> recallUids, SortParamsBean sortParamsBean) {
        final List<Object> objects = redisService.execPipelineForRead(connection -> {
            for (String recallUid : recallUids) {
                connection.sCard((RedisKeyConstant.REDIS_BE_LIKED_TEMP_SET_KEY_ + recallUid).getBytes(StandardCharsets.UTF_8));
                connection.sCard((RedisKeyConstant.REDIS_BE_SUPER_LIKED_TEMP_SET_KEY_ + recallUid).getBytes(StandardCharsets.UTF_8));
            }
            return null;
        });
        final List<Long> showNums = Lists.partition(objects, 2)
                .parallelStream()
                .map(part -> part.stream().mapToLong(o -> (long) o).sum())
                .collect(Collectors.toList());
        final int size = recallUids.size();
        Map<String, Double> scoreMap = new HashMap<>();
        for (int i = 0; i < size; i++) {
            final String recallUid = recallUids.get(i);
            final Long showNum = showNums.get(i);
            scoreMap.put(recallUid, showNum.doubleValue());
        }
        return scoreMap;
    }
}
