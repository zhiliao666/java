package com.ufoto.utils.redis;

import java.lang.reflect.Field;

public class RedisKeyConstant {

    public final static Integer HASH_BUCKETS = 1000;
    /**
     * 已修改为新的key,目前程序中使用的地方大多是补余,可在某个时间节点完全删除
     * 修改动机: string->int
     * {@link RedisKeyConstant#REDIS_BE_UN_LIKED_SET_KEY_NEW}
     */
    public final static String REDIS_BE_UN_LIKED_SET_KEY_ = "be_un_liked:";
    /**
     * 用户被dislike的SET，
     * 格式：  be_un_liked:{uid}
     * 1000
     * 1001
     * ...
     * 1010
     * <p>
     * 使用场景：
     * 规则引擎获取对应配置;
     * 随机匹配时过滤;
     * 计算用户的受欢迎程度;
     * 判断新用户曝光次数是否达到下限;
     * 判断用户是否被对应的人dislike;
     * UnLikeMeSortStrategy排序策略;
     * dump用户数据;
     * 更新场景：
     * 用户被dislike;
     * 用户撤销dislike操作;
     * 用户删除账号时删除对应的key
     * 更新用户受欢迎程度
     * like/superlike时尝试移除dislike记录,保证数据一致性
     */
    public static final String REDIS_BE_UN_LIKED_SET_KEY_NEW = "disliked:";

    /**
     * 每天用户被dislike的set
     * date(20180829)
     * 格式: be_un_liked_daily:{uid}:{date}
     * 1000
     * 1001
     * ...
     * 1002
     * <p>
     * 使用场景：
     * ExposureLimitFilterStrategy中判断用户当天的曝光次数
     * 更新场景：
     * 用户被dislike;
     * 用户撤销dislike操作;
     */
    public final static String REDIS_BE_UN_LIKED_DAILY_HASH = "disliked_daily:{0}";

    /**
     * 已修改为新的key,目前程序中使用的地方大多是补余,可在某个时间节点完全删除
     * 修改动机: string->int
     * {@link RedisKeyConstant#REDIS_MY_LIKED_SET_KEY_NEW}
     */
    public final static String REDIS_MY_LIKED_SET_KEY_ = "my_liked:";
    /**
     * 用户的like SET，
     * 格式：  my_liked:{uid}
     * 1000
     * 1001
     * ...
     * 1010
     * <p>
     * 使用场景：
     * 判断用户是否有送出过like;
     * 统计用户送出了多少like(ELikeStatisticsType类中使用);
     * LikeActNumSortStrategy排序策略使用;
     * 规则引擎获取对应配置;
     * dump用户数据;
     * 更新场景：
     * 用户送出like;
     * 用户取消like;
     * 删除用户是删除对应的key
     */
    public final static String REDIS_MY_LIKED_SET_KEY_NEW = "like:";

    /**
     * 用户被like的SET，
     * 格式：  be_liked:{uid}
     * 1000
     * 1001
     * ...
     * 1010
     * <p>
     * 使用场景：
     * BeLikedSortStrategy排序策略使用;
     * 统计用户收到了多少like(ELikeStatisticsType类中使用);
     * LikeMeCutter在打散时使用;
     * LikeMeSortStrategy排序策略使用;
     * NGSimilarityFollowerRecall召回策略使用;
     * 随机匹配过滤使用;
     * 判断是被某人like使用;
     * 更新用户受欢迎程度;
     * 判断是否相互like;
     * 判断新用户曝光次数是否达到下限;
     * dump用户数据;
     * 更新场景：
     * 用户被like;
     * 用户取消like;
     */
    public final static String REDIS_BE_LIKED_SET_KEY_ = "be_liked:";

    /**
     * 每天用户被like的set
     * date(20180829)
     * 格式: be_liked_daily:{uid}:{date}
     * 1000
     * 1001
     * ...
     * 1002
     * <p>
     * 使用场景：
     * ExposureLimitFilterStrategy中判断用户当天的曝光次数;
     * LikeLimitFilterStrategy中判断用户当天收到like次数;
     * 更新场景：
     * 用户被like;
     * 用户撤销like操作;
     */
    public final static String REDIS_BE_LIKED_DAILY_HASH = "liked_daily:{0}";
    /**
     * 每天用户临时好友配对数量hash
     * date(20180829)
     * 格式: tempfriend_daily:{date}
     * 
     * 使用场景：
     * TempFriendLimitFilterStrategy中判断用户当天的配对次数;
     * 更新场景：
     * 用户产生临时匹配通知，对应mq:Q-randomMatch ;
     */
    public final static String REDIS_TEMPFRIEND_DAILY_HASH = "tempfriend_daily:{0}";
    /**
     * 用户被like且未读的SET,会删除，
     * 格式：  be_liked_temp:{uid}
     * 1000
     * 1001
     * ...
     * 1010
     * <p>
     * 使用场景：
     * BeLikedTempTooMuchSortStrategy排序策略中使用;
     * FilterUtil中使用，保证已经like我的人不被过滤;
     * NGBelikedRecall召回策略中使用;
     * 获取规则引擎对应配置时使用;
     * 获取用户未读的like数量;
     * 获取用户未读的like人员列表;
     * RecommendedFilterStrategy过滤策略中使用，保证已经like我的人不被过滤;
     * ShowNumSortStrategy排序策略使用;
     * dump用户数据;
     * 更新场景：
     * dislike他人;
     * 收到like;
     * like他人;
     * 收到superlike;
     * superlike他人;
     * 他人取消like;
     */
    public final static String REDIS_BE_LIKED_TEMP_SET_KEY_ = "be_liked_temp:";

    /**
     * 用户的superLike SET，
     * 格式：  my_super_liked:{uid}
     * 1000
     * 1001
     * ...
     * 1010
     * <p>
     * 使用场景：
     * 统计用户送出了多少superlike(ELikeStatisticsType类中使用);
     * dump用户数据;
     * 更新场景：
     * 送出superlike
     * 取消superlike
     */
    public final static String REDIS_MY_SUPER_LIKED_SET_KEY_ = "my_super_liked:";

    /**
     * 用户被superLike的SET，
     * 格式：  be_super_liked:{uid}
     * 1000
     * 1001
     * ...
     * 1010
     * <p>
     * 使用场景：
     * 统计用户收到了多少superlike(ELikeStatisticsType类中使用);
     * 随机匹配过滤;
     * 判断用户是否被某人superlike;
     * SuperLikeMeCutter打散策略用;
     * dump用户数据;
     * 更新场景：
     * 收到superlike
     * 某人取消superlike
     */
    public final static String REDIS_BE_SUPER_LIKED_SET_KEY_ = "be_super_liked:";

    /**
     * 用户被superLike且未读的SET，会删除
     * 格式：  be_super_liked_temp:{uid}
     * 1000
     * 1001
     * ...
     * 1010
     * <p>
     * 使用场景：
     * AgeFilterStrategy过滤策略中保证superlike我的用户不被过滤（后续可以换成FilterUtil）;
     * BeLikedTempTooMuchSortStrategy排序策略中使用;
     * NGDistanceFilterStrategy过滤策略中保证superlike我的用户不被过滤（后续可以换成FilterUtil);
     * FilterUtil使用，保证superlike我的用户不被过滤;
     * NGBelikedRecall召回策略使用;
     * 规则引擎获取对应配置;
     * ShowNumSortStrategy排序策略中使用;
     * dump用户数据;
     * 更新场景：
     * dislike他人;
     * like他人;
     * 收到superlike;
     * superlike他人;
     * 他人取消superlike;
     */
    public final static String REDIS_BE_SUPER_LIKED_TEMP_SET_KEY_ = "be_super_liked_temp:";


    /**
     * 参考 RecommendedBFManager
     */
    public static final String REDIS_RECOMMENDED_BF_WEEKLY_KEY_ = "recommended_bf:{0}:{1}:{2}";
    public static final String REDIS_RECOMMENDED_BF_HASH = "recommended_bf_hash:{0}";
    public static final String REDIS_RECOMMENDED_BF_HASH_CURRENT_KEY = "c_k";

    /**
     * 记录所有已经删除帐号的uid的SET
     * <p>
     * 使用场景：
     * DeleteUserFilterStrategy过滤策略使用;
     * 更新场景：
     * RecommendService.addDeleteUser()方法，会在消息队列或者微服务流程中被调用
     */
    public static final String REDIS_DELETED_USER_SET_KEY = "deleted_user_set";

    /**
     * 某国家所有用户，
     * 格式：   region_users:{country}
     * 1000
     * 1001
     * ...
     * 1010
     * <p>
     * 相同语言排序,目前已废弃
     * 可考虑删除
     * com.ufoto.business.recommend.sort.lang.SameLanguageSortStrategy
     */
    public final static String REDIS_REGION_USERS_SET_KEY_ = "region_users:";

    /**
     * 机器人用户uid SET,跟上国家code
     * <p>
     * 格式：
     * robot_uid:CN
     * 1000
     * 1001
     * ...
     * 1010
     * <p>
     * 使用场景：
     * NGRobotRecall召回策略
     * 更新场景：
     * RecommendService.addRedisRobotUser()调用时，微服务调用或者消费消息队列
     */
    public final static String REDIS_ROBOT_UID_SET_KEY_ = "robot_uid:";


    /**
     * 机器人用户uid SET,全部的机器人
     * <p>
     * 格式：
     * robot_uid:all
     * 1000
     * 1001
     * ...
     * 1010
     * <p>
     * 使用场景：
     * RobotFilterStrategy过滤策略
     * 更新场景：
     * RecommendService.addRedisRobotUser()调用时，微服务调用或者消费消息队列
     */
    public final static String REDIS_ROBOT_UID_ALL_SET_KEY = "robot_uid:all";

    /**
     * 聊天机器用户uid SET
     * <p>
     * 格式：
     * chat_bot_uid_set
     * 1000
     * 1001
     * ...
     * 1010
     * <p>
     * 使用场景：
     * ChatBotCutter打散策略使用;
     * ChatBotUtil使用，判断是否是聊天机器;
     * ExposureLimitFilterStrategy中使用，保证机器人不被过滤;
     * LikeLimitFilterStrategy中使用，保证机器人不被过滤;
     * NGChatBotRecall召回使用
     * 更新场景：
     * 额外维护
     */
    public final static String REDIS_CHAT_BOT_UID_SET_KEY = "chat_bot_uid_set";
    public final static String REDIS_CHAT_BOT_V2_UID_SET_KEY = "chat_bot_v2_uid_set";
    public final static String REDIS_CHAT_BOT_V3_UID_SET_KEY = "chat_bot_v3_uid_set";
    public final static String REDIS_CHAT_BOT_V4_UID_SET_KEY = "chat_bot_v4_uid_set";
    /**
     * 用户分层使用的机器人池子
     * 分语言全量池子
     * chat_bot_v5_uid_set_语言
     */
    public final static String REDIS_CHAT_BOT_V5_UID_SET_KEY = "chat_bot_v5_uid_set_{0}";
    /**
     * 分性别语言机器人池子
     * male_chat_bot_v5_uid_set_性别_语言
     */
    public final static String REDIS_LANGUAGE_GENDER_CHAT_BOT_V5_UID_SET_KEY = "chat_bot_v5_uid_set_{0}_{1}";
    
    /**
     * 陪聊人员召回策略
     * 使用场景：
     * NGChatFreeRecall召回策略使用
     * 工具类人工更新
     */
    public final static String REDIS_CHAT_FREE_SET_KEY = "chat_free_set";
    
    /**
     * 无需过滤临时好友上限
     * 使用场景：
     * TempFriendLimitFilterStrategy过滤策略使用
     * 更新场景：
     * 工具类更新，包好机器人和运营陪聊人员
     */
    public final static String REDIS_NOFILTER_TEMPFRIEND_LIMIT__SET_KEY = "chat_nofilter_tempfriend_set";

    /**
     * 被举报用户uid SET
     * <p>
     * 格式：
     * 1000
     * 1001
     * ...
     * 1010
     * <p>
     * 使用场景：
     * ReportedFilterStrategy过滤策略中使用;
     * 更新场景：
     * RecommendService.addRedisUserReport()调用时，微服务调用或者消费消息队列
     * RecommendService.removeRedisUserReport()调用时，微服务调用
     * RecommendToolController.reportSyn()调用时
     */
    public final static String REDIS_USER_REPORT_UID_SET_KEY = "user_report_uid";

    /**
     * 每天用户的滑动数量
     * 格式： daily_act_num:{date} 例如：daily_act_num:20180326
     * 1000  1
     * 1001  3
     * 1002  4
     * <p>
     * 使用场景：
     * 规则引擎获取对应配置;
     * 更新场景：
     * 用户dislike
     * 用户like
     * 用户superlike
     */
    public final static String REDIS_DAILY_ACT_NUM_ZSET_KEY_ = "daily_act_num:";

    /**
     * 每天用户配对数量ZSet
     * 格式： daily_match_num:{date} 例如：daily_match_num:20180326
     * 1000  1
     * 1001  3
     * 1002  4
     * com.ufoto.business.recommend.sort.match.MatchIn3DaySortStrategy 已废弃
     */
    public final static String REDIS_DAILY_MATCH_NUM_ZSET_KEY_ = "daily_match_num:";

    /**
     * 用于存放有非法头像的用户ID
     * <p>
     * 使用场景：
     * IllegalFilterStrategy过滤策略;
     * 更新场景：
     * RecommendService.addRedisIllegalUser()调用时，调用微服务或者消费消息队列时
     * RecommendService.removeRedisIllegalUser()调用时，调用微服务或者消费消息队列时
     * RecommendToolController.illegalSyn()接口调用时;
     * RecommendToolController.checkHeadIllegal()接口调用时
     */
    public final static String REDIS_HEAD_ILLEGAL_USER_SET_KEY = "head_illegal_u_s";

    /**
     * 用于存放有非法头像的用户ID--特指头图
     * <p>
     * 使用场景：
     * IllegalFilterStrategy过滤策略;
     * 更新场景：
     * RecommendService.addRedisIllegalUser()调用时，调用微服务或者消费消息队列时
     * RecommendService.removeRedisIllegalUser()调用时，调用微服务或者消费消息队列时
     * RecommendToolController.illegalSyn()接口调用时;
     * RecommendToolController.checkHeadIllegal()接口调用时
     * RecommendToolController.importHeadFirstIllegalUser()接口调用时
     */
    public final static String REDIS_HEAD_FIRST_ILLEGAL_USER_SET_KEY = "head_first_illegal_u_s";

    /**
     * 用于存放聊天违法的用户ID
     * <p>
     * 使用场景：
     * IllegalFilterStrategy过滤策略;
     * 更新场景：
     * RecommendService.addChatIllegalUser()微服务调用时
     * RecommendService.removeChatIllegalUser()微服务调用时
     * RecommendService.removeChatIllegalUserBatch()微服务调用时
     * RecommendService.addChatIllegalUserBatch()微服务调用时
     */
    public final static String REDIS_CHAT_ILLEGAL_USER_SET_KEY = "chat_illegal_u_s";

    /**
     * 新增用用户的Set
     * 格式：new_come_user
     * 1000
     * 1001
     * 1002
     * <p>
     * 使用场景：
     * NGNewComeRecall召回策略使用
     * NewComeUserCutter低曝光用户打散策略使用
     * 规则引擎获取对应配置;
     * 更新场景：
     * CleanRedisService.cleanOldNewComeUserSet()定时任务，清理过期用户
     * RedisService.addNewComeUser()一般在第一次like之后调用
     * RedisService.checkIsNewComeUser()在用户被曝光时调用
     */
    public final static String REDIS_NEW_COME_USER_SET_KEY = "new_come_user_set";
    public final static String REDIS_NEW_COME_USER_SET_KEY_MALE = "new_come_user_set_male";
    public final static String REDIS_NEW_COME_USER_SET_KEY_FEMALE = "new_come_user_set_female";

    /**
     * 新增用户中，已经达到基准曝光次数的用户SET
     * 格式：new_come_prepared_user
     * 1000
     * 1001
     * 1002
     * <p>
     * 使用场景：
     * RedisService.getNewComePreparedUser()在新热用户处理的时候会调用，外部Python任务
     * 更新场景：
     * RedisService.checkIsNewComeUser()在用户被曝光时调用
     * RedisService.processNewComePreparedUser()在新热用户处理的时候会调用，外部Python任务
     */
    public final static String REDIS_NEW_COME_PREPARED_USER_SET_KEY = "new_come_prepared_user_set";


    /**
     * 存放热门用户的SET
     * <p>
     * 格式：hot_user_set
     * 1000
     * 1001
     * 1002
     * <p>
     * 使用场景：
     * FacePKController.recommend()接口，用户参加PK活动时调用，获取热门用户
     * NGHotRecall召回策略
     * 规则引擎获取对应配置;
     * 更新场景：
     * RedisService.processNewComePreparedUser()在新热用户处理的时候会调用，外部Python任务
     * RedisService.getHotUser()在新热用户处理的时候会调用，外部Python任务
     */
    public final static String REDIS_HOT_USER_SET_KEY = "hot_user_set";

    /**
     * 存放有收到礼物的用户的SET
     * <p>
     * 格式：gift_receive_user_set
     * 1000
     * 1001
     * 1002
     * <p>
     * 使用场景：
     * NGGiftReceiveRecall召回策略使用
     * 更新场景：
     * 无！
     */
    public final static String REDIS_GIFT_RECEIVE_USER_SET_KEY = "gift_receive_user_set";

    /**
     * 存放缺少头像用户的SET
     * 用户过滤
     * <p>
     * 格式：no_head_user_set
     * 1000
     * 1001
     * 1002
     * <p>
     * 使用场景：
     * NoHeadFilterStrategy过滤策略使用
     * 更新场景：
     * RecommendService.removeNoHeadUsers()调用时,在获取推荐列表之后并发现某些用户没有头像的情况下调用
     * RecommendService.userEditHead()调用时，微服务被调用或者消费消息队列
     * RecommendToolController.checkHeadIllegal()被微服务调用时
     */
    public final static String REDIS_NO_HEAD_USER_SET_KEY = "no_head_user_set";

    /**
     * 策略缓存hash
     * strategy_cache:{sid/HASH_BUCKETS} sid strategyJson
     * <p>
     * 目前只有缓存，没有读取。可以考虑用缓存来减少experiment的调用次数，需要调查
     */
    public final static String REDIS_STRATEGY_CACHE_KEY = "strategy_cache:";

    /**
     * 策略路径path-->hash
     * variant_path:uid field value
     * <p>
     * 目前只有缓存，没有读取。可以考虑用缓存来减少experiment的调用次数，需要调查
     */
    public final static String REDIS_VARIANT_STRATEGY_PATH = "variant_path:";

    /**
     * 设置不会被推荐SET
     * <p>
     * 使用场景：
     * NotRecommendFilterStrategy过滤策略
     * RecommendService.getUserRecommendStatus()，被微服务调用时
     * 更新场景：
     * RecommendService.userEditNotRecommended()调用时，微服务被调用或者消费消息队列
     * RecommendService.userEditCanBeRecommended()调用时，微服务被调用或者消费消息队列
     */
    public final static String REDIS_NOT_RECOMMENDED_USER_SET_KEY = "user_not_recommended";
    /**
     * 设置黑名单
     * <p>
     * 使用场景：
     * BlackListFilter过滤策略调用时
     * 更新场景：
     * RecommendToolController.addUser2BlackList()被微服务调用时
     */
    public final static String REDIS_USER_BLACKLIST_SET = "user_black_set";

    /**
     * 保存每个用户最近like的内容
     * latest_liked_item_list:{uid}
     * 1111
     * 222223
     * 311222
     * <p>
     * 使用场景：
     * NGSimilarity2Recall召回策略
     * NGSimilarityRecall召回策略
     * 更新场景：
     * like其他用户时
     * superlike其他用户时
     */
    public static final String REDIS_LATEST_LIKED_ITEM_LIST_KEY_ = "latest_liked_item_list:%d";

    /**
     * 已经为用户推荐的卡片子类型
     * user_card_type_sub:{uid}
     * <p>
     * 使用场景：
     * UfotoAppCardService.queryRandomCards()在给用户推荐基础卡片时使用
     * 更新场景：
     * 在重新获取推荐列表是（needClean）
     * UfotoAppCardService.queryRandomCards()在给用户推荐基础卡片时使用
     */
    public static final String REDIS_USER_CARD_TYPE_SUB = "user_card_type_sub:";


    /**
     * 保存所有在24小时内有行为的合法用户（有SignUpTimestamp）ZSet
     * act_in_24h_user_zset
     * {uid}  {act_time_stamp}
     * <p>
     * 使用场景：
     * NGOnlineRecall召回策略使用
     * 更新场景：
     * CleanRedisService.clearExpired24hAct()定时清理任务时调用
     * RecommendService.addRedisUserActivityTimestamp()在更新用户最近活跃时间时调用
     */
    public static final String REDIS_ACT_IN_24H_USER_ZSET_KEY = "act_in_24h_user_zset";

    /**
     * 保存所有在24小时内有行为的合法用户（有SignUpTimestamp）Set
     * act_in_24h_user_set
     * {uid}
     * <p>
     * 使用场景：
     * ActIn24HoursReagent召回成分使用
     * AreaActIn24HoursReagent召回成分使用
     * ExposureLimitFilterStrategy过滤策略使用
     * LikeLimitFilterStrategy过滤策略使用
     * 更新场景：
     * CleanRedisService.clearExpired24hAct()定时清理任务时调用
     * RecommendService.addRedisUserActivityTimestamp()在更新用户最近活跃时间时调用
     */
    public static final String REDIS_ACT_IN_24H_USER_SET_KEY = "act_in_24h_user_set";

    /**
     * 保存所有在24小时内有行为并且有对应大区的合法用户（有SignUpTimestamp）Set
     * area_act_in_24h_user_set_{area_id}
     * {uid}
     * <p>
     * <p>
     * 使用场景：
     * AreaActIn24HoursReagent召回成分使用
     * 更新场景：
     * CleanRedisService.clearExpired24hAct()定时清理任务时调用
     * RecommendService.addRedisUserActivityTimestamp()在更新用户最近活跃时间时调用
     */
    public static final String REDIS_AREA_ACT_IN_24H_USER_SET_KEY = "area_act_in_24h_user_set_{0}";

    /**
     * 保存所有在24小时内有行为的合法老用户（有SignUpTimestamp，且24h前注册）Set
     * act_in_24h_old_user_set
     * {uid}
     * <p>
     * 使用场景：
     * OldUserActIn24HoursReagent召回成分使用
     * 更新场景：
     * CleanRedisService.clearExpired24hAct()定时清理任务时调用
     * RecommendService.addRedisUserActivityTimestamp()在更新用户最近活跃时间时调用
     */
    public static final String REDIS_ACT_IN_24H_OLD_USER_SET_KEY = "act_in_24h_old_user_set";

    /**
     * 保存所有在24小时内有注册的新用户（有SignUpTimestamp，且24h内注册）Set
     * act_in_24h_new_user_set
     * {uid}
     * <p>
     * 使用场景：
     * NewUserIn24HoursReagent召回成分使用
     * 更新场景：
     * CleanRedisService.clearExpired24hAct()定时清理任务时调用
     * RecommendService.addRedisUserActivityTimestamp()在更新用户最近活跃时间时调用
     */
    public static final String REDIS_ACT_IN_24H_NEW_USER_SET_KEY = "act_in_24h_new_user_set";

    /**
     * 保存用户的各种信息HASH
     * u_h_{uid}
     * <p>
     * longitude:{经度}
     * latitude:{纬度}
     * <p>
     * 这一块内容的Key太难写了，其实一个HASH就像是对应用户的一行数据，里面各个字段的使用几乎都是独立的。
     * <p>
     * REDIS_USER_HASH_LONGITUDE、REDIS_USER_HASH_LATITUDE:记录用户的经纬度
     * NGDistanceFilterStrategy过滤策略中使用
     * RecommendService.addRedisUserGeo()调用时更新
     * <p>
     * REDIS_USER_HASH_SIGN_UP:记录用户的注册时间
     * RecommendService.addRedisUserSignUpTimestamp()调用时更新
     * <p>
     * REDIS_USER_HASH_ACT_NUM:记录用户的行为数量
     * RecommendService.addRedisUserRecommended()调用时更新
     * <p>
     * REDIS_USER_HASH_GENDER:记录用户性别
     * DirtyCaseUtil中判断用户是否有性别
     * FromOthersSortStrategy排序策略中使用
     * SexualOrientationSortStrategy排序策略中使用
     * RecommendService.addRedisUserGender()调用时更新
     * <p>
     * REDIS_USER_HASH_AREA_ID:记录用户所属大区ID
     * RecommendService.addRedisRegionUser()调用时更新
     * 用于 REDIS_AREA_ACT_IN_24H_USER_SET_KEY 写入时相关判断
     * <p>
     * REDIS_USER_HASH_GIFT_NUM:记录用户收到礼物的数量
     * RecommendService.getGiftNum()读取用户収礼数量
     * RecommendService.giftRecord()更新用户収礼数量
     * <p>
     * REDIS_USER_HASH_ACTIVITY_TIME:记录用户最近活跃时间
     * RecommendService.addRedisUserActivityTimestamp()调用时更新
     * <p>
     * REDIS_USER_HASH_SHOW_ME_GENDER:记录用户设置中想要看的性别
     * SexualOrientationSortStrategy排序策略中使用
     * RecommendService.userEditShowMeGender()调用时更新
     * <p>
     * REDIS_USER_HASH_FROM_TYPE:记录用户的来源类型
     * FromOthersSortStrategy排序策略中使用
     * 规则引擎获取对应规则时使用
     * <p>
     * REDIS_USER_FIRST_IMAGE_HAS_FACE:记录用户第一张照片是否有人脸
     * FirstImageHasFaceSortStrategy排序策略使用
     * RecommendService.userHeadFaceDetect()调用时更新
     * <p>
     * REDIS_USER_FIRST_IMAGE_NO_FACE:记录用户第一张照片是否没有人脸
     * FirstImageNoFaceSortStrategy排序策略使用
     * RecommendService.userHeadNoFaceDetect()调用时更新
     * <p>
     * REDIS_USER_HASH_BIRTH_TIMESTAMP:记录用户生日的时间戳，毫秒
     * RecommendService.addRedisUserBirthTimestamp()调用时更新
     * <p>
     * REDIS_USER_HASH_BIRTH_DATE:记录用户生日的日期字符串，"yyyy-MM-dd HH:mm:ss"
     * RecommendService.addRedisUserBirthTimestamp()调用时更新
     * <p>
     * <p>
     * 特殊情况：
     * 在XgbSortStrategy中会获取用户的所有特征来作为排序的依据
     * 在DumpUser的时候会全部导出
     * 在RecommendService.addUserProfile()调用时，会把UfotoAppUser的全部字段写入这个HASH
     */
    public static final String REDIS_USER_HASH_KEY = "u_h_{0}";
    public static final String REDIS_USER_HASH_LONGITUDE = "longitude";
    public static final String REDIS_USER_HASH_LATITUDE = "latitude";
    public static final String REDIS_USER_HASH_SIGN_UP = "create_time";
    public static final String REDIS_USER_HASH_ACTIVITY_TIME = "act_t";
    public static final String REDIS_USER_HASH_BIRTH_TIMESTAMP = "birth_t";
    public static final String REDIS_USER_HASH_BIRTH_DATE = "birth_time";
    public static final String REDIS_USER_HASH_AGE = "age";
    public static final String REDIS_USER_HASH_GENDER = "gender";
    public static final String REDIS_USER_HASH_COUNTRY_CODE = "country_code";
    public static final String REDIS_USER_HASH_AREA_ID = "area_id";
    public static final String REDIS_USER_HASH_ACT_NUM = "act_num";
    public static final String REDIS_USER_HASH_FROM_TYPE = "from_type";
    public static final String REDIS_USER_HASH_SHOW_ME_GENDER = "s_m_gender";
    public static final String REDIS_USER_HASH_GIFT_NUM = "gift_num";
    public static final String REDIS_USER_FIRST_IMAGE_HAS_FACE = "fihf";
    public static final String REDIS_USER_FIRST_IMAGE_NO_FACE = "finf";
    public static final String REDIS_USER_HASH_POPULAR = "popular";
    public static final String REDIS_USER_HASH_MATCH_NUM = "match_num";
    public static final String REDIS_USER_HASH_LOGIN_SOURCE = "login_source";

    /**
     * 用户过滤后的被like集合
     * like
     * user_filter_be_liked {uid}
     * <p>
     * 使用场景：
     * RecommendToolController.whoLikeMe接口使用的缓存
     * 更新场景：
     * RecommendToolController.whoLikeMe接口使用的缓存
     */
    public static final String REDIS_USER_FILTER_BE_LIKED = "user_filter_be_liked:";

    /**
     * 用户订阅set
     * <p>
     * 使用场景：
     * ExposureLimitFilterStrategy过滤策略，保证订阅的用户不会被过滤
     * 更新场景：
     * UfotoSnsSubscriptionService.syncSubscriptionInfoRedis()调用时，SubscriptionInfoJob的定时同步订单任务
     */
    public static final String REDIS_SUBSCRIPTION_USER_SET = "subscription_user_set";

    /**
     * 存放所有已经dump进入数据库的用户
     * uid : dump_time
     * <p>
     * 使用场景：
     * UfotoRecommendRedisDumpService.restore()查看是否需要恢复用户数据时
     * 更新场景：
     * dump用户数据时，记录dump用户的具体时间
     * restore用户数据时，删除对应记录
     */
    public static final String REDIS_HAS_DUMPED_USER_ZSET = "dumped_u";

    /**
     * firstImg是默认图片
     * <p>
     * 使用场景:
     * FirstImgDefaultSortStrategy
     * 更新场景:
     * com.ufoto.mq.RecommendConsumer#handleFirstImgDefault
     */
    public static final String REDIS_FIRST_IMG_DEFAULT = "f_img_default";

    /**
     * 推荐已经计算过的用户两天有效
     * <p>
     * 使用场景:
     * RecommendCalculatedFilterStrategy拉取推荐接口时,过滤掉已经拉取过的
     * 更新场景:
     * RecommendCalculateBloomExecutor->RecommendCalculatedBloomFilter
     */
    public static final String REDIS_RECOMMEND_CAlCULATED_CURRENT = "c_k";
    public static final String REDIS_RECOMMEND_CAlCULATED_V3 = "re_c3:{0}";
    public static final String REDIS_RECOMMEND_CAlCULATED_CHUNK_V3 = "re_c_c3:{0}:{1}";
    /**
     * 高危用户
     * <p>
     * 使用场景:
     * HighRiskFilterStrategy过滤策略
     * NGHighRiskRecall 召回策略
     * 判断是否是高危用户
     * 更新场景:
     * com.ufoto.mq.kafka.KafkaConsumer#batchUserHighRiskConsume
     */
    public static final String REDIS_HIGH_RISK_USER = "high_risk";

    public static void main(String[] args) {
        Class<?> clasz = RedisKeyConstant.class;
        printInnerParamValue(clasz);
    }

    public static void printInnerParamValue(Class<?> clasz) {
        Field[] fields = clasz.getDeclaredFields();
        for (Field field : fields) {
            try {
                Object object = field.get(clasz);
                System.out.println(object.toString());
            } catch (IllegalAccessException e) {
                e.printStackTrace();
            }

        }
    }

}
