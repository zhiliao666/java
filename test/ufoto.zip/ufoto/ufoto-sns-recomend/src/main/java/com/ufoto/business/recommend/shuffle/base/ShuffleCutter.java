package com.ufoto.business.recommend.shuffle.base;

import java.util.List;

/**
 * Created by echo on 7/11/18.
 * <p>
 * 切牌的，将用户的列表按照一定规则切成不同的列表
 */
public interface ShuffleCutter {

    List<List<String>> cut(String[] uidArray);

}
