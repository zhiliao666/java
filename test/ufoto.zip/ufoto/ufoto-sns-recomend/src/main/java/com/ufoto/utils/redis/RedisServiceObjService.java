package com.ufoto.utils.redis;

import org.springframework.data.redis.core.RedisTemplate;

import java.util.Date;
import java.util.List;
import java.util.Map;
import java.util.Set;

/**
 * <p>
 * Author     : Chan
 * CreateDate : 2019-08-27 13:50
 * Description: value serialize use json object
 * </p>
 */
public interface RedisServiceObjService {
    RedisTemplate<String, Object> getRedisTemplate();

    Long sadd(String key, Object... values);

    Long sremove(String key, Object... values);

    Set<Long> smembers(String key, boolean scan);

    boolean sismember(String key, Object member);

    Long hIncrBy(String key, String field, long increment);

    boolean expireAt(String key, Date date);

    Map<String, Integer> hscanWithInteger(String key);

    Map<String, Integer> hmgetWithInteger(String key, List<String> fields, int defaultIfNull);

    void delete(String key);
}
