package com.ufoto.constants;

/**
 * <p>
 * 推荐使用到的用户分层
 *
 * </p>
 *
 * @author zhangqh
 * @date 2020/4/2 15:08
 */
public enum ESnsUserLayer {
    NEWUSER(100),// 新用户
    BROWSEUSER(200),// 浏览用户
    LOWFINDFRIENDUSER(300), // 低寻友用户
	HIGHTFINDFRIENDUSER(400);// 高寻友用户

    private Integer layer;

    ESnsUserLayer(Integer layer) {
        this.layer = layer;
    }

    public Integer getLayer() {
        return layer;
    }
}
