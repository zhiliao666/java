package com.ufoto.dto;

import lombok.Builder;
import lombok.Data;

import java.io.Serializable;

/**
 * <p>
 * Author     : Chan
 * CreateDate : 2019-07-18 10:42
 * Description:
 * </p>
 */
@Data
@Builder
public class UserGeo implements Serializable {
    private double longitude;
    private double latitude;
}
