package com.ufoto.business.recommend.filter.friends;

import com.ufoto.annotation.RecommendMetadata;
import com.ufoto.business.elasticsearch.dto.FriendSearchDto;
import com.ufoto.business.elasticsearch.dto.FriendSearchVo;
import com.ufoto.business.recommend.RecommendFilterStrategy;
import com.ufoto.dto.RecommendAdvanceRequest;
import com.ufoto.manager.ElasticSearchManager;
import lombok.extern.slf4j.Slf4j;
import org.springframework.core.env.Environment;
import org.springframework.stereotype.Component;
import org.springframework.util.CollectionUtils;

import java.util.List;
import java.util.Set;
import java.util.stream.Collectors;

/**
 * <p>
 * Author     : Chan
 * CreateDate : 2019-08-16 10:50
 * Description:
 * </p>
 */
@Slf4j
@RecommendMetadata(
        metadataType = RecommendMetadata.MetadataType.FILTER,
        available = true,
        name = "用户好友过滤策略",
        description = "过滤用户当前的好友列表",
        branch = {
        		RecommendMetadata.Branch.NORMAL, 
        		RecommendMetadata.Branch.High_Risk,
        		RecommendMetadata.Branch.USERLAYER,
                RecommendMetadata.Branch.WINK
        		}
)
@Component
public class FriendsFilterStrategy implements RecommendFilterStrategy {

    private final ElasticSearchManager elasticSearchManager;
    private final Environment env;

    public FriendsFilterStrategy(ElasticSearchManager elasticSearchManager, Environment env) {
        this.elasticSearchManager = elasticSearchManager;
        this.env = env;
    }

    @Override
    public Set<String> filter(Set<String> recallSet, List<String> resultList, RecommendAdvanceRequest filterRequest) {
        try {
            if (!env.getProperty("recommend.filter.friends.switch", Boolean.class, true)) {
                //if switch off
                return recallSet;
            }
            if (CollectionUtils.isEmpty(recallSet)) return recallSet;
            final FriendSearchDto friendSearchDto = elasticSearchManager.checkUserFriend(
                    FriendSearchVo.builder().uid(filterRequest.getUid())
                            .friendIdList(recallSet.stream().map(Long::valueOf).collect(Collectors.toList()))
                            .build()
            );
            final List<Long> list = friendSearchDto.getFriendIdList();
            if (CollectionUtils.isEmpty(list)) return recallSet;
            recallSet.removeAll(list.stream().map(String::valueOf).collect(Collectors.toSet()));
        } catch (Exception e) {
            log.error(e.getMessage(), e);
        }
        return recallSet;
    }

}
