package com.ufoto.dao.base;

import com.ufoto.entity.UfotoSvdUserTopN;
import org.apache.ibatis.annotations.*;
import org.apache.ibatis.jdbc.SQL;

import java.util.List;

public interface BaseUfotoSvdUserTopNMapper {

    @Results({
            @Result(property = "id", column = "id"),
            @Result(property = "uId", column = "u_id"),
            @Result(property = "iId", column = "i_id"),
            @Result(property = "rank", column = "rank"),
            @Result(property = "createTime", column = "create_time"),
    })
    @Select("SELECT * FROM ufoto_svd_user_top_n")
    List<UfotoSvdUserTopN> list();

    @Select("SELECT count(*) FROM ufoto_svd_user_top_n")
    int count();

    @Results({
            @Result(property = "id", column = "id"),
            @Result(property = "uId", column = "u_id"),
            @Result(property = "iId", column = "i_id"),
            @Result(property = "rank", column = "rank"),
            @Result(property = "createTime", column = "create_time"),
    })
    @Select("SELECT * FROM ufoto_svd_user_top_n WHERE id = #{id}")
    UfotoSvdUserTopN selectOneById(@Param("id") Integer id);

    @Delete("DELETE FROM ufoto_svd_user_top_n WHERE id = #{id}")
    int delete(Integer id);

    //@Insert("INSERT INTO ufoto_svd_user_top_n(u_id,i_id,rank,create_time) VALUES(#{uId},#{iId},#{rank},#{createTime})")
    //@Options(useGeneratedKeys=true, keyProperty="id")
    //public int insert(UfotoSvdUserTopN ufotoSvdUserTopN);

    @InsertProvider(type = ProviderSqlBuilder.class, method = "insert")
    @Options(useGeneratedKeys = true, keyProperty = "id")
    int insert(UfotoSvdUserTopN ufotoSvdUserTopN);

    @UpdateProvider(type = ProviderSqlBuilder.class, method = "updateById")
    int update(UfotoSvdUserTopN ufotoSvdUserTopN);

    class ProviderSqlBuilder {

        public String insert(final UfotoSvdUserTopN ufotoSvdUserTopN) {
            return new SQL() {
                {
                    INSERT_INTO("ufoto_svd_user_top_n");
                    if (ufotoSvdUserTopN.getId() != null) {
                        VALUES("id", "#{id}");
                    }
                    if (ufotoSvdUserTopN.getUId() != null) {
                        VALUES("u_id", "#{uId}");
                    }
                    if (ufotoSvdUserTopN.getIId() != null) {
                        VALUES("i_id", "#{iId}");
                    }
                    if (ufotoSvdUserTopN.getRank() != null) {
                        VALUES("rank", "#{rank}");
                    }
                    if (ufotoSvdUserTopN.getCreateTime() != null) {
                        VALUES("create_time", "#{createTime}");
                    }
                    WHERE("id = #{id}");
                }
            }.toString();
        }

        public String updateById(final UfotoSvdUserTopN ufotoSvdUserTopN) {
            return new SQL() {
                {
                    UPDATE("ufoto_svd_user_top_n");
                    if (ufotoSvdUserTopN.getId() != null) {
                        SET("id = #{id}");
                    }
                    if (ufotoSvdUserTopN.getUId() != null) {
                        SET("u_id = #{uId}");
                    }
                    if (ufotoSvdUserTopN.getIId() != null) {
                        SET("i_id = #{iId}");
                    }
                    if (ufotoSvdUserTopN.getRank() != null) {
                        SET("rank = #{rank}");
                    }
                    if (ufotoSvdUserTopN.getCreateTime() != null) {
                        SET("create_time = #{createTime}");
                    }
                    WHERE("id = #{id}");
                }
            }.toString();
        }
    }
}
