package com.ufoto.config.disruptor.constants;

/**
 * <p>
 * Description:
 *
 * </p>
 *
 * @author Chan
 * @date 2019/12/21 14:59
 */
public interface ConsumerId {

    String CONSUMER_ASYNC = "C:ASYNC";

    String CONSUMER_RECOMMEND_CALCULATE_REMOVE = "C:REC_CALC_REM";
    String CONSUMER_RECOMMEND_CALCULATE_BLOOM = "C:REC_CALC_BLOOM";
    String CONSUMER_RECOMMEND_CALCULATE_PREPARE_TRIGGER = "C:REC_CALC_PREPARE_TRIGGER";

}
