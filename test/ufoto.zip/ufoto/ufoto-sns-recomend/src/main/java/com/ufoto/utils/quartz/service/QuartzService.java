package com.ufoto.utils.quartz.service;

import com.ufoto.utils.quartz.QuartzTaskInfo;
import org.quartz.SchedulerException;
import org.quartz.Trigger;
import org.quartz.TriggerKey;

import java.util.List;


public interface QuartzService {
    /**
     * 返回所有任务列表
     *
     * @return
     */
    List<QuartzTaskInfo> list();

    /**
     * 新增任务
     *
     * @param info
     */
    void addJob(QuartzTaskInfo info);

    /**
     * 修改定时任务
     *
     * @param info
     */
    void edit(QuartzTaskInfo info);

    /**
     * 删除定时任务
     *
     * @param jobName
     * @param jobGroup
     */
    void delete(String jobName, String jobGroup);

    /**
     * 暂停定时任务
     *
     * @param jobName
     * @param jobGroup
     */
    void pause(String jobName, String jobGroup);

    /**
     * 重新开启定时任务
     *
     * @param jobName
     * @param jobGroup
     */
    void resume(String jobName, String jobGroup);

    /**
     * 校验是否存在
     *
     * @param triggerKey
     * @return
     */
    boolean checkExists(TriggerKey triggerKey) throws SchedulerException;

    Trigger.TriggerState checkTriggerState(String jobName, String jobGroup) throws SchedulerException;
}
