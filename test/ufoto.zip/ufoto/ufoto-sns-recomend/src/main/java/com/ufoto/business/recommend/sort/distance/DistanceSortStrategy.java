package com.ufoto.business.recommend.sort.distance;

import com.google.common.collect.Lists;
import com.ufoto.annotation.RecommendMetadata;
import com.ufoto.business.recommend.bean.SortParamsBean;
import com.ufoto.business.recommend.sort.BaseNormalSortStrategy;
import com.ufoto.dto.UserGeo;
import com.ufoto.utils.KeyTransitionUtil;
import com.ufoto.utils.geo.GeoUtil;
import com.ufoto.utils.redis.RedisService;
import org.springframework.stereotype.Component;

import java.util.HashMap;
import java.util.List;
import java.util.Map;

/**
 * Created by echo on 4/8/18.
 */
@RecommendMetadata(
        metadataType = RecommendMetadata.MetadataType.SORT,
        available = true,
        name = "距离排序策略",
        description = "按照距离排序,距离单位为Km,基础分数为距离,一方经纬度不存在,则默认0",
        branch = RecommendMetadata.Branch.NORMAL
)
@Component
public class DistanceSortStrategy extends BaseNormalSortStrategy {

    private final RedisService redisService;

    public DistanceSortStrategy(RedisService redisService) {
        this.redisService = redisService;
    }

    @Override
    public Map<String, Double> getScore(List<String> recallUids, SortParamsBean sortParamsBean) {
        final Long uid = sortParamsBean.getUid();
        final List<String> uids = Lists.newArrayList(recallUids);
        uids.add(String.valueOf(uid));
        final Map<String, UserGeo> geoMap = KeyTransitionUtil.userGeoMap(redisService, uids);
        final UserGeo userGeo = geoMap.get(String.valueOf(uid));
        Map<String, Double> scoreMap = new HashMap<>();
        for (final String recallUid : recallUids) {
            final double distance = GeoUtil.getDistance(userGeo, geoMap.get(recallUid));
            scoreMap.put(recallUid, distance > 0 ? distance : 0);
        }
        return scoreMap;
    }
}
