package com.ufoto.business.recommendNG;

import com.google.common.collect.Sets;

import java.util.Set;

/**
 * <p>
 * Author     : Chan
 * CreateDate : 2019-07-18 14:28
 * Description: 本地缓存
 * </p>
 */
public interface RecommendCache {

    //更新本地缓存
    default void updateCache() {

    }

    //获取本地缓存
    default Set<String> getRecommendCache() {
        return Sets.newHashSet();
    }

}
