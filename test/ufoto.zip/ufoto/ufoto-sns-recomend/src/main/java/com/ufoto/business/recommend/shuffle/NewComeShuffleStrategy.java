package com.ufoto.business.recommend.shuffle;

import com.ufoto.annotation.RecommendMetadata;
import com.ufoto.business.recommend.shuffle.base.BaseShuffleStrategy;
import com.ufoto.business.recommend.shuffle.cutter.NewComeUserCutter;
import com.ufoto.business.recommend.shuffle.dealer.RandomBySizeWeightDealer;
import com.ufoto.utils.redis.RedisService;

@RecommendMetadata(
        metadataType = RecommendMetadata.MetadataType.SHUFFLE,
        available = true,
        name = "低曝光用户打散器",
        description = "根据是否是低曝光用户分区(NewComeUserCutter),然后根据列表长度决定权重,长度越长,越有可能排在前面(RandomBySizeWeightDealer)",
        branch = RecommendMetadata.Branch.NORMAL
)
public class NewComeShuffleStrategy extends BaseShuffleStrategy {

    public NewComeShuffleStrategy(RedisService redisService) {
        this.cutter = new NewComeUserCutter(redisService);
        this.dealer = new RandomBySizeWeightDealer();
    }

}
