package com.ufoto.business.recommend.filter.delete;

import com.ufoto.annotation.RecommendMetadata;
import com.ufoto.business.recommend.RecommendFilterStrategy;
import com.ufoto.business.recommend.filter.FilterUtil;
import com.ufoto.dto.RecommendAdvanceRequest;
import com.ufoto.utils.redis.RedisKeyConstant;
import com.ufoto.utils.redis.RedisService;
import org.springframework.stereotype.Component;

import java.util.HashSet;
import java.util.List;
import java.util.Optional;
import java.util.Set;

/**
 * <p>
 * Author     : Chan
 * CreateDate : 2018/11/7 16:49
 * Description:
 * </p>
 */
@RecommendMetadata(
        metadataType = RecommendMetadata.MetadataType.FILTER,
        available = true,
        updateCache = true,
        name = "已删除用户过滤策略",
        description = "过滤已经被删除掉的用户(真实的场景应该是在用户删除时将其移出与之相关的所有用户池)",
        branch = {
                RecommendMetadata.Branch.NORMAL,
                RecommendMetadata.Branch.DEFAULT,
                RecommendMetadata.Branch.GIFT,
                RecommendMetadata.Branch.High_Risk,
                RecommendMetadata.Branch.USERLAYER,
                RecommendMetadata.Branch.WINK
        }
)
@Component
public class DeleteUserFilterStrategy implements RecommendFilterStrategy {

    private final RedisService redisService;
    private final FilterUtil filterUtil;

    public DeleteUserFilterStrategy(RedisService redisService,
                                    FilterUtil filterUtil) {
        this.redisService = redisService;
        this.filterUtil = filterUtil;
    }

    @Override
    public Set<String> filter(Set<String> recallSet, List<String> resultList, RecommendAdvanceRequest filterRequest) {
        return filterUtil.filter(recallSet, this.getClass());
    }


    public Set<String> updateCache() {
        final String key = RedisKeyConstant.REDIS_DELETED_USER_SET_KEY;
        return Optional.ofNullable(redisService.sMember(key, true)).orElse(new HashSet<>());
    }

}
