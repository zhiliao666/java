package com.ufoto.business.elasticsearch.dto;

import lombok.Data;

import java.io.Serializable;
import java.util.List;

/**
 * @author luozq
 * @date 2019/11/15 15:22
 */
@Data
public class UserActSearchVo implements Serializable {

    /**
     * 1 like
     * 2 dislike
     * 3 super like
     * 4 rewind
     * 5 query like stat
     */
    private List<Integer> actTypeList;

    /**
     * user id
     */
    private Long uid;

    /**
     * 1: 未读
     * 2: 自己对别人操作
     * 3： 别人对自己操作
     */
    private Integer ifSelf;

    /**
     * 创建时间，行为数据的起始时间
     */
    private Integer createTime;

}
