package com.ufoto.business.elasticsearch.dto;

import lombok.Builder;
import lombok.Data;
import lombok.experimental.Tolerate;

import java.io.Serializable;

/**
 * @author luozq
 * @date 2020/4/7 11:30
 */
@Data
@Builder
public class UserImageAttrDto implements Serializable {

    private Long uid;

    private Integer activeLevel;

    private Integer riskLevel;

    @Tolerate
    public UserImageAttrDto() {

    }
}
