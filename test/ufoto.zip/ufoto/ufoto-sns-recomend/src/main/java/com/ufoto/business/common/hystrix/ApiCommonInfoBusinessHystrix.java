package com.ufoto.business.common.hystrix;

import com.ufoto.business.common.ApiCommonInfoBusiness;
import com.ufoto.utils.ApiResult;
import org.springframework.stereotype.Component;

import java.util.List;
import java.util.Map;

/**
 * 获取公共服务提供的信息
 * 熔断器
 *
 * @author luyz
 */
@Component
public class ApiCommonInfoBusinessHystrix implements ApiCommonInfoBusiness {

    @Override
    public ApiResult<List<Integer>> getAreaIdByIp(String ip,
                                                  String countryCode,
                                                  Integer appId) {
        return new ApiResult<List<Integer>>().setError(ApiResult.errorCode500, "hystrix");
    }

    @Override
    public ApiResult<Map<String, Integer>> areaCountryMap(Integer appId) {
        return new ApiResult<Map<String, Integer>>().setError(ApiResult.errorCode500, "hystrix");
    }
}
