package com.ufoto.config.disruptor.consumer;

import com.ufoto.config.disruptor.constants.EventType;
import com.ufoto.config.disruptor.data.AsyncData;
import com.ufoto.config.disruptor.event.AsyncEvent;
import com.ufoto.lmax.consumer.Consumer;
import com.ufoto.utils.SpringContextUtil;

/**
 * <p>
 * Description:
 *
 * </p>
 *
 * @author Chan
 * @date 2019/12/21 15:01
 */
public class AsyncConsumer extends Consumer<AsyncEvent> {
    public AsyncConsumer(String consumerId) {
        super(consumerId);
    }

    @Override
    public void consume(AsyncEvent event) {
        final EventType eventType = event.getEventType();
        final AsyncData asyncData = event.getAsyncData();
        if (eventType == null || eventType == EventType.ASYNC_ERROR_END) {
            throw new RuntimeException("EventTypeError");
        }
        if (asyncData == null) {
            throw new RuntimeException("AsyncDataNullError");
        }
        SpringContextUtil.getBean(eventType.getAsyncExecutorClass()).execute(asyncData);
    }
}
