package com.ufoto.business.recommend.sort.randomMatch;

import com.ufoto.entity.UfotoUserChatActivity;

import java.util.List;
import java.util.Map;

/**
 * <p>
 *
 * </p>
 *
 * @author created by chenzhou at 2018-08-02 18:38
 */
public abstract class BaseNormalRandomMatchSortStrategy implements SpecifyRandomMatchSortStrategy {

    @Override
    public Map<Long, Double> addScoreBatch(Map<Long, Double> uidScoreMap, Double weight, List<UfotoUserChatActivity> activities, UfotoUserChatActivity currentUser) {
        Map<Long, Double> targetRecallUidScoreMap = getScore(activities, currentUser);
        targetRecallUidScoreMap.forEach((recallUid, score) -> uidScoreMap.merge(recallUid, score * weight, (a, b) -> a + b));
        return uidScoreMap;
    }
}
