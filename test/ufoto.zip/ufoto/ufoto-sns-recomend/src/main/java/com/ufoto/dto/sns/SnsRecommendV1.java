package com.ufoto.dto.sns;

import lombok.Data;

import java.io.Serializable;

/**
 * <p>
 * Author     : Chan
 * CreateDate : 2018/9/17 11:24
 * Description:
 * </p>
 */
@Data
public class SnsRecommendV1 implements Serializable {
    private String userName;
    private String uid;
    private Byte gender;
    private String description;
    private Long birthTime;
    private Integer distance;
    private String headImg;
    private Integer headImgNum;
    private Byte likeState;
    private String location;
    private Integer afterLastActTime;
    private Integer isDelete;
    private String source;
    private Integer userType;//用户类型 是用户还是卡片  用户1  问题卡片2  収礼卡片3
    private Integer subType = 0;//订阅类型 0 未订阅 1订阅
    private Integer giftNum;//收到礼物数量，null和0是不同的意义
    private Integer age;//用户年龄
    private String avatar;//头像
}
