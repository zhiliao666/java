package com.ufoto.manager;

import com.google.common.collect.Lists;
import com.ufoto.business.elasticsearch.ElasticSearchBusiness;
import com.ufoto.business.elasticsearch.dto.*;
import com.ufoto.config.constant.PropertyConstant;
import com.ufoto.constants.ESnsUserLayer;
import com.ufoto.constants.ESnsUserRisk;
import com.ufoto.dto.RecommendAdvanceRequest;
import com.ufoto.plugins.interceptor.LogInterceptor;
import com.ufoto.utils.ApiResult;
import com.ufoto.utils.DirtyCaseUtil;
import com.ufoto.utils.json.JSONUtil;
import com.ufoto.utils.threadlocal.ThreadLocalManager;

import lombok.extern.slf4j.Slf4j;

import org.slf4j.MDC;
import org.springframework.core.env.Environment;
import org.springframework.stereotype.Component;

import java.util.Arrays;
import java.util.HashSet;
import java.util.List;
import java.util.Objects;
import java.util.Optional;
import java.util.Set;
import java.util.stream.Collectors;

/**
 * <p>
 * Author     : Chan
 * CreateDate : 2019/11/18 10:42
 * Description:
 * </p>
 */
@Slf4j
@Component
public class ElasticSearchManager {

    private final ElasticSearchBusiness elasticSearchBusiness;
    private final Environment env;
    private final DirtyCaseUtil dirtyCaseUtil;

    public ElasticSearchManager(ElasticSearchBusiness elasticSearchBusiness,Environment env, DirtyCaseUtil dirtyCaseUtil) {
        this.elasticSearchBusiness = elasticSearchBusiness;
        this.env = env;
        this.dirtyCaseUtil = dirtyCaseUtil;
    }

    public FriendSearchDto checkUserFriend(FriendSearchVo searchVo) {
        final ApiResult<FriendSearchDto> apiResult = elasticSearchBusiness.checkUserFriend(searchVo.getUid(), searchVo);
        if (!Objects.equals(apiResult.getC(), ApiResult.successCode)) {
            log.warn("ES_USER_FRIEND searchVo:{},result:{}", JSONUtil.toJSON(searchVo), JSONUtil.toJSON(apiResult));
            return FriendSearchDto.builder().uid(searchVo.getUid()).friendIdList(Lists.newLinkedList()).build();
        }
        return apiResult.getD();
    }

    public List<Long> queryUserAct(UserActSearchVo searchVo) {
        final ApiResult<List<Long>> apiResult = elasticSearchBusiness.searchUserActByParam(searchVo.getUid(), searchVo);
        if (!Objects.equals(apiResult.getC(), ApiResult.successCode)) {
            final String format = String.format("ES_USER_ACT searchVo:%s,result:%s",
                    JSONUtil.toJSON(searchVo), JSONUtil.toJSON(apiResult));
            log.error(format);
            throw new ElasticSearchException(format);
        }
        log.debug("searchVo:{},result:{}", JSONUtil.toJSON(searchVo), JSONUtil.toJSON(apiResult));
        return apiResult.getD();
    }

    /**
     * 过滤超过上限的用户,如果这个用户对uid like或superlike过,并且uid对其没有操作过,保留不过滤
     *
     * @param filterVo
     * @return
     */
    public List<Long> filterUserAct(UserActFilterVo filterVo) {
        final ApiResult<List<Long>> apiResult = elasticSearchBusiness.filterActLimit(filterVo.getUid(), filterVo);
        if (!Objects.equals(apiResult.getC(), ApiResult.successCode)) {
            final String format = String.format("ES_FILTER_USER_ACT filterVo:%s,result:%s",
                    JSONUtil.toJSON(filterVo), JSONUtil.toJSON(apiResult));
            log.error(format);
            throw new ElasticSearchException(format);
        }
        return apiResult.getD();
    }

    public List<Long> filterUserRecommended(UserRecommendedFilterVo filterVo) {
        final ApiResult<List<Long>> apiResult = elasticSearchBusiness.filterActRecommended(filterVo.getUid(), filterVo);
        if (!Objects.equals(apiResult.getC(), ApiResult.successCode)) {
            final String format = String.format("ES_FILTER_USER_RECOMMENDED filterVo:%s,result:%s",
                    JSONUtil.toJSON(filterVo), JSONUtil.toJSON(apiResult));
            log.error(format);
            throw new ElasticSearchException(format);
        }
        return apiResult.getD();
    }
    /**
     * 从es中获取用户分层信息
     * @param uid
     * @return default ESnsUserLayer.NEWUSER.getLayer() 新用户
     */
    public UserImageAttrDto queryUserLayer(Long uid) {
        if(uid == null) {
            log.error("requestID: {}, uid is null", MDC.get(LogInterceptor.SESSION_KEY));
            return getDefaultUserImage();
        }
        final ApiResult<UserImageAttrDto> apiResult = elasticSearchBusiness.getUserInfoByUid(uid);
        UserImageAttrDto dto = apiResult.getD();
        if (!Objects.equals(apiResult.getC(), ApiResult.successCode)
        		|| null == dto) {
            final String format = String.format("ES_QUERY_USER_LAYER_ERROR uid:%s,result:%s",
                    uid, JSONUtil.toJSON(apiResult));
            log.error(format);
            return getDefaultUserImage();
        }
        return dto;
    }

    private UserImageAttrDto getDefaultUserImage() {
        UserImageAttrDto userImageAttrDto = new UserImageAttrDto();
        userImageAttrDto.setActiveLevel(ESnsUserLayer.NEWUSER.getLayer());
        userImageAttrDto.setRiskLevel(ESnsUserRisk.MONITOR.getRiskLevel());
        return userImageAttrDto;
    }
    /**
     * 根据用户参数从 es 获取召回结果集
     * @param uid
     * @param recallRequest
     * @return
     */
    public Set<String> queryUserIdsFromESByCondition(Long uid,RecommendAdvanceRequest recallRequest,List<Integer> levels) throws ElasticSearchException {
    	final Integer esrecallimit = env.getProperty("es.userlayer.recall.limit", Integer.class, 100);

    	ImageCallConditionVo conditionVo = new ImageCallConditionVo();

        Integer minAge = dirtyCaseUtil.ifChat(recallRequest)
                ? env.getProperty(PropertyConstant.CHAT_RECALL_MIN_NUM, Integer.class, 17)
                : 0;
        Integer startAge = recallRequest.getStartAge() == null || recallRequest.getStartAge() < minAge
                ? minAge : recallRequest.getStartAge();

    	conditionVo.setAgeList(Arrays.asList(startAge,
    			Optional.ofNullable(recallRequest.getEndAge()).orElse(1000)));

    	// 没有设置距离过滤或者距离设置大于等于100时候我们认为用户距离无限制，客户端最高设置就是100+
    	if(recallRequest.getDistance() != null && recallRequest.getDistance() < 100 ) {
    		conditionVo.setDistance(recallRequest.getDistance());
    	}
    	Integer areaId = recallRequest.getAreaId();
    	if(areaId != null) {
    		conditionVo.setAreaId(areaId);
    	}
    	Integer lastRecallTime = recallRequest.getLastRecallTime();
    	if(lastRecallTime != null) {
    		conditionVo.setLastActiveTime(lastRecallTime);
    	}
    	if(recallRequest.getGender() != null) {
    		conditionVo.setGender(recallRequest.getGender()==0?null:recallRequest.getGender());
    	}
    	Double longitude = recallRequest.getLongitude();
    	Double latitude = recallRequest.getLatitude();
    	if(longitude != null && latitude != null) {
    		conditionVo.setGps(Arrays.asList(longitude,latitude));
    	}
    	if(!levels.isEmpty()) {
    		conditionVo.setLevelList(levels);
    	}
    	conditionVo.setLimit(esrecallimit);
    	final ApiResult<ImageReCallDto> apiResult = elasticSearchBusiness.reCallByCondition(uid, conditionVo);
    	log.debug("es-recall  参数：{} , 结果集：{}",JSONUtil.toJSON(conditionVo),JSONUtil.toJSON(apiResult));
    	if (!Objects.equals(apiResult.getC(), ApiResult.successCode)) {
    		final String format = String.format("ES_USER_RECALL_ERROR traceId:%s,uid:%s, filterVo:%s,result:%s",MDC.get(LogInterceptor.SESSION_KEY),uid,
                    JSONUtil.toJSON(conditionVo), JSONUtil.toJSON(apiResult));
    		if(Objects.equals(apiResult.getC(), ApiResult.errorCode500)) {
    		    // 500直接停止召回过程
    			log.error(format);
    			throw new ElasticSearchException(format);
    		}else {
    			log.warn(format);
    		}
    		return new HashSet<String>();
    	}
    	ImageReCallDto imageReCallDto = apiResult.getD();
    	List<Long> uidList = Optional.ofNullable(imageReCallDto.getUidList()).orElse(Arrays.asList());
    	// 设置从es中召回中的最晚活跃时间，以便数据不够时再次召回可以从当前时间往前召回
    	if(imageReCallDto.getMinActiveTime() != null) {
    		ThreadLocalManager.setESACTIVETIMEThreadLocal(imageReCallDto.getMinActiveTime());
    	}

		return uidList.stream().map(String::valueOf).collect(Collectors.toSet());
    	
    }

    public Set<String> queryHighRiskByCondition(Long uid,RecommendAdvanceRequest recallRequest) {
        Integer highRiskRecallNum = env.getProperty("recommend.highRisk.recall.num", Integer.class, 100);
        HighRiskCallVO highRiskCallVO = new HighRiskCallVO();
        if(recallRequest.getLastRecallTime() != null) {
            highRiskCallVO.setLastActiveTime(recallRequest.getLastRecallTime());
        }
        highRiskCallVO.setLimit(highRiskRecallNum);
        final ApiResult<ImageReCallDto> apiResult = elasticSearchBusiness.reCallHighRisk(uid, highRiskCallVO);
        log.debug("es-high-recall  参数：{} , 结果集：{}",JSONUtil.toJSON(highRiskCallVO),JSONUtil.toJSON(apiResult));
        if (!Objects.equals(apiResult.getC(), ApiResult.successCode)) {
            final String format = String.format("ES_HIGH_RISK_USER_RECALL_ERROR traceId:%s,uid:%s, filterVo:%s,result:%s",MDC.get(LogInterceptor.SESSION_KEY),uid,
                    JSONUtil.toJSON(highRiskCallVO), JSONUtil.toJSON(apiResult));
            if(Objects.equals(apiResult.getC(), ApiResult.errorCode500)) {
                // 500直接停止召回过程
                log.error(format);
                throw new ElasticSearchException(format);
            }else {
                log.warn(format);
            }
            return new HashSet<String>();
        }
        ImageReCallDto imageReCallDto = apiResult.getD();
        List<Long> uidList = Optional.ofNullable(imageReCallDto.getUidList()).orElse(Arrays.asList());

        if(imageReCallDto.getMinActiveTime() != null) {
            ThreadLocalManager.setESACTIVETIMEThreadLocal(imageReCallDto.getMinActiveTime());
        }

        return uidList.stream().map(String::valueOf).collect(Collectors.toSet());
    }
    
    public static void main(String[] args) {
    	List<Long> uidList = Arrays.asList(1L,2L);
    	Set<String> set = uidList.stream().map(String::valueOf).collect(Collectors.toSet());
		System.out.println(set);
	}

}
