package com.ufoto.bloom;

import com.ufoto.utils.DateUtil;
import com.ufoto.utils.redis.RedisKeyConstant;
import com.ufoto.utils.redis.RedisKeyUtil;
import com.ufoto.utils.redis.RedisService;
import org.springframework.data.redis.connection.RedisConnection;
import org.springframework.util.StringUtils;

import java.nio.charset.StandardCharsets;

/**
 * <p>
 * Description:
 *
 * </p>
 *
 * @author Chan
 * @date 2019/12/21 13:53
 */
public class RecommendCalculatedBloomFilter extends AbstractRecommendBloomFilter<Long, String> {

    private final static String keyTemplate = RedisKeyConstant.REDIS_RECOMMEND_CAlCULATED_CHUNK_V3;
    private final static String keyContainerTemplate = RedisKeyConstant.REDIS_RECOMMEND_CAlCULATED_V3;
    private final static String currentKeyField = RedisKeyConstant.REDIS_RECOMMEND_CAlCULATED_CURRENT;
    private final static String keyPrefix = keyTemplate.substring(0, keyTemplate.indexOf(":"));

    private final RedisService redisService;

    public RecommendCalculatedBloomFilter(RedisService redisService) {
        super(redisService, 1000, 1e-7, false);
        this.redisService = redisService;
    }

    @Override
    public String getCurrentKeyField() {
        return currentKeyField;
    }

    @Override
    public String getAndUpdateCurrentKey(Long user) {
        final String hashKey = this.getKeyContainerKey(user);
        String currentBFKey = redisService.hget(hashKey, currentKeyField);

        if (StringUtils.isEmpty(currentBFKey)) {
            currentBFKey = createAndUpdateCurrentKey(hashKey, user, 0);
        }
        return currentBFKey;
    }

    public String createAndUpdateCurrentKey(String hashKey, Long user, int index) {
        String currentBFKey = RedisKeyUtil.obtainKey(keyTemplate, user, index);
        redisService.hset(hashKey, currentKeyField, currentBFKey);
        //设置过期时间为下一个零点
        redisService.expireAt(hashKey, DateUtil.nextTwoZero());
        return currentBFKey;
    }

    @Override
    public String getKeyContainerKey(Long user) {
        return RedisKeyUtil.obtainKey(keyContainerTemplate, user);
    }

    @Override
    public boolean ifBloomFilterKey(String key) {
        return StringUtils.hasText(key) && key.startsWith(keyPrefix);
    }

    @Override
    public void expireCurrentBFKey(RedisConnection connection, String currentBFKey, String currentContainer) {
        connection.expireAt(currentContainer.getBytes(StandardCharsets.UTF_8), DateUtil.nextTwoZeroTimestamp());
        connection.expireAt(currentBFKey.getBytes(StandardCharsets.UTF_8), DateUtil.nextTwoZeroTimestamp());
    }
}
