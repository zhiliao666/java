package com.ufoto.business.recommend.shuffle;

import com.ufoto.annotation.RecommendMetadata;
import com.ufoto.business.recommend.shuffle.base.BaseShuffleStrategy;
import com.ufoto.business.recommend.shuffle.cutter.SuperLikeMeCutter;
import com.ufoto.business.recommend.shuffle.dealer.DealByOrderDealer;
import com.ufoto.utils.redis.RedisService;

@RecommendMetadata(
        metadataType = RecommendMetadata.MetadataType.SHUFFLE,
        available = true,
        name = "superlike打散器",
        description = "根据是否superlike我分区(SuperLikeMeCutter),然后按照list的顺序合并list(DealByOrderDealer)",
        branch = RecommendMetadata.Branch.NORMAL
)
public class SuperLikeMeShuffleStrategy extends BaseShuffleStrategy {

    public SuperLikeMeShuffleStrategy(RedisService redisService, long uid) {
        this.cutter = new SuperLikeMeCutter(uid, redisService);
        this.dealer = new DealByOrderDealer();
    }

}
