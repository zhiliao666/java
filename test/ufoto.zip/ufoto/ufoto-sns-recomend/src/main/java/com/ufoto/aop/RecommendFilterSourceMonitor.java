package com.ufoto.aop;

import com.google.common.collect.Sets;
import com.ufoto.dto.RecommendAdvanceRequest;
import com.ufoto.utils.CommonUtil;
import com.ufoto.utils.json.JSONUtil;
import com.ufoto.plugins.interceptor.LogInterceptor;
import lombok.extern.slf4j.Slf4j;
import org.aspectj.lang.JoinPoint;
import org.aspectj.lang.annotation.AfterReturning;
import org.slf4j.MDC;
import org.springframework.core.env.Environment;

import java.util.HashMap;
import java.util.Map;
import java.util.Set;

/**
 * <p>
 *
 * </p>
 *
 * @author created by chenzhou at 2018-07-20 09:50
 */
@Slf4j
//@Aspect
//@Component
public class RecommendFilterSourceMonitor {
    private final Environment env;

    public RecommendFilterSourceMonitor(Environment env) {
        this.env = env;
    }

    @AfterReturning(value = "execution(* com.ufoto.business.recommend.filter.*.*.filter(..))", returning = "re")
    public void doFilterAfter(JoinPoint joinPoint, Object re) {
        try {
            log.debug("start doFilterAfter pointcut:{}...", joinPoint);
            final Boolean logSwitch = env.getProperty("recommend.filter.log.switch", Boolean.class, false);
            if (!logSwitch) {
                return;
            }
            final Object[] args = joinPoint.getArgs();
            //第三个参数是参数bean
            RecommendAdvanceRequest filterParamsBean = (RecommendAdvanceRequest) args[2];
            final Long uid = filterParamsBean.getUid();
            if (uid == null) {
                return;
            }
            //过滤之前
            final Set<String> recallUids = CommonUtil.obj2Set(args[0]);
            //过滤之后
            final Set<String> filterUids = CommonUtil.obj2Set(re);
            Map<String, Object> map = new HashMap<>();
            map.put("filter", joinPoint.getTarget().getClass().getSimpleName());
            map.put("request", filterParamsBean);
            map.put("recallUids", recallUids);
            map.put("result", Sets.difference(recallUids, filterUids));
            map.put("traceId", MDC.get(LogInterceptor.SESSION_KEY));

            log.warn("filterLog:{}", JSONUtil.toJSON(map));
        } catch (Exception e) {
            log.error("joinPoint:{},errorMsg:{}", joinPoint, e.getMessage(), e);
        }
    }

}
