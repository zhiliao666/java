package com.ufoto.business.recommend.shuffle.cutter;

import com.ufoto.annotation.RecommendMetadata;
import com.ufoto.business.recommend.shuffle.base.ShuffleCutter;
import com.ufoto.utils.CommonUtil;
import com.ufoto.utils.redis.RedisKeyConstant;
import com.ufoto.utils.redis.RedisKeyUtil;
import com.ufoto.utils.redis.RedisService;

import java.nio.charset.StandardCharsets;
import java.util.LinkedList;
import java.util.List;

@RecommendMetadata(
        metadataType = RecommendMetadata.MetadataType.CUTTER,
        available = true,
        name = "运营陪聊人员分区器",
        description = "根据是否是运营人员分区",
        branch = RecommendMetadata.Branch.NORMAL
)
public class FreeChatCutter implements ShuffleCutter {

    Long requestUid;

    RedisService redisService;

    public FreeChatCutter(Long uid, RedisService redisService) {
        this.requestUid = uid;
        this.redisService = redisService;
    }

    @Override
    public List<List<String>> cut(String[] uidArray) {
        List<List<String>> result = new LinkedList<>();
        result.add(new LinkedList<>());//运营陪聊人员
        result.add(new LinkedList<>());//普通的人

        final List<Object> objects = redisService.execPipelineForRead(connection -> {
            for (String uid : uidArray) {
                connection.sIsMember((RedisKeyConstant.REDIS_CHAT_FREE_SET_KEY).getBytes(StandardCharsets.UTF_8),
                        RedisKeyUtil.serializeUid(uid).getBytes(StandardCharsets.UTF_8));
            }
            return null;
        });

        //每2个为一组 同一个用户
        for (int i = 0; i < uidArray.length; i++) {
            Object obj = objects.get(i);
            if (CommonUtil.obj2Boolean(obj)) {
                result.get(0).add(uidArray[i]);
            } else {
                result.get(1).add(uidArray[i]);
            }
        }

        return result;
    }
}
