package com.ufoto.constants;

/**
 * 
 *
 * @author zhangqh  
 * @date Apr 8, 2020 3:26:03 PM  
 * @version 1.0
 */
public enum ELanguage {

    EN("en","英语"),
    PT("pt","葡萄牙语"),
    ES("es","西班牙语");

    private String type;
    private String msg;
    
	private ELanguage(String type, String msg) {
		this.type = type;
		this.msg = msg;
	}
	public String getType() {
		return type;
	}
	public String getMsg() {
		return msg;
	}

   
}
