package com.ufoto.business.recommend.sort.age;

import com.ufoto.annotation.RecommendMetadata;
import com.ufoto.business.recommend.bean.SortParamsBean;
import com.ufoto.business.recommend.sort.BaseNormalSortStrategy;
import com.ufoto.utils.KeyTransitionUtil;
import com.ufoto.utils.redis.RedisService;
import lombok.extern.slf4j.Slf4j;
import org.springframework.stereotype.Component;

import java.util.HashMap;
import java.util.List;
import java.util.Map;

/**
 * Created by echo on 4/8/18.
 */
@RecommendMetadata(
        metadataType = RecommendMetadata.MetadataType.SORT,
        available = true,
        name = "18岁年龄差值排序策略",
        description = "如果用户的生日不存在,默认为1分.此外,计算公式为result=1-abs(18YMills-birthMills)/10YMills,小于0则默认0",
        branch = RecommendMetadata.Branch.NORMAL
)
@Slf4j
@Component
public class AgeDiff18SortStrategy extends BaseNormalSortStrategy {
    private final static long ageOf10Years = 10L;
    private final RedisService redisService;

    public AgeDiff18SortStrategy(RedisService redisService) {
        this.redisService = redisService;
    }

    /**
     * 返回对应用户和18岁的年龄差距，并以10年作为最大范围进行归一化
     */
    @Override
    public Map<String, Double> getScore(List<String> recallUids, SortParamsBean sortParamsBean) {
        long ageOf18 = 18L;
        Map<String, Integer> ageMap = KeyTransitionUtil.ageMap(redisService, recallUids);
        log.debug("ageMap:{}", ageMap);
        Map<String, Double> scoreMap = new HashMap<>();
        for (final String recallUid : recallUids) {
            final Integer age = ageMap.get(recallUid);
            if (age == null) {
                scoreMap.put(recallUid, 1d);
                continue;
            }
            double result = 1 - Math.abs(ageOf18 - age) / ageOf10Years;//10年，修改请同时修改上方注释
            if (result < 0) result = 0D;
            scoreMap.put(recallUid, result);
        }
        return scoreMap;
    }
}
