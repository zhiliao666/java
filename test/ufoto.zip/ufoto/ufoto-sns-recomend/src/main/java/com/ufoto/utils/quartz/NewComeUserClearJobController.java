package com.ufoto.utils.quartz;

import com.ufoto.utils.quartz.service.QuartzService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.core.env.Environment;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

/**
 * <p>
 * Author     : Chan
 * CreateDate : 2019-08-12 14:04
 * Description:
 * </p>
 */
@RequestMapping("/newComeJob")
@RestController
public class NewComeUserClearJobController extends BaseJobController {

    @Autowired
    public NewComeUserClearJobController(QuartzService quartzService, Environment env) {
        super(quartzService,
                QuartzHelper.GROUP_NEW_COME_USER_CLEAR,
                QuartzHelper.JOB_NEW_COME_USER_CLEAR,
                env.getProperty("cron.new.come.clear", String.class, "0 0/5 * * * ?"),
                NewComeUserClearJob.class,
                "清除活跃时间大于24小时的低曝光用户");
    }
}
