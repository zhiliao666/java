package com.ufoto.business.recommend.sort.taste;

import com.ufoto.annotation.RecommendMetadata;
import com.ufoto.business.recommend.bean.SortParamsBean;
import com.ufoto.business.recommend.sort.BaseNormalSortStrategy;
import org.springframework.stereotype.Component;

import java.util.HashMap;
import java.util.List;
import java.util.Map;

/**
 * Created by echo on 4/8/18.
 */
@RecommendMetadata(
        metadataType = RecommendMetadata.MetadataType.SORT,
        name = "挑剔程度排序算法",
        description = "根据用户的挑剔程度排序,score=sendLikeNum/recommendedNum,已废弃"
)
@Deprecated
@Component
public class TasteSortStrategy extends BaseNormalSortStrategy {
    /**
     * 返回挑剔程度值
     * 可能为null
     */
    @Override
    public Map<String, Double> getScore(List<String> recallUids, SortParamsBean sortParamsBean) {
        Map<String, Double> scoreMap = new HashMap<>();
        for (final String recallUid : recallUids) {
            scoreMap.put(recallUid, 0D);
        }
        return scoreMap;
    }
}
