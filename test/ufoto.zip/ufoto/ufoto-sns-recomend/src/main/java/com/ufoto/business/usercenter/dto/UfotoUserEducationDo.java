package com.ufoto.business.usercenter.dto;

import lombok.Data;

import java.io.Serializable;

/**
 * 用户的教育程度信息,
 * 对应ufoto_user_education, ufoto_user_education_relation两张表
 *
 * @author luozq
 * @date 2019/3/7/007
 */
@Data
public class UfotoUserEducationDo implements Serializable {

    /**
     * 用户id
     */
    private Long uId;

    private String id;

    /**
     * 学校名称
     */
    private String school;
    /**
     * 学历: College 大学, High School: 大学
     */
    private String type = "";


}
