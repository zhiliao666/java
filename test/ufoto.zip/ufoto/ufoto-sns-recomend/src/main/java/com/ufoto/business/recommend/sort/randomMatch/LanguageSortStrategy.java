package com.ufoto.business.recommend.sort.randomMatch;

import com.google.common.collect.Maps;
import com.ufoto.entity.UfotoUserChatActivity;
import org.apache.commons.lang.StringUtils;
import org.springframework.stereotype.Component;
import org.springframework.util.CollectionUtils;

import java.util.List;
import java.util.Map;

/**
 * <p>
 *
 * </p>
 *
 * @author created by chenzhou at 2018-08-02 17:47
 */
@Component
public class LanguageSortStrategy extends BaseNormalRandomMatchSortStrategy {

    @Override
    public Map<Long, Double> getScore(List<UfotoUserChatActivity> activities, UfotoUserChatActivity currentUser) {
        Map<Long, Double> uidScoreMap = Maps.newHashMap();
        if (!CollectionUtils.isEmpty(activities)) {
            for (UfotoUserChatActivity activity : activities) {
                if (StringUtils.isNotBlank(activity.getLang())) {
                    uidScoreMap.put(activity.getUId(), 1D);
                } else {
                    uidScoreMap.put(activity.getUId(), 0D);
                }
            }
        }
        return uidScoreMap;
    }
}
