package com.ufoto.utils.quartz;

import com.ufoto.utils.quartz.service.QuartzService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.core.env.Environment;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

/**
 * <p>
 * Author     : Chan
 * CreateDate : 2019-08-12 14:19
 * Description:
 * </p>
 */
@RequestMapping("/recommendedUserJob")
@RestController
public class RecommendedUserClearJobController extends BaseJobController {

    @Autowired
    public RecommendedUserClearJobController(QuartzService quartzService, Environment env) {
        super(quartzService,
                QuartzHelper.GROUP_RECOMMENDED_USER_CLEAR,
                QuartzHelper.JOB_RECOMMENDED_USER_CLEAR,
                env.getProperty("cron.recommended.user.clear", String.class, "0 0/5 * * * ?"),
                RecommendedUserClearJob.class,
                "清理24小时活跃用户中已经过期的看过的用户的BF");
    }

}
