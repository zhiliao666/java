package com.ufoto.manager;

import com.google.common.collect.Lists;
import com.google.common.collect.Maps;
import com.ufoto.annotation.RecommendMetadata;
import com.ufoto.business.recommend.RecommendFilterStrategy;
import com.ufoto.business.recommendNG.Reagent;
import com.ufoto.business.recommendNG.Recall;
import lombok.extern.slf4j.Slf4j;
import org.springframework.aop.support.AopUtils;
import org.springframework.beans.BeansException;
import org.springframework.beans.factory.config.BeanPostProcessor;
import org.springframework.boot.CommandLineRunner;
import org.springframework.stereotype.Component;

import java.util.Collection;
import java.util.List;
import java.util.Map;
import java.util.stream.Collectors;
import java.util.stream.Stream;

import static com.ufoto.annotation.RecommendMetadata.Branch;
import static com.ufoto.annotation.RecommendMetadata.Branch.DEFAULT;
import static com.ufoto.annotation.RecommendMetadata.Branch.GIFT;
import static com.ufoto.annotation.RecommendMetadata.Branch.High_Risk;
import static com.ufoto.annotation.RecommendMetadata.Branch.NORMAL;

@Slf4j
@Component
public class RecommendStrategyRegister implements BeanPostProcessor, CommandLineRunner {

    private Map<Branch, List<RecommendFilterStrategy>> FILTER_STRATEGY_MAP = Maps.newHashMap();
    private Map<Branch, List<Recall>> RECALL_MAP = Maps.newHashMap();
    private Map<Branch, List<Reagent>> REAGENT_MAP = Maps.newHashMap();

    public Map<Branch, List<RecommendFilterStrategy>> getFilterStrategyMap() {
        return FILTER_STRATEGY_MAP;
    }

    public Map<Branch, List<Recall>> getRecallMap() {
        return RECALL_MAP;
    }

    public Map<Branch, List<Reagent>> getReagentMap() {
        return REAGENT_MAP;
    }

    @Override
    public void run(String... args) {
        log.debug("----------------------------------------------------------------------");
        //filter
        log.debug("normalFilter: {}", list2Json(FILTER_STRATEGY_MAP.get(NORMAL)));
        log.debug("defaultFilter: {}", list2Json(FILTER_STRATEGY_MAP.get(DEFAULT)));
        log.debug("giftFilter: {}", list2Json(FILTER_STRATEGY_MAP.get(GIFT)));
        log.debug("highRiskFilter: {}", list2Json(FILTER_STRATEGY_MAP.get(High_Risk)));
        //recall
        log.debug("normalRecall: {}", RECALL_MAP.get(NORMAL));
        log.debug("defaultRecall: {}", RECALL_MAP.get(DEFAULT));
        log.debug("giftRecall: {}", RECALL_MAP.get(GIFT));
        log.debug("highRiskRecall: {}", RECALL_MAP.get(High_Risk));
        //reagent
        log.debug("normalReagent: {}", REAGENT_MAP.get(NORMAL));
        log.debug("defaultReagent: {}", REAGENT_MAP.get(DEFAULT));
        log.debug("giftReagent: {}", REAGENT_MAP.get(GIFT));
        log.debug("highRiskReagent: {}", REAGENT_MAP.get(High_Risk));
        log.debug("----------------------------------------------------------------------");
    }

    private String list2Json(List<?> strategies) {
        return strategies.stream()
                .map(AopUtils::getTargetClass)
                .map(Class::getSimpleName)
                .collect(Collectors.joining(","));
    }

    @Override
    public Object postProcessAfterInitialization(Object bean, String beanName) throws BeansException {
        final Class<?> targetClass = AopUtils.getTargetClass(bean);
        RecommendMetadata recommendMetadata = targetClass.getAnnotation(RecommendMetadata.class);
        if (recommendMetadata != null && recommendMetadata.available()) {

            final RecommendMetadata.MetadataType metadataType = recommendMetadata.metadataType();
            switch (metadataType) {
                case FILTER:
                    RecommendFilterStrategy filter = (RecommendFilterStrategy) bean;
                    for (RecommendMetadata.Branch branch : recommendMetadata.branch()) {
                        FILTER_STRATEGY_MAP.merge(branch, Lists.newArrayList(filter), (o, n) -> Stream.of(o, n).flatMap(Collection::stream).collect(Collectors.toList()));
                    }
                    break;
                case RECALL:
                    Recall recall = (Recall) bean;
                    for (RecommendMetadata.Branch branch : recommendMetadata.branch()) {
                        RECALL_MAP.merge(branch, Lists.newArrayList(recall), (o, n) -> Stream.of(o, n).flatMap(Collection::stream).collect(Collectors.toList()));
                    }
                    break;
                case REAGENT:
                    Reagent reagent = (Reagent) bean;
                    for (RecommendMetadata.Branch branch : recommendMetadata.branch()) {
                        REAGENT_MAP.merge(branch, Lists.newArrayList(reagent), (o, n) -> Stream.of(o, n).flatMap(Collection::stream).collect(Collectors.toList()));
                    }
                    break;
            }
        }
        return bean;
    }
}
