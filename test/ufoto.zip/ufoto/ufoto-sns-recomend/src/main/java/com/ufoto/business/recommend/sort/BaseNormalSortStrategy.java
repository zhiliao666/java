package com.ufoto.business.recommend.sort;

import com.ufoto.business.recommend.bean.SortParamsBean;
import com.ufoto.business.recommend.logger.RecommendLogger;
import org.springframework.beans.factory.annotation.Autowired;

import java.util.ArrayList;
import java.util.Map;

/**
 * Created by echo on 4/8/18.
 */
public abstract class BaseNormalSortStrategy implements SpecificRecommendSortStrategy {

    @Autowired
    protected RecommendLogger recommendLogger;

    @Override
    public Map<String, Double> addScoreBatch(Map<String, Double> uidScoreMap, Double weight, SortParamsBean sortParamsBean) {
        Map<String, Double> targetRecallUidScoreMap = getScore(new ArrayList<>(uidScoreMap.keySet()), sortParamsBean);
        targetRecallUidScoreMap.forEach((recallUid, score) ->
                uidScoreMap.merge(recallUid, score * weight, Double::sum));
        return uidScoreMap;
    }
}
