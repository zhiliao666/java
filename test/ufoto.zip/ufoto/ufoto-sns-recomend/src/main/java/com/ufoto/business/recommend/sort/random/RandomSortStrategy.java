package com.ufoto.business.recommend.sort.random;

import com.ufoto.annotation.RecommendMetadata;
import com.ufoto.business.recommend.bean.SortParamsBean;
import com.ufoto.business.recommend.sort.BaseNormalSortStrategy;
import org.apache.commons.lang.math.RandomUtils;
import org.springframework.stereotype.Component;

import java.util.HashMap;
import java.util.List;
import java.util.Map;

/**
 * Created by echo on 5/11/18.
 */
@RecommendMetadata(
        metadataType = RecommendMetadata.MetadataType.SORT,
        available = true,
        name = "随机排序策略",
        description = "基础分数为0~1之间的随机数"
)
@Component
public class RandomSortStrategy extends BaseNormalSortStrategy {

    /**
     * 返回0～1 之间的一个随机小数
     */
    @Override
    public Map<String, Double> getScore(List<String> recallUids, SortParamsBean sortParamsBean) {
        Map<String, Double> scoreMap = new HashMap<>();
        for (String recallUid : recallUids) {
            Double randomScore = RandomUtils.nextDouble();
            scoreMap.put(recallUid, randomScore);
        }
        return scoreMap;
    }
}
