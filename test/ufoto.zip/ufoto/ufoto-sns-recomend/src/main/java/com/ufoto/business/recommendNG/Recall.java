package com.ufoto.business.recommendNG;

import com.ufoto.dto.RecommendAdvanceRequest;

import java.util.Set;

/**
 * Created by echo on 10/18/18.
 */
public interface Recall {

    /**
     * 返回召回的内容，如果返回内容数量少于minSize,则表示已经词穷
     * 返回内容数量可能大于minSize
     *
     * @param minSize
     * @param recallRequest
     * @return
     */
    Set<String> recall(Integer minSize, RecommendAdvanceRequest recallRequest);

    /**
     * 召回策略是否会一次性返回所有的内容（在请求条件相同的情况下）
     * 即，是否多次请求返回的结果是否是固定的（短时间内）
     *
     * @return
     */
    boolean ifRecallOnlyOnce();

    /**
     * 是否需要Invoker进行ThreadLocal的缓存。
     * 建议ifRecallOnlyOnce为true，并且一次返回内容不会太多导致排序压力过大的置为true
     * 或者业务上不会配置成使用多次的，也不需要返回true
     * （之后还是改成配置的形式代替硬编码好了。。。）
     *
     * @return
     */
    boolean ifNeedThreadLocalCache();
}
