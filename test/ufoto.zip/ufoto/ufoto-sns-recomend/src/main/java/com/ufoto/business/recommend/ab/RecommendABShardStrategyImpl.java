package com.ufoto.business.recommend.ab;

import com.ufoto.business.recommend.RecommendABShardStrategy;
import org.springframework.stereotype.Component;

/**
 * Created by echo on 4/9/18.
 */
@Component
public class RecommendABShardStrategyImpl implements RecommendABShardStrategy {

    private String[] abNames = {"StrategyA_20180529", "StrategyB_ActIn3Day_20180607",
            "StrategyC_Taste_20180607", "StrategyD_MatchIn3Day_20180607"};

    @Override
    public int getAbType(Long uid) {
        int mod = (int) (uid % 10);
//        if(mod == 8 ) return 1;
//        if(mod == 9 ) return 2;
//        if( mod == 0 ) return 3;
        if (mod == 1 || mod == 2 || mod == 3 || mod == 4 || mod == 5) return 2;
        if (mod == 6 || mod == 7 || mod == 8 || mod == 9 || mod == 0) return 3;
        return 0;
    }

    @Override
    public String getAbName(Long uid) {
        int type = getAbType(uid);
        return getAbName(type);
    }

    @Override
    public String getAbName(int type) {
        if (type >= 0 && type < abNames.length) return abNames[type];
        return null;
    }

}
