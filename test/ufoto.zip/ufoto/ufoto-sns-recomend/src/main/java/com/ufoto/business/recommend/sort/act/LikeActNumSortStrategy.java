package com.ufoto.business.recommend.sort.act;

import com.ufoto.annotation.RecommendMetadata;
import com.ufoto.business.recommend.bean.SortParamsBean;
import com.ufoto.business.recommend.sort.BaseNormalSortStrategy;
import com.ufoto.utils.redis.RedisKeyConstant;
import com.ufoto.utils.redis.RedisService;
import org.springframework.stereotype.Component;

import java.nio.charset.StandardCharsets;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

/**
 * Created by echo on 4/8/18.
 */
@RecommendMetadata(
        metadataType = RecommendMetadata.MetadataType.SORT,
        available = true,
        name = "送出like数量排序策略",
        description = "根据用户送出的数量进行排序,基础分数为送出的like数量",
        branch = {RecommendMetadata.Branch.NORMAL}
)
@Component
public class LikeActNumSortStrategy extends BaseNormalSortStrategy {

    private final RedisService redisService;

    public LikeActNumSortStrategy(RedisService redisService) {
        this.redisService = redisService;
    }

    /**
     * 返回用户一共送出的like次数
     */
    @Override
    public Map<String, Double> getScore(List<String> recallUids, SortParamsBean sortParamsBean) {
        final List<Object> objects = redisService.execPipelineForRead(connection -> {
            for (String recallUid : recallUids) {
                connection.sCard((RedisKeyConstant.REDIS_MY_LIKED_SET_KEY_NEW + recallUid).getBytes(StandardCharsets.UTF_8));
            }
            return null;
        });
        Map<String, Double> scoreMap = new HashMap<>();
        final int size = recallUids.size();
        for (int i = 0; i < size; i++) {
            final long likeActNum = (long) objects.get(i);
            scoreMap.put(recallUids.get(i), likeActNum * 1.0);
        }
        return scoreMap;
    }
}
