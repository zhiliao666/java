package com.ufoto.business.recommend.filter;

import com.ufoto.business.recommend.filter.age.AgeFilterStrategy;
import com.ufoto.business.recommend.filter.blackList.BlackListFilter;
import com.ufoto.business.recommend.filter.delete.DeleteUserFilterStrategy;
import com.ufoto.business.recommend.filter.distance.NGDistanceFilterStrategy;
import com.ufoto.business.recommend.filter.gender.GenderFilterStrategy;
import com.ufoto.business.recommend.filter.illegal.IllegalFilterStrategy;
import com.ufoto.business.recommend.filter.me.MeFilterStrategy;
import com.ufoto.business.recommend.filter.nohead.NoHeadFilterStrategy;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;

/**
 * Created by echo on 4/3/18.
 */
@Component
public class LoginFilterStrategy extends CompositeRecommendFilterStrategy {


    @Autowired
    public LoginFilterStrategy(
            IllegalFilterStrategy illegalFilterStrategy,
            GenderFilterStrategy genderFilterStrategy,
            AgeFilterStrategy ageFilterStrategy,
            NGDistanceFilterStrategy distanceFilterStrategy,
            MeFilterStrategy meFilterStrategy,
            NoHeadFilterStrategy noHeadFilterStrategy,
            BlackListFilter blackListFilter,
            DeleteUserFilterStrategy deleteUserFilterStrategy//
    ) {
        this.filterStrategyList.add(meFilterStrategy);
        this.filterStrategyList.add(genderFilterStrategy);
        this.filterStrategyList.add(ageFilterStrategy);
        this.filterStrategyList.add(distanceFilterStrategy);
        this.filterStrategyList.add(illegalFilterStrategy);
        this.filterStrategyList.add(noHeadFilterStrategy);
        this.filterStrategyList.add(blackListFilter);
        this.filterStrategyList.add(deleteUserFilterStrategy);
    }
}
