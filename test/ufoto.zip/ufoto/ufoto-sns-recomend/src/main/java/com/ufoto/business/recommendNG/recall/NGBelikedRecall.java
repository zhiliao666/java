package com.ufoto.business.recommendNG.recall;

import com.google.common.collect.Lists;
import com.ufoto.annotation.RecommendMetadata;
import com.ufoto.business.recommendNG.Recall;
import com.ufoto.config.constant.PropertyConstant;
import com.ufoto.dto.RecommendAdvanceRequest;
import com.ufoto.utils.DirtyCaseUtil;
import com.ufoto.utils.KeyTransitionUtil;
import com.ufoto.utils.redis.RedisKeyConstant;
import com.ufoto.utils.redis.RedisService;
import org.springframework.core.env.Environment;
import org.springframework.stereotype.Component;

import java.util.HashSet;
import java.util.Map;
import java.util.Optional;
import java.util.Set;
import java.util.stream.Collectors;

/**
 * Created by echo on 10/18/18.
 */
@RecommendMetadata(
        metadataType = RecommendMetadata.MetadataType.RECALL,
        available = true,
        name = "like过uid的用户召回策略",
        description = "召回所有like过uid的用户,包括superlike",
        branch = RecommendMetadata.Branch.NORMAL
)
@Component
public class NGBelikedRecall implements Recall {

    private final RedisService redisService;
    private final Environment environment;
    private final Environment env;
    private final DirtyCaseUtil dirtyCaseUtil;

    public NGBelikedRecall(RedisService redisService, Environment environment, Environment env, DirtyCaseUtil dirtyCaseUtil) {
        this.redisService = redisService;
        this.environment = environment;
        this.env = env;
        this.dirtyCaseUtil = dirtyCaseUtil;
    }

    @Override
    public Set<String> recall(Integer minSize, RecommendAdvanceRequest recallRequest) {
        Set<String> result = new HashSet<>();
        final Long uid = recallRequest.getUid();

        Boolean ifNeedScan = environment.getProperty("recommend.recommendNG.recall.NGBelikedRecall.ifNeedScan", Boolean.class, true);

        result.addAll(
                Optional.ofNullable(
                        redisService.sdistinctRandomMembers(RedisKeyConstant.REDIS_BE_LIKED_TEMP_SET_KEY_ + uid,
                                env.getProperty("recommend.beliked.recall.num", Long.class, 100L)))
                        .orElse(new HashSet<>()));
        result.addAll(
                Optional.ofNullable(
                        redisService.sMember(RedisKeyConstant.REDIS_BE_SUPER_LIKED_TEMP_SET_KEY_ + uid, ifNeedScan))
                        .orElse(new HashSet<>()));

        Integer minAge = dirtyCaseUtil.ifChat(recallRequest)
                ? env.getProperty(PropertyConstant.CHAT_RECALL_MIN_NUM, Integer.class, 17)
                : 0;
        Integer startAge = recallRequest.getStartAge() == null || recallRequest.getStartAge() < minAge
                ? minAge : recallRequest.getStartAge();
        Integer endAge = Optional.ofNullable(recallRequest.getEndAge()).orElse(1000);

        Map<String, Integer> ageMap = KeyTransitionUtil.ageMap(redisService, Lists.newArrayList(result));
        result = ageMap.entrySet().stream().filter(entry -> entry.getValue() != null && entry.getValue() >= startAge
                && entry.getValue() <= endAge).map(Map.Entry::getKey).collect(Collectors.toSet());

        return result;
    }

    @Override
    public boolean ifRecallOnlyOnce() {
        return true;
    }

    @Override
    public boolean ifNeedThreadLocalCache() {
        return false;
    }

}
