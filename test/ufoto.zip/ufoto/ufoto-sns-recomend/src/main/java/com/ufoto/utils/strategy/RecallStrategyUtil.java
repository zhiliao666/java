package com.ufoto.utils.strategy;

import com.ufoto.business.recommendNG.Recall;
import com.ufoto.dto.CommonStrategyBean;
import com.ufoto.utils.json.JSONUtil;
import org.springframework.beans.factory.config.AutowireCapableBeanFactory;
import org.springframework.context.ApplicationContext;
import org.springframework.stereotype.Component;

/**
 * <p>
 *
 * </p>
 *
 * @author created by chenzhou at 2018-06-11 10:29
 */
@Component
public class RecallStrategyUtil {

    private final ApplicationContext context;

    public RecallStrategyUtil(ApplicationContext context) {
        this.context = context;
    }

    public Recall ngStrategy(CommonStrategyBean commonStrategyBean) {
        try {
            if (commonStrategyBean == null) throw new NullPointerException("策略bean为空");

            if ("base".equals(commonStrategyBean.getType()))
                return getNGRecall(commonStrategyBean);

            throw new RuntimeException("NG Recall strategy create fail! Wrong type:" + JSONUtil.toJSON(commonStrategyBean));
        } catch (Exception e) {
            throw new RuntimeException(e);
        }
    }


    public Recall getNGRecall(CommonStrategyBean commonStrategyBean) throws Exception {
        String strategy = commonStrategyBean.getStrategy();
        Class<?> aClass = Class.forName(strategy);
        return (Recall) context.getAutowireCapableBeanFactory().createBean(aClass,
                AutowireCapableBeanFactory.AUTOWIRE_BY_TYPE, true);
    }

}
