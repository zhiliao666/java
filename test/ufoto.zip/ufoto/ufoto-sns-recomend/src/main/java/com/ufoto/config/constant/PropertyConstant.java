package com.ufoto.config.constant;

public class PropertyConstant {

    /*
    *来源自chat的最小召回年龄
    */
    public static final String CHAT_RECALL_MIN_NUM = "recommend.chat.recall.minAge";

}
