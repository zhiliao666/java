package com.ufoto.business.usercenter;

import com.ufoto.infrastructrue.statistics.AbstractFallbackFactory;
import org.springframework.stereotype.Component;

/**
 * <p>
 * Author     : Chan
 * CreateDate : 2019-03-19 10:05
 * Description:
 * </p>
 */
@Component
public class UserInfoBusinessFallback extends AbstractFallbackFactory<UserInfoBusiness> {

    private final UserInfoBusinessHystrix userInfoControllerHystrix;

    public UserInfoBusinessFallback(UserInfoBusinessHystrix userInfoControllerHystrix) {
        this.userInfoControllerHystrix = userInfoControllerHystrix;
    }

    @Override
    protected UserInfoBusiness doCreate() {
        return userInfoControllerHystrix;
    }
}
