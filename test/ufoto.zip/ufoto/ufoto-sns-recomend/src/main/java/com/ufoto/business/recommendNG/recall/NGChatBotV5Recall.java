package com.ufoto.business.recommendNG.recall;

import com.ufoto.annotation.RecommendMetadata;
import com.ufoto.business.recommendNG.Recall;
import com.ufoto.constants.ELanguage;
import com.ufoto.dto.RecommendAdvanceRequest;
import com.ufoto.utils.redis.RedisKeyConstant;
import com.ufoto.utils.redis.RedisKeyUtil;
import com.ufoto.utils.redis.RedisService;

import org.springframework.core.env.Environment;
import org.springframework.stereotype.Component;

import java.util.HashSet;
import java.util.Objects;
import java.util.Optional;
import java.util.Set;

/**
 * 聊天机器人 - 给用户分层使用
 * 
 * @author zhangqh
 *
 */
@RecommendMetadata(metadataType = RecommendMetadata.MetadataType.RECALL, available = true, name = "聊天机器人召回策略", description = "可以召回任何没有匹配的机器人，需要运营完善机器人信息", branch = RecommendMetadata.Branch.NORMAL)
@Component
public class NGChatBotV5Recall implements Recall {

	private final RedisService redisService;
	private final Environment env;

	public NGChatBotV5Recall(RedisService redisService,Environment env) {
		this.redisService = redisService;
		this.env = env;
	}

	@Override
	public Set<String> recall(Integer minSize, RecommendAdvanceRequest recallRequest) {
		Integer targetGender = recallRequest.getGender();
		String language = recallRequest.getLanguage();
		
		Integer recallnum = env.getProperty("chatbot.recall.num", Integer.class, 100);
		
		Set<String> resultset = new HashSet<>();
		
		/**
		 * 机器人池子分性别和语言
		 * 如果想看男性用户则从男机器人池子捞取
		 * 想看女则从女机器人池子中捞取
		 * 否则从男女总池子中捞取
		 */
		// 目前机器人只有3种语言pt es en
		if(!Objects.equals(targetGender, 0) && (Objects.equals(language,ELanguage.ES.getType()) 
				|| Objects.equals(language,ELanguage.PT.getType())
				|| Objects.equals(language,ELanguage.EN.getType()) )) {
			resultset = getSetfromRedis(RedisKeyUtil.obtainKey(RedisKeyConstant.REDIS_LANGUAGE_GENDER_CHAT_BOT_V5_UID_SET_KEY,targetGender,language),recallnum);
			// 如果对应的语言拿不到到用户则用英语兜底
			if(resultset.isEmpty()) {
				resultset = getSetfromRedis(RedisKeyUtil.obtainKey(RedisKeyConstant.REDIS_LANGUAGE_GENDER_CHAT_BOT_V5_UID_SET_KEY,targetGender,ELanguage.EN.getType()),recallnum);
			}
			
			return resultset;
		}
		
		// 如果是男女都想要的则走下面逻辑
		resultset = getSetfromRedis(RedisKeyUtil.obtainKey(RedisKeyConstant.REDIS_CHAT_BOT_V5_UID_SET_KEY,language),recallnum);
		
		// 如果对应的语言拿不到到用户则用英语兜底
		if(resultset.isEmpty()) {
			resultset = getSetfromRedis(RedisKeyUtil.obtainKey(RedisKeyConstant.REDIS_CHAT_BOT_V5_UID_SET_KEY,ELanguage.EN.getType()),recallnum);
		}
		return resultset;
	}
	
	private Set<String> getSetfromRedis(String key,Integer recallnum){
		return Optional.ofNullable(
				redisService.sdistinctRandomMembers(key, recallnum))
				.orElse(new HashSet<>());
	}

	@Override
	public boolean ifRecallOnlyOnce() {
		return true;
	}

	@Override
	public boolean ifNeedThreadLocalCache() {
		return false;
	}

}
