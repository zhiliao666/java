package com.ufoto.utils.quartz;

import com.ufoto.utils.ApiResult;
import com.ufoto.utils.quartz.service.QuartzService;
import org.quartz.JobDataMap;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RestController;

/**
 * 任务管理
 */
@RestController
@RequestMapping(value = "/quartz")
public class QuartzController {

    Logger logger = LoggerFactory.getLogger(QuartzController.class);

    @Autowired
    QuartzService quartzService;

    /**
     * 新增定时任务
     *
     * @return
     */
    @RequestMapping(value = "/addJob", method = RequestMethod.GET)
    public String addJob() {
        QuartzTaskInfo info = new QuartzTaskInfo();
        info.setJobName("QuartzDemo");
        info.setJobGroup("testGroup");
        info.setJobDescription("每分钟任务");
        info.setCronExpression("0/5 * * * * ?");
        info.setJobClass("com.ufoto.utils.quartz.QuartzDemo");
        JobDataMap dataMap = new JobDataMap();
        dataMap.put("uid", 123L);
        info.setDataMap(dataMap);
        quartzService.addJob(info);
        return "true";
    }

    /**
     * 修改定时任务
     *
     * @return
     */
    @RequestMapping(value = "/updateJob", method = RequestMethod.GET)
    public String updateJob() {
        QuartzTaskInfo info = new QuartzTaskInfo();
        info.setJobName("QuartzDemo");
        info.setJobGroup("testGroup");
        info.setJobDescription("测试任务修改后22");
        info.setCronExpression("0/1 * * * * ?");
        info.setJobClass("com.ufoto.utils.quartz.QuartzDemo");
        JobDataMap dataMap = new JobDataMap();
        dataMap.put("uid", 345L);
        info.setDataMap(dataMap);
        quartzService.edit(info);
        return "true";
    }

    /**
     * 删除定时任务
     *
     * @return
     */
    @RequestMapping(value = "/deleteJob", method = RequestMethod.GET)
    public String deleteJob(String jobName, String groupName) {
        quartzService.delete(jobName, groupName);
        return "true";
    }

    /**
     * 暂停定时任务
     *
     * @return
     */
    @RequestMapping(value = "/pauseJob", method = RequestMethod.GET)
    public String pauseJob() {
        quartzService.pause("QuartzDemo", "testGroup");
        return "true";
    }

    /**
     * 重新开启定时任务
     *
     * @return
     */
    @RequestMapping(value = "/resumeJob", method = RequestMethod.GET)
    public String resumeJob() {
        quartzService.resume("QuartzDemo", "testGroup");
        return "true";
    }

    @RequestMapping("/pauseEditResumeJob")
    public String pauseEditResumeJob(String cron) {
        pauseJob();
        updateJob();
        return "true";
    }

    @RequestMapping("/listJobs")
    public ApiResult listJobs() {
        return new ApiResult<>().setResult(quartzService.list());
    }
}
