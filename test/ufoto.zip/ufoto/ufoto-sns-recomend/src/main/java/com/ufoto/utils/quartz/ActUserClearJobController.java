package com.ufoto.utils.quartz;

import com.ufoto.utils.quartz.service.QuartzService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.core.env.Environment;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

/**
 * <p>
 * Author     : Chan
 * CreateDate : 2019-08-12 14:11
 * Description:
 * </p>
 */
@RequestMapping("/actUserJob")
@RestController
public class ActUserClearJobController extends BaseJobController {

    @Autowired
    public ActUserClearJobController(QuartzService quartzService, Environment env) {
        super(quartzService,
                QuartzHelper.GROUP_ACT_USER_CLEAR,
                QuartzHelper.JOB_ACT_USER_CLEAR,
                env.getProperty("cron.act.user.clear", String.class, "0 0/5 * * * ?"),
                ActUserClearJob.class,
                "清理24h活跃用户的相关数据");
    }

}
