package com.ufoto.dto.sns;

import java.sql.Date;
import java.util.List;

/**
 * Created by echo on 12/26/17.
 */
public class SnsRecommendDto {

    private String userName;
    private Long uid;
    private Byte gender;
    private String description;
    private Long birthTime;
    private Integer distance;
    private String headImg;
    private Integer headImgNum;
    private Byte likeState;
    private String location;
    private Integer afterLastActTime;
    private Integer isDelete;
    private String source;
    private Integer age;
    private String avatar;
    private List<FeedImgInfo> feeds;//feed 流最新三张

    public List<FeedImgInfo> getFeeds() {
        return feeds;
    }

    public void setFeeds(List<FeedImgInfo> feeds) {
        this.feeds = feeds;
    }

    public String getAvatar() {
        return avatar;
    }

    public void setAvatar(String avatar) {
        this.avatar = avatar;
    }

    public Integer getAge() {
        return age;
    }

    public void setAge(Integer age) {
        this.age = age;
    }

    public String getUserName() {
        return userName;
    }

    public void setUserName(String userName) {
        this.userName = userName;
    }

    public Long getUid() {
        return uid;
    }

    public void setUid(Long uid) {
        this.uid = uid;
    }

    public Byte getGender() {
        return gender;
    }

    public void setGender(Byte gender) {
        this.gender = gender;
    }

    public String getDescription() {
        return description;
    }

    public void setDescription(String description) {
        this.description = description;
    }

    public Long getBirthTime() {
        return (birthTime);
    }

    public void setBirthTime(Date birthTime) {
        if (birthTime != null) {
            this.birthTime = birthTime.getTime();
        }
    }

    public Integer getDistance() {
        return distance;
    }

    public void setDistance(Integer distance) {
        this.distance = distance;
    }

    public String getHeadImg() {
        return headImg;
    }

    public void setHeadImg(String headImg) {
        this.headImg = headImg;
    }

    public Integer getHeadImgNum() {
        return headImgNum;
    }

    public void setHeadImgNum(Integer headImgNum) {
        this.headImgNum = headImgNum;
    }

    public Byte getLikeState() {
        return likeState;
    }

    public void setLikeState(Byte likeState) {
        this.likeState = likeState;
    }

    public String getLocation() {
        return location;
    }

    public void setLocation(String location) {
        this.location = location;
    }

    public Integer getAfterLastActTime() {
        return afterLastActTime;
    }

    public void setAfterLastActTime(Integer afterLastActTime) {
        this.afterLastActTime = afterLastActTime;
    }

    public String getSource() {
        return source;
    }

    public void setSource(String source) {
        this.source = source;
    }

    public Integer getIsDelete() {
        return isDelete;
    }

    public void setIsDelete(Integer isDelete) {
        this.isDelete = isDelete;
    }
}
