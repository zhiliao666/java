package com.ufoto.config.mysql;

import com.zaxxer.hikari.HikariConfig;
import org.springframework.boot.context.properties.ConfigurationProperties;
import org.springframework.context.annotation.Configuration;

@ConfigurationProperties(prefix = "spring.datasource.hikari")
@Configuration
public class Hikari extends HikariConfig {

}
