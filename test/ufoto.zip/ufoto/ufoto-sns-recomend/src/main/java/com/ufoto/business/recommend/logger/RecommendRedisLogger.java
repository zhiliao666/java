package com.ufoto.business.recommend.logger;

import com.google.common.collect.Maps;
import com.ufoto.log.layout.AppMdcEncoderLayout;
import com.ufoto.logging.proxy.UfotoLogFactory;
import com.ufoto.utils.DateUtil;
import com.ufoto.utils.json.JSONUtil;
import org.slf4j.Logger;
import org.springframework.stereotype.Component;

import java.util.Map;

/**
 * Created by echo on 3/30/18.
 */
@Component
public class RecommendRedisLogger implements RecommendLogger {

    private final static Logger recommendLogger = UfotoLogFactory.getLogger("recommend.score")
            .enableCustomStatus()
            .withFileName("recommend/recommend")
            .withLayout(new AppMdcEncoderLayout(null))
            .build();

    @Override
    public void loggingSimpleScore(Long requestUid, Long uid, Integer likeType) {
        Map<String, String> scoreDetail = Maps.newHashMap();
        scoreDetail.put("TIME_STAMP", DateUtil.getCurrentSecondIntValue().toString());
        scoreDetail.put("REQUEST_UID", requestUid.toString());
        scoreDetail.put("UID", uid.toString());
        scoreDetail.put("LIKE_TYPE", likeType.toString());

        String resultJsonStr = JSONUtil.toJSON(scoreDetail);
        recommendLogger.info(resultJsonStr);
    }
}
