package com.ufoto.business.recommend.filter.distance;

import com.google.common.collect.Lists;
import com.google.common.collect.Sets;
import com.ufoto.annotation.RecommendMetadata;
import com.ufoto.business.recommend.RecommendFilterStrategy;
import com.ufoto.dto.RecommendAdvanceRequest;
import com.ufoto.utils.RecommendUtil;
import com.ufoto.utils.geo.GeoUtil;
import com.ufoto.utils.json.JSONUtil;
import com.ufoto.utils.redis.RedisKeyConstant;
import com.ufoto.utils.redis.RedisKeyUtil;
import com.ufoto.utils.redis.RedisService;
import org.springframework.stereotype.Component;
import org.springframework.util.CollectionUtils;

import java.nio.charset.StandardCharsets;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.List;
import java.util.Set;

/**
 * <p>
 * 距离过滤
 * </p>
 *
 * @author created by chenzhou at 2018-05-11 15:29
 */
@RecommendMetadata(
        metadataType = RecommendMetadata.MetadataType.FILTER,
        available = true,
        name = "距离过滤策略",
        description = "过滤符合用户设置距离条件范围内的用户,同时保留supurlike过当前用户的用户.距离条件不设置默认不过滤",
        branch = {
                RecommendMetadata.Branch.NORMAL,
                RecommendMetadata.Branch.DEFAULT,
                RecommendMetadata.Branch.GIFT,
                RecommendMetadata.Branch.High_Risk
        }
)
@Component
public class NGDistanceFilterStrategy implements RecommendFilterStrategy {

    private final RedisService redisService;

    public NGDistanceFilterStrategy(RedisService redisService) {
        this.redisService = redisService;
    }

    @Override
    public Set<String> filter(Set<String> recallSet, List<String> resultList, RecommendAdvanceRequest filterRequest) {
        if (CollectionUtils.isEmpty(recallSet)) {
            return recallSet;
        }
        Double targetDistance = RecommendUtil.distanceFilterVersion(filterRequest.getApiVersion(), filterRequest.getDistance());
        if (targetDistance == null || targetDistance == 0 || targetDistance >= 100) {
            return recallSet;
        }
        Long uid = filterRequest.getUid();
        Double latitude = filterRequest.getLatitude();
        Double longitude = filterRequest.getLongitude();

        if (latitude == null || longitude == null) { //如果请求当中没有带上经纬度,尝试获取用户历史的地理位置信息
            if (uid == null) return recallSet;
            try {
                List<String> lonAndLatList = redisService.hmget(
                        RedisKeyUtil.obtainKey(RedisKeyConstant.REDIS_USER_HASH_KEY, uid),
                        Arrays.asList(RedisKeyConstant.REDIS_USER_HASH_LONGITUDE, RedisKeyConstant.REDIS_USER_HASH_LATITUDE));
                longitude = Double.valueOf(lonAndLatList.get(0));
                latitude = Double.valueOf(lonAndLatList.get(1));
            } catch (Exception e) {//获取用户经纬度失败
                return recallSet;
            }
        }

        ArrayList<String> idList = Lists.newArrayList(recallSet);
        //获取用户被super like的用户列表
        //获取用户的经纬度
        final List<Object> objects = redisService.execPipelineForRead(connection -> {
            for (String recallUid : idList) {
                connection.sIsMember(((RedisKeyConstant.REDIS_BE_SUPER_LIKED_TEMP_SET_KEY_ + uid)).getBytes(StandardCharsets.UTF_8),
                        RedisKeyUtil.serializeUid(recallUid).getBytes(StandardCharsets.UTF_8));
            }
            for (String recallUid : idList) {
                connection.hMGet(RedisKeyUtil.obtainKey(RedisKeyConstant.REDIS_USER_HASH_KEY, Long.valueOf(recallUid)).getBytes(StandardCharsets.UTF_8),
                        RedisKeyConstant.REDIS_USER_HASH_LONGITUDE.getBytes(StandardCharsets.UTF_8),
                        RedisKeyConstant.REDIS_USER_HASH_LATITUDE.getBytes(StandardCharsets.UTF_8));
            }
            return null;
        });


        //获取用户被super like的用户列表
        Set<String> superLikedMeUidSet = Sets.newHashSet();
        for (int i = 0; i < idList.size(); i++) {
            final Object superLike = objects.get(i);
            Boolean isSuperLike = superLike == null ? Boolean.FALSE : (Boolean) superLike;
            if (isSuperLike) superLikedMeUidSet.add(idList.get(i));
        }

        double[] locationBound = GeoUtil.getLonLatBound(targetDistance, longitude, latitude);
        if (locationBound.length != 4) throw new RuntimeException(
                "GeoUtil.getLonLatBound return error!targetDist:" + targetDistance
                        + ", longitude:" + longitude
                        + ", latitude:" + latitude
                        + ",bound:" + JSONUtil.toJSON(locationBound));

        Set<String> inDistUidSet = Sets.newHashSet();
        for (int i = 0; i < idList.size(); i++) {
            final List<Double> location = (List) objects.get(idList.size() + i);
            Double lon = location.get(0);
            Double lat = location.get(1);
            if (lon == null || lat == null) continue;
            if (GeoUtil.ifInBound(locationBound, lon, lat)) inDistUidSet.add(idList.get(i));
        }

        inDistUidSet.addAll(superLikedMeUidSet);
        return inDistUidSet;
    }
}
