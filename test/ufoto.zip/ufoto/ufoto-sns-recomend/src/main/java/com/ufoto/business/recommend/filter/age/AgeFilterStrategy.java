package com.ufoto.business.recommend.filter.age;

import com.google.common.collect.Lists;
import com.ufoto.annotation.RecommendMetadata;
import com.ufoto.business.recommend.RecommendFilterStrategy;
import com.ufoto.dto.RecommendAdvanceRequest;
import com.ufoto.utils.CommonUtil;
import com.ufoto.utils.KeyTransitionUtil;
import com.ufoto.utils.RecommendUtil;
import com.ufoto.utils.json.JSONUtil;
import com.ufoto.utils.redis.RedisKeyConstant;
import com.ufoto.utils.redis.RedisKeyUtil;
import com.ufoto.utils.redis.RedisService;
import lombok.extern.slf4j.Slf4j;
import org.springframework.stereotype.Component;
import org.springframework.util.CollectionUtils;

import java.nio.charset.StandardCharsets;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.HashSet;
import java.util.List;
import java.util.Map;
import java.util.Set;

/**
 * <p>
 * 年龄过滤策略
 * </p>
 *
 * @author created by chenzhou at 2018-05-11 13:52
 */
@Slf4j
@RecommendMetadata(
        metadataType = RecommendMetadata.MetadataType.FILTER,
        available = true,
        name = "年龄过滤策略",
        description = "根据年龄条件过滤,同时并保留superlike过当前用户的用户.不设置年龄条件默认不过滤",
        branch = {
                RecommendMetadata.Branch.NORMAL,
                RecommendMetadata.Branch.DEFAULT,
                RecommendMetadata.Branch.GIFT,
                RecommendMetadata.Branch.High_Risk
        }
)
@Component
public class AgeFilterStrategy implements RecommendFilterStrategy {

    private final RedisService redisService;

    public AgeFilterStrategy(RedisService redisService) {
        this.redisService = redisService;
    }

    @Override
    public Set<String> filter(Set<String> recallSet, List<String> resultList, RecommendAdvanceRequest filterRequest) {
        if (CollectionUtils.isEmpty(recallSet)) {
            return recallSet;
        }

        Integer startAge = filterRequest.getStartAge();
        Integer endAge = filterRequest.getEndAge();

        final Map<String, Integer> filterVersionMap = RecommendUtil.ageFilterVersion(filterRequest.getApiVersion(), startAge, endAge);

        if (filterVersionMap.get("startAge") == null && filterVersionMap.get("endAge") == null) {
            return recallSet;
        }

        ArrayList<String> idList = Lists.newArrayList(recallSet);
        final Long uid = filterRequest.getUid();
        //获取用户被super like的用户列表
        // TODO 是否可以考虑把super全部拿出来，然后与召回结果交集从而减少redis的执行次数
        final List objects = redisService.execPipelineForRead(connection -> {
            for (String recallUid : idList) {
                connection.sIsMember(((RedisKeyConstant.REDIS_BE_SUPER_LIKED_TEMP_SET_KEY_ + uid)).getBytes(StandardCharsets.UTF_8),
                        RedisKeyUtil.serializeUid(recallUid).getBytes(StandardCharsets.UTF_8));
            }
            return null;
        });

        Map<String, Boolean> superLikeMap = new HashMap<>();
        for (int i = 0; i < idList.size(); i++) {
            final Object superLike = objects.get(i);
            Boolean isSuperLike = superLike == null ? Boolean.FALSE : (Boolean) superLike;
            superLikeMap.put(idList.get(i), isSuperLike);
        }

        log.debug("superLikeMap:{}", JSONUtil.toJSON(superLikeMap));
        //批量获取用户的生日
        Map<String, Integer> ageMap = KeyTransitionUtil.ageMap(redisService, idList);
        log.debug("ageMap:{}", JSONUtil.toJSON(ageMap));
        for (int i = 0; i < idList.size(); i++) {
            String recallId = idList.get(i);
            final Boolean isSuperLike = superLikeMap.get(recallId);
            final boolean isAge = CommonUtil.judgeAge(ageMap.get(recallId), startAge, endAge);
            if (!isSuperLike && !isAge) {
                idList.remove(i);
                i--;
            }
        }
        return new HashSet<>(idList);
    }
}
