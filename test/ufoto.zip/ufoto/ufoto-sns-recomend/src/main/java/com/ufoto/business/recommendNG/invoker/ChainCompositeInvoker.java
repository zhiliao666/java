package com.ufoto.business.recommendNG.invoker;

import com.google.common.collect.Lists;
import com.google.common.collect.Sets;
import com.ufoto.business.recommendNG.Invoker;
import com.ufoto.dto.RecommendAdvanceRequest;

import java.util.List;
import java.util.Set;
import java.util.stream.Collectors;

/**
 * Created by echo on 10/17/18.
 */
public class ChainCompositeInvoker implements Invoker {

    //todo:test

    private List<Invoker> children;

    public ChainCompositeInvoker(List<Invoker> children) {
        this.children = children;
    }


    @Override
    public List<String> invoke(Integer minSize, RecommendAdvanceRequest recallRequest, Set<String> invokedUidSet) {
        Integer needSize = minSize;
        List<String> result = Lists.newLinkedList();
        Set<String> tempRecalledUidSet = Sets.newHashSet(invokedUidSet);
        for (Invoker invoker : children) {
            List<String> uidList = invoker.invoke(needSize, recallRequest, tempRecalledUidSet);
            result.addAll(uidList);
            tempRecalledUidSet.addAll(uidList);
            if (uidList.size() >= needSize) break;
            //todo:击穿日志
            needSize -= uidList.size();
        }
        invokerLog(minSize, recallRequest, result, "chain");
        return result;
    }

    @Override
    public void cleanThreadLocalCache() {
        children.forEach(Invoker::cleanThreadLocalCache);
    }

    public List<Invoker> getChildren() {
        return children;
    }

    @Override
    public String toString() {
        return "Chain:{"
                + children.stream()
                .map(Invoker::toString)
                .collect(Collectors.joining("->"))
                + "}";
    }
}
