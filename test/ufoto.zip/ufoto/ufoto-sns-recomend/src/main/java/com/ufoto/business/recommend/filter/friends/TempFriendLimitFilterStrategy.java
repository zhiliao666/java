package com.ufoto.business.recommend.filter.friends;

import com.github.benmanes.caffeine.cache.Caffeine;
import com.github.benmanes.caffeine.cache.LoadingCache;
import com.google.common.collect.Lists;
import com.google.common.collect.Sets;
import com.ufoto.annotation.RecommendMetadata;
import com.ufoto.business.recommend.RecommendFilterStrategy;
import com.ufoto.business.recommend.filter.FilterUtil;
import com.ufoto.dto.RecommendAdvanceRequest;
import com.ufoto.utils.CommonUtil;
import com.ufoto.utils.DateUtil;
import com.ufoto.utils.redis.RedisKeyConstant;
import com.ufoto.utils.redis.RedisKeyUtil;
import com.ufoto.utils.redis.RedisService;
import com.ufoto.utils.redis.RedisServiceObjService;
import lombok.extern.slf4j.Slf4j;
import org.springframework.core.env.Environment;
import org.springframework.stereotype.Component;

import java.time.Duration;
import java.util.List;
import java.util.Map;
import java.util.Set;

/**
 * 
 * 临时好友当天上限过滤
 * @author zhangqh  
 * @date Apr 13, 2020 3:44:07 PM  
 * @version 1.0
 */
@Slf4j
@RecommendMetadata(
        metadataType = RecommendMetadata.MetadataType.FILTER,
        available = true,
        updateCache = false,
        name = "临时好友当天上限过滤",
        description = "wink推荐流程中过滤当天临时好友匹配超过限制的人",
        branch = {
                RecommendMetadata.Branch.DEFAULT,
                RecommendMetadata.Branch.WINK
        }
)
@Component
public class TempFriendLimitFilterStrategy implements RecommendFilterStrategy {

    private final RedisService redisService;
    private final RedisServiceObjService redisServiceObjService;
    private final Environment env;
    private final FilterUtil filterUtil;
    
    private final LoadingCache<String,Set<String>> noFilterCache = Caffeine.newBuilder()
            .recordStats()
            .maximumSize(5)
            .expireAfterWrite(Duration.ofDays(365)).build(key -> initNoFilter());
    
    public Set<String> initNoFilter() {
        log.debug("noFilterCache from redis");
        return redisService.sMember(RedisKeyConstant.REDIS_NOFILTER_TEMPFRIEND_LIMIT__SET_KEY);
    }

    public TempFriendLimitFilterStrategy(RedisService redisService,
                                       RedisServiceObjService redisServiceObjService,
                                       Environment env,
                                       FilterUtil filterUtil) {
        this.redisService = redisService;
        this.redisServiceObjService = redisServiceObjService;
        this.env = env;
        this.filterUtil = filterUtil;
    }
    
    @Override
    public Set<String> filter(Set<String> recallSet, List<String> resultList, RecommendAdvanceRequest filterRequest) {
    	 int tempfriendLimit = env.getProperty("recommend.filter.tempfriend.limit", Integer.class, 20);
    	 Set<String> nofilterSet = noFilterCache.get(RedisKeyConstant.REDIS_NOFILTER_TEMPFRIEND_LIMIT__SET_KEY);
    	 log.debug("nofilterSet :{}",nofilterSet);
    	 String currentDay = DateUtil.getCurrentDateStr("yyyyMMdd");
         final String tempfriendDailyHash = RedisKeyUtil.obtainKey(RedisKeyConstant.REDIS_TEMPFRIEND_DAILY_HASH, currentDay);
         List<String> partUids = Lists.newArrayList(recallSet);
         final Map<String, Integer> partMap = redisServiceObjService.hmgetWithInteger(tempfriendDailyHash, partUids, 0);
         Set<String> result = Sets.newHashSet();
         for (Map.Entry<String, Integer> entry : partMap.entrySet()) {
             if (entry.getValue() >= tempfriendLimit && !nofilterSet.contains(entry.getKey())) {
                 result.add(entry.getKey());
             }
         }
         recallSet.removeAll(result);
        return recallSet;
    }
    
    public void refresh() {
    	noFilterCache.refresh(RedisKeyConstant.REDIS_NOFILTER_TEMPFRIEND_LIMIT__SET_KEY);
    }

}
