package com.ufoto.entity;

import com.ufoto.entity.base.BaseUfotoUserHead;

public class UfotoUserHead extends BaseUfotoUserHead {

    private static final long serialVersionUID = 1L;
    private Integer status;

    public Integer getStatus() {
        return status;
    }

    public void setStatus(Integer status) {
        this.status = status;
    }
}
