package com.ufoto.config.disruptor.consumer;

import com.ufoto.config.disruptor.constants.ConsumerId;
import com.ufoto.config.disruptor.constants.EventType;
import com.ufoto.config.disruptor.event.AsyncEvent;
import com.ufoto.lmax.consumer.Consumer;
import org.springframework.stereotype.Component;

/**
 * <p>
 * Description:
 * 已看过的列表加入bloom
 * 下一个事件 {@link EventType#RECOMMEND_CALCULATE_PREPARE_TRIGGER}
 * </p>
 *
 * @author Chan
 * @date 2019/12/21 17:49
 */
@Component
public class RecommendCalculateBloomConsumer extends AsyncConsumer {
    public RecommendCalculateBloomConsumer() {
        super(ConsumerId.CONSUMER_RECOMMEND_CALCULATE_BLOOM);
    }

    @Override
    public void consume(AsyncEvent event) {
        super.consume(event);
        event.setEventType(EventType.RECOMMEND_CALCULATE_PREPARE_TRIGGER);
    }
}
