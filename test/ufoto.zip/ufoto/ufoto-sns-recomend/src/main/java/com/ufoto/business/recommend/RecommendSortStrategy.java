package com.ufoto.business.recommend;

import com.ufoto.business.recommend.bean.SortParamsBean;

import java.util.Set;

/**
 * Created by echo on 4/9/18.
 */
public interface RecommendSortStrategy {

    /**
     * 新版排序策略：20180402
     *
     * @param recallSet 召回的用户ID集合
     * @return
     */
    String[] sort(Set<String> recallSet, SortParamsBean sortParamsBean);

}
