package com.ufoto.business.recommend.bean;

import lombok.Data;

/**
 * <p>
 *
 * </p>
 *
 * @author created by chenzhou at 2018-08-02 17:49
 */
@Data
public class SortParamsBean {
    private Long uid;
    private Double longitude;
    private Double latitude;
    private String countryCode;
    private Integer page;
    private Integer pageSize;
    //性取向
    private Integer gender;
}
