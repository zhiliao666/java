package com.ufoto.dto;

import lombok.Data;

import java.io.Serializable;
import java.util.Map;

/**
 * <p>
 * Author     : Chan
 * CreateDate : 2018/11/10 10:41
 * Description:
 * </p>
 */
@Data
public class AppSwitchDto implements Serializable {
    private String funcSwitch;
    private Integer status;
    private Map<String, Object> config;
}
