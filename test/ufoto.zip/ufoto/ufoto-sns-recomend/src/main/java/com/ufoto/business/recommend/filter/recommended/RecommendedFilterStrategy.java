package com.ufoto.business.recommend.filter.recommended;

import com.google.common.collect.Sets;
import com.ufoto.annotation.RecommendMetadata;
import com.ufoto.bloom.RecommendedRecommendBloomFilter;
import com.ufoto.business.recommend.RecommendFilterStrategy;
import com.ufoto.dto.RecommendAdvanceRequest;
import com.ufoto.utils.redis.RedisKeyConstant;
import com.ufoto.utils.redis.RedisService;
import lombok.extern.slf4j.Slf4j;
import org.springframework.stereotype.Component;
import org.springframework.util.CollectionUtils;

import java.util.HashSet;
import java.util.List;
import java.util.Set;

/**
 * Created by echo on 4/3/18.
 */
@Slf4j
@RecommendMetadata(
        metadataType = RecommendMetadata.MetadataType.FILTER,
        available = true,
        name = "推荐过的用户过滤策略",
        description = "推荐过的用户的范围是指推荐列表中出现并且用户与之有过交互,保留like过当前用户的用户",
        branch = {
                RecommendMetadata.Branch.NORMAL,
                RecommendMetadata.Branch.DEFAULT,
                RecommendMetadata.Branch.GIFT,
                RecommendMetadata.Branch.High_Risk,
                RecommendMetadata.Branch.USERLAYER,
                RecommendMetadata.Branch.WINK
        }
)
@Component
public class RecommendedFilterStrategy implements RecommendFilterStrategy {

    private final RedisService redisService;
    private final RecommendedRecommendBloomFilter recommendedRecommendBloomFilter;

    public RecommendedFilterStrategy(RedisService redisService,
                                     RecommendedRecommendBloomFilter recommendedRecommendBloomFilter) {
        this.redisService = redisService;
        this.recommendedRecommendBloomFilter = recommendedRecommendBloomFilter;
    }

    @Override
    public Set<String> filter(Set<String> recallSet, List<String> resultList, RecommendAdvanceRequest filterRequest) {
        if (CollectionUtils.isEmpty(recallSet)) {
            return Sets.newHashSet();
        }
        log.debug("Filter Input Size:" + recallSet.size());
        return filterByBF(recallSet, filterRequest);
    }

    private Set<String> filterByBF(Set<String> recallSet, RecommendAdvanceRequest filterRequest) {
        Long uid = filterRequest.getUid();
        if (uid == null) return recallSet;

        Set<String> result = new HashSet<>(recallSet);
        Set<String> beLikedTmpSet = redisService.setIntersection(RedisKeyConstant.REDIS_BE_LIKED_TEMP_SET_KEY_ + uid, result);
        result = recommendedRecommendBloomFilter.filter(uid, result);
        result.addAll(beLikedTmpSet);
        return result;
    }
}
