package com.ufoto.business.elasticsearch.dto;

import lombok.Builder;
import lombok.Data;

import java.util.List;

/**
 * @author luozq
 * @date 2019/8/23 15:26
 */
@Data
@Builder
public class FriendSearchDto {
    /**
     * uid
     */
    private Long uid;
    /**
     * friend id list, may contains id that is not a friend
     */
    private List<Long> friendIdList;
}
