package com.ufoto.business.usercenter.dto;

import lombok.Data;

import java.io.Serializable;
import java.util.List;

@Data
public class UserHeadConditionDto implements Serializable {
    private List<Long> uids;
    private List<Integer> states;
    private Integer num;//第几张图
}