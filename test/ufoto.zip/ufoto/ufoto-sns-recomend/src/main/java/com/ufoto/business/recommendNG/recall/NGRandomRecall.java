package com.ufoto.business.recommendNG.recall;

import com.ufoto.annotation.RecommendMetadata;
import com.ufoto.business.recommendNG.Recall;
import com.ufoto.dto.RecommendAdvanceRequest;
import org.springframework.stereotype.Component;

import java.util.Set;

/**
 * 这个召回类不做任何处理，只是为了这个类可以被实例化而存在
 * <p>
 * Created by echo on 10/18/18.
 */
@RecommendMetadata(
        metadataType = RecommendMetadata.MetadataType.RECALL,
        available = true,
        name = "随机召回策略",
        description = "不做召回内容处理,召回集从reagent中随机获取",
        branch = {RecommendMetadata.Branch.NORMAL, RecommendMetadata.Branch.DEFAULT}
)
@Component
public class NGRandomRecall implements Recall {

    @Override
    public Set<String> recall(Integer minSize, RecommendAdvanceRequest recallRequest) {
        throw new RuntimeException("NGRandomRecall should never be called! Method: recall()");
    }

    @Override
    public boolean ifRecallOnlyOnce() {
        return false;
    }

    @Override
    public boolean ifNeedThreadLocalCache() {
        return false;
    }

}
