package com.ufoto.constants;

import org.apache.commons.lang3.StringUtils;

/**
 * <p>
 *
 * </p>
 *
 * @author created by chenzhou at 2018-07-20 13:26
 */
public enum EApiVersion {
    v1,//age filter上限和下限发生变化
    v2,//card区分版本--兼容v1
    v3;//新增feed流 兼容 v1 v2

    public static boolean ifHandleCard(String apiVersion) {
        return StringUtils.isNotBlank(apiVersion)
                && (apiVersion.equalsIgnoreCase(v2.name()) || apiVersion.equalsIgnoreCase(v3.name()));
    }

    public static boolean ifHandleAge(String apiVersion) {
        return StringUtils.isNotBlank(apiVersion) && (EApiVersion.v1.name().equalsIgnoreCase(apiVersion)
                || EApiVersion.v2.name().equalsIgnoreCase(apiVersion)
                || EApiVersion.v3.name().equalsIgnoreCase(apiVersion));
    }

    public static boolean ifHandleDistance(String apiVersion) {
        return StringUtils.isNotBlank(apiVersion) && (EApiVersion.v1.name().equalsIgnoreCase(apiVersion)
                || EApiVersion.v2.name().equalsIgnoreCase(apiVersion)
                || EApiVersion.v3.name().equalsIgnoreCase(apiVersion));
    }

}
