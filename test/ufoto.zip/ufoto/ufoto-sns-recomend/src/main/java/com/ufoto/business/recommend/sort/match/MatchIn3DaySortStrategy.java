package com.ufoto.business.recommend.sort.match;

import com.google.common.collect.Lists;
import com.ufoto.annotation.RecommendMetadata;
import com.ufoto.business.recommend.bean.SortParamsBean;
import com.ufoto.business.recommend.sort.BaseNormalSortStrategy;
import com.ufoto.utils.DateUtil;
import com.ufoto.utils.redis.RedisKeyConstant;
import com.ufoto.utils.redis.RedisKeyUtil;
import com.ufoto.utils.redis.RedisService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;

import java.nio.charset.StandardCharsets;
import java.util.Arrays;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.stream.Collectors;

/**
 * Created by echo on 4/8/18.
 */
@RecommendMetadata(
        metadataType = RecommendMetadata.MetadataType.SORT,
        name = "三天内匹配过的数量排序策略",
        description = "基础分数为用户三天内匹配数量的总和,如若没有则为0,已废弃"
)
@Component
@Deprecated
public class MatchIn3DaySortStrategy extends BaseNormalSortStrategy {

    @Autowired
    private RedisService redisService;

    @Override
    public Map<String, Double> getScore(List<String> recallUids, SortParamsBean sortParamsBean) {
        String format = "yyyyMMdd";
        List<String> dateStrList = Arrays.asList(
                DateUtil.getOffsetDateString(0, null, null, format),
                DateUtil.getOffsetDateString(-1, null, null, format),
                DateUtil.getOffsetDateString(-2, null, null, format)
        );

        final List<Object> objects = redisService.execPipelineForRead(connection -> {
            for (String recallUid : recallUids) {
                for (String dateStr : dateStrList) {
                    connection.zScore((RedisKeyConstant.REDIS_DAILY_MATCH_NUM_ZSET_KEY_ + dateStr).getBytes(StandardCharsets.UTF_8),
                            RedisKeyUtil.serializeUid(recallUid).getBytes(StandardCharsets.UTF_8));
                }
            }
            return null;
        });

        //每三个为一组 同一个用户
        final List<List<Object>> partitions = Lists.partition(objects, 3);
        final List<Double> matchNumIn3Days = partitions.parallelStream().map(part -> part.stream().mapToDouble(d -> d == null ? 0d : (double) d).sum()).collect(Collectors.toList());
        final int size = recallUids.size();
        Map<String, Double> scoreMap = new HashMap<>();
        for (int i = 0; i < size; i++) {
            final String recallUid = recallUids.get(i);
            final Double matchNumIn3Day = matchNumIn3Days.get(i);
            scoreMap.put(recallUid, matchNumIn3Day);
        }
        return scoreMap;
    }
}
