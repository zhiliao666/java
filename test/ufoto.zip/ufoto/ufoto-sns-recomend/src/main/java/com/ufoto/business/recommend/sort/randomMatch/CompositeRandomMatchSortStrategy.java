package com.ufoto.business.recommend.sort.randomMatch;

import com.google.common.collect.Maps;
import com.ufoto.entity.UfotoUserChatActivity;

import java.util.HashMap;
import java.util.LinkedList;
import java.util.List;
import java.util.Map;
import java.util.stream.Collectors;

/**
 * <p>
 *
 * </p>
 *
 * @author created by chenzhou at 2018-08-02 18:50
 */
public class CompositeRandomMatchSortStrategy implements SpecifyRandomMatchSortStrategy, RandomMatchSortStrategy {

    protected Map<SpecifyRandomMatchSortStrategy, Double> sortStrategyWeightMap = new HashMap<>();

    @Override
    public List<Long> sort(List<UfotoUserChatActivity> activities, UfotoUserChatActivity currentUser) {
        Map<Long, Double> uidScoreMap = Maps.newHashMap();
        for (UfotoUserChatActivity activity : activities) {
            uidScoreMap.put(activity.getUId(), 0D);
        }
        for (Map.Entry<SpecifyRandomMatchSortStrategy, Double> entry : sortStrategyWeightMap.entrySet()) {
            uidScoreMap = entry.getKey().addScoreBatch(uidScoreMap, entry.getValue(), activities, currentUser);
        }
        return getSortedMapList(uidScoreMap).parallelStream().map(Map.Entry::getKey).collect(Collectors.toList());
    }

    private List<Map.Entry<Long, Double>> getSortedMapList(Map<Long, Double> finalScoreMap) {
        List<Map.Entry<Long, Double>> list = new LinkedList<>(finalScoreMap.entrySet());
        list.sort((o1, o2) -> -1 * (o1.getValue()).compareTo(o2.getValue()));
        return list;
    }

    @Override
    public Map<Long, Double> addScoreBatch(Map<Long, Double> uidScoreMap, Double weight, List<UfotoUserChatActivity> activities, UfotoUserChatActivity currentUser) {
        for (Map.Entry<SpecifyRandomMatchSortStrategy, Double> entry : sortStrategyWeightMap.entrySet()) {
            uidScoreMap = entry.getKey().addScoreBatch(uidScoreMap, entry.getValue(), activities, currentUser);
        }
        return uidScoreMap;
    }

    @Override
    public Map<Long, Double> getScore(List<UfotoUserChatActivity> activities, UfotoUserChatActivity currentUser) {
        Map<Long, Double> scoreResultMap = new HashMap<>();
        for (Map.Entry<SpecifyRandomMatchSortStrategy, Double> entry : sortStrategyWeightMap.entrySet()) {
            final Map<Long, Double> scoreMap = entry.getKey().getScore(activities, currentUser);
            scoreMap.forEach((recallId, score) -> scoreResultMap.merge(recallId, score * entry.getValue(), (a, b) -> a + b));
        }
        return scoreResultMap;
    }
}
