package com.ufoto.constants;

/**
 * <p>
 * Author     : Chan
 * CreateDate : 2018/9/29 16:35
 * Description:
 * </p>
 */
public enum ERecommendUserType {
    USER(1),
    CARD(2),
    GIFT_RECEIVE(3);

    private int type;

    ERecommendUserType(int type) {
        this.type = type;
    }

    public int getType() {
        return type;
    }
}
