package com.ufoto.utils;


import com.google.common.collect.Lists;
import com.google.common.collect.Maps;
import com.ufoto.constants.EApiVersion;
import com.ufoto.utils.redis.RedisKeyConstant;
import com.ufoto.utils.redis.RedisService;
import com.ufoto.utils.redis.RedisServiceObjService;
import org.springframework.core.env.Environment;

import java.util.*;

/**
 * <p>
 *
 * </p>
 *
 * @author created by chenzhou at 2018-07-20 13:12
 */
public class RecommendUtil {

    public static Map<String, Integer> ageFilterVersion(String apiVersion, Integer startAge, Integer endAge) {
        Map<String, Integer> resultMap = new HashMap<>();
        Integer defaultStartAge = 13;//旧版
        Integer defaultEndAge = 55;//旧版
        if (EApiVersion.ifHandleAge(apiVersion)) {
            //新版--约定: 如果age的值为-1 默认无上限或无下限
            if (Objects.equals(startAge, -1)) {
                startAge = null;
            }
            if (Objects.equals(endAge, -1)) {
                endAge = null;
            }
        }

        if (startAge != null && startAge < defaultStartAge) {
            startAge = defaultStartAge;
        }

        if (endAge != null && endAge > defaultEndAge) {
            endAge = defaultEndAge;
        }

        if (Objects.equals(startAge, defaultStartAge)) {
            startAge = null;
        }
        if (Objects.equals(endAge, defaultEndAge)) {
            endAge = null;
        }

        resultMap.put("startAge", startAge);
        resultMap.put("endAge", endAge);
        return resultMap;
    }

    public static Double distanceFilterVersion(String apiVersion, Double distance) {
        if (EApiVersion.ifHandleDistance(apiVersion)) {
            if (Objects.equals(distance, -1D)) {
                distance = null;
            }
        }
        return distance;
    }

    public static Map<String, Integer> queryDailyHashMap(RedisService redisService,
                                                         RedisServiceObjService redisServiceObjService,
                                                         Environment env,
                                                         String key) {
        final Long batch = env.getProperty("redis.scan.iter.count", Long.class, 1000L);
        Set<String> allUidSet = redisService.sMember(RedisKeyConstant.REDIS_ACT_IN_24H_USER_SET_KEY, true);
        Map<String, Integer> resultMap = Maps.newHashMap();
        List<String> partUids = Lists.newArrayList();
        for (String id : allUidSet) {
            partUids.add(id);
            if (partUids.size() == batch) {
                //达到一个批次
                final Map<String, Integer> partMap = redisServiceObjService.hmgetWithInteger(key, partUids, 0);
                for (Map.Entry<String, Integer> entry : partMap.entrySet()) {
                    resultMap.merge(entry.getKey(), entry.getValue(), Integer::sum);
                }
                partUids.clear();
            }
        }
        if (!partUids.isEmpty()) {
            final Map<String, Integer> partMap = redisServiceObjService.hmgetWithInteger(key, partUids, 0);
            for (Map.Entry<String, Integer> entry : partMap.entrySet()) {
                resultMap.merge(entry.getKey(), entry.getValue(), Integer::sum);
            }
        }
        return resultMap;
    }
}
