package com.ufoto.business.usercenter;

import com.ufoto.business.usercenter.dto.*;
import com.ufoto.dto.RecommendListUserCenterRequest;
import com.ufoto.dto.sns.SnsRecommendDto;
import com.ufoto.utils.ApiResult;
import com.ufoto.utils.json.JSONUtil;
import org.springframework.stereotype.Component;

import java.util.List;
import java.util.Map;

/**
 * <p>
 * Author     : Chan
 * CreateDate : 2019-03-19 10:06
 * Description:
 * </p>
 */
@Component
public class UserInfoBusinessHystrix implements UserInfoBusiness {

    @Override
    public ApiResult<UserBaseInfoDto> getUserBaseInfo(Long uid) {
        return new ApiResult<UserBaseInfoDto>().setError(ApiResult.errorCode500, "Hystrix Exception: " + uid);
    }

    @Override
    public ApiResult<List<UserBaseInfoDto>> getUserBaseInfoList(List<Long> idList) {
        return new ApiResult<List<UserBaseInfoDto>>().setError(ApiResult.errorCode500, "Hystrix Exception: " + idList);
    }


    @Override
    public ApiResult<UserInfoDto> getUserInfo(Long uid) {
        return new ApiResult<UserInfoDto>().setError(ApiResult.errorCode500, "Hystrix Exception: " + uid);
    }


    @Override
    public ApiResult<UserBaseInfoDto> getUserBaseInfoByUUid(String uuid) {
        return new ApiResult<UserBaseInfoDto>().setError(ApiResult.errorCode500, "Hystrix Exception: " + uuid);
    }

    @Override
    public ApiResult<List<UserBaseInfoDto>> conditionLists(UserConditionDto userConditionDto) {
        return new ApiResult<List<UserBaseInfoDto>>().setError(ApiResult.errorCode500, "Hystrix Exception: " + JSONUtil.toJSON(userConditionDto));
    }

    @Override
    public ApiResult<Integer> getGender(Long uid) {
        return new ApiResult<Integer>().setError(ApiResult.errorCode500, "Hystrix Exception: " + uid);
    }

    @Override
    public ApiResult<List<UserHeadDto>> conditionHeads(UserHeadConditionDto conditionDto) {
        return new ApiResult<List<UserHeadDto>>().setError(ApiResult.errorCode500, "Hystrix Exception: " + conditionDto);
    }

    @Override
    public ApiResult<Integer> updateGeoInfo(List<UserGeoInfoDto> geos) {
        return new ApiResult<Integer>().setError(ApiResult.errorCode500, "Hystrix Exception: " + geos);
    }

    @Override
    public ApiResult<List<SnsRecommendDto>> recommendList(RecommendListUserCenterRequest centerRequest) {
        return new ApiResult<List<SnsRecommendDto>>().setError(ApiResult.errorCode500, "Hystrix Exception: " + centerRequest);
    }

    @Override
    public ApiResult<List<UfotoUserImageDo>> getUserImageByIdList(FirstImgStateVo stateVo) {
        return new ApiResult<List<UfotoUserImageDo>>().setError(ApiResult.errorCode500, "Hystrix Exception:" + stateVo);
    }

    @Override
    public ApiResult<Map<Long, Integer>> checkFirstImageState(List<Long> idList) {
        return new ApiResult<Map<Long, Integer>>().setError(ApiResult.errorCode500, "Hystrix Exception:" + idList);
    }
}
