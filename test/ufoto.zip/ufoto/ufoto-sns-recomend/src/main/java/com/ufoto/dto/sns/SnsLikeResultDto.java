package com.ufoto.dto.sns;

/**
 * Created by echo on 1/6/18.
 */
public class SnsLikeResultDto {

    private Boolean isMatched = false;

    public Boolean getMatched() {
        return isMatched;
    }

    public void setMatched(Boolean matched) {
        isMatched = matched;
    }
}
