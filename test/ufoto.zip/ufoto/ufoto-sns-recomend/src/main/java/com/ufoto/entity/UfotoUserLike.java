package com.ufoto.entity;

import com.ufoto.entity.base.BaseUfotoUserLike;

public class UfotoUserLike extends BaseUfotoUserLike {

    private static final long serialVersionUID = 1L;

}
