package com.ufoto.business.usercenter.dto;

import lombok.Data;
import org.springframework.format.annotation.DateTimeFormat;

import java.util.Date;
import java.util.Objects;

/**
 * 用户信息类
 * 对应表ufoto_app_user
 *
 * @author luozq
 * @date 2019/3/7/007
 */
@Data
public class UfotoAppUserDo {
    /**
     * 用户id
     */
    private Long id;

    /**
     * 用户类型 1 FB用户 2 GMAIL用户
     */
    private Integer type;

    /**
     * 第三方用户唯一标识
     */
    private String uuid;

    /**
     * 用户来源 1 爱自拍 2 情人节活动 3 SweetChat 4 爱自拍社交 5 爱自拍挑战活动
     */
    private Integer fromType;

    /**
     * 用户名
     */
    private String userName;

    /**
     * 真实名
     */
    private String realName;

    /**
     * 邮箱
     */
    private String email;

    /**
     * 手机号
     */
    private String phone;

    /**
     * 出生日期
     */
    @DateTimeFormat(pattern = "yyyy-MM-dd")
    private Date birthTime;

    /**
     * 经度
     */
    private Double longitude;

    /**
     * 纬度
     */
    private Double latitude;

    /**
     * 国家code
     */
    private String countryCode;

    /**
     * 性别 1 男 2 女
     */
    private Integer gender;

    /**
     * 用户头图
     */
    private String firstImg;

    /**
     * 用户头像
     */
    private String headImg;

    /**
     * 是否删除 0 未删除 1 已删除
     */
    private Integer isDelete;

    /**
     * 创建时间
     */
    private Integer createTime;

    /**
     * 更新时间
     */
    private Integer updateTime;

    /**
     * 用户所处城市
     */
    private String location;

    /**
     * 所用APP类型
     */
    private Integer loginSource;

    /**
     * 用户家乡
     */
    private String hometown;

    /**
     * 用户语言
     */
    private String lang;

    /**
     * 邮箱是否合法
     */
    private Integer legitimateEmail;

    /**
     * 描述
     */
    private String description;


    @Override
    public boolean equals(Object o) {
        if (this == o) {
            return true;
        }
        if (o == null || getClass() != o.getClass()) {
            return false;
        }
        UfotoAppUserDo appUserDo = (UfotoAppUserDo) o;
        return Objects.equals(id, appUserDo.id) &&
                Objects.equals(uuid, appUserDo.uuid);
    }

    @Override
    public int hashCode() {
        return Objects.hash(id, uuid);
    }
}