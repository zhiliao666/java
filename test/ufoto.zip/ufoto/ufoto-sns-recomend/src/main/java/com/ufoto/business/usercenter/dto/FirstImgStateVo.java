package com.ufoto.business.usercenter.dto;

import lombok.Data;

import java.io.Serializable;
import java.util.List;

/**
 * @author luozq
 * @date 2019/10/12 18:33
 */
@Data
public class FirstImgStateVo implements Serializable {
    /**
     * id list
     */
    private List<Long> idList;
    /**
     * status list
     */
    private List<Integer> statusList;

}
