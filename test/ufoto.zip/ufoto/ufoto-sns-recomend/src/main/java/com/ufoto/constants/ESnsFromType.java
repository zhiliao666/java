package com.ufoto.constants;

/**
 * 
 *
 * @author zhangqh  
 * @date Apr 11, 2020 4:06:29 PM  
 * @version 1.0
 */
public enum ESnsFromType {
	
    SLIDE(1),
    WINK(2);

    private int type;

    ESnsFromType(int type) {
        this.type = type;
    }

    public int getType() {
        return type;
    }
}
