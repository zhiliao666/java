package com.ufoto.dto;

import java.io.Serializable;

public class AppUserFriendDto implements Serializable {
    /**
     * Default value included to remove warning. Remove or modify at will.
     **/
    private static final long serialVersionUID = 1L;

    private String headImg;
    private String userName;
    private Integer gender;//性别 1 男 2 女
    private Integer isNew;//1 是最新匹配好友列表 2 聊天列表
    private Integer isTop;//是否置顶 0 未置顶 1 置顶
    private Long uid;
    private String birthTime;
    private String createTime;


    /**
     * @return the createTime
     */
    public String getCreateTime() {
        return createTime;
    }

    /**
     * @param createTime the createTime to set
     */
    public void setCreateTime(String createTime) {
        this.createTime = createTime;
    }

    /**
     * @return the birthTime
     */
    public String getBirthTime() {
        return birthTime;
    }

    /**
     * @param birthTime the birthTime to set
     */
    public void setBirthTime(String birthTime) {
        this.birthTime = birthTime;
    }

    /**
     * @return the isNew
     */
    public Integer getIsNew() {
        return isNew;
    }

    /**
     * @param isNew the isNew to set
     */
    public void setIsNew(Integer isNew) {
        this.isNew = isNew;
    }

    /**
     * @return the isTop
     */
    public Integer getIsTop() {
        return isTop;
    }

    /**
     * @param isTop the isTop to set
     */
    public void setIsTop(Integer isTop) {
        this.isTop = isTop;
    }

    /**
     * @return the uid
     */
    public Long getUid() {
        return uid;
    }

    /**
     * @param uid the uid to set
     */
    public void setUid(Long uid) {
        this.uid = uid;
    }

    /**
     * @return the headImg
     */
    public String getHeadImg() {
        return headImg;
    }

    /**
     * @param headImg the headImg to set
     */
    public void setHeadImg(String headImg) {
        this.headImg = headImg;
    }

    /**
     * @return the userName
     */
    public String getUserName() {
        return userName;
    }

    /**
     * @param userName the userName to set
     */
    public void setUserName(String userName) {
        this.userName = userName;
    }

    /**
     * @return the gender
     */
    public Integer getGender() {
        return gender;
    }

    /**
     * @param gender the gender to set
     */
    public void setGender(Integer gender) {
        this.gender = gender;
    }


}
