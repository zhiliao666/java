package com.ufoto.business.recommendNG;

import com.ufoto.dto.RecommendAdvanceRequest;

import java.util.Set;

/**
 * Created by echo on 10/12/18.
 * <p>
 * 召回成分（候选策略、Reagent）接口。
 * 主要实现功能和过滤策略（Filter）类似，但是语义不同：
 * 召回成分代表了，召回内容的最大集合（全集），所有召回的内容都应该在这个集合的范围之内。
 * 过滤策略代表了，不符合对应规则的内容，都不应该出现在推荐的结果当中。
 * <p>
 * 另外召回成分还可以支持从当前的最大集合中随机给出部分内容，这是过滤策略的语义所不支持的。
 */
public interface Reagent {

    /**
     * 返回召回内容和召回成分的交集。
     *
     * @param request       请求参数
     * @param uidCollection 召回内容
     * @return
     */
    Set<String> makeReagents(RecommendAdvanceRequest request, Set<String> uidCollection);

    /**
     * 从召回成分中，随机选取一定数量的内容
     *
     * @param request 请求参数
     * @param size    内容数量
     * @return
     */
    Set<String> randomReagents(RecommendAdvanceRequest request, Integer size);

}
