package com.ufoto.business.recommendNG.recall;

import com.google.common.collect.Sets;
import com.ufoto.annotation.RecommendMetadata;
import com.ufoto.business.recommendNG.Recall;
import com.ufoto.dto.RecommendAdvanceRequest;
import com.ufoto.utils.KeyTransitionUtil;
import com.ufoto.utils.redis.RedisKeyConstant;
import com.ufoto.utils.redis.RedisService;
import org.springframework.stereotype.Component;

import java.util.HashSet;
import java.util.Optional;
import java.util.Set;

/**
 * Created by echo on 4/3/18.
 * <p>
 * 返回聊天机器人的召回结果
 * <p>
 */
@RecommendMetadata(
        metadataType = RecommendMetadata.MetadataType.RECALL,
        name = "聊天机器人召回策略-v2",
        description = "若uid有过match,则随机召回一批聊天机器人",
        branch = RecommendMetadata.Branch.NORMAL
)
@Component
public class NGChatBotV2Recall implements Recall {

    private final RedisService redisService;

    public NGChatBotV2Recall(RedisService redisService) {
        this.redisService = redisService;
    }

    @Override
    public Set<String> recall(Integer minSize, RecommendAdvanceRequest recallRequest) {
        Long uid = recallRequest.getUid();
        final Double matchNum = KeyTransitionUtil.userMatchNum(redisService, uid);
        if (matchNum > 0) return Sets.newHashSet();
        return Optional.ofNullable(redisService.sdistinctRandomMembers(RedisKeyConstant.REDIS_CHAT_BOT_V2_UID_SET_KEY, 20)).orElse(new HashSet<>());
    }

    @Override
    public boolean ifRecallOnlyOnce() {
        return true;
    }

    @Override
    public boolean ifNeedThreadLocalCache() {
        return false;
    }

}
