package com.ufoto.business.recommend.sort;

import com.ufoto.business.recommend.sort.random.RandomSortStrategy;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;

/**
 * Created by echo on 5/11/18.
 */
//Normal default
@Component
public class HotSortStrategy extends CompositeRecommendSortStrategy {

    @Autowired
    public HotSortStrategy(
            RandomSortStrategy randomSortStrategy
    ) {
        this.sortStrategyWeightMap.put(randomSortStrategy, 1d);
    }
}
