package com.ufoto.constants;

/**
 * <p>
 *
 * </p>
 *
 * @author created by chenzhou at 2018-08-01 17:55
 */
public enum EChoice {
    Yes(1), No(0);

    private Integer flag;

    EChoice(Integer flag) {
        this.flag = flag;
    }

    public Integer getFlag() {
        return flag;
    }
}
