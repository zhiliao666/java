package com.ufoto.utils.excel;


import org.apache.commons.lang3.time.DateFormatUtils;
import org.apache.poi.ss.usermodel.*;

import java.io.InputStream;
import java.io.Serializable;
import java.text.DecimalFormat;
import java.util.Date;

public class ReadExcelUtil implements Serializable {
    public DecimalFormat NUMBER_DF = new DecimalFormat("##############.######");//数字格式

    private Sheet sheet;//当前sheet
    private int capacity;//容量(总记录数)  从0开始
    private int pos;//当前位置 从0开始

    private ReadExcelUtil() {
        super();
    }

    public ReadExcelUtil(InputStream in) {
        this(in, true);
    }

    public ReadExcelUtil(InputStream in, boolean ignoreTitle) {
        try {
            // 支持excel 2003/2007
            Workbook wb = WorkbookFactory.create(in);
            sheet = wb.getSheetAt(0);
            capacity = sheet.getLastRowNum() + 1;
            pos = ignoreTitle ? 0 : -1;
        } catch (Exception e) {
            e.printStackTrace();
            throw new RuntimeException(e);
        }
    }

    /**
     * 是否还有记录
     *
     * @return
     */
    public boolean hasNext() {
        return (pos + 1) < capacity;
    }

    /**
     * 读取下一行
     *
     * @return
     */
    public String[] next() {
        try {
            Row row = sheet.getRow(++pos);
            String[] rowStr = new String[row.getLastCellNum()];
            for (int j = 0, len = row.getLastCellNum(); j < len; j++) {
                Cell cell = row.getCell(j);
                rowStr[j] = getCellValue(cell);
            }
            return rowStr;
        } catch (Exception e) {
            e.printStackTrace();
            throw new RuntimeException(e);
        }
    }

    /**
     * 获取内容
     *
     * @param cell
     * @return
     */
    public String getCellValue(Cell cell) {
        if (cell == null) {
            return "";
        }
        String cellValue;
        switch (cell.getCellType()) {
            case Cell.CELL_TYPE_NUMERIC:
                Double dou = cell.getNumericCellValue();
                if (DateUtil.isCellDateFormatted(cell)) {//解析日期
                    Date date = DateUtil.getJavaDate(dou);
                    if (dou > 1) {
                        if (dou - dou.intValue() == 0) {
                            cellValue = DateFormatUtils.format(date, DateTimePattern.DATE_PATTERN);
                        } else {
                            cellValue = DateFormatUtils.format(date, DateTimePattern.DATE_TIME_PATTERN);
                        }
                    } else {
                        cellValue = DateFormatUtils.format(date, DateTimePattern.TIME_PATTERN);
                    }
                } else {
                    cellValue = NUMBER_DF.format(cell.getNumericCellValue());
                }
                break;
            case Cell.CELL_TYPE_STRING:
                cellValue = cell.getRichStringCellValue().toString();
                break;
            case Cell.CELL_TYPE_BOOLEAN:
                cellValue = "" + cell.getBooleanCellValue();
                break;
            case Cell.CELL_TYPE_FORMULA:
                cellValue = cell.getCellFormula();
                break;
            case Cell.CELL_TYPE_BLANK:
                cellValue = "";
                break;
            default:
                cellValue = "";
                break;
        }
        return cellValue.trim();
    }

    /**
     * 获取当前位置
     *
     * @return
     */
    public int getPos() {
        return pos;
    }

    public int getCapacity() {
        return capacity;
    }
}
