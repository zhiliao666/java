package com.ufoto.bloom;

import lombok.Builder;
import lombok.Data;

import java.util.List;

/**
 * <p>
 * Author     : Chan
 * CreateDate : 2019/12/4 13:54
 * Description:
 * </p>
 */
@Data
@Builder
public class RawBloomFilterCache<U> {
    private U user;
    private List<byte[]> bfList;
}
