package com.ufoto.business.recommendNG.invoker;

import com.google.common.collect.Lists;
import com.google.common.collect.Maps;
import com.google.common.collect.Sets;
import com.ufoto.annotation.RecommendMetadata;
import com.ufoto.business.elasticsearch.dto.ElasticSearchException;
import com.ufoto.business.recommend.RecommendFilterStrategy;
import com.ufoto.business.recommend.RecommendSortStrategy;
import com.ufoto.business.recommend.bean.SortParamsBean;
import com.ufoto.business.recommendNG.Invoker;
import com.ufoto.business.recommendNG.Reagent;
import com.ufoto.business.recommendNG.Recall;
import com.ufoto.business.recommendNG.recall.NGRandomRecall;
import com.ufoto.dto.FilterRequestDto;
import com.ufoto.dto.RecommendAdvanceRequest;
import com.ufoto.utils.CommonUtil;
import com.ufoto.utils.json.JSONUtil;
import com.ufoto.plugins.interceptor.LogInterceptor;
import com.ufoto.utils.redis.RedisService;
import lombok.extern.slf4j.Slf4j;
import org.slf4j.MDC;
import org.springframework.beans.BeanUtils;
import org.springframework.util.CollectionUtils;

import java.util.Arrays;
import java.util.List;
import java.util.Map;
import java.util.Set;
import java.util.stream.Collectors;

/**
 * Created by echo on 10/17/18.
 */
@RecommendMetadata(
        metadataType = RecommendMetadata.MetadataType.INVOKER,
        available = true,
        name = "基础的invoker策略",
        description = "每一个策略分支中必有invoker,invoker由recall和reagent组成",
        branch = RecommendMetadata.Branch.NORMAL
)
@Slf4j
public class BaseInvoker implements Invoker {

    private static final String STAGE_REMOVE_INVOKED = "sri";
    private static final String STAGE_AFTER_REAGENT = "sar_";
    private static final String STAGE_AFTER_FILTER = "saf_";
    private static Map<String, ThreadLocal<List<String>>> threadLocalCache = Maps.newConcurrentMap();
    private Recall recallStrategy;
    private List<Reagent> reagentList;
    private List<RecommendFilterStrategy> recommendFilterStrategyList;
    private RecommendSortStrategy recommendSortStrategy;
    private InvokerEnvConfig invokerEnvConfig;
    private RedisService redisService;

    public BaseInvoker(Recall recallStrategy,
                       List<Reagent> reagentList,
                       List<RecommendFilterStrategy> recommendFilterStrategyList,
                       RecommendSortStrategy recommendSortStrategy,
                       InvokerEnvConfig invokerEnvConfig,
                       RedisService redisService) {
        this.recallStrategy = recallStrategy;
        this.reagentList = reagentList;
        this.recommendFilterStrategyList = recommendFilterStrategyList;
        this.recommendSortStrategy = recommendSortStrategy;
        this.invokerEnvConfig = invokerEnvConfig;
        this.redisService = redisService;
    }

    @Override
    public List<String> invoke(Integer minSize, RecommendAdvanceRequest request, Set<String> invokedUidSet) {
        //Tips:可以优化的点
        //召回的时候还是加上offset，不作为全局使用，在反复过滤的时候减少重复召回
        //想办法把已经看过的内容从对应的召回算法里面剔除(不推荐）
        //用户设置的过滤可以提前然后做一些预处理，如果请求里面有的话
        //修改接口减少转换类型的耗时

        //如果是支持ThreadLocal缓存的召回策略，则直接从缓存中获取
        if (recallStrategy.ifNeedThreadLocalCache()) {
            String key = toString();
            List<String> result = threadLocalCache.getOrDefault(key, new ThreadLocal<>()).get();
            if (result != null) {
                result.removeAll(invokedUidSet);
                if (result.size() > minSize) {
                    result = result.subList(0, minSize);
                }
                invokerLog(minSize, request, result, "base");
                return result;
            }
        }
        //最大召回次数
        int MAX_RECALL_TIME = invokerEnvConfig.getMaxRecallTime();
        //每次召回的倍率
        int RECALL_SIZE_INCREASE_RATE = invokerEnvConfig.getRecallSizeIncreaseRate();
        //如果对应的召回策略并不支持多次召回的话，最多只召回一次
        if (recallStrategy.ifRecallOnlyOnce()) MAX_RECALL_TIME = 1;

        Set<String> finalRecallUidSet = Sets.newHashSet();
        Set<String> recallUidSet = null;
        //minSize 每次召回的数量
        int recallSize = minSize;
        //当前召回次数
        int recallTime = 0;
        //是否已经超出当前召回集
        boolean outOfRecall = false;

        //这个Map用于保存在各个过滤阶段后的recallUids
        //一部分内容被召回出来之后，一共会经历三种筛选，分别是：
        //  去除已经召回过的内容
        //  找出和reagent相符的内容（多次）
        //  经过Filter的内容（多次）
        //任何一次筛选之后，如果剩下的recallUids数量不足minSize，则将会暂时保存在stageRecallUidsMap中
        //在下一次重新执行到对应步骤时，会重新合并对应stage的内容，然后查看是否有足够的内容
        Map<String, Set<String>> stageRecallUidsMap = Maps.newLinkedHashMap();
        //如果召回数量小于需要召回的批次(minSize) 并且没有超出当前召回集 并且召回次数没有到达上限  继续召回
        while (finalRecallUidSet.size() < minSize && !outOfRecall && recallTime < MAX_RECALL_TIME) {
            //每次召回的数量增加相应的倍率
            recallSize *= RECALL_SIZE_INCREASE_RATE;
            //是否是随机召回
            boolean ifRandomRecall = recallStrategy.getClass().getName().startsWith(NGRandomRecall.class.getName());
            //每次召回时召回次数加个
            recallTime += 1;
            if (ifRandomRecall) {
                //判断是否是random召回 如果是random  从对应的保留集中随机取出recallSize大小的uid
                recallUidSet = reagentList.get(0).randomReagents(request, recallSize);
            } else {
                //召回  取出recallSize大小的uid
                try {
                    recallUidSet = recallStrategy.recall(recallSize, request);
                } catch (ElasticSearchException e) {
                    // es500的情况下直接停止召回的流程
                    log.error("traceId:{}, request: {}, error: {}"
                            , MDC.get(LogInterceptor.SESSION_KEY), JSONUtil.toJSON(request), e.getMessage());
                    break;
                }
                log.debug("traceId:{}, 召回策略：{},召回结果：{}",MDC.get(LogInterceptor.SESSION_KEY),recallStrategy.getClass(),recallUidSet);
            }
            /*
            判断是否已经召回不出更多内容了-- 如果取出的uid的数量比目标数量小，那么说明的那个前召回集已经没有更多的用户了
            那么就没必要再次对该召回集进行召回。 标识 outOfRecall代表当前召回集已耗尽
             */
            outOfRecall = recallUidSet.size() < recallSize;
            //排除已经召回的内容内容
            recallUidSet.removeAll(invokedUidSet);
            //STAGE_REMOVE_INVOKED代表每次召回的结果暂存集  每次召回的最终结果recallUidSet会与其做并集操作
            recallUidSet.addAll(stageRecallUidsMap.getOrDefault(STAGE_REMOVE_INVOKED, Sets.newHashSet()));
            //如果已经召回不出更多的内容，或者是最后一次尝试，则必须走完全程
            //如果召回集没有耗尽并且召回次数没有到达上限并且召回结果集不足所需数量 将结果暂存 进行下次循环召回 直至召回集耗尽或到达召回次数上限或召回数量已足够
            if (!outOfRecall && recallTime != MAX_RECALL_TIME && recallUidSet.size() < minSize) {
                stageRecallUidsMap.put(STAGE_REMOVE_INVOKED, recallUidSet);
                continue;//提前回去重新召回
            }
            //当召回走到此处，说明当前召回集已经由于各种原因结束召回 开始与候选集做交集运算
            //候选集过滤
            // TODO reagent目前只有一个 随机召回策略不需要做reagent
            for (int i = ifRandomRecall ? 1 : 0; i < reagentList.size(); i++) {
                //交集之后的结果集
                recallUidSet = reagentList.get(i).makeReagents(request, recallUidSet);
                //
                recallUidSet.addAll(stageRecallUidsMap.getOrDefault(STAGE_AFTER_REAGENT + i, Sets.newHashSet()));
                //如果已经召回不出更多的内容，或者是最后一次尝试，则必须走完全程
                if (!outOfRecall && recallTime != MAX_RECALL_TIME && recallUidSet.size() < minSize) {
                    stageRecallUidsMap.put(STAGE_AFTER_REAGENT + i, recallUidSet);
                    continue;//提前回去重新召回
                }
                log.debug("traceId:{},Reagent：{}，结果：{}",MDC.get(LogInterceptor.SESSION_KEY),reagentList.getClass(),recallUidSet);
            }
            
            //中间结果
            final Set<String> tempUidSet = Sets.newHashSet(recallUidSet);
            //
            invokedUidSet.addAll(recallUidSet);
            //如果已经召回不出更多的内容，或者是最后一次尝试，则必须走完全程
            if (!outOfRecall && recallTime != MAX_RECALL_TIME && recallUidSet.size() < minSize) continue;//提前回去重新召回
            //用户设置过滤
            //黑名单过滤
            for (int i = 0; i < recommendFilterStrategyList.size(); i++) {
                recallUidSet = recommendFilterStrategyList.get(i).filter(recallUidSet, Lists.newLinkedList(), request);
                recallUidSet.addAll(stageRecallUidsMap.getOrDefault(STAGE_AFTER_FILTER + i, Sets.newHashSet()));
                //如果已经召回不出更多的内容，或者是最后一次尝试，则必须走完全程
                if (!outOfRecall && recallTime != MAX_RECALL_TIME && recallUidSet.size() < minSize) {
                    stageRecallUidsMap.put(STAGE_AFTER_FILTER + i, recallUidSet);
                    continue;//提前回去重新召回
                }
                log.debug("traceId:{},过滤策略：{}，结果：{}",MDC.get(LogInterceptor.SESSION_KEY),recommendFilterStrategyList.get(i).getClass(),recallUidSet);
            }
            //如果reagent后set不为空,但是过滤后的结果为空,日志打印出来
            if (CollectionUtils.isEmpty(recallUidSet) && !CollectionUtils.isEmpty(tempUidSet)) {
            	final String recallSimpleName = CommonUtil.getSimpleNameWithoutEnhancer(recallStrategy);
                log.warn("recallReagentFilter filter traceId:{},recallClass:{},agentClass:{},body:{}",
                        MDC.get(LogInterceptor.SESSION_KEY),
                        recallSimpleName,
                        reagentList.stream().map(CommonUtil::getSimpleNameWithoutEnhancer).collect(Collectors.joining("->")),
                        JSONUtil.toJSON(FilterRequestDto.builder().recallUids(tempUidSet).request(request).build()));
            }
            //如果已经召回不出更多的内容，或者是最后一次尝试，则必须走完全程
            if (!outOfRecall && recallTime != MAX_RECALL_TIME && recallUidSet.size() < minSize) continue;//提前回去重新召回
            finalRecallUidSet.addAll(recallUidSet);
        }
        //todo:击穿日志

        //排序前缩减数量
        //如果需要缓存，则不要缩减召回数量
        if (finalRecallUidSet.size() > minSize && !recallStrategy.ifNeedThreadLocalCache()) {
            Set<String> minSizeSet = Sets.newHashSet();
            int i = 0;
            for (String item : finalRecallUidSet) {
                minSizeSet.add(item);
                i += 1;
                if (i == minSize) break;
            }
            finalRecallUidSet = minSizeSet;
        }

        //排序
        SortParamsBean sortParamsBean = new SortParamsBean();
        BeanUtils.copyProperties(request, sortParamsBean);
        String[] sortResult = recommendSortStrategy.sort(finalRecallUidSet, sortParamsBean);

        if (recallStrategy.ifNeedThreadLocalCache()) {
            String key = toString();
            ThreadLocal<List<String>> cache = threadLocalCache.get(key);
            if (cache == null) {
                cache = new ThreadLocal<>();
                cache.set(Lists.newArrayList(sortResult));
                threadLocalCache.putIfAbsent(key, cache);
            } else {
                cache.set(Lists.newArrayList(sortResult));
            }
        }
        //截取需要的结果长度
        List<String> result;
        if (sortResult.length <= minSize) {
            result = Lists.newArrayList(sortResult);
        } else {
            result = Lists.newArrayList(Arrays.copyOfRange(sortResult, 0, minSize));
        }
        invokerLog(minSize, request, result, "base");
        return result;
    }

    @Override
    public void cleanThreadLocalCache() {
        if (recallStrategy.ifNeedThreadLocalCache()) {
            String key = toString();
            ThreadLocal<List<String>> cache = threadLocalCache.get(key);
            if (cache == null) {
                threadLocalCache.putIfAbsent(key, new ThreadLocal<>());
            } else {
                cache.set(null);
            }
        }
    }

    public Recall getRecallStrategy() {
        return recallStrategy;
    }

    public List<Reagent> getReagentList() {
        return reagentList;
    }

    public RecommendSortStrategy getRecommendSortStrategy() {
        return recommendSortStrategy;
    }

    public InvokerEnvConfig getInvokerEnvConfig() {
        return invokerEnvConfig;
    }

    @Override
    public String toString() {
        return "recall:"
                + CommonUtil.getSimpleNameWithoutEnhancer(recallStrategy)
                + ";"
                + reagentList.stream()
                .map(CommonUtil::getSimpleNameWithoutEnhancer)
                .collect(Collectors.joining(","));
    }
}
