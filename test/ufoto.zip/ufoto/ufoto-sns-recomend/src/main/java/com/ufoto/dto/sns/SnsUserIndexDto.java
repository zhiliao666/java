package com.ufoto.dto.sns;

import java.util.List;

/**
 * Created by echo on 12/26/17.
 */
public class SnsUserIndexDto {
    private Long uid;
    private String userName;
    private Integer gender;
    private List<String> headImage;
    private String description;
    private List<String> gallery;
    private Long birthTime;
    private Integer distance;
    private String location;

    public Long getUid() {
        return uid;
    }

    public void setUid(Long uid) {
        this.uid = uid;
    }

    public String getUserName() {
        return userName;
    }

    public void setUserName(String userName) {
        this.userName = userName;
    }

    public Integer getGender() {
        return gender;
    }

    public void setGender(Integer gender) {
        this.gender = gender;
    }

    public List<String> getHeadImage() {
        return headImage;
    }

    public void setHeadImage(List<String> headImage) {
        this.headImage = headImage;
    }

    public String getDescription() {
        return description;
    }

    public void setDescription(String description) {
        this.description = description;
    }

    public List<String> getGallery() {
        return gallery;
    }

    public void setGallery(List<String> gallery) {
        this.gallery = gallery;
    }

    public Long getBirthTime() {
        return birthTime;
    }

    public void setBirthTime(Long birthTime) {
        this.birthTime = birthTime;
    }

    public Integer getDistance() {
        return distance;
    }

    public void setDistance(Integer distance) {
        this.distance = distance;
    }

    public String getLocation() {
        return location;
    }

    public void setLocation(String location) {
        this.location = location;
    }
}
