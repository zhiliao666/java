package com.ufoto.config.disruptor;

import com.google.common.collect.Maps;
import com.ufoto.lmax.LMaxDisruptor;
import com.ufoto.lmax.RingBufferMonitor;
import com.ufoto.utils.JSONUtil;
import com.ufoto.utils.SpringContextUtil;
import io.micrometer.core.instrument.Measurement;
import io.micrometer.core.instrument.Metrics;
import io.micrometer.core.instrument.Statistic;
import io.micrometer.core.instrument.search.Search;
import lombok.Data;
import lombok.extern.slf4j.Slf4j;
import org.springframework.scheduling.annotation.Scheduled;
import org.springframework.stereotype.Component;

import java.util.Map;
import java.util.stream.Collectors;

/**
 * <p>
 * Author     : Chan
 * CreateDate : 2019/11/21 09:29
 * Description: 定时打印统计信息
 * </p>
 */
@Slf4j
@Component
public class DisruptorStatistics {

    @Scheduled(fixedRate = 600000)
    public void schedule() {
        log.warn(JSONUtil.toJSON(logStatistics()));
    }

    public Map<String, Object> logStatistics() {
        Map<String, Object> statMap = Maps.newHashMap();
        statMap.put("consumers", Search.in(Metrics.globalRegistry)
                .meters().stream().map(item -> {
                    ConsumerStatistics consumerStatistics = new ConsumerStatistics();
                    consumerStatistics.setName(item.getId().getName());
                    consumerStatistics.setConsumerId(item.getId().getTag("consumerId"));
                    Map<Statistic, Double> measure = Maps.newHashMap();
                    final Iterable<Measurement> measurements = item.measure();
                    measurements.forEach(measurement -> measure.put(measurement.getStatistic(), measurement.getValue()));
                    consumerStatistics.setMeasure(measure);
                    return consumerStatistics;
                })
                .collect(Collectors.toList()));
        final Map<String, LMaxDisruptor> disruptorMap = SpringContextUtil.getApplicationContext().getBeansOfType(LMaxDisruptor.class);
        Map<String, RingBufferMonitor> monitorMap = Maps.newHashMap();
        disruptorMap.forEach((k, v) -> monitorMap.put(k, v.monitorRingBuffer()));
        statMap.put("ringBuffers", monitorMap);
        return statMap;

    }

    @Data
    public static class ConsumerStatistics {
        private String name;
        private String consumerId;
        private Map<Statistic, Double> measure;
    }

}
