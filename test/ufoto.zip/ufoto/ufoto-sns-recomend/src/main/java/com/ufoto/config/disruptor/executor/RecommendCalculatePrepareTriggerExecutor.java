package com.ufoto.config.disruptor.executor;

import com.google.common.collect.Lists;
import com.ufoto.config.disruptor.data.AsyncData;
import com.ufoto.config.disruptor.data.RecommendCalculatedAsyncData;
import com.ufoto.dto.RecommendAdvanceRequest;
import com.ufoto.service.RecommendService;
import lombok.extern.slf4j.Slf4j;
import org.springframework.core.env.Environment;
import org.springframework.stereotype.Component;
import org.springframework.util.CollectionUtils;

import java.util.List;

/**
 * <p>
 * Description:
 *
 * </p>
 *
 * @author Chan
 * @date 2019/12/21 17:55
 */
@Slf4j
@Component
public class RecommendCalculatePrepareTriggerExecutor extends RecommendCalculateExecutor {
    private final RecommendService recommendService;
    private final Environment env;

    public RecommendCalculatePrepareTriggerExecutor(RecommendService recommendService,
                                                    Environment env) {
        this.recommendService = recommendService;
        this.env = env;
    }

    @Override
    public void execute(AsyncData asyncData) {
        RecommendCalculatedAsyncData recommendCalculatedAsyncData = dataCheckAndConverter(asyncData);
        if (recommendCalculatedAsyncData == null) {
            return;
        }
        //判断是否存在缓存 以计划是否提前计算
        if (!env.getProperty("recommend.list.prepare.switch", Boolean.class, true)) {
            return;
        }
        final RecommendAdvanceRequest recommendAdvanceRequest = recommendCalculatedAsyncData.getRecommendAdvanceRequest();
        if (recommendAdvanceRequest.getStart() > 0) {
            // 重置start end
            recommendAdvanceRequest.setStart(0);
            recommendAdvanceRequest.setEnd((recommendAdvanceRequest.getPage() + 1) * recommendAdvanceRequest.getPageSize() - 1);
        }
        log.debug("triggerPrepare calculate recommend list for {}", recommendAdvanceRequest);
        int pageSize = recommendAdvanceRequest.getEnd() - recommendAdvanceRequest.getStart() + 1;
        int loopCount = 0;
        List<String> result = Lists.newArrayList();
        while (loopCount < 3) {
            final List<String> list = recommendService.recommendUsers(recommendAdvanceRequest);
            if (!CollectionUtils.isEmpty(list)) {
                result.addAll(list);
            }
            if (result.size() >= pageSize) {
                break;
            }
            loopCount++;
            final int newStart = recommendAdvanceRequest.getEnd() + 1;
            final int newEnd = newStart + pageSize - 1;
            recommendAdvanceRequest.setStart(newStart);
            recommendAdvanceRequest.setEnd(newEnd);
        }
        log.warn("triggerPrepareWarn calculate recommend list for {},loopCount:{}", recommendAdvanceRequest, loopCount);
    }
}
