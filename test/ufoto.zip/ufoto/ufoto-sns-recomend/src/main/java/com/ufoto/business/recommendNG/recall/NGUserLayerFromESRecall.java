package com.ufoto.business.recommendNG.recall;

import com.github.benmanes.caffeine.cache.LoadingCache;
import com.google.common.collect.Sets;
import com.ufoto.annotation.RecommendMetadata;
import com.ufoto.business.recommendNG.Recall;
import com.ufoto.constants.ESnsUserLayer;
import com.ufoto.dto.RecommendAdvanceRequest;
import com.ufoto.manager.ElasticSearchManager;

import com.ufoto.utils.CommonUtil;
import org.springframework.stereotype.Component;

import java.util.Arrays;
import java.util.Set;
import java.util.stream.Collectors;

/**
 * 根据用户分层召回策略，从es获取低活跃和高活跃用户数据
 * @author zhangqh
 *
 */
@RecommendMetadata(
        metadataType = RecommendMetadata.MetadataType.RECALL,
        available = true,
        name = "用户分层召回低活跃和高活跃策略",
        description = "根据用户分层召回策略，从ES中获取低活跃和高活跃数据源",
        branch = {
        		RecommendMetadata.Branch.NORMAL,
        		RecommendMetadata.Branch.DEFAULT
        		}
)
@Component
public class NGUserLayerFromESRecall implements Recall {
	
	private final ElasticSearchManager elasticSearchManager;
    private final LoadingCache<Class<?>, Object> middleFrequencyLoadingCache;

    public NGUserLayerFromESRecall(ElasticSearchManager elasticSearchManager, LoadingCache<Class<?>, Object> middleFrequencyLoadingCache) {
        this.elasticSearchManager = elasticSearchManager;
        this.middleFrequencyLoadingCache = middleFrequencyLoadingCache;
    }

    @Override
    public Set<String> recall(Integer minSize, RecommendAdvanceRequest recallRequest) {
        Set<String> esResult = elasticSearchManager.queryUserIdsFromESByCondition(recallRequest.getUid(), recallRequest,Arrays.asList(ESnsUserLayer.LOWFINDFRIENDUSER.getLayer(),ESnsUserLayer.HIGHTFINDFRIENDUSER.getLayer()));
        Set<String> freeRecall = Sets.newHashSet(CommonUtil.obj2Set(middleFrequencyLoadingCache.get(NGChatFreeRecall.class)));
        return esResult.stream().filter(s -> !freeRecall.contains(s)).collect(Collectors.toSet());
    }

    @Override
    public boolean ifRecallOnlyOnce() {
        return false;
    }

    @Override
    public boolean ifNeedThreadLocalCache() {
        return false;
    }

}
