package com.ufoto.business.recommend.sort.act;

import com.github.benmanes.caffeine.cache.LoadingCache;
import com.google.common.collect.Maps;
import com.ufoto.annotation.RecommendMetadata;
import com.ufoto.business.recommend.bean.SortParamsBean;
import com.ufoto.business.recommend.sort.BaseNormalSortStrategy;
import com.ufoto.utils.CommonUtil;
import com.ufoto.utils.DateUtil;
import com.ufoto.utils.redis.RedisKeyConstant;
import com.ufoto.utils.redis.RedisService;
import org.springframework.data.redis.core.ZSetOperations;
import org.springframework.stereotype.Component;

import java.util.List;
import java.util.Map;
import java.util.Objects;

/**
 * <p>
 * Author     : Chan
 * CreateDate : 2019-09-09 16:42
 * Description:
 * </p>
 */
@RecommendMetadata(
        metadataType = RecommendMetadata.MetadataType.SORT,
        available = true,
        updateCache = true,
        name = "每天滑动数量排序策略",
        description = "新排序规则，当天滑动数/20 向下取整的整数作为加分项， 如果整数大于20，则取20",
        branch = {RecommendMetadata.Branch.NORMAL}
)
@Component
public class DailyActNumSortStrategy extends BaseNormalSortStrategy {

    private final RedisService redisService;
    private final LoadingCache<Class<?>, Object> recommendLoadingCache;

    public DailyActNumSortStrategy(RedisService redisService,
                                   LoadingCache<Class<?>, Object> recommendLoadingCache) {
        this.redisService = redisService;
        this.recommendLoadingCache = recommendLoadingCache;
    }

    @Override
    public Map<String, Double> getScore(List<String> recallUids, SortParamsBean sortParamsBean) {
        Map<String, Double> scoreMap = Maps.newHashMap();
        final Map<String, Integer> updateCacheField = CommonUtil.obj2MapInteger(recommendLoadingCache.get(this.getClass()));
        for (String recallUid : recallUids) {
            final Integer num = updateCacheField.getOrDefault(recallUid, 0);
            final double score = Math.floor(num / 20.0);
            scoreMap.put(recallUid, score > 20 ? 20 : score);
        }
        return scoreMap;
    }

    public Map<String, Integer> updateCache() {
        Map<String, Integer> updateCacheField = Maps.newConcurrentMap();
        String todayStr = DateUtil.getCurrentDateStr("yyyyMMdd");
        final List<ZSetOperations.TypedTuple<String>> list = redisService.zscan(RedisKeyConstant.REDIS_DAILY_ACT_NUM_ZSET_KEY_ + todayStr);
        for (ZSetOperations.TypedTuple<String> tuple : list) {
            updateCacheField.put(Objects.requireNonNull(tuple.getValue()), Objects.requireNonNull(tuple.getScore()).intValue());
        }
        return updateCacheField;
    }
}
