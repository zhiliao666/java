package com.ufoto.utils.geo;

import com.ufoto.dto.UserGeo;
import com.ufoto.utils.json.JSONUtil;

import java.security.InvalidParameterException;

/**
 * Created by echo on 1/12/18.
 */
public class GeoUtil {

    public static final double EARTH_RADIUS = 6378.137;//赤道半径,km
    //纬度相差1度对应的距离,近似值
    public static final double LAT_DISTANCE = EARTH_RADIUS * Math.PI / 180.0;//km
    public static final double MAX_LONGITUDE = 180;
    public static final double MIN_LONGITUDE = -180;
    public static final double MAX_LATITUDE = 85;
    public static final double MIN_LATITUDE = -85;

    private static double rad(double d) {
        return d * Math.PI / 180.0;
    }

    private static double reversRad(double d) {
        return d * 180 / Math.PI;
    }

    public static boolean checkPointLegal(Double longitude, Double latitude) {
        return longitude != null && latitude != null
                && Math.abs(longitude) < MAX_LONGITUDE
                && Math.abs(latitude) < MAX_LATITUDE;
    }

    public static double getDistance(UserGeo geo1, UserGeo geo2) {
        if (geo1 == null || geo2 == null) {
            return -1;
        }
        return getDistance(geo1.getLongitude(), geo1.getLatitude(), geo2.getLongitude(), geo2.getLatitude());
    }

    public static double getDistance(UserGeo geo, double longitude, double latitude) {
        return getDistance(geo.getLongitude(), geo.getLatitude(), longitude, latitude);
    }

    public static double getDistance(double lon1, double lat1, double lon2, double lat2) {
        double radLat1 = rad(lat1);
        double radLat2 = rad(lat2);
        double a = radLat1 - radLat2;
        double b = rad(lon1) - rad(lon2);
        double s = 2 * Math.asin(Math.sqrt(Math.pow(Math.sin(a / 2), 2) + Math.cos(radLat1) * Math.cos(radLat2) * Math.pow(Math.sin(b / 2), 2)));
        s = s * EARTH_RADIUS;
        return s;//km
    }

    /**
     * 将距离（单位km）转化为经度的差值
     * <p>
     * Yeah...Only god knows..
     *
     * @param dist 距离，km
     * @param lat  对应坐标的纬度
     * @return
     */
    public static double convertDistanceToLonDiff(double dist, double lat) {
        double b = 2 * Math.asin(Math.sin(dist / EARTH_RADIUS / 2) / Math.cos(rad(lat)));
        return reversRad(b);
    }

    /**
     * 将距离（单位km）转化为纬度的差值
     *
     * @param dist
     * @return
     */
    public static double convertDistanceToLatDiff(double dist) {
        return dist / LAT_DISTANCE;
    }

    /**
     * 返回对应坐标的一定距离范围内的经纬度上下限
     * 返回格式：
     * [经度下限，经度上限，维度下限，维度上限]
     *
     * @param dist
     * @param lon
     * @param lat
     * @return
     */
    public static double[] getLonLatBound(double dist, double lon, double lat) {
        if (dist <= 0) return new double[]{lon, lon, lat, lat};

        if (lon < MIN_LONGITUDE) lon = MIN_LONGITUDE;
        if (lon > MAX_LONGITUDE) lon = MAX_LONGITUDE;

        double lonDiff = convertDistanceToLonDiff(dist, lat);
        double latDiff = convertDistanceToLatDiff(dist);

        double lonUnderBound = lon - lonDiff;
        double lonUpperBound = lon + lonDiff;
        double latUnderBound = lat - latDiff;
        double latUpperBound = lat + latDiff;

        if (lonUnderBound < MIN_LONGITUDE) lonUnderBound = MAX_LONGITUDE - MIN_LONGITUDE + lonUnderBound;
        if (lonUpperBound > MAX_LONGITUDE) lonUpperBound = lonUpperBound - MAX_LONGITUDE + MIN_LONGITUDE;
        if (latUnderBound < MIN_LATITUDE) latUnderBound = MIN_LATITUDE;
        if (latUnderBound > MAX_LATITUDE) latUnderBound = MAX_LATITUDE;
        if (latUpperBound < MIN_LATITUDE) latUpperBound = MIN_LATITUDE;
        if (latUpperBound > MAX_LATITUDE) latUpperBound = MAX_LATITUDE;

        return new double[]{lonUnderBound, lonUpperBound, latUnderBound, latUpperBound};
    }


    /**
     * 返回对应的经纬度坐标是否在规定的框中
     *
     * @param locationBound 框
     * @param lon           经度
     * @param lat           纬度
     * @return
     */
    public static boolean ifInBound(double[] locationBound, double lon, double lat) {
        if (locationBound.length != 4) throw new InvalidParameterException(
                "GeoUtil.ifInBound locationBound size error!"
                        + ", longitude:" + lon
                        + ", latitude:" + lat
                        + ",bound:" + JSONUtil.toJSON(locationBound));

        double lonUnderBound = locationBound[0];
        double lonUpperBound = locationBound[1];
        double latUnderBound = locationBound[2];
        double latUpperBound = locationBound[3];

        if (latUnderBound > latUpperBound) throw new InvalidParameterException(
                "GeoUtil.ifInBound latUnderBound > lonUpperBound error!"
                        + ", longitude:" + lon
                        + ", latitude:" + lat
                        + ",bound:" + JSONUtil.toJSON(locationBound));

        if (latUnderBound > MAX_LATITUDE || latUnderBound < MIN_LATITUDE ||
                latUpperBound > MAX_LATITUDE || latUpperBound < MIN_LATITUDE)
            throw new InvalidParameterException(
                    "GeoUtil.ifInBound latBound Error!"
                            + ", longitude:" + lon
                            + ", latitude:" + lat
                            + ",bound:" + JSONUtil.toJSON(locationBound));

        if (lonUnderBound > MAX_LONGITUDE || lonUnderBound < MIN_LONGITUDE ||
                lonUpperBound > MAX_LONGITUDE || lonUpperBound < MIN_LONGITUDE)
            throw new InvalidParameterException(
                    "GeoUtil.ifInBound lonBound Error!"
                            + ", longitude:" + lon
                            + ", latitude:" + lat
                            + ",bound:" + JSONUtil.toJSON(locationBound));

        if (lat < latUnderBound || lat > latUpperBound) return false;
        if (lonUnderBound < lonUpperBound) {
            return (lon > lonUnderBound && lon < lonUpperBound);
        }
        return (lon > lonUnderBound || lon < lonUpperBound);
    }
}
