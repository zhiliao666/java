package com.ufoto.dao.dump;

import com.ufoto.dao.base.BaseUfotoRecommendRedisDumpMapper;
import com.ufoto.entity.UfotoRecommendRedisDump;
import org.apache.ibatis.annotations.*;

import java.util.List;

@Mapper
public interface UfotoRecommendRedisDumpMapper extends BaseUfotoRecommendRedisDumpMapper {

    @Results({
            @Result(property = "id", column = "id"),
            @Result(property = "uid", column = "uid"),
            @Result(property = "key", column = "redis_key"),
            @Result(property = "dump", column = "dump"),
            @Result(property = "createTime", column = "create_time"),
            @Result(property = "lastActTime", column = "last_act_time"),
            @Result(property = "hasRestored", column = "has_restored"),
    })
    @Select("SELECT * FROM ufoto_recommend_redis_dump WHERE uid = #{uid} AND has_restored=0")
    List<UfotoRecommendRedisDump> selectForRestoreByUid(@Param("uid") Long uid);

    @Update("<script>" +
            "UPDATE ufoto_recommend_redis_dump SET has_restored = 1 " +
            "WHERE id IN (" +
            "<foreach item='item' collection='dumpIdList' separator=','> " +
            "#{item}" +
            "</foreach>" +
            ") " +
            "</script>"
    )
    int updateHasRestoredByDumpIdList(@Param("dumpIdList") List<Long> dumpIdList);

}
