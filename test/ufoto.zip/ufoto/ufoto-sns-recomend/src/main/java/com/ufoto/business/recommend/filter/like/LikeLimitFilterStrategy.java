package com.ufoto.business.recommend.filter.like;

import com.google.common.collect.Sets;
import com.ufoto.annotation.RecommendMetadata;
import com.ufoto.business.recommend.RecommendFilterStrategy;
import com.ufoto.business.recommend.filter.FilterUtil;
import com.ufoto.dto.RecommendAdvanceRequest;
import com.ufoto.utils.CommonUtil;
import com.ufoto.utils.DateUtil;
import com.ufoto.utils.RecommendUtil;
import com.ufoto.utils.redis.RedisKeyConstant;
import com.ufoto.utils.redis.RedisKeyUtil;
import com.ufoto.utils.redis.RedisService;
import com.ufoto.utils.redis.RedisServiceObjService;
import lombok.extern.slf4j.Slf4j;
import org.springframework.core.env.Environment;
import org.springframework.stereotype.Component;

import java.util.List;
import java.util.Map;
import java.util.Set;

/**
 * <p>
 * Author     : Chan
 * CreateDate : 2018/8/29 17:02
 * Description: 被like的次数超过limit 过滤掉
 * </p>
 */
@Slf4j
@RecommendMetadata(
        metadataType = RecommendMetadata.MetadataType.FILTER,
        available = true,
        updateCache = true,
        name = "被like上限过滤策略",
        description = "过滤被like次数达到上限的用户，同时保留like或superlike过uid的用户，保留聊天机器人.过午则倍",
        branch = {
                RecommendMetadata.Branch.NORMAL,
                RecommendMetadata.Branch.DEFAULT,
                RecommendMetadata.Branch.High_Risk
        }
)
@Component
public class LikeLimitFilterStrategy implements RecommendFilterStrategy {
    private final RedisService redisService;
    private final RedisServiceObjService redisServiceObjService;
    private final Environment env;
    private final FilterUtil filterUtil;

    public LikeLimitFilterStrategy(RedisService redisService,
                                   Environment env,
                                   FilterUtil filterUtil,
                                   RedisServiceObjService redisServiceObjService) {
        this.redisService = redisService;
        this.env = env;
        this.filterUtil = filterUtil;
        this.redisServiceObjService = redisServiceObjService;
    }

    @Override
    public Set<String> filter(Set<String> recallSet, List<String> resultList, RecommendAdvanceRequest filterRequest) {
        return filterUtil.filterExcludeWhoLikedMe(filterRequest, recallSet, this.getClass());
    }
    // TODO 是否存在单次计算过大以及实时性不好的问题，是否可以只过滤召回用户超过上限的用户
    public Set<String> updateCache() {
        int likeLimit = CommonUtil.calcLimit(env.getProperty("recommend.filter.liked.limit", Integer.class, 50));
        String currentDay = DateUtil.getCurrentDateStr("yyyyMMdd");
        final String likedDailyHash = RedisKeyUtil.obtainKey(RedisKeyConstant.REDIS_BE_LIKED_DAILY_HASH, currentDay);
        Map<String, Integer> resultMap = RecommendUtil.queryDailyHashMap(redisService, redisServiceObjService, env, likedDailyHash);
        //不要过滤聊天机器人
        Set<String> chatBotUidSet = redisService.sMember(RedisKeyConstant.REDIS_CHAT_BOT_UID_SET_KEY);
        Set<String> result = Sets.newHashSet();
        for (Map.Entry<String, Integer> entry : resultMap.entrySet()) {
            if (entry.getValue() >= likeLimit && !chatBotUidSet.contains(entry.getKey())) {
                result.add(entry.getKey());
            }
        }
        log.debug("LikeLimitSubscription->updateCacheField:{}", result);
        return result;
    }
}
