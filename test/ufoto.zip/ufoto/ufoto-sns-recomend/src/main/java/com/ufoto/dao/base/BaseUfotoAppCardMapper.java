package com.ufoto.dao.base;

import com.ufoto.entity.base.BaseUfotoAppCard;
import com.ufoto.entity.base.BaseUfotoAppCardExample;
import org.apache.ibatis.annotations.*;
import org.apache.ibatis.type.JdbcType;

import java.util.List;

public interface BaseUfotoAppCardMapper {
    @SelectProvider(type = BaseUfotoAppCardSqlProvider.class, method = "countByExample")
    long countByExample(BaseUfotoAppCardExample example);

    @DeleteProvider(type = BaseUfotoAppCardSqlProvider.class, method = "deleteByExample")
    int deleteByExample(BaseUfotoAppCardExample example);

    @Delete({
            "delete from ufoto_app_card",
            "where id = #{id,jdbcType=BIGINT}"
    })
    int deleteByPrimaryKey(Long id);

    @Insert({
            "insert into ufoto_app_card (id, type, ",
            "type_id, user_name, ",
            "description, first_img, ",
            "type_sub, lang, is_delete, ",
            "create_time, update_time)",
            "values (#{id,jdbcType=BIGINT}, #{type,jdbcType=INTEGER}, ",
            "#{typeId,jdbcType=BIGINT}, #{userName,jdbcType=VARCHAR}, ",
            "#{description,jdbcType=VARCHAR}, #{firstImg,jdbcType=VARCHAR}, ",
            "#{typeSub,jdbcType=INTEGER}, #{lang,jdbcType=VARCHAR}, #{isDelete,jdbcType=INTEGER}, ",
            "#{createTime,jdbcType=INTEGER}, #{updateTime,jdbcType=INTEGER})"
    })
    @Options(useGeneratedKeys = true, keyColumn = "id")
    int insert(BaseUfotoAppCard record);

    @InsertProvider(type = BaseUfotoAppCardSqlProvider.class, method = "insertSelective")
    int insertSelective(BaseUfotoAppCard record);

    @SelectProvider(type = BaseUfotoAppCardSqlProvider.class, method = "selectByExample")
    @Results({
            @Result(column = "id", property = "id", jdbcType = JdbcType.BIGINT, id = true),
            @Result(column = "type", property = "type", jdbcType = JdbcType.INTEGER),
            @Result(column = "type_id", property = "typeId", jdbcType = JdbcType.BIGINT),
            @Result(column = "user_name", property = "userName", jdbcType = JdbcType.VARCHAR),
            @Result(column = "description", property = "description", jdbcType = JdbcType.VARCHAR),
            @Result(column = "first_img", property = "firstImg", jdbcType = JdbcType.VARCHAR),
            @Result(column = "type_sub", property = "typeSub", jdbcType = JdbcType.INTEGER),
            @Result(column = "lang", property = "lang", jdbcType = JdbcType.VARCHAR),
            @Result(column = "is_delete", property = "isDelete", jdbcType = JdbcType.INTEGER),
            @Result(column = "create_time", property = "createTime", jdbcType = JdbcType.INTEGER),
            @Result(column = "update_time", property = "updateTime", jdbcType = JdbcType.INTEGER)
    })
    List<BaseUfotoAppCard> selectByExample(BaseUfotoAppCardExample example);

    @Select({
            "select",
            "id, type, type_id, user_name, description, first_img, type_sub, lang, is_delete, ",
            "create_time, update_time",
            "from ufoto_app_card",
            "where id = #{id,jdbcType=BIGINT}"
    })
    @Results({
            @Result(column = "id", property = "id", jdbcType = JdbcType.BIGINT, id = true),
            @Result(column = "type", property = "type", jdbcType = JdbcType.INTEGER),
            @Result(column = "type_id", property = "typeId", jdbcType = JdbcType.BIGINT),
            @Result(column = "user_name", property = "userName", jdbcType = JdbcType.VARCHAR),
            @Result(column = "description", property = "description", jdbcType = JdbcType.VARCHAR),
            @Result(column = "first_img", property = "firstImg", jdbcType = JdbcType.VARCHAR),
            @Result(column = "type_sub", property = "typeSub", jdbcType = JdbcType.INTEGER),
            @Result(column = "lang", property = "lang", jdbcType = JdbcType.VARCHAR),
            @Result(column = "is_delete", property = "isDelete", jdbcType = JdbcType.INTEGER),
            @Result(column = "create_time", property = "createTime", jdbcType = JdbcType.INTEGER),
            @Result(column = "update_time", property = "updateTime", jdbcType = JdbcType.INTEGER)
    })
    BaseUfotoAppCard selectByPrimaryKey(Long id);

    @UpdateProvider(type = BaseUfotoAppCardSqlProvider.class, method = "updateByExampleSelective")
    int updateByExampleSelective(@Param("record") BaseUfotoAppCard record, @Param("example") BaseUfotoAppCardExample example);

    @UpdateProvider(type = BaseUfotoAppCardSqlProvider.class, method = "updateByExample")
    int updateByExample(@Param("record") BaseUfotoAppCard record, @Param("example") BaseUfotoAppCardExample example);

    @UpdateProvider(type = BaseUfotoAppCardSqlProvider.class, method = "updateByPrimaryKeySelective")
    int updateByPrimaryKeySelective(BaseUfotoAppCard record);

    @Update({
            "update ufoto_app_card",
            "set type = #{type,jdbcType=INTEGER},",
            "type_id = #{typeId,jdbcType=BIGINT},",
            "user_name = #{userName,jdbcType=VARCHAR},",
            "description = #{description,jdbcType=VARCHAR},",
            "first_img = #{firstImg,jdbcType=VARCHAR},",
            "type_sub = #{typeSub,jdbcType=INTEGER},",
            "lang = #{lang,jdbcType=VARCHAR},",
            "is_delete = #{isDelete,jdbcType=INTEGER},",
            "create_time = #{createTime,jdbcType=INTEGER},",
            "update_time = #{updateTime,jdbcType=INTEGER}",
            "where id = #{id,jdbcType=BIGINT}"
    })
    int updateByPrimaryKey(BaseUfotoAppCard record);
}