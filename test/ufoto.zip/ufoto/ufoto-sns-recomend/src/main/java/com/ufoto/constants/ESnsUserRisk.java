package com.ufoto.constants;

/**
 * @author tangyd
 */
public enum ESnsUserRisk {
    NORMAL(100),// 普通用户
    MONITOR(200),// 监控用户
    HIGH_RISK(300)//高危用户
    ;

    private Integer riskLevel;

    public Integer getRiskLevel() {
        return riskLevel;
    }

    ESnsUserRisk(Integer riskLevel) {
        this.riskLevel = riskLevel;
    }
}
