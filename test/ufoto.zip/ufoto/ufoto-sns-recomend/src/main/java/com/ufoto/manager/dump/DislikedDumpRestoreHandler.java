package com.ufoto.manager.dump;

import com.google.common.collect.Maps;
import com.ufoto.constants.EOldNewKey;
import com.ufoto.entity.UfotoRecommendRedisDump;
import com.ufoto.utils.redis.RedisKeyConstant;
import com.ufoto.utils.redis.RedisService;
import com.ufoto.utils.redis.RedisServiceObjService;
import lombok.extern.slf4j.Slf4j;
import org.springframework.core.env.Environment;
import org.springframework.stereotype.Component;

import java.util.Map;

/**
 * <p>
 * Author     : Chan
 * CreateDate : 2019-09-17 11:18
 * Description:
 * </p>
 */
@Slf4j
@Component
public class DislikedDumpRestoreHandler extends AbstractDumpRestoreHandler {

    public DislikedDumpRestoreHandler(RedisService redisService, Environment env, RedisServiceObjService redisServiceObjService) {
        super(redisService, env, redisServiceObjService, false);
    }

    @Override
    public void doRestoreDiff(Long uid, Map<String, UfotoRecommendRedisDump> dislikedMap) {
        //处理disliked的dump数据
        Map<EOldNewKey, String> dislikedOldNewMap = Maps.newHashMap();
        dislikedOldNewMap.put(EOldNewKey.NEW, RedisKeyConstant.REDIS_BE_UN_LIKED_SET_KEY_NEW);
        dislikedOldNewMap.put(EOldNewKey.OLD, RedisKeyConstant.REDIS_BE_UN_LIKED_SET_KEY_);
        super.handleDumpKey(uid, dislikedMap, dislikedOldNewMap);
    }

}
