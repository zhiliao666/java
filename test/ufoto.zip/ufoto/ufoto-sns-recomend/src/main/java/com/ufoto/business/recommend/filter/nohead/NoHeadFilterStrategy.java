package com.ufoto.business.recommend.filter.nohead;

import com.ufoto.annotation.RecommendMetadata;
import com.ufoto.business.recommend.RecommendFilterStrategy;
import com.ufoto.business.recommend.filter.FilterUtil;
import com.ufoto.dto.RecommendAdvanceRequest;
import com.ufoto.utils.redis.RedisKeyConstant;
import com.ufoto.utils.redis.RedisService;
import org.springframework.stereotype.Component;

import java.util.HashSet;
import java.util.List;
import java.util.Optional;
import java.util.Set;

/**
 * Created by echo on 4/3/18.
 * <p>
 * 过滤已经被举报的用户
 */
@RecommendMetadata(
        metadataType = RecommendMetadata.MetadataType.FILTER,
        available = true,
        updateCache = true,
        name = "无头像过滤策略",
        description = "过滤没有头像的用户",
        branch = {
                RecommendMetadata.Branch.NORMAL,
                RecommendMetadata.Branch.DEFAULT,
                RecommendMetadata.Branch.GIFT,
                RecommendMetadata.Branch.High_Risk,
                RecommendMetadata.Branch.USERLAYER,
                RecommendMetadata.Branch.WINK
        }
)
@Component
public class NoHeadFilterStrategy implements RecommendFilterStrategy {
    private final RedisService redisService;
    private final FilterUtil filterUtil;

    public NoHeadFilterStrategy(RedisService redisService,
                                FilterUtil filterUtil) {
        this.redisService = redisService;
        this.filterUtil = filterUtil;
    }

    @Override
    public Set<String> filter(Set<String> recallSet, List<String> resultList, RecommendAdvanceRequest filterRequest) {
        return filterUtil.filter(recallSet, this.getClass());
    }

    public Set<String> updateCache() {
        return Optional.ofNullable(redisService.sMember(RedisKeyConstant.REDIS_NO_HEAD_USER_SET_KEY, true)).orElse(new HashSet<>());
    }
}
