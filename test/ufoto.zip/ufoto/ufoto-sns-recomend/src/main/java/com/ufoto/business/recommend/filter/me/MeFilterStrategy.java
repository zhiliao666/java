package com.ufoto.business.recommend.filter.me;

import com.ufoto.annotation.RecommendMetadata;
import com.ufoto.business.recommend.RecommendFilterStrategy;
import com.ufoto.dto.RecommendAdvanceRequest;
import org.springframework.stereotype.Component;
import org.springframework.util.CollectionUtils;

import java.util.List;
import java.util.Set;

/**
 * <p>
 * 过滤自己
 * </p>
 *
 * @author created by chenzhou at 2018-06-02 17:38
 */
@RecommendMetadata(
        metadataType = RecommendMetadata.MetadataType.FILTER,
        available = true,
        name = "屏蔽自己过滤策略",
        description = "将召回集中可能出现的自己过滤掉",
        branch = {
                RecommendMetadata.Branch.NORMAL,
                RecommendMetadata.Branch.DEFAULT,
                RecommendMetadata.Branch.GIFT,
                RecommendMetadata.Branch.High_Risk,
                RecommendMetadata.Branch.USERLAYER,
                RecommendMetadata.Branch.WINK
        }
)
@Component
public class MeFilterStrategy implements RecommendFilterStrategy {

    @Override
    public Set<String> filter(Set<String> recallSet, List<String> resultList, RecommendAdvanceRequest filterRequest) {
        if (CollectionUtils.isEmpty(recallSet)) {
            return recallSet;
        }
        recallSet.remove(String.valueOf(filterRequest.getUid()));
        return recallSet;
    }
}
