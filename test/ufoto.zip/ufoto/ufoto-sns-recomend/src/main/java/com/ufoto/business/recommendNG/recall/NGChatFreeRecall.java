package com.ufoto.business.recommendNG.recall;

import com.github.benmanes.caffeine.cache.LoadingCache;
import com.google.common.collect.Sets;
import com.ufoto.annotation.RecommendMetadata;
import com.ufoto.business.recommendNG.Recall;
import com.ufoto.dto.RecommendAdvanceRequest;
import com.ufoto.utils.CommonUtil;
import com.ufoto.utils.redis.RedisKeyConstant;
import com.ufoto.utils.redis.RedisServiceObjService;
import lombok.RequiredArgsConstructor;
import org.springframework.stereotype.Component;
import org.springframework.util.CollectionUtils;

import javax.annotation.PostConstruct;
import java.util.Set;
import java.util.stream.Collectors;

/**
 * 运营人员陪聊召回策略
 * 
 * @author zhangqh
 *
 */
@RecommendMetadata(metadataType = RecommendMetadata.MetadataType.RECALL, 
	available = true, 
	name = "运营人员陪聊召回策略",
	description = "运营人员陪聊召回策略",
	branch = {
			RecommendMetadata.Branch.NORMAL
	})
@Component
@RequiredArgsConstructor
public class NGChatFreeRecall implements Recall {
	
	private final LoadingCache<Class<?>, Object> middleFrequencyLoadingCache;
    private final RedisServiceObjService redisServiceObjService;

    @PostConstruct
	public void initCache() {
		middleFrequencyLoadingCache.refresh(this.getClass());
	}

	@Override
	public Set<String> recall(Integer minSize, RecommendAdvanceRequest recallRequest) {
		return Sets.newHashSet(CommonUtil.obj2Set(middleFrequencyLoadingCache.get(this.getClass())));
	}


	@Override
	public boolean ifRecallOnlyOnce() {
		return true;
	}

	@Override
	public boolean ifNeedThreadLocalCache() {
		return true;
	}
	
	public Set<String> updateCache() {
        final Set<Long> members = redisServiceObjService.smembers(RedisKeyConstant.REDIS_CHAT_FREE_SET_KEY, true);
        if (CollectionUtils.isEmpty(members)) {
            return Sets.newHashSet();
        }
        return members.stream().map(String::valueOf).collect(Collectors.toSet());
    }

}
