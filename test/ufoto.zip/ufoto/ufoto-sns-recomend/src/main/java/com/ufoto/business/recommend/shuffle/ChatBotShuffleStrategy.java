package com.ufoto.business.recommend.shuffle;

import com.ufoto.annotation.RecommendMetadata;
import com.ufoto.business.recommend.shuffle.base.BaseShuffleStrategy;
import com.ufoto.business.recommend.shuffle.cutter.ChatBotCutter;
import com.ufoto.business.recommend.shuffle.dealer.DealChatBotDealer;
import com.ufoto.utils.redis.RedisService;


@RecommendMetadata(
        metadataType = RecommendMetadata.MetadataType.SHUFFLE,
        available = true,
        name = "聊天机器人打散器",
        description = "根据是否是聊天机器人分成两个list(ChatBotCutter)," +
                "然后随机取指定数量的聊天机器人,合并list,非聊天机器人不足20,聊天机器人直接放在最后,否则随机插入在非聊天机器人中(DealChatBotDealer)",
        branch = RecommendMetadata.Branch.NORMAL
)
public class ChatBotShuffleStrategy extends BaseShuffleStrategy {

    public ChatBotShuffleStrategy(RedisService redisService, int minChatBotCount, int maxChatBotCount) {
        this.cutter = new ChatBotCutter(redisService);
        this.dealer = new DealChatBotDealer(minChatBotCount, maxChatBotCount);
    }

}
