package com.ufoto.business.recommend.filter;

import com.ufoto.business.recommend.RecommendFilterStrategy;
import com.ufoto.dto.RecommendAdvanceRequest;

import java.util.LinkedList;
import java.util.List;
import java.util.Set;

/**
 * Created by echo on 4/3/18.
 */
public abstract class CompositeRecommendFilterStrategy implements RecommendFilterStrategy {

    protected List<RecommendFilterStrategy> filterStrategyList = new LinkedList<>();

    @Override
    public Set<String> filter(Set<String> recallSet, List<String> resultList, RecommendAdvanceRequest filterRequest) {
        for (RecommendFilterStrategy filterStrategy : filterStrategyList) {
            if (recallSet == null || recallSet.size() == 0) break;
            recallSet = filterStrategy.filter(recallSet, resultList, filterRequest);
        }
        return recallSet;
    }
}
