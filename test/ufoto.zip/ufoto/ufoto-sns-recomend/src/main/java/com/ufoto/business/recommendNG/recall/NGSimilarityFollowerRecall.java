package com.ufoto.business.recommendNG.recall;

import com.google.common.collect.Sets;
import com.ufoto.annotation.RecommendMetadata;
import com.ufoto.business.recommendNG.Recall;
import com.ufoto.dao.svd.UfotoSvdItemSimilarityMapper;
import com.ufoto.dto.RecommendAdvanceRequest;
import com.ufoto.utils.CommonUtil;
import com.ufoto.utils.redis.RedisKeyConstant;
import com.ufoto.utils.redis.RedisService;
import org.springframework.core.env.Environment;
import org.springframework.stereotype.Component;
import org.springframework.util.CollectionUtils;

import java.util.List;
import java.util.Objects;
import java.util.Set;
import java.util.stream.Collectors;

/**
 * Created by echo on 5/11/18.
 */
@RecommendMetadata(
        metadataType = RecommendMetadata.MetadataType.RECALL,
        available = true,
        name = "相似的liked用户召回策略",
        description = "以用户最近被like的用户为基础,召回与发起like的这些用户相似的用户topN",
        branch = RecommendMetadata.Branch.NORMAL
)
@Component
public class NGSimilarityFollowerRecall implements Recall {

    private final Environment env;
    private final UfotoSvdItemSimilarityMapper ufotoSvdItemSimilarityMapper;
    private final RedisService redisService;

    public NGSimilarityFollowerRecall(Environment env,
                                      UfotoSvdItemSimilarityMapper ufotoSvdItemSimilarityMapper,
                                      RedisService redisService) {
        this.env = env;
        this.ufotoSvdItemSimilarityMapper = ufotoSvdItemSimilarityMapper;
        this.redisService = redisService;
    }

    @Override
    public Set<String> recall(Integer minSize, RecommendAdvanceRequest recallRequest) {
        boolean ifSvdOn = env.getProperty("recommend.recall.ifSvdOn", Boolean.class, true);
        if (!ifSvdOn) return Sets.newHashSet();
        Set<String> latestLiked = redisService.sdistinctRandomMembers(RedisKeyConstant.REDIS_BE_LIKED_SET_KEY_ + recallRequest.getUid(), 10L);
        List<Long> lastLikedItemList = latestLiked.stream()
                .filter(CommonUtil::isLong)
                .map(Long::valueOf)
                .collect(Collectors.toList());

        List<Long> recallResultList = ufotoSvdItemSimilarityMapper.selectTopNSimilarityFollowerByIids(lastLikedItemList);
        if (CollectionUtils.isEmpty(recallResultList))
            return Sets.newHashSet();

        return recallResultList.stream()
                .filter(Objects::nonNull)
                .map(Object::toString)
                .collect(Collectors.toSet());
    }

    @Override
    public boolean ifRecallOnlyOnce() {
        return true;
    }

    @Override
    public boolean ifNeedThreadLocalCache() {
        return true;
    }
}
