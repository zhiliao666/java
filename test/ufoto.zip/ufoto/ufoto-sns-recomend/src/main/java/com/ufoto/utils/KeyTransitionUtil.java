package com.ufoto.utils;

import com.google.common.collect.Lists;
import com.google.common.collect.Maps;
import com.ufoto.dto.UserGeo;
import com.ufoto.utils.redis.RedisKeyConstant;
import com.ufoto.utils.redis.RedisKeyUtil;
import com.ufoto.utils.redis.RedisService;
import lombok.extern.slf4j.Slf4j;
import org.springframework.data.redis.serializer.RedisSerializer;
import org.springframework.util.CollectionUtils;
import org.springframework.util.StringUtils;

import java.nio.charset.Charset;
import java.nio.charset.StandardCharsets;
import java.util.List;
import java.util.Map;

/**
 * <p>
 * Author     : Chan
 * CreateDate : 2019-07-17 18:15
 * Description: redis key过渡的工具类
 * </p>
 */
@Slf4j
public class KeyTransitionUtil {

    private final static Charset charset = StandardCharsets.UTF_8;

    /**
     * 获取用户的注册时间
     * 先从画像中获取,如果为空或为null的空串,视为没有,则从之前的hash中获取,如若获取到,则同时更新到画像中
     *
     * @param redisService redisService
     * @param requestUid   用户id
     * @return 用户的注册时间 有可能为null
     */
    public static String signUp(RedisService redisService, Long requestUid) {
        final String key = RedisKeyUtil.obtainKey(RedisKeyConstant.REDIS_USER_HASH_KEY, requestUid);
        String signUpTime = redisService.hget(key, RedisKeyConstant.REDIS_USER_HASH_SIGN_UP);
        if ("null".equals(signUpTime)) {
            redisService.hDel(key, RedisKeyConstant.REDIS_USER_HASH_SIGN_UP);
            return null;
        }
        return signUpTime;
    }

    /**
     * 获取用户活跃时间
     * 先从画像中获取,如果为空或null的空串,则从之前的hash中获取,如果获取到,则更新到画像中
     *
     * @param redisService redisService
     * @param uid          用户id
     * @return 用户活跃时间 有可能为null
     */
    public static String activityTime(RedisService redisService, Long uid) {
        final String key = RedisKeyUtil.obtainKey(RedisKeyConstant.REDIS_USER_HASH_KEY, uid);
        final String actTime = redisService.hget(key, RedisKeyConstant.REDIS_USER_HASH_ACTIVITY_TIME);
        if ("null".equals(actTime)) {//dirty data
            redisService.hDel(key, RedisKeyConstant.REDIS_USER_HASH_ACTIVITY_TIME);
            return null;
        }
        return actTime;
    }

    /**
     * 批量获取用户活跃时间
     *
     * @param redisService redisService
     * @param uids         用户id list
     * @return {uid:activityTime}
     */
    public static Map<String, String> activityTimeList(RedisService redisService, List<String> uids) {
        final RedisSerializer<String> redisSerializer = redisService.getRedisTemplate().getStringSerializer();
        final List<Object> objects = redisService.execPipelineForRead(connection -> {
            for (String id : uids) {
                redisSerializer.deserialize(
                        connection.hGet(RedisKeyUtil.obtainKey(RedisKeyConstant.REDIS_USER_HASH_KEY, id).getBytes(charset),
                                RedisKeyConstant.REDIS_USER_HASH_ACTIVITY_TIME.getBytes(charset))
                );
            }
            return null;
        });
        Map<String, String> actMap = Maps.newHashMap();
        final int size = uids.size();
        for (int i = 0; i < size; i++) {
            final Object act = objects.get(i);
            final String uid = uids.get(i);
            if (act == null || "null".equals(act.toString())) {
                actMap.put(uid, null);
            } else {
                actMap.put(uid, act.toString());
            }
        }
        return actMap;
    }

    /**
     * 获取用户的地理位置
     *
     * @param redisService redisService
     * @param uid          uid
     * @return 经纬度
     */
    public static UserGeo userGeo(RedisService redisService, String uid) {
        try {
            final List<String> list = redisService.hmget(RedisKeyUtil.obtainKey(RedisKeyConstant.REDIS_USER_HASH_KEY, uid),
                    Lists.newArrayList(RedisKeyConstant.REDIS_USER_HASH_LONGITUDE, RedisKeyConstant.REDIS_USER_HASH_LATITUDE));
            String longitude = list.get(0);
            String latitude = list.get(1);
            if (!StringUtils.isEmpty(longitude) && !StringUtils.isEmpty(latitude)
                    && !"null".equals(longitude) && !"null".equals(latitude)) {
                return UserGeo.builder().longitude(Double.parseDouble(longitude)).latitude(Double.parseDouble(latitude)).build();
            }
        } catch (Exception e) {
            log.error(e.getMessage(), e);
        }
        return null;
    }

    /**
     * 批量获取用户的地理位置
     * 先从画像中获取,获取不到从之前的set中获取
     *
     * @param redisService redisService
     * @param uids         uids
     * @return {uid:经纬度}
     */
    public static Map<String, UserGeo> userGeoMap(RedisService redisService, List<String> uids) {
        final List<Object> objects = redisService.execPipelineForRead(connection -> {
            for (String uid : uids) {
                connection.hMGet(RedisKeyUtil.obtainKey(RedisKeyConstant.REDIS_USER_HASH_KEY, uid).getBytes(charset),
                        RedisKeyConstant.REDIS_USER_HASH_LONGITUDE.getBytes(charset),
                        RedisKeyConstant.REDIS_USER_HASH_LATITUDE.getBytes(charset));
            }
            return null;
        });
        Map<String, UserGeo> userGeoMap = Maps.newHashMap();
        final int size = uids.size();
        for (int i = 0; i < size; i++) {
            final String uid = uids.get(i);
            final Object object = objects.get(i);
            final List<Double> list = CommonUtil.obj2ListDouble(object);
            if (CollectionUtils.isEmpty(list)) {
                userGeoMap.put(uid, null);
                continue;
            }
            Double longitude = list.get(0);
            Double latitude = list.get(1);
            if (longitude == null || latitude == null) {
                userGeoMap.put(uid, null);
                continue;
            }
            userGeoMap.put(uid, UserGeo.builder()
                    .latitude(latitude)
                    .longitude(longitude)
                    .build());
        }
        return userGeoMap;
    }

    /**
     * 批量获取用户的性别
     *
     * @param redisService redisService
     * @param recallUids   uids
     * @return {uid:经纬度}
     */
    public static Map<Long, Integer> selectGenders(RedisService redisService, List<String> recallUids) {
        Map<Long, Integer> map = Maps.newHashMap();
        final List<Object> objects = redisService.execPipelineForRead(connection -> {
            for (String recallUid : recallUids) {
                connection.hGet(RedisKeyUtil.obtainKey(RedisKeyConstant.REDIS_USER_HASH_KEY, recallUid).getBytes(charset),
                        RedisKeyConstant.REDIS_USER_HASH_GENDER.getBytes(charset));
            }
            return null;
        });
        final int size = recallUids.size();
        for (int i = 0; i < size; i++) {
            final String recallUid = recallUids.get(i);
            final Object obj = objects.get(i);
            if (obj == null || "null".equals(obj.toString())) {
                map.put(Long.valueOf(recallUid), null);
                continue;
            }
            map.put(Long.valueOf(recallUid), Integer.valueOf(obj.toString()));
        }
        return map;
    }

    /**
     * 批量查询用户的受欢迎程度
     *
     * @param redisService redisService
     * @param recallUids   id list
     * @return {uid:popular}
     */
    public static Map<String, Double> selectPopularMap(RedisService redisService, List<String> recallUids) {
        final List<Object> objects = redisService.execPipelineForRead(connection -> {
            for (String uid : recallUids) {
                connection.hGet(RedisKeyUtil.obtainKey(RedisKeyConstant.REDIS_USER_HASH_KEY, uid).getBytes(charset),
                        RedisKeyConstant.REDIS_USER_HASH_POPULAR.getBytes(charset));
            }
            return null;
        });
        Map<String, Double> map = Maps.newHashMap();
        final int size = recallUids.size();
        for (int i = 0; i < size; i++) {
            final String uid = recallUids.get(i);
            final Object obj = objects.get(i);
            if (obj == null) {
                map.put(uid, null);
                continue;
            }
            map.put(uid, Double.valueOf(obj.toString()));
        }
        return map;
    }

    public static Double userMatchNum(RedisService redisService, Long uid) {
        try {
            final String num = redisService.hget(RedisKeyUtil.obtainKey(RedisKeyConstant.REDIS_USER_HASH_KEY, uid),
                    RedisKeyConstant.REDIS_USER_HASH_MATCH_NUM);
            return Double.valueOf(num);
        } catch (Exception e) {
            return 0D;
        }
    }

    public static Map<String, Double> userMatchNumMap(RedisService redisService, List<String> recallUids) {
        final List<Object> objects = redisService.execPipelineForRead(connection -> {
            for (String recallUid : recallUids) {
                connection.hGet(RedisKeyUtil.obtainKey(RedisKeyConstant.REDIS_USER_HASH_KEY, recallUid).getBytes(charset),
                        RedisKeyConstant.REDIS_USER_HASH_MATCH_NUM.getBytes(charset));
            }
            return null;
        });
        Map<String, Double> map = Maps.newHashMap();
        final int size = recallUids.size();
        for (int i = 0; i < size; i++) {
            final String recallUid = recallUids.get(i);
            final Object num = objects.get(i);
            if (num == null) {
                map.put(recallUid, 0D);
                continue;
            }
            map.put(recallUid, CommonUtil.null2Double(num));
        }
        return map;
    }

    /**
     * 获取用户的年龄 先获取age字段,若无,通过生日算年龄 查询不到默认为空
     *
     * @param uids 用户列表
     * @return 年龄列表
     */
    public static Map<String, Integer> ageMap(RedisService redisService, List<String> uids) {
        Map<String, Integer> ageMap = Maps.newHashMap();
        if (CollectionUtils.isEmpty(uids)) return ageMap;
        //获取用户的年龄
        final List<Object> objects = redisService.execPipelineForRead(connection -> {
            for (String uid : uids) {
                connection.hGet(RedisKeyUtil.obtainKey(RedisKeyConstant.REDIS_USER_HASH_KEY, uid).getBytes(StandardCharsets.UTF_8),
                        RedisKeyConstant.REDIS_USER_HASH_AGE.getBytes(StandardCharsets.UTF_8));
            }
            return null;
        });
        int size = uids.size();
        List<String> notInList = Lists.newArrayList();
        for (int i = 0; i < size; i++) {
            String uid = uids.get(i);
            final Object obj = objects.get(i);
            if (obj == null) {
                notInList.add(uid);
                continue;
            }
            ageMap.put(uid, (Integer) obj);
        }
        if (CollectionUtils.isEmpty(notInList)) return ageMap;

        List<Object> birthImageList = redisService.execPipelineForRead(connection -> {
            for (String id : notInList) {
                connection.hGet(RedisKeyUtil.obtainKey(RedisKeyConstant.REDIS_USER_HASH_KEY, id).getBytes(charset),
                        RedisKeyConstant.REDIS_USER_HASH_BIRTH_TIMESTAMP.getBytes(charset));
            }
            return null;
        });

        int imageSize = notInList.size();
        for (int i = 0; i < imageSize; i++) {
            Object obj = birthImageList.get(i);
            String id = notInList.get(i);
            if (obj == null) {
                ageMap.put(id, null);
                continue;
            }
            ageMap.put(id, DateUtil.getAge(obj.toString()));
        }
        return ageMap;
    }
}
