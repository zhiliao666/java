package com.ufoto.dto;

import lombok.Data;

import java.io.Serializable;
import java.util.Set;

/**
 * <p>
 * Author     : Chan
 * CreateDate : 2019/11/20 11:14
 * Description:
 * </p>
 */
@Data
public class FilterStrategyDto implements Serializable {

    private Set<String> recallUids;

    private RecommendAdvanceRequest request;

}
