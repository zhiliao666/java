package com.ufoto.business.recommend.sort.age;

import com.google.common.collect.Lists;
import com.ufoto.annotation.RecommendMetadata;
import com.ufoto.business.recommend.bean.SortParamsBean;
import com.ufoto.business.recommend.sort.BaseNormalSortStrategy;
import com.ufoto.utils.KeyTransitionUtil;
import com.ufoto.utils.redis.RedisService;
import lombok.extern.slf4j.Slf4j;
import org.springframework.stereotype.Component;

import java.util.HashMap;
import java.util.List;
import java.util.Map;

/**
 * Created by echo on 4/8/18.
 */
@RecommendMetadata(
        metadataType = RecommendMetadata.MetadataType.SORT,
        available = true,
        name = "与自己年龄差值排序策略",
        description = "如果用户的生日不存在,默认为1分.此外,计算公式为result=1-abs(selfBirthMills-birthMills)/10YMills,小于0则默认0",
        branch = RecommendMetadata.Branch.NORMAL
)
@Slf4j
@Component
public class AgeDiffSelfSortStrategy extends BaseNormalSortStrategy {
    private final static long age10Years = 10L;
    private final RedisService redisService;

    public AgeDiffSelfSortStrategy(RedisService redisService) {
        this.redisService = redisService;
    }

    /**
     * 返回对应用户和发起请求用户的年龄差距，并以10年作为最大范围进行归一化
     */
    @Override
    public Map<String, Double> getScore(List<String> recallUids, SortParamsBean sortParamsBean) {
        final String uid = sortParamsBean.getUid() + "";
        //复制一份
        List<String> tempList = Lists.newArrayList(recallUids);
        tempList.add(uid);
        Map<String, Integer> ageMap = KeyTransitionUtil.ageMap(redisService, tempList);
        log.debug("ageMap:{}", ageMap);
        int userAge = ageMap.get(uid) == null ? 0 : ageMap.get(uid);
        Map<String, Double> scoreMap = new HashMap<>();
        for (final String recallUid : recallUids) {
            final Integer age = ageMap.get(recallUid);
            if (age == null) {
                scoreMap.put(recallUid, 1d);
                continue;
            }
            double result = 1 - Math.abs(userAge - age) / age10Years;//10年，修改请同时修改上方注释
            scoreMap.put(recallUid, result);
        }
        return scoreMap;
    }
}
