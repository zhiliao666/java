package com.ufoto.business.recommend.sort.activeTime;

import com.ufoto.annotation.RecommendMetadata;
import com.ufoto.business.recommend.bean.SortParamsBean;
import com.ufoto.business.recommend.sort.BaseNormalSortStrategy;
import com.ufoto.utils.DateUtil;
import com.ufoto.utils.KeyTransitionUtil;
import com.ufoto.utils.redis.RedisService;
import lombok.extern.slf4j.Slf4j;
import org.springframework.core.env.Environment;
import org.springframework.stereotype.Component;

import java.util.HashMap;
import java.util.List;
import java.util.Map;

/**
 * Created by echo on 4/8/18.
 */
@RecommendMetadata(
        metadataType = RecommendMetadata.MetadataType.SORT,
        available = true,
        name = "按指定的活跃时间排序策略",
        description = "活跃时间超过8小时以上者得1分.默认8小时",
        branch = RecommendMetadata.Branch.NORMAL
)
@Slf4j
@Component
public class LastActiveTimeTooEarlySortStrategy extends BaseNormalSortStrategy {

    private final RedisService redisService;
    private final Environment env;

    public LastActiveTimeTooEarlySortStrategy(RedisService redisService,
                                              Environment env) {
        this.redisService = redisService;
        this.env = env;
    }

    /**
     * 如果对应用户的上次活跃时间超过阈值，返回1,否则返回0
     */
    @Override
    public Map<String, Double> getScore(List<String> recallUids, SortParamsBean sortParamsBean) {
        int threshold = env.getProperty("recommend.sort.LastActiveTimeTooEarlySortStrategy.threshold", Integer.class, 60 * 60 * 8);//默认8小时
        Integer currentTime = DateUtil.getCurrentSecondIntValue();
        final Map<String, String> actMap = KeyTransitionUtil.activityTimeList(redisService, recallUids);
        Map<String, Double> scoreMap = new HashMap<>();
        final int size = recallUids.size();
        for (int i = 0; i < size; i++) {
            final String recallUid = recallUids.get(i);
            final String activityTime = actMap.get(recallUid);
            if (activityTime == null) {
                scoreMap.put(recallUid, 0d);
                continue;
            }
            try {
                double result;
                Double activityTimeDouble = Double.valueOf(activityTime);
                result = Math.abs(currentTime - activityTimeDouble) > threshold ? 1D : 0D;
                scoreMap.put(recallUid, result);
            } catch (NumberFormatException e) {
                log.error("activity time format error:user_" + recallUids + ",userBirthTimeStr_" + activityTime);
            }
        }
        return scoreMap;
    }
}
