package com.ufoto.business.elasticsearch.dto;

import lombok.Builder;
import lombok.Data;
import lombok.experimental.Tolerate;

import java.io.Serializable;
import java.util.List;

/**
 * @author luozq
 * @date 2020/4/7 13:50
 */
@Data
@Builder
public class ImageReCallDto implements Serializable {

    private Integer minActiveTime;

    private List<Long> uidList;

    @Tolerate
    public ImageReCallDto() {

    }
}
