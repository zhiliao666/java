package com.ufoto.business.recommend.filter;

import com.github.benmanes.caffeine.cache.LoadingCache;
import com.google.common.collect.Sets;
import com.ufoto.dto.RecommendAdvanceRequest;
import com.ufoto.utils.CommonUtil;
import com.ufoto.utils.json.JSONUtil;
import com.ufoto.utils.redis.RedisKeyConstant;
import com.ufoto.utils.redis.RedisService;
import com.ufoto.utils.threadlocal.ThreadLocalManager;
import lombok.extern.slf4j.Slf4j;
import org.springframework.core.env.Environment;
import org.springframework.stereotype.Component;
import org.springframework.util.CollectionUtils;

import java.util.HashSet;
import java.util.Optional;
import java.util.Set;

/**
 * Created by echo on 6/11/19.
 */
@Slf4j
@Component
public class FilterUtil {
    private final RedisService redisService;
    private final Environment env;
    private final LoadingCache<Class<?>, Object> recommendLoadingCache;

    public FilterUtil(RedisService redisService,
                      Environment env,
                      LoadingCache<Class<?>, Object> recommendLoadingCache) {
        this.redisService = redisService;
        this.env = env;
        this.recommendLoadingCache = recommendLoadingCache;
    }

    /**
     * 针对部分过滤策略需要排除已经like我的人
     */
    public Set<String> whoLikedMe(RecommendAdvanceRequest request) {
        Long uid = request.getUid();
        final Set<String> cache = ThreadLocalManager.whoLikeMeThreadLocal();
        if (cache != null) {
            return cache;
        }
        //这里其实可以用ThreadLocal来做缓存，减少对象生成，减少IO，提高速度
        boolean ifNeedScan = env.getProperty("recommend.filter.FilterUtil.excludeWhoLikedMe.ifNeedScan", Boolean.class, true);
        Set<String> whoLikedMe = Sets.newHashSet();
        whoLikedMe.addAll(
                Optional.ofNullable(
                        redisService.sMember(RedisKeyConstant.REDIS_BE_LIKED_TEMP_SET_KEY_ + uid, ifNeedScan))
                        .orElse(new HashSet<>()));
        whoLikedMe.addAll(
                Optional.ofNullable(
                        redisService.sMember(RedisKeyConstant.REDIS_BE_SUPER_LIKED_TEMP_SET_KEY_ + uid, ifNeedScan))
                        .orElse(new HashSet<>()));
        //放入缓存
        ThreadLocalManager.whoLikeMeThreadLocal(whoLikedMe);
        log.debug("currentThread:{},request:{},whoLikedMe:{}", Thread.currentThread(), JSONUtil.toJSON(request), whoLikedMe);
        return whoLikedMe;
    }

    public Set<String> filterExcludeWhoLikedMe(RecommendAdvanceRequest filterRequest,
                                               Set<String> recallSet,
                                               Class<?> cls) {
        if (CollectionUtils.isEmpty(recallSet)) {
            return Sets.newHashSet();
        }
        Set<String> result = Sets.newHashSet(recallSet);
        final Set<String> updateCacheField = Sets.newHashSet(CommonUtil.obj2Set(recommendLoadingCache.get(cls)));
        final Set<String> whoLikedMe = whoLikedMe(filterRequest);
        updateCacheField.removeAll(whoLikedMe);
        result.removeAll(updateCacheField);
        return result;
    }

    public Set<String> filter(Set<String> recallSet, Class<?> cls) {
        if (CollectionUtils.isEmpty(recallSet)) {
            return recallSet;
        }
        Set<String> result = Sets.newHashSet(recallSet);
        result.removeAll(CommonUtil.obj2Set(recommendLoadingCache.get(cls)));
        return result;
    }

}
