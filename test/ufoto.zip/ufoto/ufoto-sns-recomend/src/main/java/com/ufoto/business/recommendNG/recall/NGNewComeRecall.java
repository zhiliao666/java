package com.ufoto.business.recommendNG.recall;

import com.github.benmanes.caffeine.cache.LoadingCache;
import com.google.common.collect.Maps;
import com.google.common.collect.Sets;
import com.ufoto.annotation.RecommendMetadata;
import com.ufoto.business.recommendNG.Recall;
import com.ufoto.dto.RecommendAdvanceRequest;
import com.ufoto.utils.CommonUtil;
import com.ufoto.utils.redis.RedisKeyConstant;
import com.ufoto.utils.redis.RedisService;
import lombok.extern.slf4j.Slf4j;
import org.springframework.stereotype.Component;

import java.util.*;

/**
 * 低曝光用户区分大区 性别
 * Created by echo on 5/11/18.
 */
@RecommendMetadata(
        metadataType = RecommendMetadata.MetadataType.RECALL,
        available = true,
        updateCache = true,
        name = "低曝光用户召回策略",
        description = "召回所有低曝光的用户",
        branch = RecommendMetadata.Branch.NORMAL
)
@Slf4j
@Component
public class NGNewComeRecall implements Recall {

    //区分性别 -1 代表全部
    private final RedisService redisService;
    private final LoadingCache<Class<?>, Object> recommendLoadingCache;

    public NGNewComeRecall(RedisService redisService,
                           LoadingCache<Class<?>, Object> recommendLoadingCache) {
        this.redisService = redisService;
        this.recommendLoadingCache = recommendLoadingCache;
    }

    @Override
    public Set<String> recall(Integer minSize, RecommendAdvanceRequest recallRequest) {
        final Map<Integer, Set<String>> updateCacheField = CommonUtil.obj2MapSet(recommendLoadingCache.get(this.getClass()));
        if (!Objects.equals(1, recallRequest.getGender()) && !Objects.equals(2, recallRequest.getGender())) {
            return Sets.newHashSet(updateCacheField.getOrDefault(-1, Sets.newHashSet()));
        }
        //获取对应的性别的低曝光用户
        return Sets.newHashSet(updateCacheField.getOrDefault(recallRequest.getGender(), Sets.newHashSet()));
    }

    @Override
    public boolean ifRecallOnlyOnce() {
        return true;
    }

    @Override
    public boolean ifNeedThreadLocalCache() {
        return false;
    }

    public Map<Integer, Set<String>> updateCache() {
        final Map<Integer, Set<String>> updateCacheField = Maps.newConcurrentMap();
        Set<String> allRecallSet = Optional.ofNullable(redisService.sMember(RedisKeyConstant.REDIS_NEW_COME_USER_SET_KEY, true)).orElse(new HashSet<>());
        Set<String> maleRecallSet = Optional.ofNullable(redisService.sMember(RedisKeyConstant.REDIS_NEW_COME_USER_SET_KEY_MALE, true)).orElse(new HashSet<>());
        Set<String> femaleRecallSet = Optional.ofNullable(redisService.sMember(RedisKeyConstant.REDIS_NEW_COME_USER_SET_KEY_FEMALE, true)).orElse(new HashSet<>());
        updateCacheField.put(-1, allRecallSet);
        updateCacheField.put(1, maleRecallSet);
        updateCacheField.put(2, femaleRecallSet);
        return updateCacheField;
    }

}
