package com.ufoto.business.recommend.filter.recommended;

import com.google.common.collect.Sets;
import com.ufoto.bloom.RecommendedRecommendBloomFilter;
import com.ufoto.business.recommend.RecommendFilterStrategy;
import com.ufoto.dto.RecommendAdvanceRequest;
import com.ufoto.utils.redis.RedisKeyConstant;
import com.ufoto.utils.redis.RedisService;
import lombok.RequiredArgsConstructor;
import org.springframework.stereotype.Component;
import org.springframework.util.CollectionUtils;

import java.util.List;
import java.util.Set;

/**
 * <p>
 * 随机匹配使用--不涉及正常的召回流程
 * </p>
 *
 * @author created by chenzhou at 2018-08-16 17:05
 */
@RequiredArgsConstructor
@Component
public class RandomMatchRecommendedFilterStrategy implements RecommendFilterStrategy {

    private final RedisService redisService;
    private final RecommendedRecommendBloomFilter recommendedRecommendBloomFilter;


    @Override
    public Set<String> filter(Set<String> recallSet, List<String> resultList, RecommendAdvanceRequest filterRequest) {
        if (CollectionUtils.isEmpty(recallSet)) {
            return Sets.newHashSet();
        }
        return filterByBF(recallSet, filterRequest);
    }

    private Set<String> filterByBF(Set<String> recallSet, RecommendAdvanceRequest filterRequest) {
        Long uid = filterRequest.getUid();
        recallSet = recommendedRecommendBloomFilter.filter(uid, recallSet);

        recallSet = redisService.setDiff(RedisKeyConstant.REDIS_BE_LIKED_SET_KEY_ + uid, recallSet);
        recallSet = redisService.setDiff(RedisKeyConstant.REDIS_BE_SUPER_LIKED_SET_KEY_ + uid, recallSet);
        recallSet = redisService.setDiff(RedisKeyConstant.REDIS_BE_UN_LIKED_SET_KEY_NEW + uid, recallSet);

        return recallSet;
    }
}
