package com.ufoto.business.recommend;

import com.ufoto.dto.RecommendAdvanceRequest;

import java.util.List;

/**
 * Created by echo on 3/31/18.
 * <p>
 * 推荐的核心类，
 * 组织用户分流
 * 具体算法选用
 * <p>
 * 结果保存在resultListKey中
 */
public interface RecommendCore {

    /**
     * 进行推荐，将结果保存在Redis的resultListKey中
     */
    void doRecommend(String resultListKey, RecommendAdvanceRequest recommendAdvanceRequest);

    List<String> doRecommendAndGetResult(String resultListKey, RecommendAdvanceRequest recommendAdvanceRequest, int start, int end);
    
    /**
     * 获取wink推荐结果
     * @param resultListKey
     * @param recommendAdvanceRequest
     * @return
     */
    List<String> doWinkRecommendAndGetResult(String resultListKey, RecommendAdvanceRequest recommendAdvanceRequest);
    /**
     * 处理wink推荐结果
     * @param resultListKey
     * @param recommendAdvanceRequest
     */
    void doWinkRecommend(String resultListKey, RecommendAdvanceRequest recommendAdvanceRequest);
}
