package com.ufoto.business.recommend.sort;

import com.ufoto.annotation.RecommendMetadata;
import com.ufoto.business.recommend.bean.SortParamsBean;
import com.ufoto.business.recommend.sort.BaseNormalSortStrategy;
import lombok.extern.slf4j.Slf4j;
import org.springframework.stereotype.Component;

import java.util.HashMap;
import java.util.List;
import java.util.Map;

/**
 * 无需过滤策略
 *
 * @author zhangqh  
 * @date Apr 10, 2020 1:58:18 PM  
 * @version 1.0
 */
@RecommendMetadata(
        metadataType = RecommendMetadata.MetadataType.SORT,
        available = true,
        name = "无需排序策略",
        description = "排序的时候判断是否存在该类，存在则无需排序",
        branch = RecommendMetadata.Branch.NORMAL
)
@Slf4j
@Component
public class NoSortStrategy extends BaseNormalSortStrategy {

    
    @Override
    public Map<String, Double> getScore(List<String> recallUids, SortParamsBean sortParamsBean) {
        Map<String, Double> scoreMap = new HashMap<>();
        for (final String recallUid : recallUids) {
                scoreMap.put(recallUid, 1d);
        }
        return scoreMap;
    }
}
