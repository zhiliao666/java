package com.ufoto.converter;

import com.ufoto.business.usercenter.dto.UserBaseInfoDto;
import com.ufoto.entity.UfotoAppUser;
import com.ufoto.utils.BeanUtil;

import java.util.List;
import java.util.stream.Collectors;

/**
 * <p>
 * Author     : Chan
 * CreateDate : 2019-03-20 18:32
 * Description:
 * </p>
 */
public class UserCenterConverter {

    public static UfotoAppUser userBaseInfo2UfotoAppUser(UserBaseInfoDto userBaseInfo) {
        if (userBaseInfo == null) return null;
        return BeanUtil.copyPropertiesByNotNull(userBaseInfo, new UfotoAppUser());
    }

    public static List<UfotoAppUser> userBaseInfos2UfotoAppUsers(List<UserBaseInfoDto> userBaseInfos) {
        return userBaseInfos.stream().map(userBaseInfo -> BeanUtil.copyPropertiesByNotNull(userBaseInfo, new UfotoAppUser())).collect(Collectors.toList());
    }

}
