package com.ufoto.config.disruptor.data;

import java.io.Serializable;

/**
 * <p>
 * Description:
 *
 * </p>
 *
 * @author Chan
 * @date 2019/12/21 15:11
 */
public class AsyncData implements Serializable {

}
