package com.ufoto.dto;

import java.io.Serializable;

/**
 * @auther: zhangjq
 * @date: 2018/11/7 13:31
 * @description:
 */
public class UfotoSubUser implements Serializable {
    private static final long serialVersionUID = 1L;
    private Long uid;
    private Integer type;

    public Long getUid() {
        return uid;
    }

    public void setUid(Long uid) {
        this.uid = uid;
    }

    public Integer getType() {
        return type;
    }

    public void setType(Integer type) {
        this.type = type;
    }
}
