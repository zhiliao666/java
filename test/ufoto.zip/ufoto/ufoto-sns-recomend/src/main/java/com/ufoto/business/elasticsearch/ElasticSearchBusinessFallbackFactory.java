package com.ufoto.business.elasticsearch;

import com.ufoto.infrastructrue.statistics.AbstractFallbackFactory;
import org.springframework.stereotype.Component;

/**
 * <p>
 * Author     : Chan
 * CreateDate : 2019-09-05 17:33
 * Description:
 * </p>
 */
@Component
public class ElasticSearchBusinessFallbackFactory extends AbstractFallbackFactory<ElasticSearchBusiness> {

    private final ElasticSearchBusinessHystrix elasticSearchBusinessHystrix;

    public ElasticSearchBusinessFallbackFactory(ElasticSearchBusinessHystrix elasticSearchBusinessHystrix) {
        this.elasticSearchBusinessHystrix = elasticSearchBusinessHystrix;
    }

    @Override
    protected ElasticSearchBusiness doCreate() {
        return elasticSearchBusinessHystrix;
    }
}
