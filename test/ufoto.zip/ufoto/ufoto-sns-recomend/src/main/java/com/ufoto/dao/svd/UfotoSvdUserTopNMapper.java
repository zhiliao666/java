package com.ufoto.dao.svd;

import com.ufoto.dao.base.BaseUfotoSvdUserTopNMapper;
import org.apache.ibatis.annotations.Mapper;
import org.apache.ibatis.annotations.Param;
import org.apache.ibatis.annotations.Select;
import org.apache.ibatis.annotations.Update;

import java.util.List;

@Mapper
public interface UfotoSvdUserTopNMapper extends BaseUfotoSvdUserTopNMapper {


    @Select("SELECT i_id FROM ufoto_svd_user_top_n WHERE u_id = #{uid} ORDER BY rank LIMIT #{limit} OFFSET #{offset}")
    List<Long> selectTopNByUid(@Param("uid") Long uid, @Param("limit") Integer limit, @Param("offset") Integer offset);

    @Select("SELECT count(*) FROM ufoto_svd_user_top_n WHERE u_id = #{uid} ")
    Long selectTopNCountByUid(@Param("uid") Long uid);


    @Select("SELECT i_id FROM ufoto_area_svd_user_top_n WHERE u_id = #{uid} ORDER BY rank LIMIT #{limit} OFFSET #{offset}")
    List<Long> selectAreaTopNByUid(@Param("uid") Long uid, @Param("limit") Integer limit, @Param("offset") Integer offset);

    @Select("SELECT i_id FROM ufoto_area_svd_2_user_top_n WHERE u_id = #{uid} ORDER BY rank LIMIT #{limit} OFFSET #{offset}")
    List<Long> selectArea2TopNByUid(@Param("uid") Long uid, @Param("limit") Integer limit, @Param("offset") Integer offset);

    @Select("SELECT count(*) FROM ufoto_area_svd_user_top_n WHERE u_id = #{uid} ")
    Long selectAreaTopNCountByUid(@Param("uid") Long uid);


    @Select("SELECT i_id FROM ufoto_svd_user_top_n_match WHERE u_id = #{uid} ORDER BY rank LIMIT #{limit} OFFSET #{offset}")
    List<Long> selectTopNMatchByUid(@Param("uid") Long uid, @Param("limit") Integer limit, @Param("offset") Integer offset);

    @Select("SELECT i_id FROM ufoto_svd_2_user_top_n_match WHERE u_id = #{uid} ORDER BY rank LIMIT #{limit} OFFSET #{offset}")
    List<Long> selectTopNMatch2ByUid(@Param("uid") Long uid, @Param("limit") Integer limit, @Param("offset") Integer offset);


    @Select("SELECT count(*) FROM ufoto_svd_user_top_n_match WHERE u_id = #{uid} ")
    Long selectTopNMatchCountByUid(@Param("uid") Long uid);

    @Update("CREATE TABLE IF NOT EXISTS `ufoto_svd_user_top_n` (\n" +
            "  `id` int(11) NOT NULL AUTO_INCREMENT,\n" +
            "  `u_id` bigint(20) NOT NULL,\n" +
            "  `i_id` bigint(20) NOT NULL,\n" +
            "  `rank` int(11) NOT NULL,\n" +
            "  PRIMARY KEY (`id`),\n" +
            "   UNIQUE KEY `idx_unique_uid_rank` (`u_id`,`rank`) USING BTREE" +
            ") ENGINE=InnoDB DEFAULT CHARSET=utf8mb4")
    void createIfNotExistsTable();

    @Update("CREATE TABLE IF NOT EXISTS `ufoto_svd_user_top_n_#{shardIndex}` (\n" +
            "  `id` int(11) NOT NULL AUTO_INCREMENT,\n" +
            "  `u_id` bigint(20) NOT NULL,\n" +
            "  `i_id` bigint(20) NOT NULL,\n" +
            "  `rank` int(11) NOT NULL,\n" +
            "  PRIMARY KEY (`id`),\n" +
            "  UNIQUE KEY `idx_unique_uid_rank` (`u_id`,`rank`) USING BTREE" +
            ") ENGINE=InnoDB DEFAULT CHARSET=utf8mb4")
    void createIfNotExistsShardingTable(@Param("shardIndex") Integer shardIndex);

    @Update("DROP TABLE IF EXISTS ufoto_svd_user_top_n")
    void dropTable();

    @Select("SHOW TABLES")
    List<String> showTables();
}
