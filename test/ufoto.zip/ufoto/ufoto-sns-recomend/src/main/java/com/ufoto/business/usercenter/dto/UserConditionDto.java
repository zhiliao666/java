package com.ufoto.business.usercenter.dto;

import lombok.Data;

import java.io.Serializable;
import java.util.List;

@Data
public class UserConditionDto implements Serializable {
    private List<Long> uids;//id列表
    private Integer isDelete;//是否已删除
    private Integer legitimateEmail;//邮箱是否合法
    private Integer type;//用户类型0 robot 1 fb 2 gg

    private Long minUid;//最小的id
    private Integer startCreateTime;//开始创建时间
    private Integer endCreateTime;//结束创建时间
}