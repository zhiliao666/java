package com.ufoto.utils;

/**
 * <p>
 * Description:
 *
 * </p>
 *
 * @author Chan
 * @date 2019/12/21 13:36
 */
public class BloomFilterUtil {

    public static int optimalNumOfHashFunctions(long n, long m) {
        return Math.max(1, (int) Math.round((double) m / n * Math.log(2)));
    }

    public static long optimalNumOfBits(long n, double p) {
        if (p == 0) {
            p = Double.MIN_VALUE;
        }
        return (long) (-n * Math.log(p) / (Math.log(2) * Math.log(2)));
    }

    public static void main(String[] args) {
        final int expectedInsertions = 1000;
        final double falseProbability = 1e-7;
        final long size = BloomFilterUtil.optimalNumOfBits(expectedInsertions, falseProbability);
        final int hashIterations = BloomFilterUtil.optimalNumOfHashFunctions(expectedInsertions, size);
        int bitSize = 7935;
        final long count = Math.round(-size / ((double) hashIterations) * Math.log(1 - bitSize / ((double) size)));
        System.out.printf("expectedInsertions=%d\n" +
                        "falseProbability=%.7f\n" +
                        "size=%d\n" +
                        "sizeInKBytes=%f\n" +
                        "hash=%d\n" +
                        "count=%d\n",
                expectedInsertions, falseProbability, size, size * 1. / (8 * 1024), hashIterations, count);
    }
}
