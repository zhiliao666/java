package com.ufoto.business.recommend.logger;

/**
 * Created by echo on 3/31/18.
 */
public interface RecommendLogger {

    void loggingSimpleScore(Long requestUid, Long uid, Integer likeType);
}
