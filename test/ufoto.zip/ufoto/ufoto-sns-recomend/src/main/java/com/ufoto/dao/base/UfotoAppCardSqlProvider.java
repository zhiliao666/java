package com.ufoto.dao.base;

import com.google.common.base.Joiner;
import com.ufoto.dto.CardParam;

/**
 * <p>
 * Author     : Chan
 * CreateDate : 2018/10/9 16:41
 * Description:
 * </p>
 */
public class UfotoAppCardSqlProvider extends BaseUfotoAppCardSqlProvider {

    public String queryRandomCards(CardParam cardParam) {
        return "SELECT ac.* FROM ufoto_app_card ac\n" +
                "WHERE ac.is_delete=0 \n" +
                "AND ac.lang=#{lang} \n" +
                "AND ac.type IN (" + Joiner.on(",").join(cardParam.getTypeWhiteList()) + ") \n" +
                "AND NOT EXISTS (SELECT card_id FROM ufoto_app_card_record cr WHERE cr.`uid`=#{uid} AND cr.card_id=ac.id)\n" +
                "ORDER BY type_sub ASC LIMIT #{limit}";
    }

    public String queryRandomCardsWithTypeSubs(CardParam cardParam) {
        return "SELECT ac.* FROM ufoto_app_card ac\n" +
                "WHERE ac.is_delete=0 \n" +
                "AND ac.lang=#{lang} \n" +
                "AND ac.type IN (" + Joiner.on(",").join(cardParam.getTypeWhiteList()) + ") \n" +
                "AND NOT EXISTS (SELECT card_id FROM ufoto_app_card_record cr WHERE cr.`uid`=#{uid} AND cr.card_id=ac.id)\n" +
                "AND ac.type_sub NOT IN (" + Joiner.on(",").join(cardParam.getTypeSubs()) + ") \n" +
                "ORDER BY type_sub ASC LIMIT #{limit}";
    }

}
