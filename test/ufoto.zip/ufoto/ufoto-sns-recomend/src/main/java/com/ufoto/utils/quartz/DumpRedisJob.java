package com.ufoto.utils.quartz;

import com.ufoto.service.UfotoRecommendRedisDumpService;
import com.ufoto.utils.SpringContextUtil;
import lombok.extern.slf4j.Slf4j;
import org.quartz.DisallowConcurrentExecution;
import org.quartz.Job;
import org.quartz.JobExecutionContext;
import org.quartz.JobExecutionException;
import org.springframework.util.StopWatch;

@Slf4j
@DisallowConcurrentExecution
public class DumpRedisJob implements Job {
    @Override
    public void execute(JobExecutionContext context) throws JobExecutionException {
        try {
            StopWatch stopWatch = new StopWatch();
            stopWatch.start();
            log.debug("dumpRedis start...");
            UfotoRecommendRedisDumpService dumpService = SpringContextUtil.getBean(UfotoRecommendRedisDumpService.class);
            dumpService.dumpExpiredUserRedisData();
            stopWatch.stop();
            log.debug("dumpRedis success...\n {}", stopWatch.prettyPrint());
        } catch (Exception e) {
            log.error(e.getMessage(), e);
        }
    }
}
