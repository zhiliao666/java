package com.ufoto.business.recommend.shuffle.dealer;

import com.ufoto.annotation.RecommendMetadata;
import com.ufoto.business.recommend.shuffle.base.ShuffleDealer;
import org.apache.commons.lang.math.RandomUtils;

import java.security.InvalidParameterException;
import java.util.List;

/**
 * 构造时设置好Rate(0~1)，如果随机小于Rate,则从前面的列表读取数据
 * 目前只支持传入两个列表
 */
@RecommendMetadata(
        metadataType = RecommendMetadata.MetadataType.DEALER,
        available = true,
        name = "rate打散收集器",
        description = "按照指定的比例,将第一个list中的元素插入到第二个list中.",
        branch = RecommendMetadata.Branch.NORMAL
)
public class RandomByRateDealer implements ShuffleDealer {

    private float rate;

    public RandomByRateDealer(float rate) {
        this.rate = rate;
    }

    /**
     * @param cutUidList 只支持传入2个列表
     */
    @Override
    public String[] shuffleAndDeal(List<List<String>> cutUidList) {
        if (cutUidList.size() != 2) throw new InvalidParameterException("RandomByRateDealer:only tow list to accept.");

        int totalSize = cutUidList.stream().mapToInt(List::size).sum();
        String[] result = new String[totalSize];

        for (int i = 0; i < totalSize; i++) {
            float rand = RandomUtils.nextFloat();
            if ((rand < rate && cutUidList.get(0).size() > 0) || cutUidList.get(1).size() == 0) {
                result[i] = cutUidList.get(0).get(0);
                cutUidList.get(0).remove(0);
            } else {
                result[i] = cutUidList.get(1).get(0);
                cutUidList.get(1).remove(0);
            }
        }
        return result;
    }
}
