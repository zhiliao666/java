package com.ufoto.utils.redis;

import com.google.common.collect.Lists;
import com.google.common.collect.Maps;
import com.google.common.collect.Sets;
import com.google.common.collect.Streams;
import com.ufoto.utils.CommonUtil;
import lombok.extern.slf4j.Slf4j;
import org.springframework.beans.factory.annotation.Qualifier;
import org.springframework.core.env.Environment;
import org.springframework.data.redis.core.Cursor;
import org.springframework.data.redis.core.HashOperations;
import org.springframework.data.redis.core.RedisTemplate;
import org.springframework.data.redis.core.ScanOptions;
import org.springframework.stereotype.Component;
import org.springframework.util.CollectionUtils;

import java.util.Arrays;
import java.util.Date;
import java.util.List;
import java.util.Map;
import java.util.Optional;
import java.util.Set;
import java.util.stream.Collectors;

/**
 * <p>
 * Author     : Chan
 * CreateDate : 2019-08-27 13:51
 * Description:
 * </p>
 */
@Slf4j
@Component
public class RedisServiceObjServiceImpl implements RedisServiceObjService {


    private final RedisTemplate<String, Object> redisTemplate;
    private final Environment env;

    public RedisServiceObjServiceImpl(@Qualifier("objRedisTemplate") RedisTemplate<String, Object> redisTemplate,
                                      Environment env) {
        this.redisTemplate = redisTemplate;
        this.env = env;
    }

    @Override
    public RedisTemplate<String, Object> getRedisTemplate() {
        return redisTemplate;
    }

    @Override
    public Long sadd(String key, Object... values) {
        long count = 0;
        if (values.length == 0) {
            log.warn("redisServiceSAdd is empty, key:{}", key);
            return count;
        }
        final List<List<Object>> partition = Lists.partition(Arrays.asList(values), 1000);
        for (List<Object> part : partition) {
            final Long add = redisTemplate.opsForSet().add(key, part.toArray(new Object[]{}));
            count += (add == null ? 0 : add);
        }
        return count;
    }

    @Override
    public Long sremove(String key, Object... values) {
        return redisTemplate.opsForSet().remove(key, values);
    }

    @Override
    public Set<Long> smembers(String key, boolean scan) {
        if (!scan) {
            final Set<Object> members = redisTemplate.opsForSet().members(key);
            if (CollectionUtils.isEmpty(members)) return Sets.newHashSet();
            return members.stream().map(CommonUtil::obj2Long).collect(Collectors.toSet());
        } else {
            Set<Long> members = Sets.newHashSet();
            final Integer scanCount = env.getProperty("redisService.sMembersByScan.scanCount", Integer.class, 1000);
            final Cursor<Object> cursor = redisTemplate.opsForSet().scan(key, ScanOptions.scanOptions().match("*").count(scanCount).build());
            cursor.forEachRemaining(o -> members.add(CommonUtil.obj2Long(o)));
            return members;
        }
    }

    @Override
    public boolean sismember(String key, Object member) {
        final Boolean b = redisTemplate.opsForSet().isMember(key, member);
        return b != null && b;
    }

    @Override
    public Long hIncrBy(String key, String field, long increment) {
        return redisTemplate.opsForHash().increment(key, field, increment);
    }

    @Override
    public boolean expireAt(String key, Date date) {
        Boolean expire = redisTemplate.expireAt(key, date);
        return expire == null ? false : expire;
    }

    @Override
    public Map<String, Integer> hscanWithInteger(String key) {
        final HashOperations<String, String, Integer> hashOperations = redisTemplate.opsForHash();
        final Cursor<Map.Entry<String, Integer>> cursor = hashOperations.scan(key, ScanOptions.scanOptions()
                .count(env.getProperty("redis.scan.iter.count", Long.class, 1000L))
                .build());
        Map<String, Integer> resultMap = Maps.newHashMap();
        cursor.forEachRemaining(entry -> resultMap.put(entry.getKey(), entry.getValue()));
        return resultMap;
    }

    @Override
    public Map<String, Integer> hmgetWithInteger(String key, List<String> fields, int defaultIfNull) {
        final HashOperations<String, String, Integer> hashOperations = redisTemplate.opsForHash();
        final List<Integer> values = hashOperations.multiGet(key, fields);
        return Streams.zip(fields.stream(), values.stream(), Maps::immutableEntry)
                .collect(Collectors.toMap(Map.Entry::getKey, entry -> Optional.ofNullable(entry.getValue()).orElse(defaultIfNull)));
    }

    @Override
    public void delete(String key) {
        redisTemplate.delete(key);
    }
}
