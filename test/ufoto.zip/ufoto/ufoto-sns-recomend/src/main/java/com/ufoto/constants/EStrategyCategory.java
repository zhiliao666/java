package com.ufoto.constants;

public enum EStrategyCategory {
    RECALL("recall", "召回"),
    FILTER("filter", "过滤"),
    SORT("sort", "排序"),
    INVOKER("invoker", "召回者"),
    REAGENT("reagent", "候选成分");

    private String category;
    private String desc;

    EStrategyCategory(String category, String desc) {
        this.category = category;
        this.desc = desc;
    }

    public String getCategory() {
        return category;
    }

    public String getDesc() {
        return desc;
    }
}
