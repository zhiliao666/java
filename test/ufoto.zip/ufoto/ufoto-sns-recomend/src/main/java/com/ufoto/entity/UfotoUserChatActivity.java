package com.ufoto.entity;

import com.ufoto.entity.base.BaseUfotoUserChatActivity;

public class UfotoUserChatActivity extends BaseUfotoUserChatActivity {

    private static final long serialVersionUID = 1L;

}
