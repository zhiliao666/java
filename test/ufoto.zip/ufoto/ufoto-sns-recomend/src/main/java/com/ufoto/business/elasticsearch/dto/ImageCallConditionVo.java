package com.ufoto.business.elasticsearch.dto;

import lombok.Data;

import javax.validation.constraints.Max;
import java.util.List;

/**
 * @author luozq
 * @date 2020/4/7 13:04
 */
@Data
public class ImageCallConditionVo {

    private Integer gender;

    private Integer areaId;

    /**
     * 用户层级列表
     */
    private List<Integer> levelList;

    /**
     * 方圆多少km
     */
    private Double distance;

    /**
     * gps: array[longitude, latitude]
     */
    private List<Double> gps;

    /**
     * 年龄 [min, max]
     */
    private List<Integer> ageList;

    /**
     * 上次返回的活跃时间
     */
    private Integer lastActiveTime;

    /**
     * 返回条数, 限制为小于 1000
     */
    @Max(value = 1000, message = "最大查询 1000 条, 请减小查询数量.")
    private Integer limit = 10;

}
