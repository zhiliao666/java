package com.ufoto.business.recommendNG.ab;

import com.ufoto.utils.json.JSONUtil;
import com.ufoto.utils.redis.RedisKeyConstant;
import com.ufoto.utils.redis.RedisService;
import lombok.extern.slf4j.Slf4j;
import org.springframework.stereotype.Component;
import org.springframework.util.CollectionUtils;

import java.util.Map;

/**
 * Created by echo on 12/24/18.
 * <p>
 * 管理AB测试相关的业务
 * <p>
 * todo:临时为了解决循环依赖而独立出来，后续还要建立接口，并且管理各种相关代码
 * todo:例如将AB策略写入Redis,删除RecommendCore中的对应接口
 */
@Slf4j
@Component
public class AbTestManager {

    private final RedisService redisService;

    public AbTestManager(RedisService redisService) {
        this.redisService = redisService;
    }

    public Map<String, String> getStrategyPath(Long uid) {
        final Map<String, String> entries = redisService.hGetAll(RedisKeyConstant.REDIS_VARIANT_STRATEGY_PATH + uid);
        if (CollectionUtils.isEmpty(entries)) {
            return null;
        }
        log.debug("uidPath:{}", JSONUtil.toJSON(entries));
        return entries;//对应StrategyPathBeanExpand
    }
}
