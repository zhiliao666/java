package com.ufoto.business.recommend.logger;

import java.util.List;
import java.util.Map;

/**
 * Created by echo on 12/4/18.
 */
public interface XGBLogger {

    void log(List<Map<String, Float>> dataFrame, float[][] result, Long aUid, List<Long> bUidList);

    void error(List<String> recallUids, Long uid, String message);
}
