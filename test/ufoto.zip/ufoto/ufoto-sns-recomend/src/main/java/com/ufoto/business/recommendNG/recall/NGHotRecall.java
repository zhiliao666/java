package com.ufoto.business.recommendNG.recall;

import com.github.benmanes.caffeine.cache.LoadingCache;
import com.google.common.collect.Sets;
import com.ufoto.annotation.RecommendMetadata;
import com.ufoto.business.recommendNG.Recall;
import com.ufoto.dto.RecommendAdvanceRequest;
import com.ufoto.utils.CommonUtil;
import com.ufoto.utils.redis.RedisKeyConstant;
import com.ufoto.utils.redis.RedisService;
import lombok.extern.slf4j.Slf4j;
import org.springframework.stereotype.Component;

import java.util.HashSet;
import java.util.Optional;
import java.util.Set;

/**
 * Created by echo on 5/11/18.
 */
@RecommendMetadata(
        metadataType = RecommendMetadata.MetadataType.RECALL,
        available = true,
        updateCache = true,
        name = "热门用户召回策略",
        description = "召回所有热门用户",
        branch = {RecommendMetadata.Branch.NORMAL, RecommendMetadata.Branch.DEFAULT}
)
@Slf4j
@Component
public class NGHotRecall implements Recall {

    private final RedisService redisService;
    private final LoadingCache<Class<?>, Object> recommendLoadingCache;

    public NGHotRecall(RedisService redisService,
                       LoadingCache<Class<?>, Object> recommendLoadingCache) {
        this.redisService = redisService;
        this.recommendLoadingCache = recommendLoadingCache;
    }

    @Override
    public Set<String> recall(Integer minSize, RecommendAdvanceRequest recallRequest) {
        return Sets.newHashSet(CommonUtil.obj2Set(recommendLoadingCache.get(this.getClass())));
    }

    @Override
    public boolean ifRecallOnlyOnce() {
        return true;
    }

    @Override
    public boolean ifNeedThreadLocalCache() {
        return false;
    }

    public Set<String> updateCache() {
        return Optional.ofNullable(redisService.sMember(RedisKeyConstant.REDIS_HOT_USER_SET_KEY, true)).orElse(new HashSet<>());
    }

}
