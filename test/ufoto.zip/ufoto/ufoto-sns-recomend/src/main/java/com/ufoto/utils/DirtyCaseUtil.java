package com.ufoto.utils;

import com.ufoto.constants.EAppPackage;
import com.ufoto.constants.ESnsUserRisk;
import com.ufoto.dto.RecommendAdvanceRequest;
import com.ufoto.utils.redis.RedisKeyConstant;
import com.ufoto.utils.redis.RedisKeyUtil;
import com.ufoto.utils.redis.RedisService;
import com.ufoto.utils.redis.RedisServiceObjService;
import lombok.RequiredArgsConstructor;
import org.springframework.stereotype.Component;
import org.springframework.util.StringUtils;

import java.util.Objects;

/**
 * Created by echo on 5/22/19.
 * <p>
 * Deal with all the fucking stupid DIRTY CASE here
 */
@RequiredArgsConstructor
@Component
public class DirtyCaseUtil {

    private final static int GIFT_RECEIVE_CARD_DC = 1;

    private final RedisService redisService;
    private final RedisServiceObjService redisServiceObjService;

    /**
     * dirty case
     * 判断是否是Snap的新用户（没有性别或者别的情况）,
     * 然后对应情况做特殊处理
     */
    public boolean ifSnapNewUserRequest(RecommendAdvanceRequest recommendAdvanceRequest) {
        if (EAppPackage.SWEETSNAP_LITE_SNAPCHAT.getPackageName().equals(recommendAdvanceRequest.getCp())) {
            Long uid = recommendAdvanceRequest.getUid();
            if (uid == null) return false;
            // 判断用户是否有性别
            String genderStr = redisService.hget(RedisKeyUtil.obtainKey(RedisKeyConstant.REDIS_USER_HASH_KEY, uid),
                    RedisKeyConstant.REDIS_USER_HASH_GENDER);
            return StringUtils.isEmpty(genderStr) || genderStr.equals("0");
        }
        return false;
    }

    public boolean ifSnap(RecommendAdvanceRequest recommendAdvanceRequest) {
        return EAppPackage.SNAP.getPackageName().equals(recommendAdvanceRequest.getCp());
    }
    
    public boolean ifChat(RecommendAdvanceRequest recommendAdvanceRequest) {
        return ifChat(recommendAdvanceRequest.getCp());
    }

    public boolean ifChat(String cp) {
        return EAppPackage.sweetchat.getPackageName().equals(cp);
    }

    /**
     * 判断是否是需要获取収礼卡片的请求。
     */
    public boolean ifNeedGiftReceiveCardRequest(RecommendAdvanceRequest recommendAdvanceRequest) {
        return Objects.equals(recommendAdvanceRequest.getDc(), GIFT_RECEIVE_CARD_DC);
    }

    public boolean ifNullForDefaultRequest(RecommendAdvanceRequest recommendAdvanceRequest) {
        return recommendAdvanceRequest.getUid() == null;
    }

    /**
     *  从redis中的高危池查询改为判断从es那里得到的risk字段
     */
    public boolean ifHighRiskRequest(RecommendAdvanceRequest recommendAdvanceRequest) {
        return ESnsUserRisk.HIGH_RISK.getRiskLevel().equals(recommendAdvanceRequest.getRiskLevel());
    }

}
