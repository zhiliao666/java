package com.ufoto.business.recommendNG.recall;

import com.ufoto.annotation.RecommendMetadata;
import com.ufoto.business.recommendNG.Recall;
import com.ufoto.dto.RecommendAdvanceRequest;
import com.ufoto.utils.redis.RedisKeyConstant;
import com.ufoto.utils.redis.RedisService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;

import java.util.HashSet;
import java.util.Optional;
import java.util.Set;

/**
 * Created by echo on 4/3/18.
 * <p>
 * 机器人数量不多，简单粗暴全部返回
 * <p>
 */
@RecommendMetadata(
        metadataType = RecommendMetadata.MetadataType.RECALL,
        name = "机器人召回策略",
        description = "根据用户国家码召回指定国家的机器人,默认国家码为US,已废弃"
)
@Component
@Deprecated
public class NGRobotRecall implements Recall {

    //todo:test

    @Autowired
    private RedisService redisService;

    @Override
    public Set<String> recall(Integer minSize, RecommendAdvanceRequest recallRequest) {
        String countryCode = recallRequest.getCountryCode();
        if (!redisService.exists(RedisKeyConstant.REDIS_ROBOT_UID_SET_KEY_ + countryCode)) {
            countryCode = "US";
        }
        Set<String> result = Optional.ofNullable(redisService.sMember(RedisKeyConstant.REDIS_ROBOT_UID_SET_KEY_ + countryCode)).orElse(new HashSet<>());
        return result;
    }

    @Override
    public boolean ifRecallOnlyOnce() {
        return true;
    }

    @Override
    public boolean ifNeedThreadLocalCache() {
        return false;
    }

}
