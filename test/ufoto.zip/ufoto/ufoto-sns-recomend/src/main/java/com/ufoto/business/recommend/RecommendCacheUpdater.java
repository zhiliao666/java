package com.ufoto.business.recommend;

import com.github.benmanes.caffeine.cache.LoadingCache;
import com.ufoto.annotation.RecommendMetadata;
import com.ufoto.utils.SpringContextUtil;
import lombok.extern.slf4j.Slf4j;
import org.apache.commons.lang.math.RandomUtils;
import org.apache.commons.lang3.ArrayUtils;
import org.springframework.aop.support.AopUtils;
import org.springframework.core.env.Environment;
import org.springframework.scheduling.annotation.Scheduled;
import org.springframework.stereotype.Component;
import org.springframework.util.ReflectionUtils;

import java.lang.reflect.Method;
import java.util.Map;

/**
 * Created by echo on 10/29/18.
 */
@Slf4j
@Component
public class RecommendCacheUpdater {
    private final static String UPDATE_CACHE_METHOD = "updateCache";
    private final Environment env;
    private final LoadingCache<Class<?>, Object> recommendLoadingCache;

    public RecommendCacheUpdater(Environment env,
                                 LoadingCache<Class<?>, Object> recommendLoadingCache) {
        this.env = env;
        this.recommendLoadingCache = recommendLoadingCache;
    }

    @Scheduled(cron = "0 0/12 * * * ?")
    public void updateCacheByAnnotation() {
        log.debug("CacheUpdaterStart...");
        final String[] activeProfiles = env.getActiveProfiles();
        if (ArrayUtils.contains(activeProfiles, "test")) {
            log.debug("CacheUpdaterDone...");
            return;
        }
        final Map<String, Object> beanMap = SpringContextUtil.getBeansWithAnnotation(RecommendMetadata.class);
        beanMap.forEach((key, bean) -> {
            Class<?> targetClass = AopUtils.getTargetClass(bean);
            RecommendMetadata recommendMetadata = targetClass.getAnnotation(RecommendMetadata.class);
            if (recommendMetadata.available() && recommendMetadata.updateCache()) {
                final Method method = ReflectionUtils.findMethod(targetClass, UPDATE_CACHE_METHOD);
                if (method != null) {
                    final Object o = ReflectionUtils.invokeMethod(method, bean);
                    if (o != null) {
                        recommendLoadingCache.put(targetClass, o);
                    }
                    try {
                        Thread.sleep(3000 + RandomUtils.nextInt(10) * 100);
                    } catch (InterruptedException e) {
                        log.error(e.getMessage(), e);
                    }
                }
            }
        });
        log.debug("CacheUpdaterDone...");
    }
}
