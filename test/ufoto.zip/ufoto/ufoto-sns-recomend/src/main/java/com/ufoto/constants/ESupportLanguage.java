package com.ufoto.constants;

/**
 * <p>
 * Author     : Chan
 * CreateDate : 2018/10/10 10:59
 * Description:
 * </p>
 */
public enum ESupportLanguage {
    EN("en"),
    HI("hi"),
    ES("es"),
    PT("pt"),
    AR("ar"),//阿拉伯语
    IN("in"),//印尼
    RU("ru");//俄语


    private String lang;

    ESupportLanguage(String lang) {
        this.lang = lang;
    }

    public String getLang() {
        return lang;
    }
}
