package com.ufoto.dto;

import com.ufoto.entity.UfotoUserChatActivity;

/**
 * <p>
 *
 * </p>
 *
 * @author created by chenzhou at 2018-08-16 18:17
 */
public class UfotoUserChatActivityIndexDto {
    private UfotoUserChatActivity ufotoUserChatActivity;
    private Integer index;

    public UfotoUserChatActivity getUfotoUserChatActivity() {
        return ufotoUserChatActivity;
    }

    public void setUfotoUserChatActivity(UfotoUserChatActivity ufotoUserChatActivity) {
        this.ufotoUserChatActivity = ufotoUserChatActivity;
    }

    public Integer getIndex() {
        return index;
    }

    public void setIndex(Integer index) {
        this.index = index;
    }
}
