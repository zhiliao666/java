package com.ufoto.business.recommend.sort.likeme;

import com.ufoto.annotation.RecommendMetadata;
import com.ufoto.business.recommend.bean.SortParamsBean;
import com.ufoto.business.recommend.sort.BaseNormalSortStrategy;
import com.ufoto.utils.CommonUtil;
import com.ufoto.utils.redis.RedisKeyConstant;
import com.ufoto.utils.redis.RedisService;
import org.springframework.stereotype.Component;

import java.nio.charset.StandardCharsets;
import java.util.List;
import java.util.Map;

/**
 * Created by echo on 4/8/18.
 */
@RecommendMetadata(
        metadataType = RecommendMetadata.MetadataType.SORT,
        available = true,
        name = "dislike我排序策略",
        description = "dislike我,基础分数为1,此外为0",
        branch = RecommendMetadata.Branch.NORMAL
)
@Component
public class UnLikeMeSortStrategy extends BaseNormalSortStrategy {

    private final RedisService redisService;

    public UnLikeMeSortStrategy(RedisService redisService) {
        this.redisService = redisService;
    }

    /**
     * 返回对应用户是否disLike我
     */
    @Override
    public Map<String, Double> getScore(List<String> recallUids, SortParamsBean sortParamsBean) {
        final Long uid = sortParamsBean.getUid();
        final List<Object> objects = redisService.execPipelineForRead(connection -> {
            for (String recallUid : recallUids) {
                connection.sIsMember((RedisKeyConstant.REDIS_BE_UN_LIKED_SET_KEY_NEW + uid).getBytes(StandardCharsets.UTF_8),
                        recallUid.getBytes(StandardCharsets.UTF_8));
            }
            return null;
        });
        return CommonUtil.getScoreMapOfLike(recallUids, objects);
    }
}
