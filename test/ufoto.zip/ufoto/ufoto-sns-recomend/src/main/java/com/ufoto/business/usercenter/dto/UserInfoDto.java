package com.ufoto.business.usercenter.dto;


import lombok.Data;

import java.io.Serializable;

/**
 * 用户所有信息
 *
 * @author luozq
 * @date 2019/3/20/020
 */
@Data
public class UserInfoDto implements Serializable {

    /**
     * 用户基本信息
     */
    private UserBaseInfoDto baseInfo;
    /**
     * 用户拓展信息
     */
    private UserAdditionalInfoDo additionInfo;
}
