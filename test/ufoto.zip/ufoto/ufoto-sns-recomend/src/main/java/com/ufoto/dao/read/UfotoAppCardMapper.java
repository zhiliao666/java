package com.ufoto.dao.read;

import com.ufoto.dao.base.BaseUfotoAppCardMapper;
import com.ufoto.dao.base.UfotoAppCardSqlProvider;
import com.ufoto.dto.CardParam;
import com.ufoto.entity.UfotoAppCard;
import org.apache.ibatis.annotations.Result;
import org.apache.ibatis.annotations.Results;
import org.apache.ibatis.annotations.SelectProvider;
import org.apache.ibatis.type.JdbcType;

import java.util.List;

/**
 * <p>
 * Author     : Chan
 * CreateDate : 2018/9/15 10:14
 * Description:
 * </p>
 */
public interface UfotoAppCardMapper extends BaseUfotoAppCardMapper {
    @SelectProvider(method = "queryRandomCards", type = UfotoAppCardSqlProvider.class)
    @Results({
            @Result(column = "id", property = "id", jdbcType = JdbcType.BIGINT, id = true),
            @Result(column = "type", property = "type", jdbcType = JdbcType.INTEGER),
            @Result(column = "type_id", property = "typeId", jdbcType = JdbcType.BIGINT),
            @Result(column = "user_name", property = "userName", jdbcType = JdbcType.VARCHAR),
            @Result(column = "description", property = "description", jdbcType = JdbcType.VARCHAR),
            @Result(column = "first_img", property = "firstImg", jdbcType = JdbcType.VARCHAR),
            @Result(column = "type_sub", property = "typeSub", jdbcType = JdbcType.INTEGER),
            @Result(column = "lang", property = "lang", jdbcType = JdbcType.VARCHAR),
            @Result(column = "is_delete", property = "isDelete", jdbcType = JdbcType.INTEGER),
            @Result(column = "create_time", property = "createTime", jdbcType = JdbcType.INTEGER),
            @Result(column = "update_time", property = "updateTime", jdbcType = JdbcType.INTEGER)
    })
    List<UfotoAppCard> queryRandomCards(CardParam cardParam);

    @SelectProvider(method = "queryRandomCardsWithTypeSubs", type = UfotoAppCardSqlProvider.class)
    @Results({
            @Result(column = "id", property = "id", jdbcType = JdbcType.BIGINT, id = true),
            @Result(column = "type", property = "type", jdbcType = JdbcType.INTEGER),
            @Result(column = "type_id", property = "typeId", jdbcType = JdbcType.BIGINT),
            @Result(column = "user_name", property = "userName", jdbcType = JdbcType.VARCHAR),
            @Result(column = "description", property = "description", jdbcType = JdbcType.VARCHAR),
            @Result(column = "first_img", property = "firstImg", jdbcType = JdbcType.VARCHAR),
            @Result(column = "type_sub", property = "typeSub", jdbcType = JdbcType.INTEGER),
            @Result(column = "lang", property = "lang", jdbcType = JdbcType.VARCHAR),
            @Result(column = "is_delete", property = "isDelete", jdbcType = JdbcType.INTEGER),
            @Result(column = "create_time", property = "createTime", jdbcType = JdbcType.INTEGER),
            @Result(column = "update_time", property = "updateTime", jdbcType = JdbcType.INTEGER)
    })
    List<UfotoAppCard> queryRandomCardsWithTypeSubs(CardParam cardParam);
}
