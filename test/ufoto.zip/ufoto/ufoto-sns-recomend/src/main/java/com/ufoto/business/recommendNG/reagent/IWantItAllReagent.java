package com.ufoto.business.recommendNG.reagent;

import com.ufoto.annotation.RecommendMetadata;
import com.ufoto.business.recommendNG.Reagent;
import com.ufoto.dto.RecommendAdvanceRequest;
import org.springframework.stereotype.Component;

import java.util.Set;

/**
 * Created by echo on 10/17/18.
 */
@RecommendMetadata(
        metadataType = RecommendMetadata.MetadataType.REAGENT,
        available = true,
        name = "全部都要保留集",
        description = "不做任何操作"
)
@Component
public class IWantItAllReagent implements Reagent {

    @Override
    public Set<String> makeReagents(RecommendAdvanceRequest request, Set<String> uidCollection) {
        return uidCollection;
    }

    @Override
    public Set<String> randomReagents(RecommendAdvanceRequest request, Integer size) {
        throw new RuntimeException("You cant random recall on IWantItAll reagent.");
    }
}
