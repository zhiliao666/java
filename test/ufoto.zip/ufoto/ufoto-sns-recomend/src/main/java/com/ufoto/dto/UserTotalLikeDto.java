package com.ufoto.dto;

import java.io.Serializable;

public class UserTotalLikeDto implements Serializable {

    /**
     *
     */
    private static final long serialVersionUID = 1L;

    private Integer likeNum;

    private Long tUId;

    /**
     * @return the likeNum
     */
    public Integer getLikeNum() {
        return likeNum;
    }

    /**
     * @param likeNum the likeNum to set
     */
    public void setLikeNum(Integer likeNum) {
        this.likeNum = likeNum;
    }

    /**
     * @return the tUId
     */
    public Long gettUId() {
        return tUId;
    }

    /**
     * @param tUId the tUId to set
     */
    public void settUId(Long tUId) {
        this.tUId = tUId;
    }


}
