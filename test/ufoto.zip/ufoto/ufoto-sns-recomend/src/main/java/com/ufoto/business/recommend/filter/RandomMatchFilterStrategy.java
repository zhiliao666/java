package com.ufoto.business.recommend.filter;

import com.ufoto.business.recommend.filter.blackList.BlackListFilter;
import com.ufoto.business.recommend.filter.delete.DeleteUserFilterStrategy;
import com.ufoto.business.recommend.filter.illegal.ChatIllegalFilterStrategy;
import com.ufoto.business.recommend.filter.illegal.IllegalFilterStrategy;
import com.ufoto.business.recommend.filter.me.MeFilterStrategy;
import com.ufoto.business.recommend.filter.recommended.RandomMatchRecommendedFilterStrategy;
import com.ufoto.business.recommend.filter.result.ResultFilterStrategy;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;

/**
 * <p>
 *
 * </p>
 *
 * @author created by chenzhou at 2018-08-08 09:39
 */
@Component
public class RandomMatchFilterStrategy extends CompositeRecommendFilterStrategy {
    @Autowired
    public RandomMatchFilterStrategy(
            RandomMatchRecommendedFilterStrategy randomMatchRecommendedFilterStrategy,
            IllegalFilterStrategy illegalFilterStrategy,
            ResultFilterStrategy resultFilterStrategy,
            MeFilterStrategy meFilterStrategy,
            BlackListFilter blackListFilter,
            DeleteUserFilterStrategy deleteUserFilterStrategy,
            ChatIllegalFilterStrategy chatIllegalFilterStrategy) {
        this.filterStrategyList.add(meFilterStrategy);
        this.filterStrategyList.add(resultFilterStrategy);
        this.filterStrategyList.add(illegalFilterStrategy);
        this.filterStrategyList.add(randomMatchRecommendedFilterStrategy);
        this.filterStrategyList.add(blackListFilter);
        this.filterStrategyList.add(deleteUserFilterStrategy);
        this.filterStrategyList.add(chatIllegalFilterStrategy);
    }
}
