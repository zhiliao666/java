package com.ufoto.business.chat;

import com.ufoto.business.chat.dto.UfotoChatMsg;
import com.ufoto.utils.ApiResult;
import org.springframework.stereotype.Component;

import java.util.List;

@Component
public class MsgChatBusinessHystrix implements MsgChatBusiness {


    @Override
    public ApiResult<String> sendMsg(Long fromUid, Long toUid, String msg,
                                     Integer msgType, Integer chatType) {
        return new ApiResult<String>().setError(ApiResult.errorCode500, "垄断器异常");
    }

    @Override
    public ApiResult<List<UfotoChatMsg>> listChatMsg(Long fromUid, Long toUid,
                                                     Integer page, Integer pageSize) {
        return new ApiResult<List<UfotoChatMsg>>().setError(ApiResult.errorCode500, "垄断器异常");
    }

    @Override
    public ApiResult<String> msgRead(Long fid, Long uid, Integer msgTime) {
        return new ApiResult<String>().setError(ApiResult.errorCode500, "垄断器异常");
    }

    @Override
    public ApiResult<List<UfotoChatMsg>> listChatMsgByTime(Long fromUid,
                                                           Long toUid, Integer startTime, Integer endTime) {
        return new ApiResult<List<UfotoChatMsg>>().setError(ApiResult.errorCode500, "垄断器异常");
    }

}
