package com.ufoto.business.recommend.sort.act;

import com.ufoto.annotation.RecommendMetadata;
import com.ufoto.business.recommend.bean.SortParamsBean;
import com.ufoto.business.recommend.sort.BaseNormalSortStrategy;
import org.springframework.stereotype.Component;

import java.util.HashMap;
import java.util.List;
import java.util.Map;

/**
 * Created by echo on 4/8/18.
 */
@RecommendMetadata(
        metadataType = RecommendMetadata.MetadataType.SORT,
        name = "三天内划过的数量排序策略",
        description = "基础分数为用户三天内划过的用户数量,已废弃"
)
@Deprecated
@Component
public class ActNumIn3DaySortStrategy extends BaseNormalSortStrategy {

    @Override
    public Map<String, Double> getScore(List<String> recallUids, SortParamsBean sortParamsBean) {
        Map<String, Double> scoreMap = new HashMap<>();
        for (String recallUid : recallUids) {
            double actNumIn3Day = 0d;
            scoreMap.put(recallUid, actNumIn3Day);
        }
        return scoreMap;
    }
}
