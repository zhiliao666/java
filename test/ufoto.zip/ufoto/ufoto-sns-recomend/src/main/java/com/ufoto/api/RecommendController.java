package com.ufoto.api;

import com.google.common.collect.Lists;
import com.ufoto.bloom.AbstractRecommendBloomFilter;
import com.ufoto.bloom.RecommendedRecommendBloomFilter;
import com.ufoto.business.recommend.filter.exposure.ExposureLimitFilterStrategy;
import com.ufoto.business.recommend.filter.like.LikeLimitFilterStrategy;
import com.ufoto.business.recommend.filter.recommended.RecommendedFilterStrategy;
import com.ufoto.business.recommendNG.InvokerFactory;
import com.ufoto.dto.ConditionRequest;
import com.ufoto.dto.FilterStrategyDto;
import com.ufoto.dto.RecommendAdvanceRequest;
import com.ufoto.dto.RecommendListRequest;
import com.ufoto.entity.UfotoRecommendRedisDump;
import com.ufoto.logging.proxy.UfotoLogFactory;
import com.ufoto.mq.kafka.HighRiskMsg;
import com.ufoto.runner.RuleBuildRunner;
import com.ufoto.runner.RuleCacheManager;
import com.ufoto.runner.RuleEngineManager;
import com.ufoto.service.UfotoAppUserService;
import com.ufoto.service.UfotoRecommendRedisDumpService;
import com.ufoto.utils.ApiResult;
import com.ufoto.utils.BeanUtil;
import com.ufoto.utils.CommonUtil;
import com.ufoto.utils.DateUtil;
import com.ufoto.utils.SpringContextUtil;
import com.ufoto.utils.json.JSONUtil;
import com.ufoto.utils.redis.RedisKeyConstant;
import com.ufoto.utils.redis.RedisKeyUtil;
import com.ufoto.utils.redis.RedisService;
import com.ufoto.utils.strategy.ParamsConverter;
import lombok.RequiredArgsConstructor;
import lombok.extern.slf4j.Slf4j;
import org.apache.kafka.clients.producer.ProducerRecord;
import org.slf4j.Logger;
import org.springframework.core.env.Environment;
import org.springframework.kafka.core.KafkaTemplate;
import org.springframework.util.StringUtils;
import org.springframework.util.concurrent.ListenableFuture;
import org.springframework.util.concurrent.ListenableFutureCallback;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.RestController;

import java.nio.charset.StandardCharsets;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.Set;

/**
 * <p>
 * Author     : Chan
 * CreateDate : 2019-09-04 11:26
 * Description:
 * </p>
 */
@Slf4j
@RequestMapping("/recommend")
@RestController
@RequiredArgsConstructor
public class RecommendController {

    private final UfotoRecommendRedisDumpService ufotoRecommendRedisDumpService;
    private final RuleEngineManager ruleEngineManager;
    private final RuleBuildRunner ruleBuildRunner;
    private final RuleCacheManager ruleCacheManager;
    private final UfotoAppUserService ufotoAppUserService;
    private final RecommendedFilterStrategy recommendedFilterStrategy;
    private final LikeLimitFilterStrategy likeLimitFilterStrategy;
    private final ExposureLimitFilterStrategy exposureLimitFilterStrategy;
    private final Environment env;
    private final ParamsConverter paramsConverter;
    private final InvokerFactory invokerFactory;
    private final KafkaTemplate kafkaTemplate;
    private final RedisService redisService;

    private final Logger kafkaLogger = UfotoLogFactory.getLogger("test")
            .enableCustomStatus().disableFileAppender().enableKafkaAppender().build();

    @RequestMapping("/restoreDump")
    public ApiResult<Object> restoreDump(Long uid) {
        ufotoRecommendRedisDumpService.restore(uid);
        return new ApiResult<>().setResult(true);
    }

    @RequestMapping("/dump/user")
    public ApiResult<Object> dumpRedis(@RequestParam Long uid,
                                       @RequestParam(required = false) Integer limitDays) {
        if (limitDays == null) {
            limitDays = env.getProperty("cleanTask.dump.limitDays", Integer.class, 12);
        }
        String lastActTimeStr = redisService.hget(RedisKeyUtil.obtainKey(RedisKeyConstant.REDIS_USER_HASH_KEY, uid),
                RedisKeyConstant.REDIS_USER_HASH_ACTIVITY_TIME);
        boolean canDump = StringUtils.isEmpty(lastActTimeStr) || !CommonUtil.isInteger(lastActTimeStr);
        int lastActTime = 0;
        if (!canDump) {
            lastActTime = Integer.parseInt(lastActTimeStr);
            int currentTime = DateUtil.getCurrentSecondIntValue();
            canDump = currentTime - lastActTime > limitDays * 24 * 60 * 60;
        }
        if (!canDump) {
            return new ApiResult<>().setError(ApiResult.errorCode302, "NoNeedDump");
        }
        List<UfotoRecommendRedisDump> dumpList = ufotoRecommendRedisDumpService.createDumpKeyList(uid, lastActTime);
        for (UfotoRecommendRedisDump redisDump : dumpList) {
            int result = ufotoRecommendRedisDumpService.insert(redisDump);
            if (result == 1) redisService.del(redisDump.getKey());
        }
        redisService.zadd(RedisKeyConstant.REDIS_HAS_DUMPED_USER_ZSET, String.valueOf(uid), DateUtil.getCurrentSecondIntValue());
        return new ApiResult<>().setResult(true);
    }

    @RequestMapping(path = "/strategyNG", method = RequestMethod.POST)
    public ApiResult<Object> strategyNG(@RequestBody ConditionRequest request) {
        return new ApiResult<>().setResult(ruleEngineManager.strategyNG(request));
    }

    @RequestMapping("/obtainRulesInMemory")
    public ApiResult<Object> obtainRulesInMemory() {
        return new ApiResult<>().setResult(ruleEngineManager.obtainRulesInMemory());
    }

    @RequestMapping("/obtainRulesInRedis")
    public ApiResult<Object> obtainRulesInRedis() {
        return new ApiResult<>().setResult(ruleEngineManager.obtainRulesInRedis());
    }

    @RequestMapping("/invoker")
    public ApiResult<Object> createInvokerFromRuleEngine(@RequestBody RecommendAdvanceRequest recommendAdvanceRequest) {
        return new ApiResult<>().setResult(invokerFactory.obtainInvoker(recommendAdvanceRequest).toString());
    }

    @RequestMapping("/rebuildRule")
    public ApiResult<Object> rebuildRule() {
        ruleBuildRunner.run();
        return new ApiResult<>().setResult(true);
    }

    @RequestMapping("/refreshRuleCache")
    public ApiResult<Object> refreshRuleMemoryView() {
        ruleCacheManager.refresh();
        return new ApiResult<>().setResult(true);
    }

    @RequestMapping("/ruleStats")
    public ApiResult<Object> ruleCacheStats() {
        return new ApiResult<>().setResult(ruleCacheManager.stats());
    }

    @RequestMapping("/ruleMemoryView")
    public ApiResult<Object> ruleMemoryView() {
        return new ApiResult<>().setResult(ruleCacheManager.memoryView());
    }

    @RequestMapping("/kafka")
    public ApiResult<Object> kafka() {
        Map<String, Object> map = new HashMap<>();
        map.put("id", 1010L);
        map.put("name", "cat");
        map.put("amount", 180.0);
        kafkaLogger.info(JSONUtil.toJSON(map));
        return new ApiResult<>().setResult(true);
    }

    @RequestMapping("/list")
    public ApiResult<Object> recommendList(RecommendListRequest recommendListRequest) {
        return new ApiResult<>().setResult(ufotoAppUserService.selectRecommendDtoBySortedUidList(recommendListRequest));
    }

    @RequestMapping("/test/recommended")
    public ApiResult<Object> filterRecommended(@RequestBody FilterStrategyDto filterDto) {
        final Set<String> filter = recommendedFilterStrategy.filter(filterDto.getRecallUids(), Lists.newArrayList(), filterDto.getRequest());
        return new ApiResult<>().setResult(filter);
    }

    @RequestMapping("/test/likeLimit")
    public ApiResult<Object> filterLikeLimit(@RequestBody FilterStrategyDto filterDto) {
        final Set<String> filter = likeLimitFilterStrategy.filter(filterDto.getRecallUids(), Lists.newArrayList(), filterDto.getRequest());
        return new ApiResult<>().setResult(filter);
    }

    @RequestMapping("/test/exposureLimit")
    public ApiResult<Object> filterExposureLimit(@RequestBody FilterStrategyDto filterDto) {
        final Set<String> filter = exposureLimitFilterStrategy.filter(filterDto.getRecallUids(), Lists.newArrayList(), filterDto.getRequest());
        return new ApiResult<>().setResult(filter);
    }

    @SuppressWarnings("unchecked")
    @RequestMapping(path = "/bf/{beanName}/{user}/add/{item}")
    public ApiResult<Object> bloomFilterAdd(@PathVariable Long user,
                                            @PathVariable String item,
                                            @PathVariable String beanName) {
        return new ApiResult<>().setResult(SpringContextUtil.getBean(beanName, AbstractRecommendBloomFilter.class).add(user, item));
    }

    @SuppressWarnings("unchecked")
    @RequestMapping(path = "/bf/{beanName}/{user}/contain/{item}")
    public ApiResult<Object> bloomFilterContain(@PathVariable Long user,
                                                @PathVariable String item,
                                                @PathVariable String beanName) {
        return new ApiResult<>().setResult(SpringContextUtil.getBean(beanName, AbstractRecommendBloomFilter.class).contains(user, item));
    }

    @SuppressWarnings("unchecked")
    @RequestMapping(path = "/bf/{beanName}/{user}/count")
    public ApiResult<Object> bloomFilterCount(@PathVariable Long user,
                                              @PathVariable String beanName) {
        return new ApiResult<>().setResult(SpringContextUtil.getBean(beanName, AbstractRecommendBloomFilter.class).count(user));
    }

    @SuppressWarnings("unchecked")
    @RequestMapping(path = "/bf/{beanName}/{user}/filter")
    public ApiResult<Object> bloomFilterFilter(@PathVariable Long user,
                                               @RequestParam Set<String> items,
                                               @PathVariable String beanName) {
        return new ApiResult<>().setResult(SpringContextUtil.getBean(beanName, AbstractRecommendBloomFilter.class).filter(user, items));
    }

    @SuppressWarnings("unchecked")
    @RequestMapping(path = "/bf/{beanName}/{user}/clear")
    public ApiResult<Object> bloomFilterClear(@PathVariable Long user,
                                              @PathVariable String beanName) {
        SpringContextUtil.getBean(beanName, AbstractRecommendBloomFilter.class).clear(user);
        return new ApiResult<>().setResult(true);
    }

    @SuppressWarnings("unchecked")
    @RequestMapping(path = "/bf/{beanName}/{user}/expire")
    public ApiResult<Object> bloomFilterExpire(@PathVariable Long user,
                                               @PathVariable String beanName) {
        SpringContextUtil.getBean(beanName, AbstractRecommendBloomFilter.class).cleanExpireBloomKeys(user);
        return new ApiResult<>().setResult(true);
    }

    @RequestMapping(path = "/mightContain")
    public ApiResult<Object> mightContain(Long uid, Long targetUid) {
        return new ApiResult<>().setResult(SpringContextUtil.getBean(RecommendedRecommendBloomFilter.class).contains(uid, String.valueOf(targetUid)));
    }

    @RequestMapping("getUserStrategy")
    public ApiResult<Map> getUserStrategy(@RequestParam Long uid, @RequestParam String countryCode) {
        RecommendAdvanceRequest recommendAdvanceRequest = new RecommendAdvanceRequest();
        recommendAdvanceRequest.setUid(uid);
        recommendAdvanceRequest.setCountryCode(countryCode);
        final ConditionRequest strategyRequest = paramsConverter.obtainStrategyRequest(recommendAdvanceRequest);
        return new ApiResult<Map>().setResult(ruleEngineManager.strategyNG(BeanUtil.copyPropertiesByNotNull(strategyRequest, new ConditionRequest())));
    }

    @RequestMapping(path = "/highRisk", method = RequestMethod.POST)
    public ApiResult<Object> highRiskTest(@RequestBody List<HighRiskMsg> msgs) {
        final String topic = env.getProperty("kafka.user.layer.topic", String.class, "");
        for (HighRiskMsg msg : msgs) {
            ProducerRecord<byte[], byte[]> record = new ProducerRecord<>(topic,
                    com.ufoto.utils.JSONUtil.toJSON(msg).getBytes(StandardCharsets.UTF_8));
            final ListenableFuture future = kafkaTemplate.send(record);
            future.addCallback(new ListenableFutureCallback() {
                @Override
                public void onFailure(Throwable ex) {
                    log.error(ex.getMessage(), ex);
                }

                @Override
                public void onSuccess(Object result) {
                    log.debug("result:{}", result);
                }
            });
        }
        return new ApiResult<>().setResult(true);
    }
}
