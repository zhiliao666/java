package com.ufoto.business.recommend.sort.randomMatch;

import com.ufoto.entity.UfotoUserChatActivity;

import java.util.List;
import java.util.Map;

/**
 * <p>
 *
 * </p>
 *
 * @author created by chenzhou at 2018-08-02 18:30
 */
public interface SpecifyRandomMatchSortStrategy {

    Map<Long, Double> addScoreBatch(Map<Long, Double> uidScoreMap, Double weight, List<UfotoUserChatActivity> activities, UfotoUserChatActivity currentUser);

    Map<Long, Double> getScore(List<UfotoUserChatActivity> activities, UfotoUserChatActivity currentUser);

}
