package com.ufoto.dto.sns;

import lombok.Data;

import java.io.Serializable;
import java.util.List;

/**
 * 
 *
 * @author zhangqh  
 * @date Apr 13, 2020 10:51:54 AM  
 * @version 1.0
 */
@Data
public class WinkRecommendDto implements Serializable {
    /**
	 * 
	 */
	private static final long serialVersionUID = 1L;
	
	private List<String> uids;
}
