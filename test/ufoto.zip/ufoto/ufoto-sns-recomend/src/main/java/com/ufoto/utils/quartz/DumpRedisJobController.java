package com.ufoto.utils.quartz;

import com.ufoto.utils.quartz.service.QuartzService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.core.env.Environment;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

/**
 * <p>
 * Author     : Chan
 * CreateDate : 2018/11/15 19:45
 * Description: dump redis
 * </p>
 */
@RestController
@RequestMapping("/dumpRedisJob")
public class DumpRedisJobController extends BaseJobController {

    @Autowired
    public DumpRedisJobController(QuartzService quartzService, Environment env) {
        super(quartzService,
                QuartzHelper.GROUP_NAME_DUMP_REDIS,
                QuartzHelper.JOB_NAME_DUMP_REDIS,
                env.getProperty("cron.dump.redis", String.class, "0 0/5 * * * ?"),
                DumpRedisJob.class,
                "dumpRedis冷数据");
    }
}
