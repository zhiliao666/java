package com.ufoto.dto;

import lombok.Data;
import lombok.EqualsAndHashCode;

import java.util.Set;

/**
 * <p>
 * Author     : Chan
 * CreateDate : 2018/11/7 17:06
 * Description:
 * </p>
 */
@EqualsAndHashCode(callSuper = true)
@Data
public class RecommendAdvanceRequestExpand extends RecommendAdvanceRequest {
    private Set<String> targetUids;
    private Boolean unread;
}
