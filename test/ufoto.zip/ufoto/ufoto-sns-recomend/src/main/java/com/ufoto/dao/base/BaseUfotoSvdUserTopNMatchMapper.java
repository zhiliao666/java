package com.ufoto.dao.base;

import com.ufoto.entity.UfotoSvdUserTopNMatch;
import org.apache.ibatis.annotations.*;
import org.apache.ibatis.jdbc.SQL;

import java.util.List;

public interface BaseUfotoSvdUserTopNMatchMapper {

    @Results({
            @Result(property = "id", column = "id"),
            @Result(property = "uId", column = "u_id"),
            @Result(property = "iId", column = "i_id"),
            @Result(property = "rank", column = "rank"),
            @Result(property = "createTime", column = "create_time"),
    })
    @Select("SELECT * FROM ufoto_svd_user_top_n_match")
    List<UfotoSvdUserTopNMatch> list();

    @Select("SELECT count(*) FROM ufoto_svd_user_top_n_match")
    int count();

    @Results({
            @Result(property = "id", column = "id"),
            @Result(property = "uId", column = "u_id"),
            @Result(property = "iId", column = "i_id"),
            @Result(property = "rank", column = "rank"),
            @Result(property = "createTime", column = "create_time"),
    })
    @Select("SELECT * FROM ufoto_svd_user_top_n_match WHERE id = #{id}")
    UfotoSvdUserTopNMatch selectOneById(@Param("id") Integer id);

    @Delete("DELETE FROM ufoto_svd_user_top_n_match WHERE id = #{id}")
    int delete(Integer id);

    //@Insert("INSERT INTO ufoto_svd_user_top_n_match(u_id,i_id,rank,create_time) VALUES(#{uId},#{iId},#{rank},#{createTime})")
    //@Options(useGeneratedKeys=true, keyProperty="id")
    //public int insert(UfotoSvdUserTopNMatch ufotoSvdUserTopNMatch);

    @InsertProvider(type = ProviderSqlBuilder.class, method = "insert")
    @Options(useGeneratedKeys = true, keyProperty = "id")
    int insert(UfotoSvdUserTopNMatch ufotoSvdUserTopNMatch);

    @UpdateProvider(type = ProviderSqlBuilder.class, method = "updateById")
    int update(UfotoSvdUserTopNMatch ufotoSvdUserTopNMatch);

    class ProviderSqlBuilder {

        public String insert(final UfotoSvdUserTopNMatch ufotoSvdUserTopNMatch) {
            return new SQL() {
                {
                    INSERT_INTO("ufoto_svd_user_top_n_match");
                    if (ufotoSvdUserTopNMatch.getId() != null) {
                        VALUES("id", "#{id}");
                    }
                    if (ufotoSvdUserTopNMatch.getUId() != null) {
                        VALUES("u_id", "#{uId}");
                    }
                    if (ufotoSvdUserTopNMatch.getIId() != null) {
                        VALUES("i_id", "#{iId}");
                    }
                    if (ufotoSvdUserTopNMatch.getRank() != null) {
                        VALUES("rank", "#{rank}");
                    }
                    if (ufotoSvdUserTopNMatch.getCreateTime() != null) {
                        VALUES("create_time", "#{createTime}");
                    }
                    WHERE("id = #{id}");
                }
            }.toString();
        }

        public String updateById(final UfotoSvdUserTopNMatch ufotoSvdUserTopNMatch) {
            return new SQL() {
                {
                    UPDATE("ufoto_svd_user_top_n_match");
                    if (ufotoSvdUserTopNMatch.getId() != null) {
                        SET("id = #{id}");
                    }
                    if (ufotoSvdUserTopNMatch.getUId() != null) {
                        SET("u_id = #{uId}");
                    }
                    if (ufotoSvdUserTopNMatch.getIId() != null) {
                        SET("i_id = #{iId}");
                    }
                    if (ufotoSvdUserTopNMatch.getRank() != null) {
                        SET("rank = #{rank}");
                    }
                    if (ufotoSvdUserTopNMatch.getCreateTime() != null) {
                        SET("create_time = #{createTime}");
                    }
                    WHERE("id = #{id}");
                }
            }.toString();
        }
    }
}
