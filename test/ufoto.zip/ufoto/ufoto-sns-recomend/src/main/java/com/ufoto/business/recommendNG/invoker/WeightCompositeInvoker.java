package com.ufoto.business.recommendNG.invoker;

import com.google.common.collect.Lists;
import com.google.common.collect.Sets;
import com.ufoto.business.recommendNG.Captain;
import com.ufoto.business.recommendNG.Invoker;
import com.ufoto.dto.RecommendAdvanceRequest;

import java.util.Collections;
import java.util.List;
import java.util.Set;

/**
 * Created by echo on 10/17/18.
 */
public class WeightCompositeInvoker implements Invoker {


    private List<Invoker> children;
    private List<Float> weightList;
    private List<Integer> assembleWeightList;
    private Captain captain;


    public WeightCompositeInvoker(List<Invoker> children,
                                  List<Float> weightList,
                                  List<Integer> assembleWeightList,
                                  Captain captain) {
        this.children = children;
        this.weightList = weightList;
        this.assembleWeightList = assembleWeightList;
        this.captain = captain;
    }

    @Override
    public List<String> invoke(Integer minSize, RecommendAdvanceRequest recallRequest, Set<String> invokedUidSet) {
        Integer needSize = minSize;
        //权重总和
        Float weightSum = weightList.stream().reduce(0F, Float::sum);
        //累加权重比
         /*
        weightList(0.9,0.1)
       accWeightList(0.9,1)

       weightList(0.9,0.05)
       accWeightList(0.9473684, 1.0)
         */
        List<Float> accWeightList = Lists.newLinkedList();
        Float acc = 0F;
        for (Float aFloat : weightList) {
            Float weight = aFloat + acc;
            accWeightList.add(weight / weightSum);
            acc = weight;
        }
        //每一个子invoker召回出的用户list集合
        List<List<String>> subUidList = Lists.newLinkedList();
        //由于召回过程中可能会添加部分并不需要的结果，所以复制一份
        Set<String> tempRecalledUidSet = Sets.newHashSet(invokedUidSet);
        for (int i = 0; i < children.size(); i++) {
            Invoker invoker = children.get(i);
            if (weightList.get(i) == 0) {//magic here
                //如果对Invoker的权重配置的是0,则会要求他返回minSize数量的内容，并且不影响剩余的返回数量
                List<String> uidList = invoker.invoke(minSize, recallRequest, tempRecalledUidSet);
                subUidList.add(uidList);
                tempRecalledUidSet.addAll(uidList);
                continue;
            }
            if (needSize == 0) {
                subUidList.add(Collections.emptyList());
                continue;
            }
            Integer childrenMinSize = i == 0 ?
                    (int) (needSize * accWeightList.get(i)) :
                    (int) (needSize * accWeightList.get(i)) - (int) (needSize * accWeightList.get(i - 1));
            List<String> uidList = invoker.invoke(childrenMinSize, recallRequest, tempRecalledUidSet);
            subUidList.add(uidList);
            tempRecalledUidSet.addAll(uidList);
            if (uidList.size() < childrenMinSize && weightList.get(i) > 0) {
                // 如果某位召回者的数量不足，
                // 则以数量最少的标准更新所需要的随从数量总和
                needSize = (int) (uidList.size() * weightSum / weightList.get(i));
            }
        }
        //如果部分召回过多，则需要对最终长度进行截断
        for (int i = 0; i < subUidList.size(); i++) {
            if (weightList.get(i) == 0) {//magic here
                continue;
            }
            List<String> uidList = subUidList.get(i);
            if (needSize == 0) {
                uidList.clear();
                continue;
            }
            Integer exceptSize = i == 0 ?
                    (int) (needSize * accWeightList.get(i)) :
                    (int) (needSize * accWeightList.get(i)) - (int) (needSize * accWeightList.get(i - 1));
            Integer currentSize = uidList.size();
            if (currentSize > exceptSize) {
                for (int _ = 0; _ < (currentSize - exceptSize); _++) {
                    uidList.remove(uidList.size() - 1);
                }
            }
        }
        List<String> result = captain.assemble(recallRequest, subUidList, assembleWeightList);
        invokerLog(minSize, recallRequest, result, "weight");
        return result;
    }

    @Override
    public void cleanThreadLocalCache() {
        children.forEach(Invoker::cleanThreadLocalCache);
    }

    public List<Invoker> getChildren() {
        return children;
    }

    public List<Float> getWeightList() {
        return weightList;
    }

    public List<Integer> getAssembleWeightList() {
        return assembleWeightList;
    }

    public Captain getCaptain() {
        return captain;
    }


    @Override
    public String toString() {
        StringBuilder stringBuilder = new StringBuilder("WEIGHT:{");
        for (int i = 0; i < children.size(); i++) {
            stringBuilder.append(children.get(i).toString())
                    .append(";weight:").append(weightList.get(i))
                    .append(";assemble:").append(assembleWeightList.get(i))
                    .append("<->");
        }
        stringBuilder.append("}");
        return stringBuilder.toString();
    }
}
