package com.ufoto.dto.sns;

import lombok.Data;

import java.io.Serializable;
import java.util.List;

/**
 * <p>
 * Description:
 *
 * </p>
 *
 * @author Chan
 * @date 2019/12/24 17:11
 */
@Data
public class SnsRecommendV2 implements Serializable {
    private String userName;
    private String uid;
    private Byte gender;
    private String firstImg;
    private Byte likeState;
    private Integer subType = 0;//订阅类型 0 未订阅 1订阅
    private Integer age;//用户年龄
    private String avatar;//头像
    private List<FeedImgInfo> feeds;//feed 流最新三张
}
