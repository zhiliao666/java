package com.ufoto.utils.quartz;

import com.ufoto.utils.quartz.service.QuartzService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.core.env.Environment;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

/**
 * <p>
 * Author     : Chan
 * CreateDate : 2019-07-29 17:34
 * Description:
 * </p>
 */
@RestController
@RequestMapping("/redisClearJob")
public class RedisKeyClearJobController extends BaseJobController {

    @Autowired
    public RedisKeyClearJobController(QuartzService quartzService, Environment env) {
        super(quartzService,
                QuartzHelper.GROUP_NAME_REDIS_KEY_CLEAR,
                QuartzHelper.JOB_NAME_REDIS_KEY_CLEAR,
                env.getProperty("cron.redis.key.clear", String.class, "0 0/5 * * * ?"),
                RedisKeyClearJob.class,
                "清除redis中的过期数据");
    }

}
