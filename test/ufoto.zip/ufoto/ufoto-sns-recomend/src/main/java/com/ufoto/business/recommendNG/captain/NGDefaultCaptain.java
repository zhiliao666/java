package com.ufoto.business.recommendNG.captain;

import com.google.common.collect.Lists;
import com.ufoto.annotation.RecommendMetadata;
import com.ufoto.business.recommendNG.Captain;
import com.ufoto.dto.RecommendAdvanceRequest;
import lombok.extern.slf4j.Slf4j;
import org.apache.commons.lang.math.RandomUtils;
import org.springframework.core.env.Environment;
import org.springframework.stereotype.Component;
import org.springframework.util.CollectionUtils;

import java.security.InvalidParameterException;
import java.util.List;

/**
 * 根据assembleWeight权重，权重越高越有机会排在考前的位置
 * <p>
 * Created by echo on 10/18/18.
 */
@RecommendMetadata(
        metadataType = RecommendMetadata.MetadataType.CAPTAIN,
        available = true,
        name = "默认的归并策略",
        description = "根据assembleWeight权重，权重越高越有机会排在考前的位置",
        branch = RecommendMetadata.Branch.NORMAL
)
@Slf4j
@Component
public class NGDefaultCaptain implements Captain {

    private final Environment env;

    public NGDefaultCaptain(Environment env) {
        this.env = env;
    }

    @Override
    public List<String> assemble(RecommendAdvanceRequest recallRequest,
                                 List<List<String>> subUidList,
                                 List<Integer> assembleWeightList) {
        if (subUidList == null || subUidList.size() == 0) return Lists.newLinkedList();
        if (subUidList.size() == 1) return subUidList.get(0);
        if (CollectionUtils.isEmpty(assembleWeightList))
            throw new InvalidParameterException("NGDefaultCaptain:assembleWeightList is empty.");
        if (assembleWeightList.size() != subUidList.size())
            throw new InvalidParameterException("NGDefaultCaptain:assembleWeightList size is error.Weight size:" + assembleWeightList.size() + ",subUidList size:" + subUidList.size());

        List<List<String>> copySubUidList = Lists.newLinkedList(subUidList);
        List<Integer> copyWeightList = Lists.newLinkedList(assembleWeightList);

        //copy if we change share field
        removeEmptyIndex(recallRequest, copySubUidList, copyWeightList);

        List<String> result = Lists.newLinkedList();
        Integer totalWeight = copyWeightList.stream().reduce(0, Integer::sum);
        int totalSize = copySubUidList.stream().mapToInt(List::size).sum();

        for (int _ = 0; _ < totalSize; _++) {
            Integer rand = RandomUtils.nextInt(totalWeight);
            for (int i = 0; i < copyWeightList.size(); i++) {
                if (rand < copyWeightList.get(i) && copySubUidList.get(i).size() > 0) {
                    result.add(copySubUidList.get(i).get(0));
                    copySubUidList.get(i).remove(0);
                    if (copySubUidList.get(i).size() == 0) {
                        copySubUidList.remove(i);
                        totalWeight -= copyWeightList.get(i);
                        copyWeightList.remove(i);
                    }
                    break;
                }
                rand -= copyWeightList.get(i);
            }
        }

        return result;
    }

    private void removeEmptyIndex(RecommendAdvanceRequest recallRequest, List<List<String>> subUidList, List<Integer> assembleWeightList) {
        final Boolean removeEmptySwitch = env.getProperty("captain.remove.empty.switch", Boolean.class, true);
        if (!removeEmptySwitch) {
            return;
        }
        int remove = 0;
        for (int i = 0; i < subUidList.size(); i++) {
            final List<String> list = subUidList.get(i);
            if (CollectionUtils.isEmpty(list)) {
                remove++;
                subUidList.remove(i);
                assembleWeightList.remove(i);
                i--;
            }
        }
        if (remove > 0) {
            log.warn("CaptainEmpty request:{}, emptySize:{}", recallRequest, remove);
        }
    }
}
