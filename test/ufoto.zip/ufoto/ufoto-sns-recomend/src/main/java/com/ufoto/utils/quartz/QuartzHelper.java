package com.ufoto.utils.quartz;

import java.util.Date;

public class QuartzHelper {

    /**
     * 机器人发起主动聊天定时任务前缀
     */
    public static final String JOB_TAG_ROBOT_START_TIMER = "ROBOT_START_";

    /**
     * 定时任务 分组名
     */
    public static final String JOB_TAG_ROBOT_GROUP_NAME = "ROBOT_TASK_GROUP_NAME";

    public static final String JOB_RECOMMEND_RANDOM_MATCH_GROUP_NAME = "JOB_RECOMMEND_RANDOM_MATCH_GROUP_NAME";
    public static final String RECOMMEND_RANDOM_MATCH_JOB = "RECOMMEND_RANDOM_MATCH_JOB";

    //分组名 match之后的倒计时任务
    public static final String GROUP_NAME_COUNT_DOWN_AFTER_MATCH = "GROUP_NAME_COUNT_DOWN_AFTER_MATCH";
    //job名 match之后的倒计时任务
    public static final String JOB_NAME_COUNT_DOWN_AFTER_MATCH = "JOB_NAME_COUNT_DOWN_AFTER_MATCH";

    //等待匹配时超过一定时间 自动匹配机器人任务
    public static final String GROUP_NAME_ROBOT_RANDOM_MATCH = "GROUP_NAME_ROBOT_RANDOM_MATCH";
    public static final String JOB_NAME_ROBOT_RANDOM_MATCH = "JOB_NAME_ROBOT_RANDOM_MATCH";
    /**
     * 配对成功用户未发起聊天时间间隔  单位 分钟
     */
    public static final int NOT_START_CHAT_TIME_INTERVAL = 5;
    //订阅的分组名info
    public static final String GROUP_NAME_SUBSCRIPTION_REDIS_INFO = "GROUP_NAME_SUBSCRIPTION_REDIS_INFO";
    //订阅的job名info
    public static final String JOB_NAME_SUBSCRIPTION_REDIS_INFO = "JOB_NAME_SUBSCRIPTION_REDIS_INFO";

    public static final String GROUP_NAME_DUMP_REDIS = "GROUP_NAME_DUMP_REDIS";
    public static final String JOB_NAME_DUMP_REDIS = "JOB_NAME_DUMP_REDIS";


    public static final String JOB_NAME_REDIS_KEY_CLEAR = "JOB_NAME_REDIS_KEY_CLEAR";
    public static final String GROUP_NAME_REDIS_KEY_CLEAR = "GROUP_NAME_REDIS_KEY_CLEAR";

    public static final String GROUP_NAME_XGB = "GROUP_NAME_XGB";
    public static final String JOB_NAME_XGB = "JOB_NAME_XGB";

    public static final String GROUP_NEW_COME_USER_CLEAR = "GROUP_NEW_COME_USER_CLEAR";
    public static final String JOB_NEW_COME_USER_CLEAR = "JOB_NEW_COME_USER_CLEAR";

    public static final String GROUP_ACT_USER_CLEAR = "GROUP_ACT_USER_CLEAR";
    public static final String JOB_ACT_USER_CLEAR = "JOB_ACT_USER_CLEAR";

    public static final String GROUP_RECOMMENDED_USER_CLEAR = "GROUP_RECOMMENDED_USER_CLEAR";
    public static final String JOB_RECOMMENDED_USER_CLEAR = "JOB_RECOMMENDED_USER_CLEAR";

    /**
     * 时间转换成cron
     *
     * @param times
     * @return
     */
    @SuppressWarnings("deprecation")
    public static String timesToCron(Date times) {
        int sec = times.getSeconds();
        int min = times.getMinutes();
        int hou = times.getHours();
        int day = times.getDate();
        int mon = times.getMonth() + 1;
        int yea = times.getYear() + 1900;
        //System.out.println("cron时间="+sec + " " + min + " " + hou + " " + day + " " + mon + " ? " + yea);
        return sec + " " + min + " " + hou + " " + day + " " + mon + " ? " + yea;
    }
}
