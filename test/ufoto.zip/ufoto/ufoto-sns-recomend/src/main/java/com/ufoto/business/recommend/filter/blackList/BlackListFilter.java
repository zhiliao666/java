package com.ufoto.business.recommend.filter.blackList;

import com.ufoto.annotation.RecommendMetadata;
import com.ufoto.business.recommend.RecommendFilterStrategy;
import com.ufoto.dto.RecommendAdvanceRequest;
import com.ufoto.utils.redis.RedisKeyConstant;
import com.ufoto.utils.redis.RedisService;
import org.springframework.core.env.Environment;
import org.springframework.stereotype.Component;
import org.springframework.util.CollectionUtils;

import java.util.List;
import java.util.Set;

/**
 * @auther: zhangjq
 * @date: 2018/10/17 18:40
 * @description: 过滤黑名单
 */
@RecommendMetadata(
        metadataType = RecommendMetadata.MetadataType.FILTER,
        available = true,
        name = "黑名单过滤策略",
        description = "过滤黑名单中的用户,可通过开关(recommend.filter.blacklist)关闭",
        branch = {
                RecommendMetadata.Branch.NORMAL,
                RecommendMetadata.Branch.DEFAULT,
                RecommendMetadata.Branch.GIFT,
                RecommendMetadata.Branch.High_Risk,
                RecommendMetadata.Branch.USERLAYER,
                RecommendMetadata.Branch.WINK
        }
)
@Component
public class BlackListFilter implements RecommendFilterStrategy {

    private final RedisService redisService;
    private final Environment environment;

    public BlackListFilter(RedisService redisService, Environment environment) {
        this.redisService = redisService;
        this.environment = environment;
    }

    @Override
    public Set<String> filter(Set<String> recallSet, List<String> resultList, RecommendAdvanceRequest filterRequest) {
        if (environment.getProperty("recommend.filter.blacklist", Boolean.class, true)) {
            Set<String> blacklistSet = redisService.sMember(RedisKeyConstant.REDIS_USER_BLACKLIST_SET);
            if (!CollectionUtils.isEmpty(blacklistSet)) {
                recallSet.removeAll(blacklistSet);
            }
        }
        return recallSet;
    }
}
