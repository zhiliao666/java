package com.ufoto.business.recommend.bean;

import java.io.Serializable;

/**
 * <p>
 * 推荐列表 过滤参数设置
 * </p>
 *
 * @author created by chenzhou at 2018-05-11 14:00
 */
public class FilterParamsBean implements Serializable {

    private Long uid;//当前用户id
    private Integer startAge;//目标用户起始年龄
    private Integer endAge;//目标用户结束年龄
    private Double distance;//目标用户离自己的距离
    private Integer targetGender;//目标用户性别

    private Double latitude;//用户位置
    private Double longitude;//用户位置

    private String apiVersion;//api version

    public Long getUid() {
        return uid;
    }

    public void setUid(Long uid) {
        this.uid = uid;
    }

    public Integer getStartAge() {
        return startAge;
    }

    public void setStartAge(Integer startAge) {
        this.startAge = startAge;
    }

    public Integer getEndAge() {
        return endAge;
    }

    public void setEndAge(Integer endAge) {
        this.endAge = endAge;
    }

    public Double getDistance() {
        return distance;
    }

    public void setDistance(Double distance) {
        this.distance = distance;
    }

    public Integer getTargetGender() {
        return targetGender;
    }

    public void setTargetGender(Integer targetGender) {
        this.targetGender = targetGender;
    }

    public Double getLatitude() {
        return latitude;
    }

    public void setLatitude(Double latitude) {
        this.latitude = latitude;
    }

    public Double getLongitude() {
        return longitude;
    }

    public void setLongitude(Double longitude) {
        this.longitude = longitude;
    }

    public String getApiVersion() {
        return apiVersion;
    }

    public void setApiVersion(String apiVersion) {
        this.apiVersion = apiVersion;
    }
}
