package com.ufoto.constants;

/**
 * <p>
 *
 * </p>
 *
 * @author created by chenzhou at 2018-08-06 15:03
 */
public enum EUserType {
    ROBOT(0),
    FACEBOOK(1),
    GMAIL(2);

    private int type;

    EUserType(int type) {
        this.type = type;
    }

    public int getType() {
        return type;
    }
}
