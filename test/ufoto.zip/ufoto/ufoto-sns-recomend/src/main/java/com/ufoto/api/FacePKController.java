package com.ufoto.api;

import com.ufoto.dto.facepk.FacePKCompetitorsDto;
import com.ufoto.manager.UserManager;
import com.ufoto.utils.ApiResult;
import com.ufoto.utils.redis.RedisKeyConstant;
import com.ufoto.utils.redis.RedisService;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.ResponseBody;
import org.springframework.web.bind.annotation.RestController;

import java.util.List;
import java.util.Objects;
import java.util.stream.Collectors;

/**
 * Created by echo on 6/3/19.
 */
@RestController
@RequestMapping("/facepk")
public class FacePKController {

    private final RedisService redisService;

    private final UserManager userManager;

    public FacePKController(RedisService redisService, UserManager userManager) {
        this.redisService = redisService;
        this.userManager = userManager;
    }


    /**
     * 获取facePK活动的对手
     *
     * @param uid   参加活动的用户id
     * @param count 获取对手数量，不传默认为5，暂定上限为10
     * @return competitor list
     */
    @RequestMapping(value = "/competitors", method = RequestMethod.GET)
    public @ResponseBody
    ApiResult<List<FacePKCompetitorsDto>> recommend(Long uid,
                                                    @RequestParam(defaultValue = "5") Integer count) {
        if (count > 10) {
            count = 10;
        }
        if (count < 1) {
            count = 1;
        }
        //开始丑陋而不合规的实现
        List<String> competitorUidList = redisService.srandomMembers(RedisKeyConstant.REDIS_HOT_USER_SET_KEY, count * 2);
        List<FacePKCompetitorsDto> facePKCompetitorsDtoList = competitorUidList.stream()
                .map(Long::parseLong)
                .map(userManager::queryUserOne)
                .filter(Objects::nonNull)
                .limit(count)
                .map(ufotoAppUser -> {
                    FacePKCompetitorsDto competitorsDto = new FacePKCompetitorsDto();
                    competitorsDto.setUid(ufotoAppUser.getId());
                    competitorsDto.setHeadImg(ufotoAppUser.getFirstImg());
                    competitorsDto.setUserName(ufotoAppUser.getUserName());
                    competitorsDto.setGender(ufotoAppUser.getGender());
                    return competitorsDto;
                })
                .collect(Collectors.toList());
        return new ApiResult<List<FacePKCompetitorsDto>>().setResult(facePKCompetitorsDtoList);
    }
}
