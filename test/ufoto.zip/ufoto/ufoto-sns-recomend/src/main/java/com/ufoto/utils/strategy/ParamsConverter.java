package com.ufoto.utils.strategy;

import com.ufoto.business.elasticsearch.dto.UserImageAttrDto;
import com.ufoto.dto.ConditionRequest;
import com.ufoto.dto.RecommendAdvanceRequest;
import com.ufoto.manager.ElasticSearchManager;
import com.ufoto.utils.CommonUtil;
import com.ufoto.utils.DirtyCaseUtil;
import com.ufoto.utils.redis.RedisKeyConstant;
import com.ufoto.utils.redis.RedisKeyUtil;
import com.ufoto.utils.redis.RedisService;
import lombok.RequiredArgsConstructor;
import lombok.extern.slf4j.Slf4j;
import org.springframework.stereotype.Component;
import org.springframework.util.StringUtils;

import java.nio.charset.Charset;
import java.nio.charset.StandardCharsets;
import java.util.List;

/**
 * <p>
 *
 * </p>
 *
 * @author created by chenzhou at 2018-06-11 16:35
 */
@Slf4j
@Component
@RequiredArgsConstructor
public class ParamsConverter {

	private final RedisService redisService;
	private final ElasticSearchManager elasticSearchManager;
	private final DirtyCaseUtil dirtyCaseUtil;

	public ConditionRequest obtainStrategyRequest(RecommendAdvanceRequest request) {
		final Charset charset = StandardCharsets.UTF_8;
//        Integer areaId = request.getAreaId();

		ConditionRequest strategyRequest = new ConditionRequest();
		// 设置用户推荐来源
		strategyRequest.setFromType(request.getFromType());
		
		strategyRequest.setCountry(request.getCountryCode());
		strategyRequest.setAreaId(request.getAreaId());
		strategyRequest.setLanguage(request.getLanguage());
		strategyRequest.setFirstRequest(request.getFirstRequest());

		strategyRequest.setVipStatus(request.getVipStatus());
		strategyRequest.setPlatform(request.getPlatform());
		final Long uid = request.getUid();
		if (uid == null) {
			throw new RuntimeException("参数异常，uid为空");
		}
		strategyRequest.setUid(uid);
		strategyRequest.setGender(CommonUtil
				.string2Int(redisService.hget(RedisKeyUtil.obtainKey(RedisKeyConstant.REDIS_USER_HASH_KEY, uid),
						RedisKeyConstant.REDIS_USER_HASH_GENDER)));

		final byte[] uidValues = RedisKeyUtil.serializeUid(uid).getBytes(charset);
		final List<Object> objects = redisService.execPipelineForRead(connection -> {
			// 送出like数
			connection.sCard((RedisKeyConstant.REDIS_MY_LIKED_SET_KEY_NEW + uid).getBytes(charset));
			// 是否是热门用户
			connection.sIsMember(RedisKeyConstant.REDIS_HOT_USER_SET_KEY.getBytes(charset), uidValues);
			return null;
		});
		strategyRequest.setFromSweetChat(dirtyCaseUtil.ifChat(request) ? 1 : 0);
		Object likeNumObj = objects.get(0);
		if (likeNumObj != null) {
			strategyRequest.setLikeNum(Math.toIntExact((long) likeNumObj));
		} else {
			strategyRequest.setLikeNum(0);
		}
		Object isHotObj = objects.get(1);
		boolean isHot = isHotObj != null && (boolean) isHotObj;
		strategyRequest.setHotUser(isHot ? 1 : 0);
		// 因为涉及到高危用户invoker判断 需要把用户画像的查询提前 当然也可能存在业务上直接到这里的情况
		if(StringUtils.isEmpty(request.getUserLayer())) {
			UserImageAttrDto userImage = elasticSearchManager.queryUserLayer(uid);

			request.setUserLayer(userImage.getActiveLevel());
			request.setRiskLevel(userImage.getRiskLevel());

			strategyRequest.setUserLayer(userImage.getActiveLevel());
		} else {
			strategyRequest.setUserLayer(request.getUserLayer());
		}

		log.debug("strategyRequest: {}", strategyRequest);
		return strategyRequest;
	}
}
