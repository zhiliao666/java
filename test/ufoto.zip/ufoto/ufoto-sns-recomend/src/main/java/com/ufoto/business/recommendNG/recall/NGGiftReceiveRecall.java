package com.ufoto.business.recommendNG.recall;

import com.github.benmanes.caffeine.cache.LoadingCache;
import com.google.common.collect.Sets;
import com.ufoto.annotation.RecommendMetadata;
import com.ufoto.business.recommendNG.Recall;
import com.ufoto.dto.RecommendAdvanceRequest;
import com.ufoto.utils.CommonUtil;
import com.ufoto.utils.redis.RedisKeyConstant;
import com.ufoto.utils.redis.RedisService;
import lombok.extern.slf4j.Slf4j;
import org.springframework.stereotype.Component;

import java.util.HashSet;
import java.util.Optional;
import java.util.Set;

/**
 * Created by echo on 5/24/19.
 */
@RecommendMetadata(
        metadataType = RecommendMetadata.MetadataType.RECALL,
        available = true,
        updateCache = true,
        name = "礼物召回策略",
        description = "召回所有收到过礼物的用户,目前礼物卡片专用",
        branch = RecommendMetadata.Branch.GIFT
)
@Slf4j
@Component
public class NGGiftReceiveRecall implements Recall {
    private final RedisService redisService;
    private final LoadingCache<Class<?>, Object> recommendLoadingCache;

    public NGGiftReceiveRecall(RedisService redisService,
                               LoadingCache<Class<?>, Object> recommendLoadingCache) {
        this.redisService = redisService;
        this.recommendLoadingCache = recommendLoadingCache;
    }

    @Override
    public Set<String> recall(Integer minSize, RecommendAdvanceRequest recallRequest) {
        return Sets.newHashSet(CommonUtil.obj2Set(recommendLoadingCache.get(this.getClass())));
    }

    @Override
    public boolean ifRecallOnlyOnce() {
        return false;
    }

    @Override
    public boolean ifNeedThreadLocalCache() {
        return false;
    }

    public Set<String> updateCache() {
        return Optional.ofNullable(redisService.sMember(RedisKeyConstant.REDIS_GIFT_RECEIVE_USER_SET_KEY, true)).orElse(new HashSet<>());
    }
}
