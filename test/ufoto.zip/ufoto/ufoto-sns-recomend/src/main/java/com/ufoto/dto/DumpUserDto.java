package com.ufoto.dto;

import lombok.Data;

import java.io.Serializable;

/**
 * <p>
 * Author     : Chan
 * CreateDate : 2019-09-12 11:31
 * Description:
 * </p>
 */
@Data
public class DumpUserDto implements Serializable {
    private Long id;
    private Long uid;
}
