package com.ufoto.business.recommend.shuffle.base;

import java.util.List;

/**
 * Created by echo on 7/11/18.
 * <p>
 * 发牌员，将切分好的多个Uid列表按照一定的规则混洗然后返回
 */
public interface ShuffleDealer {

    String[] shuffleAndDeal(List<List<String>> cutUidList);

}
