package com.ufoto.api.tool;

import org.springframework.data.redis.core.RedisTemplate;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import com.ufoto.utils.redis.RedisKeyConstant;
import com.ufoto.utils.redis.RedisService;

import lombok.RequiredArgsConstructor;
import lombok.extern.slf4j.Slf4j;

/**
 * 
 *
 * @author zhangqh  
 * @date Apr 3, 2020 3:12:06 PM  
 * @version 1.0
 */
@Slf4j
@RestController
@RequestMapping(path = {"/winkTool/"})
@RequiredArgsConstructor
public class ApiWinkTool {
	
	private final RedisTemplate<String, String> redisTemplate;
	private final RedisService redisService;
	
	
	/**
	 * 手动设置当天临时好友上限
	 * @param key @see RedisKeyConstant.REDIS_TEMPFRIEND_DAILY_HASH
	 * @param field
	 * @param value
	 * @return
	 */
	@RequestMapping(path = "/refreshTempFriendToday")
	public String refreshAndaddchatBotUser(String key,String field,String value) {
		redisService.hset(key, field, value);
		return "sucess";
	}
}
