package com.ufoto.utils.threadlocal;

import com.ufoto.bloom.RawBloomFilterCache;
import com.ufoto.business.recommendNG.Invoker;
import lombok.extern.slf4j.Slf4j;

import java.util.Set;

/**
 * <p>
 * Author     : Chan
 * CreateDate : 2019/12/3 18:18
 * Description:
 * </p>
 */
@Slf4j
public class ThreadLocalManager {

    //已看过的列表过滤策略
    private final static ThreadLocal<RawBFListCache> REQUEST_CONTEXT_RECOMMENDED_RAW_BF = ThreadLocal.withInitial(() -> null);
    //who like me filter
    private final static ThreadLocal<Set<String>> REQUEST_CONTEXT_WHO_LIKE_ME = ThreadLocal.withInitial(() -> null);
    //gender filter
    private final static ThreadLocal<Integer> REQUEST_CONTEXT_GENDER = ThreadLocal.withInitial(() -> null);
    //通用的布隆过滤器
    public final static ThreadLocal<RawBloomFilterCache<Long>> REQUEST_CONTEXT_BLOOM_FILTER_RECOMMENDED = ThreadLocal.withInitial(() -> null);
    public final static ThreadLocal<RawBloomFilterCache<Long>> REQUEST_CONTEXT_BLOOM_FILTER_REC_CALC = ThreadLocal.withInitial(() -> null);

    private final static ThreadLocal<Invoker> REQUEST_CONTEXT_INVOKER = ThreadLocal.withInitial(() -> null);
    
    private static ThreadLocal<Integer> ESACTIVETIME = ThreadLocal.withInitial(() -> null);
    
    public static void setESACTIVETIMEThreadLocal(Integer value) {
    	ESACTIVETIME.set(value);
    }
    
    public static Integer getESACTIVETIMEThreadLocal() {
    	return ESACTIVETIME.get();
    }

    public static RawBFListCache rawBfThreadLocal() {
        return REQUEST_CONTEXT_RECOMMENDED_RAW_BF.get();
    }

    public static void rawBfThreadLocal(RawBFListCache value) {
        REQUEST_CONTEXT_RECOMMENDED_RAW_BF.set(value);
    }

    @SuppressWarnings("unchecked")
    public static Set<String> whoLikeMeThreadLocal() {
        return REQUEST_CONTEXT_WHO_LIKE_ME.get();
    }

    public static void whoLikeMeThreadLocal(Set<String> value) {
        REQUEST_CONTEXT_WHO_LIKE_ME.set(value);
    }

    public static Integer needGenderThreadLocal() {
        return REQUEST_CONTEXT_GENDER.get();
    }

    public static void needGenderThreadLocal(Integer value) {
        REQUEST_CONTEXT_GENDER.set(value);
    }

    public static Invoker invokerThreadLocal() {
        return REQUEST_CONTEXT_INVOKER.get();
    }

    public static void invokerThreadLocal(Invoker invoker) {
        REQUEST_CONTEXT_INVOKER.set(invoker);
    }

    public static void clear() {
        REQUEST_CONTEXT_RECOMMENDED_RAW_BF.remove();
        REQUEST_CONTEXT_WHO_LIKE_ME.remove();
        REQUEST_CONTEXT_GENDER.remove();
        REQUEST_CONTEXT_BLOOM_FILTER_RECOMMENDED.remove();
        REQUEST_CONTEXT_BLOOM_FILTER_REC_CALC.remove();
        REQUEST_CONTEXT_INVOKER.remove();
        ESACTIVETIME.remove();
    }
}
