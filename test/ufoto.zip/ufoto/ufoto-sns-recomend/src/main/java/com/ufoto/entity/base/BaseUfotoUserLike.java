package com.ufoto.entity.base;

import java.io.Serializable;

public class BaseUfotoUserLike implements Serializable {
    /**
     * Default value included to remove warning. Remove or modify at will.
     **/
    private static final long serialVersionUID = 1L;

    private java.lang.Integer createTime;
    private java.lang.Long id;
    private java.lang.Long tUId;
    private java.lang.Long fUId;
    private java.lang.Integer type;

    public java.lang.Integer getCreateTime() {
        return createTime;
    }

    public void setCreateTime(java.lang.Integer createTime) {
        this.createTime = createTime;
    }

    public java.lang.Long getId() {
        return id;
    }

    public void setId(java.lang.Long id) {
        this.id = id;
    }

    public java.lang.Long getTUId() {
        return tUId;
    }

    public void setTUId(java.lang.Long tUId) {
        this.tUId = tUId;
    }

    public java.lang.Long getFUId() {
        return fUId;
    }

    public void setFUId(java.lang.Long fUId) {
        this.fUId = fUId;
    }

    public java.lang.Integer getType() {
        return type;
    }

    public void setType(java.lang.Integer type) {
        this.type = type;
    }


//	@Override
//	public String toString() {
//		return "{ id:" + id + ", name:" + name + ", email:" + email
//				+ ", phone:" + phoneNumber + " }";
//	}
}
