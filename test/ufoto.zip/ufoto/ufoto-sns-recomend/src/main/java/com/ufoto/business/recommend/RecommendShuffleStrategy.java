package com.ufoto.business.recommend;

/**
 * Created by echo on 7/11/18.
 */
public interface RecommendShuffleStrategy {

    String[] shuffle(String[] uidArray);
}
