package com.ufoto.business.recommend.sort.fromOthers;

import com.google.common.collect.Maps;
import com.ufoto.annotation.RecommendMetadata;
import com.ufoto.business.recommend.bean.SortParamsBean;
import com.ufoto.business.recommend.sort.BaseNormalSortStrategy;
import com.ufoto.utils.CommonUtil;
import com.ufoto.utils.redis.RedisKeyConstant;
import com.ufoto.utils.redis.RedisKeyUtil;
import com.ufoto.utils.redis.RedisService;
import lombok.extern.slf4j.Slf4j;
import org.springframework.stereotype.Component;
import org.springframework.util.CollectionUtils;
import org.springframework.util.StringUtils;

import java.nio.charset.StandardCharsets;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.stream.Collectors;

@RecommendMetadata(
        metadataType = RecommendMetadata.MetadataType.SORT,
        available = true,
        name = "非chat男性用户排序策略",
        description = "任何非chat男性用户,基础分数为-1,其他为0",
        branch = RecommendMetadata.Branch.NORMAL
)
@Slf4j
@Component
public class FromOthersSortStrategy extends BaseNormalSortStrategy {

    private final RedisService redisService;

    public FromOthersSortStrategy(RedisService redisService) {
        this.redisService = redisService;
    }

    /**
     * 将sweetChat与其他来源用户区分开
     */
    @Override
    public Map<String, Double> getScore(List<String> recallUids, SortParamsBean sortParamsBean) {
        List<Long> uids = recallUids.stream().filter(StringUtils::hasText).map(Long::valueOf).collect(Collectors.toList());
        if (CollectionUtils.isEmpty(uids)) {
            return Maps.newHashMap();
        }

        List<Object> fromTypeGenderList = redisService.execPipelineForRead(connection -> {
            for (String id : recallUids) {
                connection.hMGet(
                        RedisKeyUtil.obtainKey(RedisKeyConstant.REDIS_USER_HASH_KEY, id).getBytes(StandardCharsets.UTF_8),
                        RedisKeyConstant.REDIS_USER_HASH_FROM_TYPE.getBytes(StandardCharsets.UTF_8),
                        RedisKeyConstant.REDIS_USER_HASH_GENDER.getBytes(StandardCharsets.UTF_8)
                );
            }
            return null;
        });

        Map<String, Double> scoreMap = new HashMap<>();
        final int size = recallUids.size();
        for (int i = 0; i < size; i++) {
            final Object fromTypeGender = fromTypeGenderList.get(i);
            final String recallUid = recallUids.get(i);
            if (ifMaleFromOther(fromTypeGender)) {
                scoreMap.put(recallUid, -1D);
            } else {
                scoreMap.put(recallUid, 0D);
            }
        }
        return scoreMap;
    }

    /**
     * 判断对应的用户是否 “非chat男性用户”
     * <p>
     * 出现任何异常都认为他是 “非chat男性用户”
     */
    private boolean ifMaleFromOther(Object redisResultFromTypeGenderObj) {
        try {
            final List<Integer> fromTypeGender = CommonUtil.obj2ListInt(redisResultFromTypeGenderObj);
            if (fromTypeGender.size() != 2) return true;
            Integer fromType = fromTypeGender.get(0);
            Integer gender = fromTypeGender.get(1);
            return fromType == null || gender == null
                    || (!fromType.equals(3) && !gender.equals(2));
        } catch (Exception e) {
            log.error("redisResultFromTypeGenderObj:{},err:{}", redisResultFromTypeGenderObj, e.getMessage());
            return true;
        }
    }
}
