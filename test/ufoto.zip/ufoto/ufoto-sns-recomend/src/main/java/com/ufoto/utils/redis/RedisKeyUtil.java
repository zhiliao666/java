package com.ufoto.utils.redis;

import com.google.common.base.Joiner;
import org.apache.commons.lang.ArrayUtils;
import org.apache.commons.lang.StringUtils;

import java.nio.charset.Charset;
import java.nio.charset.StandardCharsets;
import java.text.MessageFormat;
import java.util.Arrays;

/**
 * Created by echo on 1/3/18.
 */
public class RedisKeyUtil {

    private final static Charset CHARSET = StandardCharsets.UTF_8;

    /**
     * 获取redis的组合key
     *
     * @param redisKey     redis key 带占位符
     * @param placeholders 占位符对应的值
     * @return 组合key
     */
    public static String obtainKey(String redisKey, Object... placeholders) {
        if (StringUtils.isBlank(redisKey)) {
            throw new RuntimeException("redisKey is null");
        }
        if (ArrayUtils.isEmpty(placeholders)) {
            return redisKey;
        }
        return MessageFormat.format(redisKey, Arrays.stream(placeholders).map(String::valueOf).toArray());
    }

    public static String serializeUid(Long uid) {
        if (uid == null) return null;
        return Joiner.on("").join("\"", uid, "\"");
    }

    public static String serializeUid(String uid) {
        if (uid == null) return null;
        return Joiner.on("").join("\"", uid, "\"");
    }

    public static byte[] keyBytes(String key) {
        return key.getBytes(CHARSET);
    }

    public static byte[] keyBytesWithSerializeUid(String uid) {
        if (uid == null) return null;
        return serializeUid(uid).getBytes(CHARSET);
    }

    public static byte[] keyBytesWithSerializeUid(Long uid) {
        if (uid == null) return null;
        return serializeUid(uid).getBytes(CHARSET);
    }

    public static void main(String[] args) {
        String result = RedisKeyUtil.obtainKey(RedisKeyConstant.REDIS_LANGUAGE_GENDER_CHAT_BOT_V5_UID_SET_KEY, "343",12);
        System.out.print(result);
    }
}
