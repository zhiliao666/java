package com.ufoto.business.elasticsearch.dto;

/**
 * <p>
 * Author     : Chan
 * CreateDate : 2019/11/20 09:39
 * Description:
 * </p>
 */
public class ElasticSearchException extends RuntimeException {

    public ElasticSearchException() {
        super();
    }

    public ElasticSearchException(String message) {
        super(message);
    }

    public ElasticSearchException(String message, Throwable cause) {
        super(message, cause);
    }

    public ElasticSearchException(Throwable cause) {
        super(cause);
    }

    protected ElasticSearchException(String message, Throwable cause, boolean enableSuppression, boolean writableStackTrace) {
        super(message, cause, enableSuppression, writableStackTrace);
    }
}
