package com.ufoto.dto;

import lombok.Data;

import java.io.Serializable;
import java.util.Set;

/**
 * <p>
 * Author     : Chan
 * CreateDate : 2018/10/10 10:42
 * Description:
 * </p>
 */
@Data
public class CardParam implements Serializable {
    private Long uid;
    private String lang;
    private int limit;
    private Set<Integer> typeSubs;
    private Set<Integer> typeWhiteList;
}
