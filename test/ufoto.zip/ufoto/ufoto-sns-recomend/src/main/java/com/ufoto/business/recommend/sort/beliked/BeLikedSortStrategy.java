package com.ufoto.business.recommend.sort.beliked;

import com.ufoto.annotation.RecommendMetadata;
import com.ufoto.business.recommend.bean.SortParamsBean;
import com.ufoto.business.recommend.sort.BaseNormalSortStrategy;
import com.ufoto.utils.CommonUtil;
import com.ufoto.utils.redis.RedisKeyConstant;
import com.ufoto.utils.redis.RedisService;
import org.springframework.stereotype.Component;

import java.nio.charset.StandardCharsets;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

/**
 * Created by echo on 4/8/18.
 */
@RecommendMetadata(
        metadataType = RecommendMetadata.MetadataType.SORT,
        available = true,
        name = "用户收到like数排序策略",
        description = "基础分数为每个用户收到的like数量,如果没收到过like,默认为0",
        branch = RecommendMetadata.Branch.NORMAL
)
@Component
public class BeLikedSortStrategy extends BaseNormalSortStrategy {

    private final RedisService redisService;

    public BeLikedSortStrategy(RedisService redisService) {
        this.redisService = redisService;
    }

    /**
     * 返回某用户一共收到的like次数
     */
    @Override
    public Map<String, Double> getScore(List<String> recallUids, SortParamsBean sortParamsBean) {
        final List<Object> objects = redisService.execPipelineForRead(connection -> {
            for (String recallUid : recallUids) {
                connection.sCard((RedisKeyConstant.REDIS_BE_LIKED_SET_KEY_ + recallUid).getBytes(StandardCharsets.UTF_8));
            }
            return null;
        });
        Map<String, Double> scoreMap = new HashMap<>();
        final int size = recallUids.size();
        for (int i = 0; i < size; i++) {
            final long likedNum = CommonUtil.null2Long(objects.get(i));
            final String recallUid = recallUids.get(i);
            scoreMap.put(recallUid, likedNum * 1.0);
        }
        return scoreMap;
    }
}
