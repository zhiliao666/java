package com.ufoto.dao.base;

import com.ufoto.entity.UfotoRecommendRedisDump;
import org.apache.ibatis.annotations.*;
import org.apache.ibatis.jdbc.SQL;

import java.util.List;

public interface BaseUfotoRecommendRedisDumpMapper {

    @Results({
            @Result(property = "id", column = "id"),
            @Result(property = "uid", column = "uid"),
            @Result(property = "key", column = "redis_key"),
            @Result(property = "dump", column = "dump"),
            @Result(property = "createTime", column = "create_time"),
            @Result(property = "lastActTime", column = "last_act_time"),
            @Result(property = "hasRestored", column = "has_restored"),
    })
    @Select("SELECT * FROM ufoto_recommend_redis_dump")
    List<UfotoRecommendRedisDump> list();

    @Select("SELECT count(*) FROM ufoto_recommend_redis_dump")
    int count();

    @Results({
            @Result(property = "id", column = "id"),
            @Result(property = "uid", column = "uid"),
            @Result(property = "key", column = "redis_key"),
            @Result(property = "dump", column = "dump"),
            @Result(property = "createTime", column = "create_time"),
            @Result(property = "lastActTime", column = "last_act_time"),
            @Result(property = "hasRestored", column = "has_restored"),
    })
    @Select("SELECT * FROM ufoto_recommend_redis_dump WHERE id = #{id}")
    UfotoRecommendRedisDump selectOneById(@Param("id") Long id);

    @Delete("DELETE FROM ufoto_recommend_redis_dump WHERE id = #{id}")
    int delete(Long id);

    //@Insert("INSERT INTO ufoto_recommend_redis_dump(uid,key,dump,create_time,last_act_time,has_restored) VALUES(#{uid},#{key},#{dump},#{createTime},#{lastActTime},#{hasRestored})")
    //@Options(useGeneratedKeys=true, keyProperty="id")
    //public int insert(UfotoRecommendRedisDump ufotoRecommendRedisDump);

    @InsertProvider(type = ProviderSqlBuilder.class, method = "insert")
    @Options(useGeneratedKeys = true, keyProperty = "id")
    int insert(UfotoRecommendRedisDump ufotoRecommendRedisDump);

    @UpdateProvider(type = ProviderSqlBuilder.class, method = "updateById")
    int update(UfotoRecommendRedisDump ufotoRecommendRedisDump);

    class ProviderSqlBuilder {

        public String insert(final UfotoRecommendRedisDump ufotoRecommendRedisDump) {
            return new SQL() {
                {
                    INSERT_INTO("ufoto_recommend_redis_dump");
                    if (ufotoRecommendRedisDump.getId() != null) {
                        VALUES("id", "#{id}");
                    }
                    if (ufotoRecommendRedisDump.getUid() != null) {
                        VALUES("uid", "#{uid}");
                    }
                    if (ufotoRecommendRedisDump.getKey() != null) {
                        VALUES("redis_key", "#{key}");
                    }
                    if (ufotoRecommendRedisDump.getDump() != null) {
                        VALUES("dump", "#{dump}");
                    }
                    if (ufotoRecommendRedisDump.getCreateTime() != null) {
                        VALUES("create_time", "#{createTime}");
                    }
                    if (ufotoRecommendRedisDump.getLastActTime() != null) {
                        VALUES("last_act_time", "#{lastActTime}");
                    }
                    if (ufotoRecommendRedisDump.getHasRestored() != null) {
                        VALUES("has_restored", "#{hasRestored}");
                    }
                    WHERE("id = #{id}");
                }
            }.toString();
        }

        public String updateById(final UfotoRecommendRedisDump ufotoRecommendRedisDump) {
            return new SQL() {
                {
                    UPDATE("ufoto_recommend_redis_dump");
                    if (ufotoRecommendRedisDump.getId() != null) {
                        SET("id = #{id}");
                    }
                    if (ufotoRecommendRedisDump.getUid() != null) {
                        SET("uid = #{uid}");
                    }
                    if (ufotoRecommendRedisDump.getKey() != null) {
                        SET("redis_key = #{key}");
                    }
                    if (ufotoRecommendRedisDump.getDump() != null) {
                        SET("dump = #{dump}");
                    }
                    if (ufotoRecommendRedisDump.getCreateTime() != null) {
                        SET("create_time = #{createTime}");
                    }
                    if (ufotoRecommendRedisDump.getLastActTime() != null) {
                        SET("last_act_time = #{lastActTime}");
                    }
                    if (ufotoRecommendRedisDump.getHasRestored() != null) {
                        SET("has_restored = #{hasRestored}");
                    }
                    WHERE("id = #{id}");
                }
            }.toString();
        }
    }
}
