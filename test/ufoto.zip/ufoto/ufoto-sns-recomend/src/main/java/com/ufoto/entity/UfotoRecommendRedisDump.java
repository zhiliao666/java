package com.ufoto.entity;

import com.ufoto.entity.base.BaseUfotoRecommendRedisDump;

public class UfotoRecommendRedisDump extends BaseUfotoRecommendRedisDump {

    private static final long serialVersionUID = 1L;


}
