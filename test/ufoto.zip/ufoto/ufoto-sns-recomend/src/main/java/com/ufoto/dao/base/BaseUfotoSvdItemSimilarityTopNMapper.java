package com.ufoto.dao.base;

import com.ufoto.entity.UfotoSvdItemSimilarityTopN;
import org.apache.ibatis.annotations.*;
import org.apache.ibatis.jdbc.SQL;

import java.util.List;

public interface BaseUfotoSvdItemSimilarityTopNMapper {

    @Results({
            @Result(property = "id", column = "id"),
            @Result(property = "iId", column = "i_id"),
            @Result(property = "sIId", column = "s_i_id"),
            @Result(property = "rank", column = "rank"),
            @Result(property = "createTime", column = "create_time"),
    })
    @Select("SELECT * FROM ufoto_svd_item_similarity_top_n")
    List<UfotoSvdItemSimilarityTopN> list();

    @Select("SELECT count(*) FROM ufoto_svd_item_similarity_top_n")
    int count();

    @Results({
            @Result(property = "id", column = "id"),
            @Result(property = "iId", column = "i_id"),
            @Result(property = "sIId", column = "s_i_id"),
            @Result(property = "rank", column = "rank"),
            @Result(property = "createTime", column = "create_time"),
    })
    @Select("SELECT * FROM ufoto_svd_item_similarity_top_n WHERE id = #{id}")
    UfotoSvdItemSimilarityTopN selectOneById(@Param("id") Integer id);

    @Delete("DELETE FROM ufoto_svd_item_similarity_top_n WHERE id = #{id}")
    int delete(Integer id);

    //@Insert("INSERT INTO ufoto_svd_item_similarity_top_n(i_id,s_i_id,rank,create_time) VALUES(#{iId},#{sIId},#{rank},#{createTime})")
    //@Options(useGeneratedKeys=true, keyProperty="id")
    //public int insert(UfotoSvdItemSimilarityTopN ufotoSvdItemSimilarityTopN);

    @InsertProvider(type = ProviderSqlBuilder.class, method = "insert")
    @Options(useGeneratedKeys = true, keyProperty = "id")
    int insert(UfotoSvdItemSimilarityTopN ufotoSvdItemSimilarityTopN);

    @UpdateProvider(type = ProviderSqlBuilder.class, method = "updateById")
    int update(UfotoSvdItemSimilarityTopN ufotoSvdItemSimilarityTopN);

    class ProviderSqlBuilder {

        public String insert(final UfotoSvdItemSimilarityTopN ufotoSvdItemSimilarityTopN) {
            return new SQL() {
                {
                    INSERT_INTO("ufoto_svd_item_similarity_top_n");
                    if (ufotoSvdItemSimilarityTopN.getId() != null) {
                        VALUES("id", "#{id}");
                    }
                    if (ufotoSvdItemSimilarityTopN.getIId() != null) {
                        VALUES("i_id", "#{iId}");
                    }
                    if (ufotoSvdItemSimilarityTopN.getSIId() != null) {
                        VALUES("s_i_id", "#{sIId}");
                    }
                    if (ufotoSvdItemSimilarityTopN.getRank() != null) {
                        VALUES("rank", "#{rank}");
                    }
                    if (ufotoSvdItemSimilarityTopN.getCreateTime() != null) {
                        VALUES("create_time", "#{createTime}");
                    }
                    WHERE("id = #{id}");
                }
            }.toString();
        }

        public String updateById(final UfotoSvdItemSimilarityTopN ufotoSvdItemSimilarityTopN) {
            return new SQL() {
                {
                    UPDATE("ufoto_svd_item_similarity_top_n");
                    if (ufotoSvdItemSimilarityTopN.getId() != null) {
                        SET("id = #{id}");
                    }
                    if (ufotoSvdItemSimilarityTopN.getIId() != null) {
                        SET("i_id = #{iId}");
                    }
                    if (ufotoSvdItemSimilarityTopN.getSIId() != null) {
                        SET("s_i_id = #{sIId}");
                    }
                    if (ufotoSvdItemSimilarityTopN.getRank() != null) {
                        SET("rank = #{rank}");
                    }
                    if (ufotoSvdItemSimilarityTopN.getCreateTime() != null) {
                        SET("create_time = #{createTime}");
                    }
                    WHERE("id = #{id}");
                }
            }.toString();
        }
    }
}
