package com.ufoto.config;

import com.ufoto.bloom.RecommendCalculatedBloomFilter;
import com.ufoto.bloom.RecommendedRecommendBloomFilter;
import com.ufoto.utils.redis.RedisService;
import com.ufoto.utils.threadlocal.ThreadLocalManager;
import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;

/**
 * <p>
 * Author     : Chan
 * CreateDate : 2019/12/5 12:44
 * Description:
 * </p>
 */
@Configuration
public class BloomFilterConfig {

    @Bean
    public RecommendedRecommendBloomFilter recommendedRecommendBloomFilter(RedisService redisService) {
        final RecommendedRecommendBloomFilter bloomFilter = new RecommendedRecommendBloomFilter(redisService);
        bloomFilter.setThreadLocal(ThreadLocalManager.REQUEST_CONTEXT_BLOOM_FILTER_RECOMMENDED);
        return bloomFilter;
    }

    @Bean
    public RecommendCalculatedBloomFilter recommendCalculatedBloomFilter(RedisService redisService) {
        final RecommendCalculatedBloomFilter bloomFilter = new RecommendCalculatedBloomFilter(redisService);
        bloomFilter.setThreadLocal(ThreadLocalManager.REQUEST_CONTEXT_BLOOM_FILTER_REC_CALC);
        return bloomFilter;
    }

}
