package com.ufoto.business.recommend.sort.popular;

import com.ufoto.annotation.RecommendMetadata;
import com.ufoto.business.recommend.bean.SortParamsBean;
import com.ufoto.business.recommend.sort.BaseNormalSortStrategy;
import com.ufoto.utils.KeyTransitionUtil;
import com.ufoto.utils.redis.RedisService;
import org.springframework.stereotype.Component;

import java.util.List;
import java.util.Map;

/**
 * Created by echo on 4/8/18.
 */
@RecommendMetadata(
        metadataType = RecommendMetadata.MetadataType.SORT,
        available = true,
        name = "受欢迎程度排序",
        description = "根据用户的受欢迎程度计算分数,如果受欢迎程度为null,默认0.05f",
        branch = {RecommendMetadata.Branch.NORMAL}
)
@Component
public class PopularSortStrategy extends BaseNormalSortStrategy {

    private static final double DEFAULT_POPULAR = 0.05f;
    private final RedisService redisService;

    public PopularSortStrategy(RedisService redisService) {
        this.redisService = redisService;
    }

    /**
     * 返回受欢迎程度值 可能为null
     */
    @Override
    public Map<String, Double> getScore(List<String> recallUids, SortParamsBean sortParamsBean) {
        final Map<String, Double> scoreMap = KeyTransitionUtil.selectPopularMap(redisService, recallUids);
        for (Map.Entry<String, Double> entry : scoreMap.entrySet()) {
            if (entry.getValue() == null) {
                entry.setValue(DEFAULT_POPULAR);
            }
        }
        return scoreMap;
    }
}
