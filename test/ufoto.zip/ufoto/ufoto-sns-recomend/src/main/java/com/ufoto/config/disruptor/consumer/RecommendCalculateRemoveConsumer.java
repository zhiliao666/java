package com.ufoto.config.disruptor.consumer;

import com.ufoto.config.disruptor.constants.ConsumerId;
import com.ufoto.config.disruptor.constants.EventType;
import com.ufoto.config.disruptor.event.AsyncEvent;
import org.springframework.stereotype.Component;

/**
 * <p>
 * Description:
 * 推荐列表计算后 将制定list移出缓存
 * 下一个事件 {@link EventType#RECOMMEND_CALCULATE_BLOOM}
 * </p>
 *
 * @author Chan
 * @date 2019/12/21 17:48
 */
@Component
public class RecommendCalculateRemoveConsumer extends AsyncConsumer {
    public RecommendCalculateRemoveConsumer() {
        super(ConsumerId.CONSUMER_RECOMMEND_CALCULATE_REMOVE);
    }

    @Override
    public void consume(AsyncEvent event) {
        super.consume(event);
        event.setEventType(EventType.RECOMMEND_CALCULATE_BLOOM);
    }
}
