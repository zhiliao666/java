package com.ufoto.constants;

import com.ufoto.utils.redis.RedisKeyConstant;

/**
 * <p>
 * Author     : Chan
 * CreateDate : 2019-04-04 12:42
 * Description:
 * </p>
 */
public enum ELikeStatisticsType {
    LIKE(1, "喜欢", RedisKeyConstant.REDIS_MY_LIKED_SET_KEY_NEW),
    SUPER_LIKE(3, "超级喜欢", RedisKeyConstant.REDIS_MY_SUPER_LIKED_SET_KEY_),
    BE_LIKE(4, "被like", RedisKeyConstant.REDIS_BE_LIKED_SET_KEY_),
    BE_SUPER_LIKE(5, "被super like", RedisKeyConstant.REDIS_BE_SUPER_LIKED_SET_KEY_);

    private int type;
    private String desc;
    private String key;

    ELikeStatisticsType(int type, String desc, String key) {
        this.type = type;
        this.desc = desc;
        this.key = key;
    }

    public int getType() {
        return type;
    }

    public String getDesc() {
        return desc;
    }

    public String getKey() {
        return key;
    }

}
