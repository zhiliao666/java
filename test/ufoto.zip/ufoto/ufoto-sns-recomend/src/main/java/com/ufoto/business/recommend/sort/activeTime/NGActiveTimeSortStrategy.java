package com.ufoto.business.recommend.sort.activeTime;

import com.google.common.collect.Maps;
import com.ufoto.annotation.RecommendMetadata;
import com.ufoto.business.recommend.bean.SortParamsBean;
import com.ufoto.business.recommend.sort.BaseNormalSortStrategy;
import com.ufoto.utils.DateUtil;
import com.ufoto.utils.KeyTransitionUtil;
import com.ufoto.utils.redis.RedisService;
import lombok.extern.slf4j.Slf4j;
import org.apache.commons.lang3.StringUtils;
import org.springframework.core.env.Environment;
import org.springframework.stereotype.Component;

import java.math.BigDecimal;
import java.util.List;
import java.util.Map;

/**
 * <p>
 * Author     : Chan
 * CreateDate : 2019-08-21 11:17
 * Description:
 * </p>
 */
@RecommendMetadata(
        metadataType = RecommendMetadata.MetadataType.SORT,
        available = true,
        name = "活跃时间排序策略(新)",
        description = "默认是24分，活跃时间与当前时间每差1小时，扣除掉 1* K的分数。 K可以配置" +
                "1. 如果是online状态，则返回24 - 0*K = 24" +
                "2. 如果不是online状态，则计算上次活跃时间和当前时间相差的小时数，如果小于一小时，则为0. 最后积分是24-小时数*K" +
                "online状态目前以可配置时间计算,默认活跃时间相差30分钟视为在线",
        branch = RecommendMetadata.Branch.NORMAL
)
@Slf4j
@Component
public class NGActiveTimeSortStrategy extends BaseNormalSortStrategy {

    private final Environment env;
    private final RedisService redisService;

    public NGActiveTimeSortStrategy(Environment env,
                                    RedisService redisService) {
        this.env = env;
        this.redisService = redisService;
    }

    @Override
    public Map<String, Double> getScore(List<String> recallUids, SortParamsBean sortParamsBean) {
        final BigDecimal kRate = env.getProperty("activity.time.sort.k", BigDecimal.class, BigDecimal.ONE);
        final BigDecimal defaultScore = env.getProperty("activity.time.sort.default.score", BigDecimal.class, new BigDecimal("24"));
        final Integer onlineWindow = env.getProperty("activity.time.sort.online", Integer.class, 60);
        final Map<String, String> actMap = KeyTransitionUtil.activityTimeList(redisService, recallUids);
        final Map<String, Double> scoreMap = Maps.newHashMap();
        for (String uid : recallUids) {
            final String actTimeStr = actMap.get(uid);
            if (StringUtils.isBlank(actTimeStr)) {
                scoreMap.put(uid, 0D);
                continue;
            }
            scoreMap.put(uid,
                    defaultScore.subtract(
                            kRate.multiply(new BigDecimal(onlineRate(uid, actTimeStr, onlineWindow) + ""))
                    ).doubleValue());
        }
        log.debug("kRate:{},defaultScore:{},onlineWindow:{},scoreMap:{}",
                kRate, defaultScore, onlineWindow, scoreMap);
        return scoreMap;
    }

    // implement
    private int onlineRate(String uid, String actTimeStr, Integer onlineWindow) {
        try {
            int act = Integer.parseInt(actTimeStr);
            int diff = DateUtil.getCurrentSecondIntValue() - act;
            return diff < 0 ? 0 : diff / (onlineWindow * 60);
        } catch (NumberFormatException e) {
            log.error(uid + "  " + e.getMessage(), e);
        }
        return 0;
    }
}
