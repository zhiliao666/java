package com.ufoto.business.usercenter.dto;

import com.fasterxml.jackson.annotation.JsonProperty;
import lombok.Data;

import java.io.Serializable;

/**
 * @author luozq
 * @date 2019/9/23 15:23
 */
@Data
public class UfotoUserImageDo implements Serializable {

    /**
     * swipe type
     */
    public static final int SWIPE_IMAGE_TYPE = 0;

    private Long id;

    /**
     * user id
     */
    @JsonProperty("uid")
    private Long uid;

    /**
     * num, default 0
     */
    private Integer num;

    /**
     * image link
     */
    private String url;

    /**
     * 0 default, 1 pass, 2 illegal 3 error, 4 reviewing
     */
    private Integer status;

    /**
     * 1 deleted, 0 not delete
     */
    private Integer isDelete;

    /**
     * 0 default, swipe activity, 1 DNA activity, 2 coin tree activity, 3 sticker activity
     */
    private Integer type;

    /**
     * 0 not visible , 1 visible
     */
    private Integer isVisible;

    /**
     * create time, timestamp
     */
    private Integer createTime;

    /**
     * update time
     */
    private Integer updateTime;
}
