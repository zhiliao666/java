package com.ufoto.dto;

import lombok.Data;

import java.io.Serializable;

/**
 * <p>
 * Author     : Chan
 * CreateDate : 2019-04-04 12:39
 * Description:
 * </p>
 */
@Data
public class LikeStatisticsDto implements Serializable {
    //被like的数量
    private int beLikedNum;
    //被superlike的数量
    private int beSuperLikedNum;
    //送出superlike的数量
    private int sentSuperLikedNum;
    //送出的like数量
    private int sendLikedNum;
}
