package com.ufoto.api;

import com.google.common.collect.Lists;
import com.google.common.collect.Maps;
import com.google.common.collect.Sets;
import com.ufoto.annotation.RecommendMetadata;
import com.ufoto.business.recommend.RecommendCacheUpdater;
import com.ufoto.business.recommend.RecommendFilterStrategy;
import com.ufoto.business.recommend.bean.SortParamsBean;
import com.ufoto.business.recommend.filter.LoginFilterStrategy;
import com.ufoto.business.recommend.filter.RandomMatchFilterStrategy;
import com.ufoto.business.recommend.shuffle.ChatBotShuffleStrategy;
import com.ufoto.business.recommend.shuffle.GenderShuffleStrategy;
import com.ufoto.business.recommend.shuffle.LikeMeShuffleStrategy;
import com.ufoto.business.recommend.shuffle.NewComeShuffleStrategy;
import com.ufoto.business.recommend.shuffle.SuperLikeMeShuffleStrategy;
import com.ufoto.business.recommend.sort.CompositeRecommendSortStrategy;
import com.ufoto.business.recommend.sort.SpecificRecommendSortStrategy;
import com.ufoto.business.recommendNG.Invoker;
import com.ufoto.business.recommendNG.InvokerFactory;
import com.ufoto.business.recommendNG.Reagent;
import com.ufoto.business.recommendNG.Recall;
import com.ufoto.business.recommendNG.ab.AbTestManager;
import com.ufoto.business.recommendNG.recall.NGRandomRecall;
import com.ufoto.business.usercenter.dto.UfotoUserImageDo;
import com.ufoto.config.disruptor.constants.EventType;
import com.ufoto.config.disruptor.data.UserActivityTimestampAsyncData;
import com.ufoto.config.disruptor.event.AsyncEvent;
import com.ufoto.config.rule.LocalRuleStorage;
import com.ufoto.constants.EGender;
import com.ufoto.constants.ELikeStatisticsType;
import com.ufoto.constants.ELikeType;
import com.ufoto.constants.ERecommendUserType;
import com.ufoto.constants.RedisKeyConstants;
import com.ufoto.dto.CommonStrategyBean;
import com.ufoto.dto.ConditionRequest;
import com.ufoto.dto.FilterRequestDto;
import com.ufoto.dto.LikeStatisticsDto;
import com.ufoto.dto.RandomMatchFilterDto;
import com.ufoto.dto.RecommendAdvanceRequest;
import com.ufoto.dto.RecommendAdvanceRequestExpand;
import com.ufoto.dto.RecommendListRequest;
import com.ufoto.dto.UserBeLikedDto;
import com.ufoto.dto.sns.SnsLikeStatusDto;
import com.ufoto.dto.sns.SnsRecommendExpandDto;
import com.ufoto.entity.UfotoAppUser;
import com.ufoto.lmax.LMaxDisruptor;
import com.ufoto.manager.CommonServiceManager;
import com.ufoto.manager.UserManager;
import com.ufoto.mq.RabbitProducer;
import com.ufoto.mq.constants.EExchange;
import com.ufoto.runner.RuleCacheManager;
import com.ufoto.runner.RuleEngineManager;
import com.ufoto.service.CleanRedisService;
import com.ufoto.service.RecommendScoreLogService;
import com.ufoto.service.RecommendService;
import com.ufoto.service.RecommendToolService;
import com.ufoto.service.UfotoAppUserService;
import com.ufoto.service.UfotoRecommendRedisDumpService;
import com.ufoto.service.UfotoUserLikeToService;
import com.ufoto.utils.ApiResult;
import com.ufoto.utils.BeanUtil;
import com.ufoto.utils.DateUtil;
import com.ufoto.utils.JSONUtil;
import com.ufoto.utils.KeyTransitionUtil;
import com.ufoto.utils.SpringContextUtil;
import com.ufoto.utils.redis.RedisKeyConstant;
import com.ufoto.utils.redis.RedisKeyUtil;
import com.ufoto.utils.redis.RedisService;
import com.ufoto.utils.strategy.ParamsConverter;
import com.ufoto.utils.threadlocal.ThreadLocalManager;
import lombok.RequiredArgsConstructor;
import lombok.extern.slf4j.Slf4j;
import org.apache.commons.lang.math.RandomUtils;
import org.springframework.aop.support.AopUtils;
import org.springframework.cloud.context.environment.EnvironmentManager;
import org.springframework.data.redis.core.RedisCallback;
import org.springframework.data.redis.core.RedisTemplate;
import org.springframework.util.CollectionUtils;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.RestController;

import java.nio.charset.StandardCharsets;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.Collection;
import java.util.EnumSet;
import java.util.HashSet;
import java.util.List;
import java.util.Map;
import java.util.Objects;
import java.util.Set;
import java.util.concurrent.TimeUnit;
import java.util.stream.Collectors;


/**
 * Created by echo on 1/8/18.
 */
@Slf4j
@RestController
@RequestMapping(path = {"/recommendTool/", "recommend"})
@RequiredArgsConstructor
public class RecommendToolController {

    private final RecommendService recommendService;
    private final RedisService redisService;
    private final UfotoAppUserService ufotoAppUserService;
    private final RecommendScoreLogService recommendScoreLogService;
    private final RandomMatchFilterStrategy randomMatchFilterStrategy;
    private final CleanRedisService cleanRedisService;
    private final RecommendToolService recommendToolService;
    private final UfotoUserLikeToService ufotoUserLikeToService;
    private final UfotoRecommendRedisDumpService ufotoRecommendRedisDumpService;
    private final RecommendCacheUpdater recommendCacheUpdater;
    private final LoginFilterStrategy loginFilterStrategy;
    private final EnvironmentManager environmentManager;
    private final RabbitProducer rabbitProducer;
    private final UserManager userManager;
    private final LMaxDisruptor<AsyncEvent> asyncEventLMaxDisruptor;
    private final AbTestManager abTestManager;
    private final InvokerFactory invokerFactory;
    private final ParamsConverter paramsConverter;
    private final RuleEngineManager ruleEngineManager;
    private final RuleCacheManager ruleCacheManager;
    private final RedisTemplate<String, String> redisTemplate;
    
    
    
    @RequestMapping("getDistanceByUid")
    public ApiResult<Double> getDistanceByUid(Long uid, Long targetUid) {
        Double result = recommendService.getDistance(uid, targetUid);
        return new ApiResult<Double>().setResult(result);
    }

    @RequestMapping("getDistanceByLocation")
    public ApiResult<Double> getDistanceByLocation(Double longitude, Double latitude, Long targetUid) {
        Double result = recommendService.getDistance(longitude, latitude, targetUid);
        return new ApiResult<Double>().setResult(result);
    }

    /**
     * 判断两个用户是否在对方的 be_liked列表中
     */
    @RequestMapping("isUserLikeEachOther")
    public ApiResult<Boolean> isUserLikeEachOther(Long uid1, Long uid2) {
        Boolean result = recommendService.isUserLikeEachOther(uid1, uid2);
        return new ApiResult<Boolean>().setResult(result);
    }

    @RequestMapping("addRedisRobotUser")
    public ApiResult<Long> addRedisRobotUser(Long uid, String country) {
        recommendService.addRedisRobotUser(uid, country);
        return new ApiResult<Long>().setResult(1L);
    }


    @RequestMapping("addRedisUserReport")
    public ApiResult<Long> addRedisUserReport(Long uid) {
        recommendService.addRedisUserReport(uid);
        return new ApiResult<Long>().setResult(1L);
    }

    /**
     * 向Redis中添加用户被unLike的信息
     *
     * @param beLikedUid 被like的用户的UID
     * @param requestUid 发起like请求的UID
     */
    @RequestMapping("addRedisUserBeUnLiked")
    public ApiResult<Long> addRedisUserBeUnLiked(Long beLikedUid, Long requestUid) {
        if (beLikedUid == null || requestUid == null)
            return new ApiResult<Long>().setError(ApiResult.errorCode302, "uid is null");
        recommendService.handleSignForNewCome(requestUid, ELikeType.DISLIKE.getType());
        Long result = recommendService.addRedisUserBeUnLiked(beLikedUid, requestUid);
        recommendScoreLogService.recordRecommendScore(requestUid, beLikedUid, RecommendScoreLogService.LIKE_TYPE_UNLIKE);
        return new ApiResult<Long>().setResult(result);
    }

    /**
     * @param beLikedUid 被like的用户的UID
     * @param requestUid 发起like请求的UID
     */
    @RequestMapping("addRedisUserBeLiked")
    public ApiResult<Long> addRedisUserBeLiked(Long beLikedUid, Long requestUid,
                                               @RequestParam(required = false) Integer userType) {
        recommendService.handleSignForNewCome(requestUid, ELikeType.LIKE.getType());
        if (userType == null || Objects.equals(userType, ERecommendUserType.USER.getType())) {
            Long result = recommendService.addRedisUserBeLiked(beLikedUid, requestUid);
            recommendScoreLogService.recordRecommendScore(requestUid, beLikedUid, RecommendScoreLogService.LIKE_TYPE_LIKE);

            return new ApiResult<Long>().setResult(result);
        }
        return new ApiResult<Long>().setResult(1L);
    }


    /**
     * @param beLikedUid 被like的用户的UID
     * @param requestUid 发起like请求的UID
     */
    @RequestMapping("addRedisUserBeSuperLiked")
    public ApiResult<Long> addRedisUserBeSuperLiked(Long beLikedUid, Long requestUid) {
        recommendService.handleSignForNewCome(requestUid, ELikeType.SUPER_LIKE.getType());
        Long result = recommendService.addRedisUserBeSuperLiked(beLikedUid, requestUid);
        recommendScoreLogService.recordRecommendScore(requestUid, beLikedUid, RecommendScoreLogService.LIKE_TYPE_SUPER_LIKE);
        return new ApiResult<Long>().setResult(result);
    }

    @RequestMapping("addRedisUserGeo")
    public ApiResult<Long> addRedisUserGeo(Long uid, Double longitude, Double latitude) {
        recommendService.addRedisUserGeo(uid, longitude, latitude);
        return new ApiResult<Long>().setResult(1L);
    }


    @RequestMapping("addRedisUserGender")
    public ApiResult<Long> addRedisUserGender(Long uid, Integer gender) {
        log.debug("addRedisUserGender: uid:" + uid + ",gender:" + gender);
        recommendService.addRedisUserGender(uid, gender);
        return new ApiResult<Long>().setResult(1L);
    }

    /**
     * @param uid            请求推荐列表的用户UID
     * @param recommendedUid 已经推荐过的用户的UID
     */
    @RequestMapping("addRedisUserRecommended")
    public ApiResult<Boolean> addRedisUserRecommended(Long uid, Long recommendedUid) {
        if (uid == null)
            return new ApiResult<Boolean>().setError(ApiResult.errorCode302, "uid is null");
        recommendService.addRedisUserRecommended(uid, recommendedUid);
        return new ApiResult<Boolean>().setResult(true);
    }


    @RequestMapping("addRedisRegionUser")
    public ApiResult<Long> addRedisRegionUser(Long uid, String region) {
        recommendService.addRedisRegionUser(uid, region, null);
        return new ApiResult<Long>().setResult(1L);
    }

    @RequestMapping("addRedisUserActivityTimestamp")
    public ApiResult<Boolean> addRedisUserActivityTimestamp(Long uid, Integer timestamp) {
        if (uid == null)
            return new ApiResult<Boolean>().setError(ApiResult.errorCode302, "uid is null");
        asyncEventLMaxDisruptor.send(AsyncEvent.builder()
                .eventType(EventType.USER_ACTIVITY_TIMESTAMP)
                .asyncData(UserActivityTimestampAsyncData.builder()
                        .uid(uid)
                        .timestamp(timestamp)
                        .build())
                .build());
        return new ApiResult<Boolean>().setResult(true);
    }

    @RequestMapping("addRedisUserSignUpTimestamp")
    public ApiResult<Boolean> addRedisUserSignUpTimestamp(Long uid, Integer timestamp) {
        recommendService.addRedisUserSignUpTimestamp(uid, timestamp);
        return new ApiResult<Boolean>().setResult(true);
    }

    @RequestMapping("addRedisUserBirthTimestamp")
    public ApiResult<Boolean> addRedisUserBirthTimestamp(Long uid, Long timestamp) {
        recommendService.addRedisUserBirthTimestamp(uid, timestamp);
        return new ApiResult<Boolean>().setResult(true);
    }

    @RequestMapping("addRedisUserAge")
    public ApiResult<Boolean> addRedisUserAge(Long uid, Integer age) {
        recommendService.addRedisUserAge(uid, age);
        return new ApiResult<Boolean>().setResult(true);
    }

    @RequestMapping(value = "addRedisUser", method = RequestMethod.POST)
    public ApiResult<Boolean> addRedisUser(@RequestBody UfotoAppUser ufotoAppUser) {

        //由于App端接口管理的操蛋问题，此接口暂时失效
        //2018-05-15
        //添加用户画像
        //2018-12-03
        recommendService.addUserProfile(ufotoAppUser);
        return new ApiResult<Boolean>().setResult(true);
    }

    @RequestMapping("userEditShowMeGender")
    public ApiResult<Boolean> userEditShowMeGender(Long uid, Integer showMeGender) {
        recommendService.userEditShowMeGender(uid, showMeGender);
        return new ApiResult<Boolean>().setResult(true);
    }

    @RequestMapping("delRedisUserRecommended")
    public ApiResult<Boolean> delRedisUserRecommended(Long uid) {
        Boolean result = recommendService.delRedisUserRecommended(uid);
        return new ApiResult<Boolean>().setResult(result);
    }

    /**
     * 撤销用户行为
     */
    @RequestMapping("userCancel")
    public ApiResult<Boolean> userCancel(Long uid, Long fUid, Integer type) {
        boolean result = false;
        switch (type) {
            case 1://like
                result = recommendService.cancelLike(uid, fUid);
                break;
            case 2://unlike
                result = recommendService.cancelUnLike(uid, fUid);
                break;
            case 3://superLike
                result = recommendService.cancelSuperLike(uid, fUid);
                break;
            default:
                break;
        }
        return new ApiResult<Boolean>().setResult(result);
    }

    /**
     * 取消用户配对
     */
    @RequestMapping("cancelMatch")
    public ApiResult<Boolean> cancelMatch(Long uid, Long fUid) {
        boolean result = recommendService.cancelMatch(uid, fUid);
        return new ApiResult<Boolean>().setResult(result);
    }

    /**
     * 导入用户受欢迎分数
     */
    @RequestMapping("importUserPopularZset")
    public ApiResult<Boolean> importUserPopularZset() {
        boolean result = recommendService.importUserPopularZset();
        return new ApiResult<Boolean>().setResult(result);
    }

    /**
     * 添加非法用户
     */
    @RequestMapping("addRedisIllegalUser")
    public ApiResult<Boolean> addRedisIllegalUser(@RequestParam Long uid) {
        boolean result = recommendService.addRedisIllegalUser(uid, false);
        return new ApiResult<Boolean>().setResult(result);
    }

    @RequestMapping("addRedisIllegalUserOrFirst")
    public ApiResult<Boolean> addRedisIllegalUser(@RequestParam Long uid,
                                                  @RequestParam Boolean first) {
        boolean result = recommendService.addRedisIllegalUser(uid, first);
        return new ApiResult<Boolean>().setResult(result);
    }

    /**
     * 去除非法用户
     */
    @RequestMapping("removeRedisIllegalUser")
    public ApiResult<Boolean> removeRedisIllegalUser(@RequestParam Long uid) {
        boolean result = recommendService.removeRedisIllegalUser(uid, false);
        return new ApiResult<Boolean>().setResult(result);
    }

    @RequestMapping("removeRedisIllegalUserOrFirst")
    public ApiResult<Boolean> removeRedisIllegalUser(@RequestParam Long uid,
                                                     @RequestParam Boolean first) {
        boolean result = recommendService.removeRedisIllegalUser(uid, first);
        return new ApiResult<Boolean>().setResult(result);
    }

    /**
     * 添加聊天非法用户
     */
    @RequestMapping("addChatIllegalUser")
    public ApiResult<Boolean> addChatIllegalUser(@RequestParam Long uid) {
        boolean result = recommendService.addChatIllegalUser(uid);
        return new ApiResult<Boolean>().setResult(result);
    }

    @RequestMapping(path = "addChatIllegalUserBatch", method = RequestMethod.POST)
    public ApiResult<Boolean> addChatIllegalUserBatch(@RequestBody List<Long> uids) {
        boolean result = recommendService.addChatIllegalUserBatch(uids);
        return new ApiResult<Boolean>().setResult(result);
    }

    /**
     * 移除聊天非法用户
     */
    @RequestMapping("removeChatIllegalUser")
    public ApiResult<Boolean> removeChatIllegalUser(@RequestParam Long uid) {
        boolean result = recommendService.removeChatIllegalUser(uid);
        return new ApiResult<Boolean>().setResult(result);
    }

    @RequestMapping(path = "removeChatIllegalUserBatch", method = RequestMethod.POST)
    public ApiResult<Boolean> removeChatIllegalUserBatch(@RequestBody List<Long> uids) {
        boolean result = recommendService.removeChatIllegalUserBatch(uids);
        return new ApiResult<Boolean>().setResult(result);
    }

    /**
     * 处理已经有足够曝光次数的新用户
     *
     * @param processType 1转到热门 2转到普通
     */
    @RequestMapping("processNewComePreparedUser")
    public ApiResult<Boolean> processNewComePreparedUser(Long[] uidArray, Integer processType) {
        boolean result = recommendService.processNewComePreparedUser(uidArray, processType);
        return new ApiResult<Boolean>().setResult(result);
    }

    /**
     * 获取已经有足够曝光次数的新用户列表
     */
    @RequestMapping("getNewComePreparedUser")
    public ApiResult<List<String>> getNewComePreparedUser() {
        List<String> result = recommendService.getNewComePreparedUser();
        return new ApiResult<List<String>>().setResult(result);
    }

    @RequestMapping("getHotUser")
    public ApiResult<List<String>> getHotUser() {
        List<String> result = recommendService.getHotUser();
        return new ApiResult<List<String>>().setResult(result);
    }


    /**
     * 获取某个用户最近一次行为到现在多少时间
     * 如果没有对应用户，会返回null
     *
     * @param uid user id
     * @return last act time
     */
    @RequestMapping("getAfterLastActTime")
    public ApiResult<Integer> getAfterLastActTime(Long uid) {
        Integer result = recommendService.getRedisUserActivityTimestamp(uid);
        if (result != null) result = DateUtil.getCurrentSecondIntValue() - result;
        return new ApiResult<Integer>().setResult(result);
    }

    @RequestMapping("userEditHead")
    public ApiResult<Boolean> userEditHead(Long uid) {
        recommendService.userEditHead(uid);
        return new ApiResult<Boolean>().setResult(true);
    }

    @RequestMapping("getUserStrategyPath")
    public ApiResult<Map<String, String>> getStrategyPath(@RequestParam Long uid) {
        return new ApiResult<Map<String, String>>().setResult(abTestManager.getStrategyPath(uid));
    }

    @RequestMapping("getUserUnReadLikeNum")
    public ApiResult<Integer> getUserUnReadLikeNum(@RequestParam Long uid) {
        return new ApiResult<Integer>().setResult(recommendService.getUserUnReadLikeNum(uid));
    }

    /**
     * 用户设置自己不被推荐
     */
    @RequestMapping("userNotRecommend")
    public ApiResult<Boolean> userEditNotRecommended(@RequestParam Long uid) {
        recommendService.userEditNotRecommended(uid);
        return new ApiResult<Boolean>().setResult(true);
    }

    /**
     * 用户设置自己可以被推荐
     */
    @RequestMapping("userCanBeRecommended")
    public ApiResult<Boolean> userEditCanBeRecommended(@RequestParam Long uid) {
        recommendService.userEditCanBeRecommended(uid);
        return new ApiResult<Boolean>().setResult(true);
    }

    /**
     * 查询用户是否设置了自己不被推荐
     */
    @RequestMapping("getUserRecommendStatus")
    public ApiResult<Boolean> getUserRecommendStatus(@RequestParam Long uid) {

        return new ApiResult<Boolean>().setResult(recommendService.getUserRecommendStatus(uid));
    }

    /**
     * 用户收到like次数未被滑到的uid
     */
    @RequestMapping("getUserBeLikedUnreadUids")
    public ApiResult<Set<String>> getUserBeLikedUnreadUids(@RequestParam Long uid) {
        return new ApiResult<Set<String>>().setResult(recommendService.getUserBeLikedUnreadUids(uid));
    }

    @RequestMapping("/likeStatus")
    public ApiResult<SnsLikeStatusDto> likeStatus(Long uid, Long targetUid) {
        SnsLikeStatusDto snsLikeStatusDto = new SnsLikeStatusDto();
        snsLikeStatusDto.setIfLike(recommendService.isUserBeLiked(targetUid, uid));
        snsLikeStatusDto.setIfBeLiked(recommendService.isUserBeLiked(uid, targetUid));
        snsLikeStatusDto.setIfMatch(snsLikeStatusDto.isIfBeLiked() && snsLikeStatusDto.isIfLike());
        snsLikeStatusDto.setIfDislike(recommendService.isUserDislikeTargetUid(uid, targetUid));
        snsLikeStatusDto.setIfDisliked(recommendService.isUserDislikeTargetUid(targetUid, uid));
        return new ApiResult<SnsLikeStatusDto>().setResult(snsLikeStatusDto);
    }

    @RequestMapping("/randomMatchFilter")
    public ApiResult<Set<String>> randomMatchFilter(@RequestParam("uid") Long uid,
                                                    @RequestParam("targetUids") Set<String> targetUids) {
        log.debug("randomMatchFilter uid:" + uid + ",uids size:" + targetUids.size());
        if (CollectionUtils.isEmpty(targetUids)) {
            return new ApiResult<Set<String>>().setResult(Sets.newHashSet());
        }
        RecommendAdvanceRequest filterRequest = new RecommendAdvanceRequest();
        filterRequest.setUid(uid);
        final Set<String> filter = randomMatchFilterStrategy.filter(targetUids, Lists.newArrayList(), filterRequest);
        return new ApiResult<Set<String>>().setResult(filter);
    }

    @RequestMapping("/randomMatchFilterPost")
    public ApiResult<Set<String>> randomMatchFilterPost(@RequestBody RandomMatchFilterDto randomMatchFilterDto) {
        Long uid = randomMatchFilterDto.getUid();
        Set<String> targetUids = randomMatchFilterDto.getTargetUids();
        log.debug("randomMatchFiletr uid:" + uid + ",uids size:" + targetUids.size());
        return randomMatchFilter(uid, targetUids);
    }

    @RequestMapping("/randomMatchFilterResult")
    public ApiResult<Map<String, Object>> randomMatchFilterResult(@RequestParam("uid") Long uid,
                                                                  @RequestParam("targetUids") Set<String> targetUids) {
        if (CollectionUtils.isEmpty(targetUids)) {
            return new ApiResult<Map<String, Object>>().setResult(Maps.newHashMap());
        }
        return new ApiResult<Map<String, Object>>().setResult(recommendToolService.randomFilter(uid, targetUids));
    }

    @RequestMapping("/cleanOldNewComeUser")
    public ApiResult<Boolean> cleanOldNewComeUser() {
        cleanRedisService.cleanOldNewComeUserSet();
        return new ApiResult<Boolean>().setResult(true);
    }


    @RequestMapping(path = "filter", method = RequestMethod.POST)
    public ApiResult<Map> filter(@RequestBody FilterRequestDto filterRequestDto) {
        return new ApiResult<Map>().setResult(recommendToolService.filter(filterRequestDto));
    }

    @RequestMapping("/tryFilter")
    public ApiResult<Map> tryFilter(@RequestParam("uid") Long uid,
                                    @RequestParam("recallUids") String[] recallUids) {

        Map result = recommendToolService.tryFilter(uid, recallUids);
        return new ApiResult<Map>().setResult(result);
    }

    @RequestMapping("/globalFilter")
    public ApiResult<String[]> globalFilter(@RequestBody String[] uids) {
        String[] result = recommendToolService.globalFilter(uids);
        return new ApiResult<String[]>().setResult(result);
    }

    //移除被举报的用户
    @RequestMapping("removeRedisUserReport")
    public ApiResult<Long> removeRedisUserReport(@RequestParam("uids") List<Long> uids) {
        return new ApiResult<Long>().setResult(recommendService.removeRedisUserReport(uids));
    }

    @RequestMapping("/checkHeadIllegal")
    public ApiResult<Object> checkHeadIllegal(@RequestParam("uid") String uid) {
        List<UfotoUserImageDo> heads = userManager.userFeedImages(Long.valueOf(uid));
        final Boolean firstMember = redisService.isMember(RedisKeyConstant.REDIS_HEAD_FIRST_ILLEGAL_USER_SET_KEY, uid);
        final Boolean headMember = redisService.isMember(RedisKeyConstant.REDIS_HEAD_ILLEGAL_USER_SET_KEY, uid);
        final Boolean noHeadMember = redisService.isMember(RedisKeyConstant.REDIS_NO_HEAD_USER_SET_KEY, uid);

        if (CollectionUtils.isEmpty(heads)) {
            if (firstMember) {
                redisService.sremove(RedisKeyConstant.REDIS_HEAD_FIRST_ILLEGAL_USER_SET_KEY, uid);
            }
            if (headMember) {
                redisService.sremove(RedisKeyConstant.REDIS_HEAD_ILLEGAL_USER_SET_KEY, uid);
            }
            if (!noHeadMember) {
                redisService.sadd(RedisKeyConstant.REDIS_NO_HEAD_USER_SET_KEY, uid);
            }
        } else {
            if (noHeadMember) {
                redisService.sremove(RedisKeyConstant.REDIS_NO_HEAD_USER_SET_KEY, uid);
            }
            final Integer num0 = heads.stream().filter(ufotoUserHead -> ufotoUserHead.getNum() == 0)
                    .map(UfotoUserImageDo::getStatus)
                    .findFirst().orElse(null);
            if (num0 != null) {
                if (num0 == 2 || num0 == 4) {
                    if (!firstMember) {
                        redisService.sadd(RedisKeyConstant.REDIS_HEAD_FIRST_ILLEGAL_USER_SET_KEY, uid);
                    }
                } else {
                    if (firstMember) {
                        redisService.sremove(RedisKeyConstant.REDIS_HEAD_FIRST_ILLEGAL_USER_SET_KEY, uid);
                    }
                }
            } else {
                if (firstMember) {
                    redisService.sremove(RedisKeyConstant.REDIS_HEAD_FIRST_ILLEGAL_USER_SET_KEY, uid);
                }
            }
            final long illegalCount = heads.stream().filter(ufotoUserHead -> ufotoUserHead.getStatus() == 2 || ufotoUserHead.getStatus() == 4)
                    .count();
            if (illegalCount > 0) {
                if (!headMember) {
                    redisService.sadd(RedisKeyConstant.REDIS_HEAD_ILLEGAL_USER_SET_KEY, uid);
                }
            } else {
                if (headMember) {
                    redisService.sremove(RedisKeyConstant.REDIS_HEAD_ILLEGAL_USER_SET_KEY, uid);
                }
            }
        }
        return new ApiResult<>().setResult(true);
    }

    @RequestMapping("/addToBlackList")
    public ApiResult<Boolean> addUser2BlackList(@RequestParam("uid") Long uid) {
        if (null != uid) {
            redisService.sadd(RedisKeyConstant.REDIS_USER_BLACKLIST_SET, uid + "");
            return new ApiResult<Boolean>().setResult(true);
        }
        return new ApiResult<Boolean>().setResult(false);
    }

    @RequestMapping("filterUsers")
    public ApiResult<List<String>> filterUsers(@RequestBody RecommendAdvanceRequestExpand recommendAdvanceRequest) {
        final Set<String> targetUids = recommendAdvanceRequest.getTargetUids();
        final Set<String> filter = loginFilterStrategy.filter(targetUids, Lists.newArrayList(), recommendAdvanceRequest);
        if (CollectionUtils.isEmpty(filter)) return new ApiResult<List<String>>().setResult(Lists.newArrayList());
        return new ApiResult<List<String>>().setResult(new ArrayList<>(filter));
    }

    @RequestMapping("getBeLikedNumV2")
    public ApiResult<List<UserBeLikedDto>> getBeLikedNumV2(@RequestBody RecommendAdvanceRequestExpand recommendAdvanceRequest) {
        if (recommendAdvanceRequest.getUnread() == null) recommendAdvanceRequest.setUnread(true);
        final Long uid = recommendAdvanceRequest.getUid();
        final Boolean unread = recommendAdvanceRequest.getUnread();
        log.debug("recommendAdvanceRequest:{}", recommendAdvanceRequest);
        if (unread != null && unread) {
            final Set<String> uids = recommendService.getUserBeLikedUnreadUids(uid);
            if (CollectionUtils.isEmpty(uids)) {
                return new ApiResult<List<UserBeLikedDto>>().setResult(Lists.newArrayList());
            }
            recommendAdvanceRequest.setTargetUids(uids);
        } else {
            final List<String> liked = ufotoUserLikeToService.selectLikeByTUidOrdered(uid);
            if (CollectionUtils.isEmpty(liked)) {
                return new ApiResult<List<UserBeLikedDto>>().setResult(Lists.newArrayList());
            }
            recommendAdvanceRequest.setTargetUids(new HashSet<>(liked));
        }
        return new ApiResult<List<UserBeLikedDto>>().setResult(queryBeLikedDto(filterUsers(recommendAdvanceRequest)));
    }

    private List<UserBeLikedDto> queryBeLikedDto(ApiResult<List<String>> filterUsers) {
        final List<String> longs = filterUsers.getD();
        if (CollectionUtils.isEmpty(longs)) return Lists.newArrayList();
        final Integer genderParam = ThreadLocalManager.needGenderThreadLocal();
        return Lists.newArrayList(new UserBeLikedDto(genderParam, longs.size()));
    }

    @RequestMapping("/whoLikeMe")
    public ApiResult<List<SnsRecommendExpandDto>> whoLikeMe(@RequestBody RecommendAdvanceRequestExpand requestExpand) {
        log.debug("whoLikeMe:{}", requestExpand);
        final Long uid = requestExpand.getUid();
        Integer page = requestExpand.getPage();
        Integer pageSize = requestExpand.getPageSize();
        if (page == null || page == 0) page = 1;
        if (pageSize == null) pageSize = 10;
        int fromIndex = (page - 1) * pageSize;
        int toIndex = page * pageSize;
        if (page == 1) {//第一页
            //清空缓存表
            redisService.del(RedisKeyConstant.REDIS_USER_FILTER_BE_LIKED + requestExpand.getUid());
            //重新查
            final List<String> liked = Lists.newArrayList(recommendService.getUserBeLikedUnreadUids(uid));
            if (CollectionUtils.isEmpty(liked))
                return new ApiResult<List<SnsRecommendExpandDto>>().setResult(Lists.newArrayList());
            requestExpand.setTargetUids(new HashSet<>(liked));
            //过滤
            final ApiResult<List<String>> listApiResult = filterUsers(requestExpand);
            //过滤后的list
            final List<String> list = listApiResult.getD();
            if (CollectionUtils.isEmpty(list)) {
                return new ApiResult<List<SnsRecommendExpandDto>>().setResult(Lists.newArrayList());
            }
            //存入缓存
            redisService.lpush(RedisKeyConstant.REDIS_USER_FILTER_BE_LIKED + requestExpand.getUid(), list.toArray(new String[]{}));
            redisService.expire(RedisKeyConstant.REDIS_USER_FILTER_BE_LIKED + requestExpand.getUid(), 1, TimeUnit.HOURS);
            if (toIndex > list.size()) {
                toIndex = list.size();
            }
            RecommendListRequest centerRequest = new RecommendListRequest();
            centerRequest.setUids(list.subList(fromIndex, toIndex));
            centerRequest.setLang(requestExpand.getLanguage());
            final List<SnsRecommendExpandDto> result = ufotoAppUserService.selectRecommendDtoBySortedUidList(centerRequest);
            return new ApiResult<List<SnsRecommendExpandDto>>().setResult(handleResult(result));
        } else {
            final List<String> list = redisService.lrange(RedisKeyConstant.REDIS_USER_FILTER_BE_LIKED + requestExpand.getUid(), fromIndex, toIndex - 1);
            if (CollectionUtils.isEmpty(list)) {
                return new ApiResult<List<SnsRecommendExpandDto>>().setResult(Lists.newArrayList());
            }
            RecommendListRequest centerRequest = new RecommendListRequest();
            centerRequest.setUids(list);
            centerRequest.setLang(requestExpand.getLanguage());
            final List<SnsRecommendExpandDto> result = ufotoAppUserService.selectRecommendDtoBySortedUidList(centerRequest);
            return new ApiResult<List<SnsRecommendExpandDto>>().setResult(handleResult(result));
        }
    }

    private List<SnsRecommendExpandDto> handleResult(List<SnsRecommendExpandDto> result) {
        return result;
    }

    @RequestMapping("/dumpRedis")
    public ApiResult<Boolean> dumpExpiredUserRedisData() {
        ufotoRecommendRedisDumpService.dumpExpiredUserRedisData();
        return new ApiResult<Boolean>().setResult(true);
    }

    @RequestMapping("/updateCache")
    public ApiResult<Boolean> updateCache() {
        recommendCacheUpdater.updateCacheByAnnotation();
        return new ApiResult<Boolean>().setResult(true);
    }

    @RequestMapping("/migrateRecommendedSet")
    public ApiResult<Boolean> migrateRecommendedSet() {
        return new ApiResult<Boolean>().setResult(true);
    }

    @RequestMapping("getUserActivityTimestamp")
    public ApiResult<Integer> getUserActivityTimestamp(Long uid) {
        if (uid == null) {
            return new ApiResult<Integer>().setError(ApiResult.errorCode302, "uid is null");
        }
        return new ApiResult<Integer>().setResult(recommendService.getRedisUserActivityTimestamp(uid));
    }

    @RequestMapping("addDeleteUser")
    public ApiResult<Boolean> addDeleteUser(Long uid) {
        if (uid == null) {
            return new ApiResult<Boolean>().setError(ApiResult.errorCode302, "uid is null");
        }
        recommendService.addDeleteUser(uid);
        return new ApiResult<Boolean>().setResult(true);
    }


    /**
     * 查询like数量
     *
     * @param types 1 like 3 super like  4 be like 5 be super like
     */
    @RequestMapping(value = "/{uid}/likeStatistics", method = RequestMethod.POST)
    public ApiResult<LikeStatisticsDto> likeStatistics(@PathVariable Long uid, @RequestBody List<Integer> types) {
        LikeStatisticsDto likeStatisticsDto = new LikeStatisticsDto();
        final ApiResult<LikeStatisticsDto> likeStatisticsDtoApiResult = new ApiResult<LikeStatisticsDto>().setResult(likeStatisticsDto);
        if (CollectionUtils.isEmpty(types)) return likeStatisticsDtoApiResult;
        final Map<Integer, ELikeStatisticsType> typeMap = EnumSet.allOf(ELikeStatisticsType.class).stream()
                .collect(Collectors.toMap(ELikeStatisticsType::getType, t -> t));
        final List<Integer> typeList = types.stream().filter(typeMap::containsKey).collect(Collectors.toList());
        if (CollectionUtils.isEmpty(typeList)) return likeStatisticsDtoApiResult;
        final List<Object> objects = redisService.getRedisTemplate().executePipelined((RedisCallback<Object>) connection -> {
            for (Integer type : typeList) {
                final ELikeStatisticsType statisticsType = typeMap.get(type);
                connection.sCard((statisticsType.getKey() + uid).getBytes(StandardCharsets.UTF_8));
            }
            return null;
        });
        if (CollectionUtils.isEmpty(objects)) return likeStatisticsDtoApiResult;
        final int size = typeList.size();
        for (int i = 0; i < size; i++) {
            final Object obj = objects.get(i);
            final Integer type = typeList.get(i);
            final ELikeStatisticsType statisticsType = typeMap.get(type);
            long num = obj == null ? 0 : (Long) obj;
            switch (statisticsType) {
                case LIKE:
                    likeStatisticsDto.setSendLikedNum((int) num);
                    break;
                case BE_LIKE:
                    likeStatisticsDto.setBeLikedNum((int) num);
                    break;
                case SUPER_LIKE:
                    likeStatisticsDto.setSentSuperLikedNum((int) num);
                    break;
                case BE_SUPER_LIKE:
                    likeStatisticsDto.setBeSuperLikedNum((int) num);
                    break;
            }
        }
        return likeStatisticsDtoApiResult;
    }

    @RequestMapping("isSubscription")
    public ApiResult<Boolean> isSubscriptionUser(Long uid) {
        return new ApiResult<Boolean>().setResult(redisService.isMember(RedisKeyConstant.REDIS_SUBSCRIPTION_USER_SET, uid + ""));
    }

    //用户画像数据
    @RequestMapping("userMap")
    public ApiResult<Map<String, String>> userMap(Long uid) {
        return new ApiResult<Map<String, String>>().setResult(redisService.hGetAll(RedisKeyUtil.obtainKey(RedisKeyConstant.REDIS_USER_HASH_KEY, uid)));
    }

    @RequestMapping("countryAreaMap")
    public ApiResult<Map<String, Integer>> countryAreaMap() {
        return new ApiResult<Map<String, Integer>>().setResult(SpringContextUtil.getBean(CommonServiceManager.class).getCountryAreaMap());
    }

    @RequestMapping("/recallTest")
    public ApiResult<Object> recallFilterTest(RecommendAdvanceRequest recommendAdvanceRequest) {
        final Map<String, Object> beanMap = SpringContextUtil.getBeansWithAnnotation(RecommendMetadata.class);
        List<Recall> recallList = Lists.newArrayList();
        List<RecommendFilterStrategy> filterStrategyList = Lists.newArrayList();
        List<Reagent> reagentList = Lists.newArrayList();
        List<SpecificRecommendSortStrategy> sortStrategyList = Lists.newArrayList();

        beanMap.forEach((k, bean) -> {
            Class<?> targetClass = AopUtils.getTargetClass(bean);
            RecommendMetadata recommendMetadata = targetClass.getAnnotation(RecommendMetadata.class);
            switch (recommendMetadata.metadataType()) {
                case RECALL:
                    if (!bean.getClass().getSimpleName().equals(NGRandomRecall.class.getSimpleName())) {
                        recallList.add((Recall) bean);
                    }
                    break;
                case FILTER:
                    filterStrategyList.add((RecommendFilterStrategy) bean);
                    break;
                case REAGENT:
                    reagentList.add((Reagent) bean);
                    break;
                case SORT:
                    sortStrategyList.add((SpecificRecommendSortStrategy) bean);
                    break;
                default:
                    break;
            }
        });
        int minSize = 1250;

        Set<String> resultSet = recallList.stream()
                .map(recall -> {
                    final Set<String> results = recall.recall(minSize, recommendAdvanceRequest);
                    log.debug("recallFilterSortShuffleResult->recall->{}:{}", recall.getClass().getSimpleName(), results);
                    return results;
                })
                .flatMap(Collection::parallelStream)
                .collect(Collectors.toSet());

        final Set<String> resultSet2 = filterStrategyList.stream()
                .map(filter -> {
                    final Set<String> filterResult = filter.filter(resultSet, Lists.newArrayList(), recommendAdvanceRequest);
                    log.debug("recallFilterSortShuffleResult->filter->{}:{}", filter.getClass().getSimpleName(), Sets.difference(resultSet, filterResult));
                    return filterResult;
                })
                .flatMap(Collection::parallelStream)
                .collect(Collectors.toSet());


        CompositeRecommendSortStrategy compositeRecommendSortStrategy = new CompositeRecommendSortStrategy() {
        };
        compositeRecommendSortStrategy.setSortStrategyWeightMap(sortStrategyList.stream().collect(Collectors.toMap(
                k -> k, v -> RandomUtils.nextDouble()
        )));
        final String[] sort = compositeRecommendSortStrategy.sort(resultSet2, BeanUtil.copyProperties(recommendAdvanceRequest, new SortParamsBean()));

        ChatBotShuffleStrategy chatBotShuffleStrategy = new ChatBotShuffleStrategy(redisService, 10, 20);
        final String[] shuffle = chatBotShuffleStrategy.shuffle(sort);
        log.debug("recallFilterSortShuffleResult->shuffle->{}:{}", "ChatBotShuffleStrategy", Arrays.toString(shuffle));

        GenderShuffleStrategy genderShuffleStrategy = new GenderShuffleStrategy(redisService);
        final String[] shuffle1 = genderShuffleStrategy.shuffle(shuffle);
        log.debug("recallFilterSortShuffleResult->shuffle->{}:{}", "GenderShuffleStrategy", Arrays.toString(shuffle1));

        NewComeShuffleStrategy newComeShuffleStrategy = new NewComeShuffleStrategy(redisService);
        final String[] shuffle2 = newComeShuffleStrategy.shuffle(shuffle1);
        log.debug("recallFilterSortShuffleResult->shuffle->{}:{}", "NewComeShuffleStrategy", Arrays.toString(shuffle2));

        LikeMeShuffleStrategy likeMeShuffleStrategy = new LikeMeShuffleStrategy(redisService, 0.6f, recommendAdvanceRequest.getUid());
        final String[] shuffle3 = likeMeShuffleStrategy.shuffle(shuffle2);
        log.debug("recallFilterSortShuffleResult->shuffle->{}:{}", "LikeMeShuffleStrategy", Arrays.toString(shuffle3));

        SuperLikeMeShuffleStrategy superLikeMeShuffleStrategy = new SuperLikeMeShuffleStrategy(redisService, recommendAdvanceRequest.getUid());
        final String[] shuffle4 = superLikeMeShuffleStrategy.shuffle(shuffle3);
        log.debug("recallFilterSortShuffleResult->shuffle->{}:{}", "SuperLikeMeShuffleStrategy", Arrays.toString(shuffle4));

        return new ApiResult<>().setResult(shuffle4);

    }

    @RequestMapping("/signup/{uid}")
    public ApiResult userSignUp(@PathVariable Long uid) {
        return new ApiResult<>().setResult(KeyTransitionUtil.signUp(redisService, uid));
    }

    @RequestMapping("/migrateNewCome")
    public ApiResult migrateNewComeByGender() {
        final Set<String> comes = redisService.sMember(RedisKeyConstant.REDIS_NEW_COME_USER_SET_KEY, true);
        final Map<Long, Integer> genders = KeyTransitionUtil.selectGenders(redisService, Lists.newArrayList(comes));
        final Map<Integer, Set<String>> map = genders.entrySet().stream()
                .filter(entry -> Objects.equals(entry.getValue(), EGender.MALE.getType())
                        || Objects.equals(entry.getValue(), EGender.FEMALE.getType()))
                .collect(Collectors.groupingBy(Map.Entry::getValue, Collectors.mapping(entry -> entry.getKey().toString(), Collectors.toSet())));

        final Set<String> maleSet = map.get(EGender.MALE.getType());
        if (!CollectionUtils.isEmpty(maleSet)) {
            redisService.sadd(RedisKeyConstant.REDIS_NEW_COME_USER_SET_KEY_MALE, maleSet.toArray(new String[]{}));
        }
        final Set<String> femaleSet = map.get(EGender.FEMALE.getType());
        if (!CollectionUtils.isEmpty(femaleSet)) {
            redisService.sadd(RedisKeyConstant.REDIS_NEW_COME_USER_SET_KEY_FEMALE, femaleSet.toArray(new String[]{}));
        }
        return new ApiResult<>().setResult(true);
    }
    
    @RequestMapping(path = "/env/{name}/{value}")
    public ApiResult<Object> environmentModify(@PathVariable String name,
                                               @PathVariable String value) {
        environmentManager.setProperty(name, value);
        Map<String, String> resultMap = Maps.newHashMap();
        resultMap.put(name, value);
        rabbitProducer.produceByJson(EExchange.SWEETCHAT_FANOUT_RECOMMEND, "", resultMap);
        return new ApiResult<>().setResult(environmentManager.getProperty(name));
    }
}
