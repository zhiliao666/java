package com.ufoto.config.disruptor.executor;

import com.google.common.collect.Sets;
import com.ufoto.bloom.RecommendCalculatedBloomFilter;
import com.ufoto.config.disruptor.data.AsyncData;
import com.ufoto.config.disruptor.data.RecommendCalculatedAsyncData;
import com.ufoto.dto.RecommendAdvanceRequest;
import com.ufoto.utils.redis.RedisKeyConstant;
import com.ufoto.utils.redis.RedisKeyUtil;
import com.ufoto.utils.redis.RedisService;
import lombok.extern.slf4j.Slf4j;
import org.springframework.stereotype.Component;

import java.util.List;
import java.util.Objects;

/**
 * <p>
 * Description:
 *
 * </p>
 *
 * @author Chan
 * @date 2019/12/21 17:55
 */
@Slf4j
@Component
public class RecommendCalculateBloomExecutor extends RecommendCalculateExecutor {
    private final RecommendCalculatedBloomFilter recommendCalculatedBloomFilter;
    private final RedisService redisService;

    public RecommendCalculateBloomExecutor(RecommendCalculatedBloomFilter recommendCalculatedBloomFilter,
                                           RedisService redisService) {
        this.recommendCalculatedBloomFilter = recommendCalculatedBloomFilter;
        this.redisService = redisService;
    }

    @Override
    public void execute(AsyncData asyncData) {
        RecommendCalculatedAsyncData recommendCalculatedAsyncData = dataCheckAndConverter(asyncData);
        if (recommendCalculatedAsyncData == null) {
            return;
        }
        final RecommendAdvanceRequest recommendAdvanceRequest = recommendCalculatedAsyncData.getRecommendAdvanceRequest();
        final Long uid = recommendAdvanceRequest.getUid();
        final List<String> calculatedList = recommendCalculatedAsyncData.getCalculatedList();
        if (uid != null) {
            String gender = redisService.hget(RedisKeyUtil.obtainKey(RedisKeyConstant.REDIS_USER_HASH_KEY, uid), RedisKeyConstant.REDIS_USER_HASH_GENDER);
            //性别为1或2时,保存用户看过的记录
            if (Objects.equals(gender, "1")
                    || Objects.equals(gender, "2")) {
                recommendCalculatedBloomFilter.addBatch(uid, Sets.newHashSet(calculatedList));
            }
        }
        log.debug("recommendCalculatedBloomFilter:uid:{},list:{} add done...", uid, calculatedList);
    }
}
