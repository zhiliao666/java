package com.ufoto.config;

import com.github.benmanes.caffeine.cache.CacheLoader;
import com.github.benmanes.caffeine.cache.Caffeine;
import com.github.benmanes.caffeine.cache.LoadingCache;
import com.ufoto.annotation.RecommendMetadata;
import com.ufoto.business.recommendNG.Invoker;
import com.ufoto.utils.SpringContextUtil;
import com.ufoto.utils.strategy.InvokerUtil;
import org.springframework.beans.BeanUtils;
import org.springframework.boot.actuate.endpoint.annotation.DeleteOperation;
import org.springframework.boot.actuate.endpoint.annotation.Endpoint;
import org.springframework.boot.actuate.endpoint.annotation.ReadOperation;
import org.springframework.boot.actuate.endpoint.annotation.Selector;
import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;
import org.springframework.stereotype.Component;

import javax.annotation.Nonnull;
import javax.annotation.Nullable;
import java.lang.reflect.Method;
import java.util.concurrent.TimeUnit;

/**
 * <p>
 * Author : Chan CreateDate : 2019/11/29 12:48 Description:
 * </p>
 */
@Configuration
public class CacheConfig {

    private final static String UPDATE_CACHE_METHOD = "updateCache";

    @Bean
    public LoadingCache<Class<?>, Object> middleFrequencyLoadingCache() {
        return Caffeine.newBuilder().recordStats().refreshAfterWrite(1L, TimeUnit.MINUTES).build(new CacheLoader<Class<?>, Object>() {
            @Nullable
            @Override
            public Object load(@Nonnull Class<?> key) throws Exception {
                final Method updateCache = BeanUtils.findMethod(key, UPDATE_CACHE_METHOD);
                if (updateCache != null) {
                    return updateCache.invoke(SpringContextUtil.getBean(key));
                }
                return null;
            }
        });
    }

    @Bean
    public LoadingCache<Class<?>, Object> recommendLoadingCache() {
        return Caffeine.newBuilder().recordStats().build(new CacheLoader<Class<?>, Object>() {
            @Nullable
            @Override
            public Object load(@Nonnull Class<?> key) throws Exception {
                final Method updateCache = BeanUtils.findMethod(key, UPDATE_CACHE_METHOD);
                if (updateCache != null) {
                    return updateCache.invoke(SpringContextUtil.getBean(key));
                }
                return null;
            }
        });
    }

    @Bean
    public LoadingCache<RecommendMetadata.Branch, Invoker> specialCaseInvokerCache(InvokerUtil invokerUtil) {
        return Caffeine.newBuilder().recordStats().build(new CacheLoader<RecommendMetadata.Branch, Invoker>() {
            @Nullable
            @Override
            public Invoker load(@Nonnull RecommendMetadata.Branch key) throws Exception {
                switch (key) {
                    case GIFT:
                        return invokerUtil.createGiftBaseInvokerForGift();
                    case DEFAULT:
                        return invokerUtil.createDefaultInvoker();
                    case High_Risk:
                        return invokerUtil.createHighRiskInvoker();
                    default:
                        throw new RuntimeException("Not Support Branch for Current Invoker");
                }
            }
        });
    }

    @Endpoint(id = "recommend-cache")
    @Component
    public static class RecommendLoadingCacheEndpoint {

        private final LoadingCache<Class<?>, Object> recommendLoadingCache;

        public RecommendLoadingCacheEndpoint(LoadingCache<Class<?>, Object> recommendLoadingCache) {
            this.recommendLoadingCache = recommendLoadingCache;
        }

        @ReadOperation
        public Object stats(@Selector CMD cmd) {
            if (cmd == CMD.stats) {
                return recommendLoadingCache.stats().toString();
            }
            throw new RuntimeException("not support operation");
        }

        @ReadOperation
        public Object get(@Selector CMD cmd, @Selector String pkg) throws ClassNotFoundException {
            if (cmd == CMD.get) {
                return recommendLoadingCache.get(Class.forName(pkg));
            }
            throw new RuntimeException("not support operation");
        }

        @DeleteOperation
        public Object invalidate(@Selector String pkg, @Selector CMD cmd) throws ClassNotFoundException {
            if (cmd == CMD.invalidate) {
                recommendLoadingCache.invalidate(Class.forName(pkg));
                return true;
            }
            throw new RuntimeException("not support operation");
        }

        enum CMD {
            stats, invalidate, get
        }
    }

    @Endpoint(id = "special-cache")
    @Component
    public static class SpecialCaseInvokerCacheEndpoint {

        private final LoadingCache<RecommendMetadata.Branch, Invoker> specialCaseInvokerCache;

        public SpecialCaseInvokerCacheEndpoint(
                LoadingCache<RecommendMetadata.Branch, Invoker> specialCaseInvokerCache) {
            this.specialCaseInvokerCache = specialCaseInvokerCache;
        }

        @ReadOperation
        public Object invoker(@Selector String param) {
            if ("stats".equals(param)) {
                return specialCaseInvokerCache.stats().toString();
            }
            return specialCaseInvokerCache.get(RecommendMetadata.Branch.valueOf(param));
        }
    }

}
