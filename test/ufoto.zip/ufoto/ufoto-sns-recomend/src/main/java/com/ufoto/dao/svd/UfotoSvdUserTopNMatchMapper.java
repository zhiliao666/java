package com.ufoto.dao.svd;

import com.ufoto.dao.base.BaseUfotoSvdUserTopNMatchMapper;
import org.apache.ibatis.annotations.Mapper;

@Mapper
public interface UfotoSvdUserTopNMatchMapper extends BaseUfotoSvdUserTopNMatchMapper {

}
