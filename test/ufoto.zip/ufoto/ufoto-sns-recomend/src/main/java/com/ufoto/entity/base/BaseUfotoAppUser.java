package com.ufoto.entity.base;

import java.io.Serializable;

public class BaseUfotoAppUser implements Serializable {
    /**
     * Default value included to remove warning. Remove or modify at will.
     **/
    private static final long serialVersionUID = 1L;

    private java.lang.Long id;
    private java.lang.Double latitude;
    private java.lang.String uuid;
    private java.lang.String countryCode;
    private java.lang.String userName;
    private java.lang.String location;
    private java.lang.String hometown;
    private java.lang.String email;
    private java.lang.String firstImg;
    private java.lang.Integer createTime;
    private java.lang.String phone;
    private java.lang.String headImg;
    private java.lang.Integer isDelete;
    private java.lang.Integer fromType;
    private java.lang.Integer updateTime;
    private java.lang.Integer type;
    private java.lang.Integer gender;
    private java.lang.String realName;
    private java.lang.Double longitude;
    private java.util.Date birthTime;
    private java.lang.String description;
    private String lang;

    //new add
    private Integer age;

    private Integer loginSource;

    public Integer getLoginSource() {
        return loginSource;
    }

    public void setLoginSource(Integer loginSource) {
        this.loginSource = loginSource;
    }

    public Integer getAge() {
        return age;
    }

    public void setAge(Integer age) {
        this.age = age;
    }

    public String getLang() {
        return lang;
    }

    public void setLang(String lang) {
        this.lang = lang;
    }

    public java.lang.Long getId() {
        return id;
    }

    public void setId(java.lang.Long id) {
        this.id = id;
    }

    public java.lang.Double getLatitude() {
        return latitude;
    }

    public void setLatitude(java.lang.Double latitude) {
        this.latitude = latitude;
    }

    public java.lang.String getUuid() {
        return uuid;
    }

    public void setUuid(java.lang.String uuid) {
        this.uuid = uuid;
    }

    public java.lang.String getCountryCode() {
        return countryCode;
    }

    public void setCountryCode(java.lang.String countryCode) {
        this.countryCode = countryCode;
    }

    public java.lang.String getUserName() {
        return userName;
    }

    public void setUserName(java.lang.String userName) {
        this.userName = userName;
    }

    public java.lang.String getLocation() {
        return location;
    }

    public void setLocation(java.lang.String location) {
        this.location = location;
    }

    public java.lang.String getHometown() {
        return hometown;
    }

    public void setHometown(java.lang.String hometown) {
        this.hometown = hometown;
    }

    public java.lang.String getEmail() {
        return email;
    }

    public void setEmail(java.lang.String email) {
        this.email = email;
    }

    public java.lang.String getFirstImg() {
        return firstImg;
    }

    public void setFirstImg(java.lang.String firstImg) {
        this.firstImg = firstImg;
    }

    public java.lang.Integer getCreateTime() {
        return createTime;
    }

    public void setCreateTime(java.lang.Integer createTime) {
        this.createTime = createTime;
    }

    public java.lang.String getPhone() {
        return phone;
    }

    public void setPhone(java.lang.String phone) {
        this.phone = phone;
    }

    public java.lang.String getHeadImg() {
        return headImg;
    }

    public void setHeadImg(java.lang.String headImg) {
        this.headImg = headImg;
    }

    public java.lang.Integer getIsDelete() {
        return isDelete;
    }

    public void setIsDelete(java.lang.Integer isDelete) {
        this.isDelete = isDelete;
    }

    public java.lang.Integer getFromType() {
        return fromType;
    }

    public void setFromType(java.lang.Integer fromType) {
        this.fromType = fromType;
    }

    public java.lang.Integer getUpdateTime() {
        return updateTime;
    }

    public void setUpdateTime(java.lang.Integer updateTime) {
        this.updateTime = updateTime;
    }

    public java.lang.Integer getType() {
        return type;
    }

    public void setType(java.lang.Integer type) {
        this.type = type;
    }

    public java.lang.Integer getGender() {
        return gender;
    }

    public void setGender(java.lang.Integer gender) {
        this.gender = gender;
    }

    public java.lang.String getRealName() {
        return realName;
    }

    public void setRealName(java.lang.String realName) {
        this.realName = realName;
    }

    public java.lang.Double getLongitude() {
        return longitude;
    }

    public void setLongitude(java.lang.Double longitude) {
        this.longitude = longitude;
    }

    public java.util.Date getBirthTime() {
        return birthTime;
    }

    public void setBirthTime(java.util.Date birthTime) {
        this.birthTime = birthTime;
    }

    public java.lang.String getDescription() {
        return description;
    }

    public void setDescription(java.lang.String description) {
        this.description = description;
    }


//	@Override
//	public String toString() {
//		return "{ id:" + id + ", name:" + name + ", email:" + email
//				+ ", phone:" + phoneNumber + " }";
//	}
}
