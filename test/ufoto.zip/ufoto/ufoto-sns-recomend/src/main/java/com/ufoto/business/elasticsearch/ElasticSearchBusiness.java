package com.ufoto.business.elasticsearch;

import com.ufoto.business.elasticsearch.dto.*;
import com.ufoto.utils.ApiResult;
import org.springframework.cloud.openfeign.FeignClient;
import org.springframework.validation.annotation.Validated;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;

import java.util.List;

/**
 * <p>
 * Author     : Chan
 * CreateDate : 2019-09-05 17:29
 * Description:
 * </p>
 */
@FeignClient(value = "ufoto-elastic-api", fallbackFactory = ElasticSearchBusinessFallbackFactory.class)
public interface ElasticSearchBusiness {
    @PostMapping("/v1/es/friend/{uid}/list")
    ApiResult<FriendSearchDto> checkUserFriend(@PathVariable(value = "uid") long uid,
                                               @RequestBody FriendSearchVo searchVo);

    @PostMapping("/v1/es/act/{uid}/search")
    ApiResult<List<Long>> searchUserActByParam(@PathVariable(value = "uid") Long uid,
                                               @RequestBody UserActSearchVo searchVo);

    @PostMapping("/v1/es/act/{uid}/filter/limit")
    ApiResult<List<Long>> filterActLimit(@PathVariable(value = "uid") Long uid,
                                         @RequestBody UserActFilterVo filterVo);

    @PostMapping("/v1/es/act/{uid}/filter/recommended")
    ApiResult<List<Long>> filterActRecommended(@PathVariable(value = "uid") Long uid,
                                               @RequestBody UserRecommendedFilterVo filterVo);
    /**
     * 获取用户分层数据 100-新用户 200-浏览用户 300-低寻友用户 400-高寻友用户
     * 并获取用户高危级别风险层级: 100: 普通用户 200: 监控用户 300: 高危用户
     * @param uid uid
     * @return user image attr
     */
    @GetMapping("/v1/es/image/{uid}/info")
    public ApiResult<UserImageAttrDto> getUserInfoByUid(@PathVariable("uid") Long uid);
    
    /**
     * es获取用户数据，用户分层召回使用
     * @param conditionVo param
     * @return result
     */
    @PostMapping("/v1/es/image/recommend/{uid}/recall/filter")
    public ApiResult<ImageReCallDto> reCallByCondition(@PathVariable(value = "uid") Long uid,@RequestBody @Validated ImageCallConditionVo conditionVo);

    @PostMapping("/v1/es/image/recommend/{uid}/risk/filter")
    public ApiResult<ImageReCallDto> reCallHighRisk(@PathVariable(value = "uid") Long uid,@RequestBody @Validated HighRiskCallVO highRiskCallVO);

}
