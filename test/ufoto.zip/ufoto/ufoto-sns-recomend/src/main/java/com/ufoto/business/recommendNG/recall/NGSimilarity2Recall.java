package com.ufoto.business.recommendNG.recall;

import com.google.common.collect.Sets;
import com.ufoto.annotation.RecommendMetadata;
import com.ufoto.business.recommendNG.Recall;
import com.ufoto.dao.svd.UfotoSvdItemSimilarityMapper;
import com.ufoto.dto.RecommendAdvanceRequest;
import com.ufoto.utils.CommonUtil;
import com.ufoto.utils.redis.RedisKeyConstant;
import com.ufoto.utils.redis.RedisService;
import org.springframework.core.env.Environment;
import org.springframework.stereotype.Component;
import org.springframework.util.CollectionUtils;

import java.util.List;
import java.util.Objects;
import java.util.Set;
import java.util.stream.Collectors;

/**
 * Created by echo on 5/11/18.
 */
@RecommendMetadata(
        metadataType = RecommendMetadata.MetadataType.RECALL,
        available = true,
        name = "相似用户召回策略-升级版",
        description = "以用户最近like的内容为基础,召回与用户喜欢内容相似的用户topN",
        branch = RecommendMetadata.Branch.NORMAL
)
@Component
public class NGSimilarity2Recall implements Recall {
    private final Environment env;
    private final UfotoSvdItemSimilarityMapper ufotoSvdItemSimilarityMapper;
    private final RedisService redisService;

    public NGSimilarity2Recall(Environment env,
                               UfotoSvdItemSimilarityMapper ufotoSvdItemSimilarityMapper,
                               RedisService redisService) {
        this.env = env;
        this.ufotoSvdItemSimilarityMapper = ufotoSvdItemSimilarityMapper;
        this.redisService = redisService;
    }

    @Override
    public Set<String> recall(Integer minSize, RecommendAdvanceRequest recallRequest) {
        boolean ifSvdOn = env.getProperty("recommend.recall.ifSvdOn", Boolean.class, true);
        if (!ifSvdOn) return Sets.newHashSet();
        List<String> latestLiked = redisService.lrange(String.format(RedisKeyConstant.REDIS_LATEST_LIKED_ITEM_LIST_KEY_, recallRequest.getUid()), 0, -1);
        List<Long> lastLikedItemList = latestLiked.stream()
                .filter(CommonUtil::isLong)
                .map(Long::valueOf)
                .collect(Collectors.toList());

        List<Long> recallResultList = ufotoSvdItemSimilarityMapper.selectTopNSimilarity2ByIids(lastLikedItemList);
        if (CollectionUtils.isEmpty(recallResultList))
            return Sets.newHashSet();

        return recallResultList.stream()
                .filter(Objects::nonNull)
                .map(Object::toString)
                .collect(Collectors.toSet());
    }

    @Override
    public boolean ifRecallOnlyOnce() {
        return true;
    }

    @Override
    public boolean ifNeedThreadLocalCache() {
        return true;
    }
}
