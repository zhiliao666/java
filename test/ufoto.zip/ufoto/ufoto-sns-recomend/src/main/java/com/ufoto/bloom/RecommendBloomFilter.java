package com.ufoto.bloom;


import java.util.Set;

/**
 * <p>
 * Author     : Chan
 * CreateDate : 2019/12/4 11:28
 * Description: 推荐的布隆过滤器
 * </p>
 */
public interface RecommendBloomFilter<U, T> {

    /**
     * Adds element
     *
     * @param user - user identify
     * @param item - element to add
     * @return <code>true</code> if element has been added successfully
     * <code>false</code> if element is already present
     */
    boolean add(U user, T item);

    /**
     * Check for element present
     *
     * @param user - user identify
     * @param item - element
     * @return <code>true</code> if element is present
     * <code>false</code> if element is not present
     */
    boolean contains(U user, T item);

    /**
     * filter element for present
     *
     * @param user  user
     * @param items items
     * @return item for absent
     */
    Set<T> filter(U user, Set<T> items);

    /**
     * Initializes Bloom filter params (size and hashIterations)
     * calculated from <code>expectedInsertions</code> and <code>falseProbability</code>
     * Stores config to Redis server.
     *
     * @param expectedInsertions - expected amount of insertions per element
     * @param falseProbability   - expected false probability
     * @return <code>true</code> if Bloom filter initialized
     * <code>false</code> if Bloom filter already has been initialized
     */
    boolean tryInit(long expectedInsertions, double falseProbability);

    /**
     * Returns expected amount of insertions per element.
     * Calculated during bloom filter initialization.
     *
     * @return expected amount of insertions per element
     */
    long getExpectedInsertions();

    /**
     * Returns false probability of element presence.
     * Calculated during bloom filter initialization.
     *
     * @return false probability of element presence
     */
    double getFalseProbability();

    /**
     * Returns number of bits in Redis memory required by this instance
     *
     * @return number of bits
     */
    long getSize();

    /**
     * Returns hash iterations amount used per element.
     * Calculated during bloom filter initialization.
     *
     * @return hash iterations amount
     */
    int getHashIterations();

    /**
     * Calculates probabilistic number of elements already added to Bloom filter.
     *
     * @param user - user identify
     * @return probabilistic number of elements
     */
    long count(U user);

    /**
     * 清理bloom keys
     */
    void cleanExpireBloomKeys(U user);

    /**
     * 清理所有key
     */
    void clear(U user);
}
