# -*- coding: utf-8 -*-
'''
将对应用户的u_h_{id} 当中的gift num
从数据库统计到Redis中
'''
import pymysql
from rediscluster import StrictRedisCluster
import sys

#MYSQL_HOST="cluster-appservice-rds.cluster-ro-czficfutfvot.us-east-1.rds.amazonaws.com"
#MYSQL_USER="root"
#MYSQL_PWD="ufoto$1234"

#REDIS_HOST = "recommend-prod.mihgdg.clustercfg.use1.cache.amazonaws.com"

MYSQL_HOST="beta-public-mysql.cluster-czficfutfvot.us-east-1.rds.amazonaws.com"
MYSQL_USER="root"
MYSQL_PWD="ufoto1234"

REDIS_HOST = "cluster-redis-beta.mihgdg.clustercfg.use1.cache.amazonaws.com"

REDIS_PORT = "6379"
startup_nodes = [{"host":REDIS_HOST ,"port": REDIS_PORT}]

def get_count(uid,db):
    SQL='''
    SELECT count(*)
    FROM ufoto_gift_record
    WHERE uid = {0}
    '''.format(uid)
    
    # 获取一行
    with db.cursor() as cursor:
        cursor.execute(SQL)
        count = cursor.fetchone()[0]

    return count

def write_redis(uid,count,r):
    #操作redis
    r.hset("u_h_{0}".format(uid),"gift_num",count)

def import_user_to_redis(uid,r):
    r.sadd("gift_receive_user_set","\""+str(uid)+"\"")

def main():
    if len(sys.argv)<2:
        print("fuck!")
        return

    db = pymysql.connect(MYSQL_HOST,MYSQL_USER,MYSQL_PWD,"ufoto")
    r = StrictRedisCluster(startup_nodes=startup_nodes,decode_responses=True,skip_full_coverage_check=True)

    if sys.argv[1] == "import":
        file_path = sys.argv[2]
        print("import")

        with open(file_path) as input_file:
            uid_list = list(map(lambda l: l.strip()[1:-1],input_file.readlines()))

        for uid in uid_list :
            print(uid)
            print("------")
            import_user_to_redis(uid,r)

        return 



    file_path = sys.argv[1]
    with open(file_path) as input_file:
        uid_list = list(map(lambda l: l.strip()[1:-1],input_file.readlines()))

    for uid in uid_list :
        count = get_count(uid,db)
        print(uid)
        print(count)
        print("------")
        write_redis(uid,count,r)

    db.close()

if __name__ == "__main__":
    main()
