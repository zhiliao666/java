# -*- coding: utf-8 -*-
'''
将数据库中的所有机器人保存下来
'''
import pymysql
import pandas as pd

MYSQL_HOST="192.168.60.199"
MYSQL_USER="root"
MYSQL_PWD="123456"

def dump_all_robot():
    db = pymysql.connect(MYSQL_HOST,MYSQL_USER,MYSQL_PWD,"ufoto" )
    df = pd.read_sql('SELECT id FROM ufoto_app_user WHERE type = 0 AND uuid NOT LIKE \'del_%\';', con=db)
    db.close()
 #   df.to_csv('./all_robot.txt')

    with open('./all_robot.txt','w') as dump_file:
        for uid in df['id']:
            dump_file.write("\"%d\"\n"%(uid))


def main():
    print("main")
    dump_all_robot()

if __name__ == '__main__':
    main()
