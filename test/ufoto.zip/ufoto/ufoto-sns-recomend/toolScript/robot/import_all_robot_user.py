# -*- coding: utf-8 -*-
'''
将机器人导入Redis
'''
from rediscluster import StrictRedisCluster
from datetime import datetime,timedelta
import sys

startup_nodes = [{"host": "recommend-prod.mihgdg.clustercfg.use1.cache.amazonaws.com","port": "6379"}]
r = StrictRedisCluster(startup_nodes=startup_nodes,decode_responses=True,skip_full_coverage_check=True)

def import_all_robot(file_path='./all_robot.txt'):
    with open(file_path) as robot_file:
        for line in robot_file.readlines():
            print(line.strip())
            r.sadd("robot_uid:all",line.strip())
    print("done")


def main():
    print("main")
    import_all_robot()


if __name__ == '__main__':
    main()
