<!-- toc -->

- [1. 架构--ufoto-behavior](#1-架构--ufoto-behavior)
- [2. 对外提供的接口](#2-对外提供的接口)
  * [2.1 com.ufoto.api.manager.BehaviorManager](#21-comufotobehaviormanagerBehaviorManager)
    + [2.1.1 发送金币消耗的通知](#211-发送金币消耗的通知)
  * [2.2 com.ufoto.behavior.manager.ESManager](#22-comufotobehaviormanagerESManager)
  * [2.3 com.ufoto.behavior.manager.slide](#23-comufotobehaviormanagerslide)
    + [2.3.1 主要处理逻辑](#231-主要处理逻辑)
      - [2.3.1.1. like/superlike](#2311-likesuperlike)
      - [2.3.1.2 dislike](#2312-dislike)
  * [2.4 com.ufoto.behavior.manager.UserActivityTimeManager](#24-comufotobehaviormanagerUserActivityTimeManager)
  * [2.5 com.ufoto.behavior.manager.UserGeoManager](#25-comufotobehaviormanagerUserGeoManager)
  * [2.6 com.ufoto.behavior.manager.RobotCacheManager](#26-comufotobehaviormanagerRobotCacheManager)

<!-- tocstop -->

# 1. 架构--ufoto-behavior
 
 > 主要负责用户行为相关的功能
 > 

# 2. 对外提供的接口

```
com.ufoto.behavior.manager
```

## 2.1 com.ufoto.api.manager.BehaviorManager

### 2.1.1 发送金币消耗的通知

```
com.ufoto.api.manager.BehaviorManager.sendConsumeCoinMQ
```
 
    目前主要是superlike的金币消耗通知
    交换机: social.superlike.consume.coin
    消息格式: 
    {
        "uid":null,//用户id
        "coin":0,//当前变动的金币 消耗和获取有消息类型提供
        "amount":0//总金额
    }
 
 ## 2.2 com.ufoto.behavior.manager.ESManager
 
 主要负责ES相关数据操作
 
 ## 2.3 com.ufoto.behavior.manager.slide
 
 like/superlike/dislike的主要处理类
 其中包括:
 ```
 com.ufoto.behavior.manager.slide.LikeSlideOperation
 com.ufoto.behavior.manager.slide.SuperLikeSlideOperation
 com.ufoto.behavior.manager.slide.DislikeSlideOperation
 ```
 
 入口函数为
 ```
 com.ufoto.behavior.manager.slide.SlideContext
 ```
 
 通过`com.ufoto.behavior.constants.ELikeType#getOperationClass`确定最终的操作类
 
### 2.3.1 主要处理逻辑
#### 2.3.1.1. like/superlike
    1. 判断对方是否like过自己，包括superlike
    2. 如果like过自己，删除两人之间的行为数据，目前不包括db，只尝试删除es中的数据，并标识当前两人为配对状态
    3. 如果没有like过自己
        3.1 如果对方不是机器人，直接插入like行为数据，包括db和es
        3.2 如果对方是机器人，首先确定自己之前是否已经与机器人配对过，如果没有配对过，则直接插入like行为数据，包括db和es，反之，确定概率是否要与机器人配对，如果配对成功，记录当前两人的状态为配对状态，并标识对方是机器人。如果概率配对失败，插入like行为数据。
    4. 以上操作执行完成后，发送MQ消息，会做一下几件事
        4.1 配对状态下，发送sayHi
        4.2 写入用户行为日志
        4.3 发送MQ消息，通知各服务当前的行为

> 基于以上4.3， MQ的基本信息如下
> 1. 交换机: social.sns.slide,表示当前的行为信息
> 2. 交换机: social.sns.slide.match,表示当前用户处于配对状态
> 3. 消息格式:
 {
    "action": null,//行为类型
    "ifChatBot": false,//对方是否是机器人
    "ifMatch": false,//配对状态
    "targetUid": null,//对方的id
    "uid": null//自己的id
}
> 4. 以上两种交换机均为fanout

#### 2.3.1.2 dislike
    1. 删除两人的行为记录，不包括db
    2. 发送MQ消息，交换机 social.sns.slide


## 2.4 com.ufoto.behavior.manager.UserActivityTimeManager
    每次有请求，尝试处理用户的活跃时间，一个小时更新一次

## 2.5 com.ufoto.behavior.manager.UserGeoManager
    每次有请求，尝试处理用户的地理位置信息，每天更新一次
    
## 2.6 com.ufoto.behavior.manager.RobotCacheManager
    机器人管理，启动加载
