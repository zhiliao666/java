package com.ufoto.behavior.constants;

/**
 * <p>
 * Author     : Chan
 * CreateDate : 2019-01-10 13:03
 * Description:
 * </p>
 */
public enum EAppPackage {
    sweetchat("sweetchat.localdatingtinder.meet", "3,30"),
    chat_meetme("chat.meetme.date.sweetmeet", "8"),
    SWEETSNAP_LITE_SNAPCHAT("sweetsnap.lite.snapchat", "11"),
    SNAP("com.ufotosoft.justshot", "10");

    private String packageName;
    private String type;

    public String getType() {
        return type;
    }

    EAppPackage(String packageName, String type) {
        this.packageName = packageName;
        this.type = type;
    }

    public String getPackageName() {
        return packageName;
    }
}
