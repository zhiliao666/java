package com.ufoto.behavior.utils.constant;

/**
 * @author luozq
 * @date 2020/2/28 11:18
 */
public interface ElasticConstant {

    /**
     * like index
     */
    String USER_LIKE_INDEX = "ufoto_user_like";

    /**
     * user_image index
     */
    String USER_IMAGE_INDEX = "user_image";


}
