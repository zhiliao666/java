package com.ufoto.behavior.manager.slide;

import com.ufoto.behavior.bean.SnsLikeRequest;
import com.ufoto.behavior.constants.ELikeType;
import com.ufoto.common.utils.SpringContextUtil;
import org.springframework.stereotype.Component;

/**
 * <p>
 * Description:
 *
 * </p>
 *
 * @author Chan
 * @date 2020/2/11 13:47
 */
@Component
public class SlideContext {

    public void slideOperation(SnsLikeRequest likeRequest) {
        final ELikeType likeType = likeRequest.getType();
        final Class<? extends SlideOperation> operationClass = likeType.getOperationClass();
        SpringContextUtil.getBean(operationClass).slide(likeRequest);
    }

}
