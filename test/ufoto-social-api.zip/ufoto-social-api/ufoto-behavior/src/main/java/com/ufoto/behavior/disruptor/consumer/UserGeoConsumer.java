package com.ufoto.behavior.disruptor.consumer;

import com.ufoto.behavior.disruptor.constants.ConsumerId;
import com.ufoto.behavior.disruptor.event.UserGeoEvent;
import com.ufoto.behavior.manager.UserGeoManager;
import com.ufoto.common.utils.GeoUtil;
import com.ufoto.lmax2.consumer.Consumer;
import io.micrometer.core.instrument.simple.SimpleMeterRegistry;
import org.springframework.stereotype.Component;

/**
 * <p>
 * Author     : Chan
 * CreateDate : 2019/11/15 17:19
 * Description:
 * </p>
 */
@Component
public class UserGeoConsumer extends Consumer<UserGeoEvent> {

    private final UserGeoManager userGeoManager;

    public UserGeoConsumer(UserGeoManager userGeoManager,
                           SimpleMeterRegistry simpleMeterRegistry) {
        super(ConsumerId.CONSUMER_USER_GEO, simpleMeterRegistry);
        this.userGeoManager = userGeoManager;
    }

    public void consume(UserGeoEvent event) {
        final String latitude = event.getLatitude();
        final String longitude = event.getLongitude();
        if (event.getUid() != null && GeoUtil.checkLongLat(longitude, latitude)) {
            userGeoManager.geoHandleSync(event.getUid(), longitude, latitude);
        }
    }
}
