package com.ufoto.behavior.bean.es;

import com.fasterxml.jackson.annotation.JsonAutoDetect;
import com.fasterxml.jackson.annotation.JsonIgnore;
import com.fasterxml.jackson.annotation.JsonInclude;
import com.fasterxml.jackson.annotation.JsonProperty;
import com.fasterxml.jackson.databind.PropertyNamingStrategy;
import com.fasterxml.jackson.databind.annotation.JsonNaming;
import lombok.Builder;
import lombok.Data;
import lombok.experimental.Tolerate;

import java.io.Serializable;

/**
 * @author luozq
 * @date 2020/2/28 09:45
 */
@Data
@Builder
@JsonNaming(PropertyNamingStrategy.SnakeCaseStrategy.class)
@JsonInclude(JsonInclude.Include.NON_NULL)
public class EsUserLikeDto implements Serializable {

    @JsonProperty("like_attr")
    private LikeAttrDto likeAttr;

    @JsonProperty("f_base_attr")
    private BaseAttrDto fBaseAttr;

    @JsonProperty("f_black_attr")
    private BlackAttrDto fBlackAttr;

    @Tolerate
    public EsUserLikeDto() {

    }

    @JsonIgnore
    public LikeAttrDto getLikeAttr() {
        return likeAttr;
    }

    @JsonIgnore
    public void setLikeAttr(LikeAttrDto likeAttr) {
        this.likeAttr = likeAttr;
    }

    @JsonIgnore
    public BaseAttrDto getfBaseAttr() {
        return fBaseAttr;
    }

    @JsonIgnore
    public void setfBaseAttr(BaseAttrDto fBaseAttr) {
        this.fBaseAttr = fBaseAttr;
    }

    @JsonIgnore
    public BlackAttrDto getfBlackAttr() {
        return fBlackAttr;
    }

    @JsonIgnore
    public void setfBlackAttr(BlackAttrDto fBlackAttr) {
        this.fBlackAttr = fBlackAttr;
    }
}

