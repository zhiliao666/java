package com.ufoto.behavior.service.impl;

import com.ufoto.behavior.entity.UfotoUserLikeFrom;
import com.ufoto.behavior.entity.UfotoUserLikeTo;
import com.ufoto.behavior.manager.EsManager;
import com.ufoto.behavior.mapper.sharding.UfotoUserLikeFromMapper;
import com.ufoto.behavior.mapper.sharding.UfotoUserLikeToMapper;
import com.ufoto.behavior.service.UfotoUserLikeService;
import lombok.RequiredArgsConstructor;
import lombok.extern.slf4j.Slf4j;
import org.springframework.core.env.Environment;
import org.springframework.dao.DuplicateKeyException;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

/**
 * <p>
 * Description:
 *
 * </p>
 *
 * @author Chan
 * @date 2020/2/12 12:57
 */
@RequiredArgsConstructor
@Slf4j
@Service
public class UfotoUserLikeServiceImpl implements UfotoUserLikeService {

    private final UfotoUserLikeFromMapper ufotoUserLikeFromMapper;
    private final UfotoUserLikeToMapper ufotoUserLikeToMapper;
    private final Environment env;
    private final EsManager esManager;

    @Transactional(transactionManager = "behaviorShardingTransactionManager", noRollbackFor = DuplicateKeyException.class)
    @Override
    public void insert(UfotoUserLikeFrom from, UfotoUserLikeTo to) {
        boolean dbSwitch = env.getProperty("user.act.write.switch.db", Boolean.class, true);
        if (dbSwitch) {
            ufotoUserLikeFromMapper.insertOnDuplicateKey(from);
            ufotoUserLikeToMapper.insertOnDuplicateKey(to);
        }
    }

    @Override
    public int selectCount(UfotoUserLikeFrom condition) {
        boolean dbSwitch = env.getProperty("user.act.write.switch.db", Boolean.class, true);
        if (dbSwitch) {
            return ufotoUserLikeFromMapper.selectCount(condition);
        } else {
            return esManager.selectCount(condition);
        }
    }

    @Transactional(transactionManager = "behaviorShardingTransactionManager")
    @Override
    public void deleteBothRecord(Long uid, Long targetUid) {
        ufotoUserLikeFromMapper.deleteWithUids(uid, targetUid);
        ufotoUserLikeFromMapper.deleteWithUids(targetUid, uid);
        ufotoUserLikeToMapper.deleteWithUids(uid, targetUid);
        ufotoUserLikeToMapper.deleteWithUids(targetUid, uid);
    }

    @Transactional(transactionManager = "behaviorShardingTransactionManager")
    @Override
    public void remainFixedTimeRecords(int fixedTimeSecond) {
        boolean dbSwitch = env.getProperty("user.act.write.switch.db", Boolean.class, true);
        if (dbSwitch) {
            ufotoUserLikeFromMapper.deleteLessFixedTime(fixedTimeSecond);
            ufotoUserLikeToMapper.deleteLessFixedTime(fixedTimeSecond);
        }
    }
}
