package com.ufoto.behavior.bean.es;

import com.fasterxml.jackson.annotation.JsonProperty;
import lombok.Builder;
import lombok.Data;
import lombok.experimental.Tolerate;

/**
 * @author luozq
 * @date 2020/2/28 09:46
 */
@Data
@Builder
public class LikeAttrDto {


    @JsonProperty("f_u_id")
    private Long fUid;

    @JsonProperty("t_u_id")
    private Long tUid;

    @JsonProperty("create_time")
    private Long createTime;

    private Integer type;

    private Integer visible;

    @Tolerate
    public LikeAttrDto () {

    }
}

