package com.ufoto.behavior.manager;

import com.github.benmanes.caffeine.cache.Caffeine;
import com.github.benmanes.caffeine.cache.LoadingCache;
import com.google.common.hash.BloomFilter;
import com.google.common.hash.Funnels;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.core.env.Environment;
import org.springframework.stereotype.Component;

import java.time.Duration;

/**
 * <p>
 * Author     : Chan
 * CreateDate : 2019-07-31 13:18
 * Description:
 * </p>
 */
@Component
public class LocalBloomFilterCacheManager {
    private final LoadingCache<String, BloomFilter<Long>> activityTimeBloomFilterCache;
    private final LoadingCache<String, BloomFilter<Long>> geoBloomFilterCache;

    private final static String ACTIVITY_TIME_BF = "act_time_bf";

    private final static String GEO_BF = "geo_bf";
    private final Environment env;

    @Autowired
    public LocalBloomFilterCacheManager(Environment env) {
        this.env = env;
        this.activityTimeBloomFilterCache = Caffeine.newBuilder()
                .expireAfterWrite(Duration.ofSeconds(env.getProperty("user.activity.time.expire", Integer.class, 3600)))
                .maximumSize(1)
                .build(key -> createBloomFilter());
        this.geoBloomFilterCache = Caffeine.newBuilder()
                .expireAfterWrite(Duration.ofSeconds(env.getProperty("user.geo.expire", Integer.class, 86400)))
                .maximumSize(1)
                .build(key -> createBloomFilter());
    }

    private BloomFilter<Long> createBloomFilter() {
        return BloomFilter.create(Funnels.longFunnel(),
                env.getProperty("api.bf.insertions", Integer.class, 1000000),
                env.getProperty("api.bf.fpp", Double.class, 0.00001));
    }

    public BloomFilter<Long> userActivityBF() {
        return activityTimeBloomFilterCache.get(ACTIVITY_TIME_BF);
    }

    public BloomFilter<Long> userGeoBF() {
        return geoBloomFilterCache.get(GEO_BF);
    }
}
