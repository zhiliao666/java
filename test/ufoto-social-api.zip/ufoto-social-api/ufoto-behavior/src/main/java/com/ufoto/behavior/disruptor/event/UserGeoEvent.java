package com.ufoto.behavior.disruptor.event;

import com.ufoto.lmax2.event.Event;
import lombok.Builder;
import lombok.Data;
import lombok.EqualsAndHashCode;

import java.io.Serializable;

/**
 * <p>
 * Author     : Chan
 * CreateDate : 2019/11/16 13:25
 * Description: 具体的时间-用户地理位置
 * </p>
 */
@EqualsAndHashCode(callSuper = true)
@Data
@Builder
public class UserGeoEvent extends Event implements Serializable {
    private Long uid;
    private String longitude;
    private String latitude;
}
