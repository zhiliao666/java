package com.ufoto.behavior.bean;

import lombok.Builder;
import lombok.Data;
import lombok.EqualsAndHashCode;

@EqualsAndHashCode(callSuper = true)
@Data
@Builder
public class SnsLikeResult extends LikeResultDto {
    @Builder.Default
    private Boolean isMatched = false;//是否match
    private Integer remain;//免费剩余次数
    private Integer buyRemain;//购买剩余次数
    private Integer ttl;//下次刷新免费次数时间
    //--new add limit for free use
    private Integer limit;//每天免费次数
}
