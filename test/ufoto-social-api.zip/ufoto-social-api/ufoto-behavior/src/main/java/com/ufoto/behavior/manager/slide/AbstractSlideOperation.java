package com.ufoto.behavior.manager.slide;

import com.ufoto.behavior.bean.SnsLikeRequest;
import com.ufoto.behavior.bean.SnsTransitResult;
import com.ufoto.behavior.disruptor.consumer.SnsSlideActConsumer;
import com.ufoto.behavior.disruptor.consumer.SnsSlideWriteLogConsumer;
import com.ufoto.behavior.disruptor.event.SnsSlideEvent;
import com.ufoto.behavior.entity.UfotoUserLikeFrom;
import com.ufoto.behavior.entity.UfotoUserLikeTo;
import com.ufoto.behavior.manager.EsManager;
import com.ufoto.behavior.service.UfotoUserLikeService;
import com.ufoto.common.utils.BeanUtil;
import com.ufoto.lmax2.disruptor.LMaxDisruptor;
import lombok.RequiredArgsConstructor;
import lombok.extern.slf4j.Slf4j;

/**
 * <p>
 * Description:
 *
 * </p>
 *
 * @author Chan
 * @date 2020/2/11 13:36
 */
@Slf4j
@RequiredArgsConstructor
public abstract class AbstractSlideOperation implements SlideOperation {
    private final UfotoUserLikeService ufotoUserLikeService;
    private final LMaxDisruptor<SnsSlideEvent> snsSlideEventLMaxDisruptor;
    private final EsManager esManager;

    protected void insertLike(SnsLikeRequest likeRequest) {

        UfotoUserLikeFrom likeFrom = new UfotoUserLikeFrom();
        likeFrom.setTUId(likeRequest.getTargetUid());
        likeFrom.setFUId(likeRequest.getUid());
        likeFrom.setType(likeRequest.getType().getType());

        UfotoUserLikeTo likeTo = BeanUtil.copyProperties(likeFrom, new UfotoUserLikeTo());
        ufotoUserLikeService.insert(likeFrom, likeTo);

        esManager.insert(likeFrom);
    }

    protected void deleteBothRecord(SnsLikeRequest likeRequest) {
        ufotoUserLikeService.deleteBothRecord(likeRequest.getUid(), likeRequest.getTargetUid());
        esManager.delete(likeRequest.getUid(), likeRequest.getTargetUid());
    }

    /**
     * 具体消息消费逻辑如下:
     * {@link SnsSlideActConsumer}
     * {@link SnsSlideWriteLogConsumer}
     * 发送滑动消息
     * 消息内容包含 滑动类型 配对状态 对方机器人状态
     * 做什么事情
     * 0. 金币变动--同步
     * 1. 额度变动--同步
     * 2. 魅力值
     * 3. 好友 如果是聊天机器人  还需要发送消息处理自动聊天程序
     * 4. 推荐
     * 5. 任务
     * 6. 推送
     * 7. 聊天机器人
     * 消息格式
     * uid targetUid action ifMatch ifChatBot
     * 交换器
     * social.sns.slide
     */
    protected void sendMQ(SnsLikeRequest likeRequest, SnsTransitResult snsTransitResult) {
        snsSlideEventLMaxDisruptor.send(
                SnsSlideEvent.builder()
                        .request(likeRequest)
                        .transitResult(snsTransitResult)
                        .build()
        );
    }
}
