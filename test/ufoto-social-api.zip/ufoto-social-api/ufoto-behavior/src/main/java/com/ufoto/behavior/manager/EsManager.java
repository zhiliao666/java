package com.ufoto.behavior.manager;

import com.ufoto.behavior.bean.es.BaseAttrDto;
import com.ufoto.behavior.bean.es.BlackAttrDto;
import com.ufoto.behavior.bean.es.EsUserLikeDto;
import com.ufoto.behavior.bean.es.LikeAttrDto;
import com.ufoto.behavior.entity.UfotoUserLike;
import com.ufoto.common.utils.JsonUtil;
import com.ufoto.es.config.CustomElasticListener;
import lombok.RequiredArgsConstructor;
import lombok.extern.slf4j.Slf4j;
import org.elasticsearch.action.get.GetRequest;
import org.elasticsearch.action.get.GetResponse;
import org.elasticsearch.action.index.IndexRequest;
import org.elasticsearch.action.index.IndexResponse;
import org.elasticsearch.client.RestHighLevelClient;
import org.elasticsearch.common.Strings;
import org.elasticsearch.common.unit.TimeValue;
import org.elasticsearch.common.xcontent.XContentType;
import org.elasticsearch.index.query.QueryBuilders;
import org.elasticsearch.index.reindex.BulkByScrollResponse;
import org.elasticsearch.index.reindex.DeleteByQueryRequest;
import org.elasticsearch.search.fetch.subphase.FetchSourceContext;
import org.springframework.stereotype.Component;
import org.springframework.util.CollectionUtils;
import org.springframework.util.StopWatch;

import java.io.IOException;
import java.time.Instant;
import java.util.Map;
import java.util.Objects;

import static com.ufoto.behavior.utils.constant.ElasticConstant.USER_IMAGE_INDEX;
import static com.ufoto.behavior.utils.constant.ElasticConstant.USER_LIKE_INDEX;

/**
 * <p>
 * Description:
 *
 * </p>
 *
 * @author Chan
 * @date 2020/2/26 17:38
 */
@Slf4j
@RequiredArgsConstructor
@Component
public class EsManager {

    private static final String BASE_ATTR_FIELD = "base_attr";
    private static final String BLACK_ATTR = "black_attr";
    private static final String LIKE_ROUTE_KEY = "t_u_id";
    private final RestHighLevelClient restHighLevelClient;

    /**
     * save user like data
     *
     * @param record param
     */
    public void insert(UfotoUserLike record) {
        /**
         * 1. 查询 f_u_id 在 user_image 的信息
         * 2. 组装 like 信息
         * 3. 写入 es
         */
        StopWatch watch = new StopWatch();
        watch.start();
        String esId = record.getFUId() + ":" + record.getTUId();
        try {
            EsUserLikeDto likeDto = buildUserLikeDto(record);
            IndexRequest request = buildLikeIndexRequest(esId, record.getTUId(), likeDto);
            IndexResponse response = restHighLevelClient.index(request, CustomElasticListener.getReferOptions());
            log.debug("insert user like, response as follows: {}", response.toString());
        } catch (Exception e) {
            log.error("insert user like task occurs error, msg:{}", JsonUtil.toJson(record), e);
        } finally {
            watch.stop();
            log.warn("insert user like statics, esId:{}, cost:{}", esId, watch.getLastTaskTimeMillis());
        }

    }

    /**
     * 构建 save request
     *
     * @param esId    esId
     * @param tuId    t uid
     * @param likeDto like info
     * @return index request
     */
    private IndexRequest buildLikeIndexRequest(String esId, Long tuId, EsUserLikeDto likeDto) {
        IndexRequest request = new IndexRequest(USER_LIKE_INDEX);
        request.id(esId);
        request.routing(tuId + "");
        request.source(JsonUtil.toJson(likeDto), XContentType.JSON);

        return request;
    }

    public static void main(String[] args) {
        LikeAttrDto likeAttrDto = LikeAttrDto.builder().build();
        likeAttrDto.setFUid(1L);
        likeAttrDto.setTUid(2L);
        likeAttrDto.setType(0);
        likeAttrDto.setCreateTime(1583738061 * 1000L);

        BaseAttrDto baseAttrDto = BaseAttrDto.builder()
                .age(1)
                .country("zh")
                .build();

        BlackAttrDto blackAttrDto = BlackAttrDto.builder()
                .banned(0)
                .riskLevel(100)
                .build();

        EsUserLikeDto likeDto = EsUserLikeDto.builder()
                .likeAttr(likeAttrDto)
                .fBaseAttr(baseAttrDto)
                .fBlackAttr(blackAttrDto)
                .build();

        String json = JsonUtil.toJson(likeDto);
        System.out.println(json);
        EsUserLikeDto esUserLikeDto = JsonUtil.toObject(json, EsUserLikeDto.class);

        System.out.println(esUserLikeDto);
    }

    /**
     * 构建 like data
     *
     * @param record record
     * @return like data
     * @throws IOException
     */
    private EsUserLikeDto buildUserLikeDto(UfotoUserLike record) throws IOException {
        Long fuId = record.getFUId();
        GetResponse response = null;
        try {
            GetRequest request = new GetRequest(USER_IMAGE_INDEX, fuId + "");
            request.routing(fuId + "");
            response = restHighLevelClient.get(request, CustomElasticListener.getReferOptions());
        } catch (Exception e) {
            log.error("buildUserLikeDto task occurs error, msg:{}", JsonUtil.toJson(record), e);
        }
        Map<String, Object> queryMap = null;
        if (Objects.nonNull(response) && response.isExists()) {
            queryMap = response.getSourceAsMap();
        } else {
            log.warn("{}, index:{}, uid:{}", "QUERY_NO_RESULT", USER_IMAGE_INDEX, fuId);
        }
        EsUserLikeDto likeDto = EsUserLikeDto.builder().build();
        if (!CollectionUtils.isEmpty(queryMap)) {
            if (queryMap.containsKey(BASE_ATTR_FIELD)) {
                Object baseData = queryMap.get(BASE_ATTR_FIELD);
                BaseAttrDto baseAttrDto = JsonUtil.toObject(JsonUtil.toJson(baseData), BaseAttrDto.class);
                likeDto.setfBaseAttr(baseAttrDto);
            }
            if (queryMap.containsKey(BLACK_ATTR)) {
                Object blackData = queryMap.get(BLACK_ATTR);
                BlackAttrDto blackAttrDto = JsonUtil.toObject(JsonUtil.toJson(blackData), BlackAttrDto.class);
                likeDto.setfBlackAttr(blackAttrDto);
            }
        }
        long time = Instant.now().toEpochMilli();
        LikeAttrDto likeAttrDto = LikeAttrDto.builder()
                .fUid(record.getFUId())
                .tUid(record.getTUId())
                .createTime(time)
                .visible(0)
                .type(record.getType())
                .build();

        likeDto.setLikeAttr(likeAttrDto);
        return likeDto;
    }

    /**
     * check like each other
     *
     * @param condition param
     * @return 1 like each other, otherwise 0
     */
    public int selectCount(UfotoUserLike condition) {
        // 通过 ES 查询对方是否like过当前用户
        GetRequest request = buildCountRequest(condition);
        try {
            GetResponse response = restHighLevelClient.get(request, CustomElasticListener.getReferOptions());
            log.debug("user like selectCount task msg, as follows: {}, response: {}",
                    JsonUtil.toJson(condition),
                    JsonUtil.toJson(response.toString()));
            return response.isSourceEmpty() ? 0 : 1;
        } catch (IOException e) {
            log.error("es like selectCount task occurs error, msg:{}", JsonUtil.toJson(condition), e);
            return 0;
        }
    }

    /**
     * build search request
     *
     * @param condition condition
     * @return request
     */
    private GetRequest buildCountRequest(UfotoUserLike condition) {
        String esId = condition.getFUId() + ":" + condition.getTUId();
        GetRequest request = new GetRequest(USER_LIKE_INDEX);
        request.routing(condition.getTUId() + "");
        request.id(esId);
        String[] includes = new String[]{"like_attr.f_u_id"};
        String[] excludes = Strings.EMPTY_ARRAY;
        FetchSourceContext fetchSourceContext =
                new FetchSourceContext(true, includes, excludes);
        request.fetchSourceContext(fetchSourceContext);
        return request;
    }

    /**
     * delete like data
     */
    public void delete(Long uid, Long targetUid) {
        // 删除ES数据
        DeleteByQueryRequest request = buildDeleteRequest(uid, targetUid);
        try {
            BulkByScrollResponse response = restHighLevelClient.deleteByQuery(request, CustomElasticListener.getReferOptions());
            log.debug("user like delete task msg, as follows: uid:{}, targetUid:{}, response: {}",
                    uid, targetUid,
                    JsonUtil.toJson(response.toString()));
        } catch (Exception e) {
            log.error("user like delete task occurs error,uid:{}, targetUid:{}", uid, targetUid, e);
        }
    }

    /**
     * build delete request
     *
     * @return request
     */
    private DeleteByQueryRequest buildDeleteRequest(Long uid, Long targetUid) {
        DeleteByQueryRequest request = new DeleteByQueryRequest(USER_LIKE_INDEX);

        String esId = uid + ":" + targetUid;
        String esIdT = targetUid + ":" + uid;
        String routeKey = uid + "," + targetUid;
        request.setRouting(routeKey);
        request.setQuery(QueryBuilders.constantScoreQuery(QueryBuilders.idsQuery().addIds(esId, esIdT)));
        return request;
    }

    /**
     * 删除小于固定时间的记录
     *
     * @param fixedTimeSecond time
     */
    public void delete(int fixedTimeSecond) {
        // 删除小于固定时间的记录
        long time = fixedTimeSecond * 1000L;
        try {
            DeleteByQueryRequest request = buildDeleteByQuery(time);
            BulkByScrollResponse response = restHighLevelClient.deleteByQuery(request, CustomElasticListener.getReferOptions());
            log.debug("delete by query task msg, as follows :{}", JsonUtil.toJson(response));
        } catch (IOException e) {
            log.error("delete by query task occurs error, param:{}", fixedTimeSecond, e);
        }
    }

    /**
     * build delete by query request
     *
     * @param time time
     * @return request
     */
    private DeleteByQueryRequest buildDeleteByQuery(long time) {
        DeleteByQueryRequest request = new DeleteByQueryRequest(USER_LIKE_INDEX);
        request.setQuery(QueryBuilders.rangeQuery("like_attr.create_time").lte(time));
        request.setBatchSize(5000);
        request.setScroll(TimeValue.timeValueMinutes(10));
        return request;
    }
}
