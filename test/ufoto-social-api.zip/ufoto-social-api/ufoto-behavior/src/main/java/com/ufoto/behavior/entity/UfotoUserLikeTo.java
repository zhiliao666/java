package com.ufoto.behavior.entity;

import lombok.Data;
import lombok.EqualsAndHashCode;

import javax.persistence.Entity;
import javax.persistence.Table;

@EqualsAndHashCode(callSuper = true)
@Entity
@Table(name = "ufoto_user_like_t")
@Data
public class UfotoUserLikeTo extends UfotoUserLike {

}
