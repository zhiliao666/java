package com.ufoto.behavior.config;

import com.lmax.disruptor.BlockingWaitStrategy;
import com.lmax.disruptor.dsl.EventHandlerGroup;
import com.ufoto.behavior.disruptor.constants.ConsumerId;
import com.ufoto.behavior.disruptor.consumer.SnsSlideActConsumer;
import com.ufoto.behavior.disruptor.consumer.SnsSlideWriteLogConsumer;
import com.ufoto.behavior.disruptor.event.SnsSlideEvent;
import com.ufoto.lmax2.consumer.UnityConsumer;
import com.ufoto.lmax2.disruptor.LMaxDisruptor;
import com.ufoto.lmax2.event.ContextEvent;
import com.ufoto.lmax2.event.UnityEvent;
import com.ufoto.lmax2.handlers.CustomizerExecuteConsumer;
import io.micrometer.core.instrument.simple.SimpleMeterRegistry;
import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;

/**
 * <p>
 * Author     : Chan
 * CreateDate : 2019/11/15 17:10
 * Description:
 * </p>
 */
@Configuration
public class DisruptorConfig {

    @Bean(initMethod = "startDisruptor", destroyMethod = "shutdown")
    public LMaxDisruptor<UnityEvent> unityEventLMaxDisruptor(UnityConsumer unityConsumer) {
        LMaxDisruptor<UnityEvent> disruptor = LMaxDisruptor.<UnityEvent>builder()
                .waitStrategy(new BlockingWaitStrategy())
                .consumer(CustomizerExecuteConsumer.class)
                .build();

        disruptor.subscribeCustomizer(
                dis -> dis.handleEventsWithWorkerPool(unityConsumer, unityConsumer, unityConsumer)
        );
        return disruptor;
    }

    @Bean
    public UnityConsumer unityConsumer(SimpleMeterRegistry simpleMeterRegistry) {
        return new UnityConsumer(ConsumerId.CONSUMER_UNITY, simpleMeterRegistry);
    }

    @Bean(initMethod = "startDisruptor", destroyMethod = "shutdown")
    public LMaxDisruptor<SnsSlideEvent> snsSlideEventLMaxDisruptor(
            SnsSlideActConsumer snsSlideActConsumer,
            SnsSlideWriteLogConsumer snsSlideWriteLogConsumer
    ) {
        LMaxDisruptor<SnsSlideEvent> disruptor = LMaxDisruptor.<SnsSlideEvent>builder()
                .waitStrategy(new BlockingWaitStrategy())
                .consumer(CustomizerExecuteConsumer.class)
                .build();

        disruptor.subscribeCustomizer(
                dis -> {
                    //调整执行方式
                    final EventHandlerGroup<ContextEvent<SnsSlideEvent>> actGroup = dis.handleEventsWithWorkerPool(snsSlideActConsumer, snsSlideActConsumer, snsSlideActConsumer);
                    final EventHandlerGroup<ContextEvent<SnsSlideEvent>> logGroup = dis.handleEventsWithWorkerPool(snsSlideWriteLogConsumer, snsSlideWriteLogConsumer, snsSlideWriteLogConsumer);
                    actGroup.and(logGroup);
                }
        );
        return disruptor;
    }
}
