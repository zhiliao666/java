package com.ufoto.behavior.service;

import com.ufoto.behavior.entity.UfotoUserLikeFrom;
import com.ufoto.behavior.entity.UfotoUserLikeTo;

/**
 * <p>
 * Description:
 *
 * </p>
 *
 * @author Chan
 * @date 2020/2/12 12:56
 */
public interface UfotoUserLikeService {

    void insert(UfotoUserLikeFrom from, UfotoUserLikeTo to);

    int selectCount(UfotoUserLikeFrom condition);

    void deleteBothRecord(Long uid, Long targetUid);

    void remainFixedTimeRecords(int fixedTimeSecond);
}
