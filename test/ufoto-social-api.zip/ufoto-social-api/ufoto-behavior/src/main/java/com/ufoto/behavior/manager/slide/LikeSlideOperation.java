package com.ufoto.behavior.manager.slide;

import com.ufoto.behavior.bean.SnsLikeRequest;
import com.ufoto.behavior.bean.SnsTransitResult;
import com.ufoto.behavior.disruptor.event.SnsSlideEvent;
import com.ufoto.behavior.entity.UfotoUserLikeFrom;
import com.ufoto.behavior.manager.EsManager;
import com.ufoto.behavior.manager.RobotCacheManager;
import com.ufoto.behavior.service.UfotoChatBotProgressService;
import com.ufoto.behavior.service.UfotoUserLikeService;
import com.ufoto.behavior.utils.ChatBotUtil;
import com.ufoto.lmax2.disruptor.LMaxDisruptor;
import lombok.extern.slf4j.Slf4j;
import org.apache.commons.lang3.RandomUtils;
import org.springframework.core.env.Environment;
import org.springframework.stereotype.Component;

/**
 * <p>
 * Description:
 *
 * </p>
 *
 * @author Chan
 * @date 2020/2/11 13:35
 */
@Slf4j
@Component
public class LikeSlideOperation extends AbstractSlideOperation {

    private final RobotCacheManager robotCacheManager;
    private final UfotoUserLikeService ufotoUserLikeService;
    private final UfotoChatBotProgressService ufotoChatBotProgressService;
    private final Environment env;

    public LikeSlideOperation(RobotCacheManager robotCacheManager,
                              UfotoUserLikeService ufotoUserLikeService,
                              UfotoChatBotProgressService ufotoChatBotProgressService,
                              Environment env,
                              LMaxDisruptor<SnsSlideEvent> snsSlideEventLMaxDisruptor, EsManager esManager) {
        super(ufotoUserLikeService, snsSlideEventLMaxDisruptor, esManager);
        this.robotCacheManager = robotCacheManager;
        this.ufotoUserLikeService = ufotoUserLikeService;
        this.ufotoChatBotProgressService = ufotoChatBotProgressService;
        this.env = env;
    }

    /**
     * //  0. 对方是否是机器人的判断
     * //  1. 对方未 like 自己,处理 like 数据
     * //  2. 对方已 like 自己,处理好友数据
     * //  2.1 删除双方的 like 记录
     * //  3. 魅力值变动消息
     * //  4. like 额度变动消息
     * //  5. 推荐 like 行为消息
     * //  6. 每日任务
     *
     * @param likeRequest params
     */
    @Override
    public void slide(SnsLikeRequest likeRequest) {
        SnsTransitResult snsTransitResult = new SnsTransitResult();
        final Long uid = likeRequest.getUid();
        final Long targetUid = likeRequest.getTargetUid();
        UfotoUserLikeFrom likeFrom = new UfotoUserLikeFrom();
        likeFrom.setFUId(targetUid);
        likeFrom.setTUId(uid);
        final int likeFromCount = ufotoUserLikeService.selectCount(likeFrom);
        if (likeFromCount > 0) {
            // 对方 like 了自己
            // 删除 like 数据
            this.deleteBothRecord(likeRequest);
            snsTransitResult.setMatch(true);
        } else {
            // 对方没有 like 自己
            // 1. 检查对方是否是机器人
            boolean ifChatBot = ChatBotUtil.chatBotType(robotCacheManager, targetUid);
            if (ifChatBot) {
                //是否执行自动match 默认 true
                boolean ifAutoMatch = true;
                if (env.getProperty("chatbot.match.strict", Boolean.class, true)) {
                    final int chatBotRecordCount = ufotoChatBotProgressService.selectCount(uid);
                    //如果已经有聊天机器人的记录 不执行机器人自动匹配的逻辑
                    ifAutoMatch = chatBotRecordCount < 0;
                }
                //如果允许自动配对 并且随机数在 80 以内 (模拟 80% 的概率)
                if (ifAutoMatch && RandomUtils.nextInt(0, 100) < env.getProperty("robot_auto_matching_rate", Integer.class, 80)) {
                    snsTransitResult.setChatBot(true);
                    snsTransitResult.setMatch(true);
                } else {
                    //插入 like 数据
                    this.insertLike(likeRequest);
                }
            } else {
                //插入 like 数据
                this.insertLike(likeRequest);
            }
        }
        try {
            //处理消息
            this.sendMQ(likeRequest, snsTransitResult);
        } catch (Exception e) {
            log.error(e.getMessage(), e);
        }
    }
}
