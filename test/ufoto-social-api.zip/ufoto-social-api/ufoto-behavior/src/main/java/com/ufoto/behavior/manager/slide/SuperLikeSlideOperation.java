package com.ufoto.behavior.manager.slide;

import com.ufoto.behavior.bean.SnsLikeRequest;
import com.ufoto.behavior.disruptor.event.SnsSlideEvent;
import com.ufoto.behavior.manager.EsManager;
import com.ufoto.behavior.service.UfotoUserLikeService;
import com.ufoto.lmax2.disruptor.LMaxDisruptor;
import lombok.extern.slf4j.Slf4j;
import org.springframework.stereotype.Component;

/**
 * <p>
 * Description:
 *
 * </p>
 *
 * @author Chan
 * @date 2020/2/20 13:49
 */
@Slf4j
@Component
public class SuperLikeSlideOperation extends AbstractSlideOperation {

    private final LikeSlideOperation likeSlideOperation;

    public SuperLikeSlideOperation(UfotoUserLikeService ufotoUserLikeService,
                                   LMaxDisruptor<SnsSlideEvent> snsSlideEventLMaxDisruptor,
                                   LikeSlideOperation likeSlideOperation,
                                   EsManager esManager) {
        super(ufotoUserLikeService, snsSlideEventLMaxDisruptor, esManager);
        this.likeSlideOperation = likeSlideOperation;
    }

    @Override
    public void slide(SnsLikeRequest likeRequest) {
        // superlike的执行逻辑与like相同，处理数据稍有差异，
        // 以likeRequest中type标识操作类型
        likeSlideOperation.slide(likeRequest);
    }
}
