package com.ufoto.behavior.service.impl;

import com.ufoto.behavior.entity.UfotoChatBotProgress;
import com.ufoto.behavior.mapper.read.UfotoChatBotProgressReadMapper;
import com.ufoto.behavior.service.UfotoChatBotProgressService;
import lombok.RequiredArgsConstructor;
import lombok.extern.slf4j.Slf4j;
import org.springframework.stereotype.Service;

/**
 * <p>
 * Description:
 *
 * </p>
 *
 * @author Chan
 * @date 2020/2/12 15:37
 */
@Slf4j
@RequiredArgsConstructor
@Service
public class UfotoChatBotProgressServiceImpl implements UfotoChatBotProgressService {

    private final UfotoChatBotProgressReadMapper ufotoChatBotProgressReadMapper;

    @Override
    public int selectCount(Long uid) {
        UfotoChatBotProgress chatBotProgress = new UfotoChatBotProgress();
        chatBotProgress.setUid(uid);
        return ufotoChatBotProgressReadMapper.selectCount(chatBotProgress);
    }

}
