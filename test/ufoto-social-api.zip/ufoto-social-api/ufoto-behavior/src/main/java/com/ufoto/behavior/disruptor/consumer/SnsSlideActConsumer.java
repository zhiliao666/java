package com.ufoto.behavior.disruptor.consumer;

import com.ufoto.behavior.bean.SnsLikeRequest;
import com.ufoto.behavior.bean.SnsTransitResult;
import com.ufoto.behavior.constants.ELikeType;
import com.ufoto.behavior.disruptor.constants.ConsumerId;
import com.ufoto.behavior.disruptor.event.SnsSlideEvent;
import com.ufoto.common.utils.CommonUtil;
import com.ufoto.lmax2.consumer.Consumer;
import com.ufoto.rabbit.behavior.msg.SnsSlideMsg;
import com.ufoto.rabbit.config.RabbitProducer;
import io.micrometer.core.instrument.simple.SimpleMeterRegistry;
import lombok.extern.slf4j.Slf4j;
import org.springframework.stereotype.Component;

/**
 * <p>
 * Description:
 *
 * </p>
 *
 * @author Chan
 * @date 2019/12/19 11:33
 */
@Slf4j
@Component
public class SnsSlideActConsumer extends Consumer<SnsSlideEvent> {

    private final RabbitProducer rabbitProducer;

    public SnsSlideActConsumer(RabbitProducer rabbitProducer,
                               SimpleMeterRegistry simpleMeterRegistry) {
        super(ConsumerId.CONSUMER_SNS_SLIDE + ":Act", simpleMeterRegistry);
        this.rabbitProducer = rabbitProducer;
    }

    @Override
    public void consume(SnsSlideEvent event) {
        final SnsLikeRequest request = event.getRequest();
        final SnsTransitResult transitResult = event.getTransitResult();
        if (request == null || transitResult == null) {
            return;
        }
        //发送 uid->targetUid 的行为消息
        syncAct(request, transitResult);
        //TODO 如果对方是机器人 并且 match 发送 targetUid->uid 的行为消息
        // 如果是 match 发送 match 通知
        // 以上判断交由消费方处理
    }

    private void syncAct(SnsLikeRequest likeRequest, SnsTransitResult transitResult) {
        final ELikeType likeType = likeRequest.getType();
        if (likeType != null && CommonUtil.isNumber(likeRequest.getFUid())) {
            final SnsSlideMsg msg = SnsSlideMsg.builder()
                    .uid(likeRequest.getUid())
                    .targetUid(likeRequest.getTargetUid())
                    .action(likeType.getActionType().getType())
                    .ifMatch(transitResult.isMatch())
                    .ifChatBot(transitResult.isChatBot())
                    .build();
            rabbitProducer.produceByJson(likeType.getActionType().getExchange(),
                    likeType.getActionType().getRoutingKey(),
                    msg);

            if (transitResult.isMatch()) {
                rabbitProducer.produceByJson(
                        likeType.getActionType().getMatchExchange(),
                        likeType.getActionType().getRoutingKey(),
                        msg);
            }
        }
    }
}
