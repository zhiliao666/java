package com.ufoto.behavior.manager;

import ch.qos.logback.classic.spi.ILoggingEvent;
import com.google.common.hash.BloomFilter;
import com.ufoto.behavior.constants.RedisKeyConstant;
import com.ufoto.logging.kafka.KafkaAppenderConfig;
import com.ufoto.logging.layout.KafkaLayout;
import com.ufoto.logging.proxy.UfotoLogFactory;
import com.ufoto.logging.util.JSONUtil;
import com.ufoto.rabbit.behavior.constants.BehaviorExchange;
import com.ufoto.rabbit.behavior.constants.BehaviorRoutingKey;
import com.ufoto.rabbit.behavior.msg.AddActivityTimestampRequest;
import com.ufoto.rabbit.config.RabbitProducer;
import com.ufoto.redis.service.RedisService;
import lombok.RequiredArgsConstructor;
import lombok.extern.slf4j.Slf4j;
import org.slf4j.Logger;
import org.springframework.core.env.Environment;
import org.springframework.stereotype.Component;

/**
 * <p>
 * Description:
 *
 * </p>
 *
 * @author Chan
 * @date 2020/2/10 13:32
 */
@Slf4j
@RequiredArgsConstructor
@Component
public class UserActivityTimeManager {
    private final static Logger userActivityLogger = UfotoLogFactory.getLogger("user.activity.time")
            .enableCustomStatus()
            .disableFileAppender()
            .enableKafkaAppender()
            .withKafkaAppenderConfig(KafkaAppenderConfig.<ILoggingEvent>builder()
                    .topic("user_activity_time")
                    .kafkaLayout(new KafkaLayout())
                    .build())
            .build();

    private final Environment env;
    private final LocalBloomFilterCacheManager localBloomFilterCacheManager;
    private final RedisService redisService;
    private final RabbitProducer rabbitProducer;

    public void updateUserActivityTimestamp(Long uid, Integer timestamp) {
        try {
            AddActivityTimestampRequest addActivityTimestampRequest = new AddActivityTimestampRequest();
            addActivityTimestampRequest.setUid(uid);
            addActivityTimestampRequest.setTimestamp(timestamp);
            userActivityLogger.info(JSONUtil.toJSON(addActivityTimestampRequest));

            final BloomFilter<Long> bloomFilter = localBloomFilterCacheManager.userActivityBF();
            boolean contain = false;
            if (bloomFilter != null) {
                contain = bloomFilter.mightContain(uid);
            }
            if (!contain) {//一定不存在
                final boolean exists = redisService.exists(RedisKeyConstant.USER_ACTIVITY_RECORD + uid);
                if (!exists) {//如果不存在,那么更新
                    log.debug("updateUserActivityTimestamp:{}", uid);
                    rabbitProducer.produce(BehaviorExchange.SWEETCHAT_DIRECT_RECOMMEND,
                            BehaviorRoutingKey.ROUTE_KEY_ADD_REDIS_USER_ACTIVITY_TIMESTAMP,
                            addActivityTimestampRequest);
                    //执行完后放入redis
                    redisService.set(RedisKeyConstant.USER_ACTIVITY_RECORD + uid, "1",
                            env.getProperty("user.activity.time.expire", Long.class, 600L));
                }
                //放入bloom
                if (bloomFilter != null) {
                    bloomFilter.put(uid);
                }
            }
        } catch (Exception e) {
            log.error("用户活跃时间更新失败: {}", e.getMessage());
        }
    }


}
