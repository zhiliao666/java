package com.ufoto.behavior.manager;

import com.ufoto.behavior.utils.ChatBotUtil;
import com.ufoto.feign.usercenter.dto.UserBaseInfoDto;
import com.ufoto.robot.RobotCommonCacheManager;
import lombok.RequiredArgsConstructor;
import lombok.extern.slf4j.Slf4j;
import org.springframework.stereotype.Component;

import java.util.List;
import java.util.Map;
import java.util.stream.Collectors;

/**
 * <p>
 * Author     : Chan
 * CreateDate : 2019-05-14 10:45
 * Description:
 * </p>
 */
@Slf4j
@RequiredArgsConstructor
@Component
public class RobotCacheManager {

    private final RobotCommonCacheManager robotCommonCacheManager;


    public List<Long> chatBotList() {
        final Map<Long, UserBaseInfoDto> robotMap = this.getRobotMap();
        return robotMap.values().stream()
                .filter(u -> ChatBotUtil.ifChatBotType(u.getType()))
                .map(UserBaseInfoDto::getId)
                .collect(Collectors.toList());
    }

    public Map<Long, UserBaseInfoDto> getRobotMap() {
        return robotCommonCacheManager.getRobotMap();
    }

}
