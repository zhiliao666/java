package com.ufoto.behavior.manager;

import com.google.common.hash.BloomFilter;
import com.ufoto.behavior.constants.RedisKeyConstant;
import com.ufoto.rabbit.behavior.constants.BehaviorExchange;
import com.ufoto.rabbit.behavior.constants.BehaviorRoutingKey;
import com.ufoto.rabbit.config.RabbitProducer;
import com.ufoto.redis.service.RedisService;
import lombok.RequiredArgsConstructor;
import lombok.extern.slf4j.Slf4j;
import org.apache.commons.lang3.StringUtils;
import org.springframework.core.env.Environment;
import org.springframework.scheduling.annotation.Async;
import org.springframework.stereotype.Component;

import java.util.HashMap;
import java.util.Map;

/**
 * <p>
 * Author     : Chan
 * CreateDate : 2019-07-16 10:39
 * Description: 用户经纬度更新管理类
 * </p>
 */
@SuppressWarnings("all")
@Slf4j
@RequiredArgsConstructor
@Component
public class UserGeoManager {

    private final RabbitProducer rabbitProducer;
    private final RedisService redisService;
    private final Environment env;
    private final LocalBloomFilterCacheManager localBloomFilterCacheManager;

    /**
     * 用户经纬度处理
     *
     * @param uid       用户id
     * @param longitude 经度
     * @param latitude  纬度
     */
    @Async
    public void geoHandle(Long uid, String longitude, String latitude) {
        geoHandleSync(uid, longitude, latitude);
    }

    public void geoHandleSync(Long uid, String longitude, String latitude) {
        log.debug("geo uid:{},longitude:{},latitude:{}", uid, longitude, latitude);
        if (uid == null) return;
        if (StringUtils.isBlank(longitude) || StringUtils.isBlank(latitude)) return;
        final BloomFilter<Long> bloomFilter = localBloomFilterCacheManager.userGeoBF();
        boolean contain = false;
        if (bloomFilter != null) {
            contain = bloomFilter.mightContain(uid);
        }
        if (!contain) {//一定不存在
            boolean exists = redisService.exists(RedisKeyConstant.USER_GEO_RECORD + uid);
            if (!exists) {
                //如果不存在 更新
                final Map<String, Object> map = new HashMap<>();
                map.put("id", uid);
                map.put("longitude", longitude);
                map.put("latitude", latitude);
                rabbitProducer.produceByJson(BehaviorExchange.SOCIAL_DIRECT_USERCENTER,
                        BehaviorRoutingKey.ROUTING_KEY_USER_CENTER_GEO,
                        map);
                //同时放入缓存
                redisService.set(RedisKeyConstant.USER_GEO_RECORD + uid, "1",
                        env.getProperty("user.geo.expire", Long.class, 86400L));
            }
            if (bloomFilter != null) {
                bloomFilter.put(uid);
            }
        }
    }

}
