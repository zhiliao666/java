package com.ufoto.behavior.config.mysql;

import com.zaxxer.hikari.HikariDataSource;
import lombok.RequiredArgsConstructor;
import org.apache.ibatis.session.SqlSessionFactory;
import org.mybatis.spring.SqlSessionFactoryBean;
import org.mybatis.spring.SqlSessionTemplate;
import org.springframework.beans.BeanUtils;
import org.springframework.beans.factory.annotation.Qualifier;
import org.springframework.boot.context.properties.ConfigurationProperties;
import org.springframework.boot.jdbc.DataSourceBuilder;
import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;
import org.springframework.core.io.support.PathMatchingResourcePatternResolver;
import org.springframework.jdbc.datasource.DataSourceTransactionManager;
import tk.mybatis.spring.annotation.MapperScan;

import javax.sql.DataSource;

/**
 * 配置写数据源
 *
 * @author luozq
 * @date 2019/3/6/006
 */
@RequiredArgsConstructor
@Configuration
@MapperScan(basePackages = {"com.ufoto.behavior.mapper.write"}, sqlSessionTemplateRef = "behaviorWriteSqlSessionTemplate")
public class BehaviorWriteDataSourceConfig extends DataSourceConfig {

    private final BehaviorHikari beHaviorHikari;

    @Bean(destroyMethod = "shutdown")
    @ConfigurationProperties(prefix = "spring.datasource.write.behavior")
    public HikariDataSource behaviorWriteDataSource() {
        final HikariDataSource dataSource = DataSourceBuilder.create().type(HikariDataSource.class).build();
        // 配置Hikari的相关配置参数
        BeanUtils.copyProperties(beHaviorHikari, dataSource);
        return dataSource;
    }

    @Bean
    public SqlSessionFactory behaviorWriteSqlSessionFactory(@Qualifier("behaviorWriteDataSource") DataSource dataSource) throws Exception {
        SqlSessionFactoryBean bean = new SqlSessionFactoryBean();
        // 设置mybatis配置文件路径
        bean.setMapperLocations(new PathMatchingResourcePatternResolver()
                .getResources("classpath*:mapper/behavior/write/**/*.xml"));

        bean.setDataSource(dataSource);
        return getSqlSessionFactory(dataSource, bean);
    }

    @Bean
    public DataSourceTransactionManager behaviorWriteTransactionManager(@Qualifier("behaviorWriteDataSource") DataSource dataSource) {
        return new DataSourceTransactionManager(dataSource);
    }

    @Bean
    public SqlSessionTemplate behaviorWriteSqlSessionTemplate(@Qualifier("behaviorWriteSqlSessionFactory") SqlSessionFactory sqlSessionFactory) {
        return new SqlSessionTemplate(sqlSessionFactory);
    }

}
