package com.ufoto.behavior.mapper.sharding;

import com.ufoto.base.mapper.SysMapper;
import com.ufoto.behavior.entity.UfotoUserLikeTo;
import org.apache.ibatis.annotations.Param;

public interface UfotoUserLikeToMapper extends SysMapper<UfotoUserLikeTo> {

    int deleteLessFixedTime(@Param("fixedTimeSecond") int fixedTimeSecond);

    int insertOnDuplicateKey(UfotoUserLikeTo to);

    int deleteWithUids(@Param("uid") Long uid, @Param("targetUid") Long targetUid);
}
