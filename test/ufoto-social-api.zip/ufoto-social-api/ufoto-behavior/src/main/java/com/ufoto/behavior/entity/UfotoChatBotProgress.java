package com.ufoto.behavior.entity;

import lombok.Data;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.Id;
import javax.persistence.Table;
import java.io.Serializable;

/**
 * <p>
 * Description:
 *
 * </p>
 *
 * @author Chan
 * @date 2020/2/12 15:30
 */
@Data
@Entity
@Table(name = "ufoto_chat_bot_progress")
public class UfotoChatBotProgress implements Serializable {
    @Id
    @Column(name = "id")
    private Integer id;
    @Column(name = "create_time")
    private Integer createTime;
    @Column(name = "update_time")
    private Integer updateTime;
    @Column(name = "match_type")
    private Integer matchType;
    @Column(name = "uid")
    private Long uid;
    @Column(name = "current_state_id")
    private Integer currentStateId;
    @Column(name = "chat_bot_uid")
    private Long chatBotUid;
}
