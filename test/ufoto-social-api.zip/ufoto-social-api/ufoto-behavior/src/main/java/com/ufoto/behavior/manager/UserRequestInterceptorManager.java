package com.ufoto.behavior.manager;

import com.google.common.collect.Lists;
import com.ufoto.behavior.disruptor.consumer.UserActivityConsumer;
import com.ufoto.behavior.disruptor.consumer.UserGeoConsumer;
import com.ufoto.behavior.disruptor.event.UserActivityEvent;
import com.ufoto.behavior.disruptor.event.UserGeoEvent;
import com.ufoto.common.utils.DateUtil;
import com.ufoto.common.utils.GeoUtil;
import com.ufoto.lmax2.disruptor.LMaxDisruptor;
import com.ufoto.lmax2.event.EventMap;
import com.ufoto.lmax2.event.UnityEvent;
import lombok.RequiredArgsConstructor;
import org.springframework.stereotype.Component;

import java.util.List;

/**
 * <p>
 * Description:
 *
 * </p>
 *
 * @author Chan
 * @date 2020/2/10 13:16
 */
@RequiredArgsConstructor
@Component
public class UserRequestInterceptorManager {
    private final LMaxDisruptor<UnityEvent> unityEventLMaxDisruptor;
    private final UserActivityConsumer userActivityConsumer;
    private final UserGeoConsumer userGeoConsumer;

    public void requestManager(Long uid, String latitude, String longitude) {
        List<EventMap> eventMaps = Lists.newArrayList();
        eventMaps.add(EventMap.builder()
                .event(UserActivityEvent.builder()
                        .uid(uid)
                        .timestamp(DateUtil.getCurrentSecondIntValue())
                        .build())
                .consumer(userActivityConsumer)
                .build());
        if (GeoUtil.checkLongLat(longitude, latitude)) {
            eventMaps.add(EventMap.builder()
                    .event(UserGeoEvent.builder()
                            .uid(uid)
                            .latitude(latitude)
                            .longitude(longitude)
                            .build())
                    .consumer(userGeoConsumer)
                    .build());
        }
        unityEventLMaxDisruptor.send(UnityEvent.builder().eventMaps(eventMaps).build());
    }

}
