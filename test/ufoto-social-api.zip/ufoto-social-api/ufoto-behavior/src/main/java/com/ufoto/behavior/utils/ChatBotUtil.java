package com.ufoto.behavior.utils;

import com.ufoto.behavior.manager.RobotCacheManager;
import com.ufoto.feign.usercenter.dto.UserBaseInfoDto;
import lombok.extern.slf4j.Slf4j;

import java.util.Map;

/**
 * Created by echo on 3/12/19.
 * <p>
 * ChatBotEventManager 是所有的 chatbot 事件的入口，所有 chatbot 相关的行为，
 * 都通过向 ChatBotEventManager 发送消息来进行触发。
 * <p>
 * - 机器人定律
 * --- 机器人定律一:机器人永不花钱！
 * ----- 不记录GoodsTransactionRecode
 * ----- 以及COIN校验
 * ----- 不检查剩余SuperLike、like次数
 * --- 机器人定律二:机器人行事低调！
 * ----- 不会出现在排行榜
 * --- 机器人定律三:机器人全年无休！
 * ----- 需要展示在线状态时，永远在线
 * ----- 在需要的时候，和用户聊天
 */
@Slf4j
public class ChatBotUtil {

    public static boolean ifChatBotType(Integer userType) {
        return userType != null && userType >= 100;
    }

    public static boolean chatBotType(RobotCacheManager robotCacheManager, Long uid) {
        try {
            final Map<Long, UserBaseInfoDto> robotMap = robotCacheManager.getRobotMap();
            final UserBaseInfoDto dto = robotMap.get(uid);
            return dto != null && ifChatBotType(dto.getType());
        } catch (Exception e) {
            log.error(e.getMessage(), e);
        }
        return false;
    }
}
