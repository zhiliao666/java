package com.ufoto.behavior.bean;

import com.ufoto.behavior.constants.ELikeType;
import lombok.Data;

import java.io.Serializable;

/**
 * <p>
 * Author     : Chan
 * CreateDate : 2018/9/15 10:35
 * Description:
 * </p>
 */
@Data
public class SnsLikeRequest implements Serializable {
    private Long uid;
    private String sign;
    private String fUid;
    private Long targetUid;
    private ELikeType type;
    private Integer useCoin;
    private String lang;
    private int source;//like/rewind的来源 1 滑动 2 wholikeme
    //包名
    private String cp;
    private Integer userType;//1 正常用户 2 问题卡片 3 収礼卡片
}
