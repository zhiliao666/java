package com.ufoto.behavior.disruptor.consumer;

import com.ufoto.behavior.disruptor.constants.ConsumerId;
import com.ufoto.behavior.disruptor.event.UserActivityEvent;
import com.ufoto.behavior.manager.UserActivityTimeManager;
import com.ufoto.lmax2.consumer.Consumer;
import io.micrometer.core.instrument.simple.SimpleMeterRegistry;
import org.springframework.stereotype.Component;

/**
 * <p>
 * Author     : Chan
 * CreateDate : 2019/11/16 17:55
 * Description:
 * </p>
 */
@Component
public class UserActivityConsumer extends Consumer<UserActivityEvent> {
    private final UserActivityTimeManager userActivityTimeManager;

    public UserActivityConsumer(UserActivityTimeManager userActivityTimeManager,
                                SimpleMeterRegistry simpleMeterRegistry) {
        super(ConsumerId.CONSUMER_USER_ACTIVITY, simpleMeterRegistry);
        this.userActivityTimeManager = userActivityTimeManager;
    }

    @Override
    public void consume(UserActivityEvent event) {
        if (event != null && event.getUid() != null) {
            userActivityTimeManager.updateUserActivityTimestamp(event.getUid(), event.getTimestamp());
        }
    }
}
