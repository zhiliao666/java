package com.ufoto.behavior.manager.slide;

import com.ufoto.behavior.bean.SnsLikeRequest;
import com.ufoto.behavior.bean.SnsTransitResult;
import com.ufoto.behavior.disruptor.event.SnsSlideEvent;
import com.ufoto.behavior.manager.EsManager;
import com.ufoto.behavior.service.UfotoUserLikeService;
import com.ufoto.lmax2.disruptor.LMaxDisruptor;
import lombok.extern.slf4j.Slf4j;
import org.springframework.stereotype.Component;

/**
 * <p>
 * Description:
 *
 * </p>
 *
 * @author Chan
 * @date 2020/2/20 13:48
 */
@Slf4j
@Component
public class DislikeSlideOperation extends AbstractSlideOperation {
    public DislikeSlideOperation(UfotoUserLikeService ufotoUserLikeService,
                                 LMaxDisruptor<SnsSlideEvent> snsSlideEventLMaxDisruptor,
                                 EsManager esManager) {
        super(ufotoUserLikeService, snsSlideEventLMaxDisruptor, esManager);
    }

    @Override
    public void slide(SnsLikeRequest likeRequest) {
        // 1. 删除两人所有的like/superlike/dislike记录
        // 2. 发送MQ通知各端处理
        log.debug("likeRequest:{}", likeRequest);
        //暂时不删除
        //this.deleteBothRecord(likeRequest);
        this.sendMQ(likeRequest, new SnsTransitResult());
    }
}
