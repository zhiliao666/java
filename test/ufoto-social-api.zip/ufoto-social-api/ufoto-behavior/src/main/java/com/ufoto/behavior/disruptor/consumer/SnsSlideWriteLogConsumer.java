package com.ufoto.behavior.disruptor.consumer;

import ch.qos.logback.classic.spi.ILoggingEvent;
import com.ufoto.behavior.bean.SnsLikeRequest;
import com.ufoto.behavior.bean.SnsTransitResult;
import com.ufoto.behavior.disruptor.constants.ConsumerId;
import com.ufoto.behavior.disruptor.event.SnsSlideEvent;
import com.ufoto.common.utils.DateUtil;
import com.ufoto.common.utils.JsonUtil;
import com.ufoto.lmax2.consumer.Consumer;
import com.ufoto.logging.kafka.KafkaAppenderConfig;
import com.ufoto.logging.layout.AppMdcEncoderLayout;
import com.ufoto.logging.layout.KafkaLayout;
import com.ufoto.logging.proxy.UfotoLogFactory;
import io.micrometer.core.instrument.simple.SimpleMeterRegistry;
import lombok.extern.slf4j.Slf4j;
import org.slf4j.Logger;
import org.springframework.stereotype.Component;

import java.util.HashMap;
import java.util.Map;

/**
 * <p>
 * Description:
 *
 * </p>
 *
 * @author Chan
 * @date 2020/2/14 15:47
 */
@Slf4j
@Component
public class SnsSlideWriteLogConsumer extends Consumer<SnsSlideEvent> {

    private final static Logger USER_ACT_LOGGER = UfotoLogFactory.getLogger("sns.user.act")
            .enableCustomStatus()
            .withFileName("sns/sns_user_act")
            .withLayout(new AppMdcEncoderLayout(null))
            .enableKafkaAppender()
            .withKafkaAppenderConfig(KafkaAppenderConfig.<ILoggingEvent>builder()
                    .topic("sns_user_act")
                    .kafkaLayout(new KafkaLayout())
                    .build())
            .build();

    public SnsSlideWriteLogConsumer(SimpleMeterRegistry simpleMeterRegistry) {
        super(ConsumerId.CONSUMER_SNS_SLIDE + ":Log", simpleMeterRegistry);
    }

    @Override
    public void consume(SnsSlideEvent event) {
        final SnsLikeRequest request = event.getRequest();
        final SnsTransitResult transitResult = event.getTransitResult();
        if (request == null || transitResult == null) {
            return;
        }
        writeLog(request);
    }

    private void writeLog(SnsLikeRequest request) {
        try {
            Map<String, Object> objectMap = new HashMap<>();
            objectMap.put("actName", request.getType().getLogName());
            objectMap.put("uid", request.getUid());
            //此处兼容 card
            objectMap.put("targetUid", request.getFUid());
            objectMap.put("timestamp", DateUtil.getCurrentSecondIntValue());
            USER_ACT_LOGGER.info(JsonUtil.toJson(objectMap));
        } catch (Exception e) {
            log.error("slide: " + JsonUtil.toJson(request), e);
        }
    }
}
