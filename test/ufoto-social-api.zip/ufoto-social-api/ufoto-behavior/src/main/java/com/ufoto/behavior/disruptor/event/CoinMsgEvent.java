package com.ufoto.behavior.disruptor.event;

import com.fasterxml.jackson.annotation.JsonIgnore;
import com.ufoto.lmax2.event.Event;
import lombok.Builder;
import lombok.Data;
import lombok.EqualsAndHashCode;

import java.math.BigDecimal;

/**
 * <p>
 * Description:
 *
 * </p>
 *
 * @author Chan
 * @date 2020/2/27 13:13
 */
@EqualsAndHashCode(callSuper = true)
@Builder
@Data
public class CoinMsgEvent extends Event {
    @JsonIgnore
    private Long uid;
    private BigDecimal coin;
    private BigDecimal amount;//余额
}
