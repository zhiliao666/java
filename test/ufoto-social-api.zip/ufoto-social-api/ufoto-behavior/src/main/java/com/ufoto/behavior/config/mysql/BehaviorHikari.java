package com.ufoto.behavior.config.mysql;

import com.zaxxer.hikari.HikariConfig;
import org.springframework.boot.context.properties.ConfigurationProperties;
import org.springframework.context.annotation.Configuration;

/**
 * <p>
 * Author     : Chan
 * CreateDate : 2018/9/21 18:29
 * Description:
 * </p>
 */
@ConfigurationProperties(prefix = "spring.datasource.hikari")
@Configuration
public class BehaviorHikari extends HikariConfig {

}
