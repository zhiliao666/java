package com.ufoto.behavior.bean.es;

import com.fasterxml.jackson.annotation.JsonProperty;
import lombok.Builder;
import lombok.Data;
import lombok.experimental.Tolerate;

import java.util.List;

/**
 * @author luozq
 * @date 2020/2/28 09:46
 */
@Data
@Builder
public class BaseAttrDto {

    private int age;

    private String country;

    @JsonProperty("from_type")
    private int fromType;

    private int gender;

    private List<Double> gps;

    @JsonProperty("has_face_img")
    private int hasFaceImg;

    @JsonProperty("head_imgs")
    private int headImgs;

    private String lang;

    private String network;

    private int deleted;

    @Tolerate
    public BaseAttrDto() {

    }
}

