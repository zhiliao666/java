package com.ufoto.behavior.disruptor.consumer;

import com.ufoto.behavior.disruptor.constants.ConsumerId;
import com.ufoto.behavior.disruptor.event.CoinMsgEvent;
import com.ufoto.common.utils.JsonUtil;
import com.ufoto.feign.chat.constants.EMsgType;
import com.ufoto.friendchat.service.UfotoChatService;
import com.ufoto.lmax2.consumer.Consumer;
import io.micrometer.core.instrument.simple.SimpleMeterRegistry;
import lombok.extern.slf4j.Slf4j;
import org.springframework.stereotype.Component;

/**
 * <p>
 * Description:
 *
 * </p>
 *
 * @author Chan
 * @date 2020/3/9 13:27
 */
@Slf4j
@Component
public class SuperLikeConsumeCoinConsumer extends Consumer<CoinMsgEvent> {

    private final UfotoChatService ufotoChatService;

    public SuperLikeConsumeCoinConsumer(SimpleMeterRegistry simpleMeterRegistry,
                                        UfotoChatService ufotoChatService) {
        super(ConsumerId.CONSUMER_SUPER_LIKE_CONSUME_COIN, simpleMeterRegistry);
        this.ufotoChatService = ufotoChatService;
    }

    @Override
    public void consume(CoinMsgEvent event) {
        if (event == null
                || event.getUid() == null
                || event.getCoin() == null
                || event.getAmount() == null) {
            log.warn("ConsumerCoinWarn: all params empty");
            return;
        }
        ufotoChatService.sendMsg(0L, event.getUid(), JsonUtil.toJson(event), EMsgType.COIN_TASK_EXPENSE.getMsgType());
    }

    @Override
    public boolean clear() {
        return true;
    }
}
