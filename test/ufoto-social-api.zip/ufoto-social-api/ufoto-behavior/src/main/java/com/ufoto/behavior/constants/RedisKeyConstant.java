package com.ufoto.behavior.constants;

/**
 * redis相关key
 *
 * @author zhangqh
 * @date 2017年11月23日
 */
public class RedisKeyConstant {
    public static final String REDIS_ROBOT_USER = "robot_user_set";
    public static final String REDIS_ROBOT_MAN_SET = "robot_man_set";
    public static final String REDIS_ROBOT_WOMAN_SET = "robot_woman_set";
    public static final String USER_ACTIVITY_RECORD = "u_act:";
    public static final String USER_GEO_RECORD = "u_geo:";
    public static final String REDIS_SUBSCRIPTION_USER_SET = "subscription_user_set";
    /**
     * 用户匹配存储SET，
     * 格式：
     * 1000：1001
     * 1002：1003
     * ...
     * 1002：1017
     * 数值较小的在左边
     */
    public final static String REDIS_USER_MATCHING_SET_KEY = "user_matching";
}
