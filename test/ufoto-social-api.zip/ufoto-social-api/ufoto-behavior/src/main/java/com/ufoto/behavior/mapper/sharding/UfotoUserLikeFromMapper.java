package com.ufoto.behavior.mapper.sharding;

import com.ufoto.base.mapper.SysMapper;
import com.ufoto.behavior.entity.UfotoUserLikeFrom;
import org.apache.ibatis.annotations.Param;

public interface UfotoUserLikeFromMapper extends SysMapper<UfotoUserLikeFrom> {

    int deleteLessFixedTime(@Param("fixedTimeSecond") int fixedTimeSecond);

    int insertOnDuplicateKey(UfotoUserLikeFrom from);

    int deleteWithUids(@Param("uid") Long uid, @Param("targetUid") Long targetUid);
}
