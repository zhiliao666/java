package com.ufoto.behavior.mapper.read;

import com.ufoto.base.mapper.SysMapper;
import com.ufoto.behavior.entity.UfotoChatBotProgress;

/**
 * <p>
 * Description:
 *
 * </p>
 *
 * @author Chan
 * @date 2020/2/12 15:36
 */
public interface UfotoChatBotProgressReadMapper extends SysMapper<UfotoChatBotProgress> {

}
