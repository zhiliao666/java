package com.ufoto.behavior.constants;

import com.ufoto.behavior.manager.slide.DislikeSlideOperation;
import com.ufoto.behavior.manager.slide.LikeSlideOperation;
import com.ufoto.behavior.manager.slide.SlideOperation;
import com.ufoto.behavior.manager.slide.SuperLikeSlideOperation;
import com.ufoto.rabbit.behavior.constants.ActionType;

/**
 * <p>
 * like 的类型
 * </p>
 *
 * @author created by chenzhou at 2018-08-01 13:25
 */
public enum ELikeType {
    LIKE(1, "喜欢", LikeSlideOperation.class, "Like", ActionType.ACTION_LIKE),
    DISLIKE(2, "不喜欢", DislikeSlideOperation.class, "SuperLike", ActionType.ACTION_DISLIKE),
    SUPER_LIKE(3, "超级喜欢", SuperLikeSlideOperation.class, "Dislike", ActionType.ACTION_SUPER_LIKE);

    private Integer type;
    private String description;
    private Class<? extends SlideOperation> operationClass;
    private String logName;
    private ActionType actionType;

    ELikeType(Integer type, String description, Class<? extends SlideOperation> operationClass,
              String logName, ActionType actionType) {
        this.type = type;
        this.description = description;
        this.operationClass = operationClass;
        this.logName = logName;
        this.actionType = actionType;
    }

    public Integer getType() {
        return type;
    }

    public String getDescription() {
        return description;
    }

    public Class<? extends SlideOperation> getOperationClass() {
        return operationClass;
    }

    public String getLogName() {
        return logName;
    }

    public ActionType getActionType() {
        return actionType;
    }
}

