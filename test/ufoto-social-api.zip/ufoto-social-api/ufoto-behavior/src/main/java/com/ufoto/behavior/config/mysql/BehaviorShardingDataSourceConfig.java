package com.ufoto.behavior.config.mysql;

import io.shardingsphere.api.config.rule.MasterSlaveRuleConfiguration;
import io.shardingsphere.api.config.rule.ShardingRuleConfiguration;
import io.shardingsphere.api.config.rule.TableRuleConfiguration;
import io.shardingsphere.api.config.strategy.InlineShardingStrategyConfiguration;
import io.shardingsphere.shardingjdbc.api.ShardingDataSourceFactory;
import lombok.extern.slf4j.Slf4j;
import org.apache.ibatis.session.SqlSessionFactory;
import org.mybatis.spring.SqlSessionFactoryBean;
import org.mybatis.spring.SqlSessionTemplate;
import org.springframework.beans.factory.annotation.Qualifier;
import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;
import org.springframework.core.io.support.PathMatchingResourcePatternResolver;
import org.springframework.jdbc.datasource.DataSourceTransactionManager;
import tk.mybatis.spring.annotation.MapperScan;

import javax.sql.DataSource;
import java.sql.SQLException;
import java.util.Collections;
import java.util.HashMap;
import java.util.Map;
import java.util.Properties;
import java.util.concurrent.ConcurrentHashMap;

/**
 * @author luozq
 * @date 2019/1/8/008
 */
@Slf4j
@Configuration
@MapperScan(basePackages = "com.ufoto.behavior.mapper.sharding", sqlSessionTemplateRef = "behaviorShardingSqlSessionTemplate")
public class BehaviorShardingDataSourceConfig extends DataSourceConfig {

    @Bean
    public DataSource behaviorShardingDataSource(@Qualifier("behaviorWriteDataSource") DataSource writeDataSource,
                                                 @Qualifier("behaviorReadDataSource") DataSource readDataSource) throws SQLException {
        // 定义数据源
        Map<String, DataSource> dataSourceMap = new HashMap<>(10);
        dataSourceMap.put("ds_0_master", writeDataSource);
        dataSourceMap.put("ds_0_slave", readDataSource);

        TableRuleConfiguration userLikeFromTableRuleConfig = new TableRuleConfiguration();
        userLikeFromTableRuleConfig.setLogicTable("ufoto_user_like_f");
        userLikeFromTableRuleConfig.setActualDataNodes("ds_0.ufoto_user_like_f${0..99}");
        userLikeFromTableRuleConfig.setTableShardingStrategyConfig(
                new InlineShardingStrategyConfiguration("f_u_id", "ufoto_user_like_f${f_u_id % 100}"));

        TableRuleConfiguration userLikeToTableRuleConfig = new TableRuleConfiguration();
        userLikeToTableRuleConfig.setLogicTable("ufoto_user_like_t");
        userLikeToTableRuleConfig.setActualDataNodes("ds_0.ufoto_user_like_t${0..99}");
        userLikeToTableRuleConfig.setTableShardingStrategyConfig(
                new InlineShardingStrategyConfiguration("t_u_id", "ufoto_user_like_t${t_u_id % 100}"));


        MasterSlaveRuleConfiguration masterSlaveRuleConfiguration = new MasterSlaveRuleConfiguration();
        masterSlaveRuleConfiguration.setName("ds_0");
        masterSlaveRuleConfiguration.setMasterDataSourceName("ds_0_master");
        masterSlaveRuleConfiguration.setSlaveDataSourceNames(Collections.singleton("ds_0_slave"));

        // 配置分片规则
        ShardingRuleConfiguration shardingRuleConfig = new ShardingRuleConfiguration();
        shardingRuleConfig.getTableRuleConfigs().add(userLikeFromTableRuleConfig);
        shardingRuleConfig.getTableRuleConfigs().add(userLikeToTableRuleConfig);
        shardingRuleConfig.getMasterSlaveRuleConfigs().add(masterSlaveRuleConfiguration);

        Map<String, Object> map = new ConcurrentHashMap<>(10);
        Properties props = new Properties();
        if (log.isDebugEnabled()) {
            // 分片sql 打印
            props.setProperty("sql.show", "true");
        }
        // 设置每次sql执行可以使用的最大连接数 --- 并发执行sql
//         props.setProperty("max.connections.size.per.query", "6");
        // 配置执行sql线程池的大小 --- 工作线程
//         props.setProperty("executor.size", "6");
        return ShardingDataSourceFactory.createDataSource(dataSourceMap, shardingRuleConfig, map, props);
    }


    @Bean
    public SqlSessionFactory behaviorShardingSqlSessionFactory(@Qualifier("behaviorShardingDataSource") DataSource dataSource) throws Exception {
        SqlSessionFactoryBean bean = new SqlSessionFactoryBean();
        bean.setMapperLocations(new PathMatchingResourcePatternResolver()
                .getResources("classpath*:mapper/behavior/sharding/**/*.xml"));
        return getSqlSessionFactory(dataSource, bean);
    }


    @Bean
    public SqlSessionTemplate behaviorShardingSqlSessionTemplate(@Qualifier("behaviorShardingSqlSessionFactory") SqlSessionFactory sqlSessionFactory) throws Exception {
        return new SqlSessionTemplate(sqlSessionFactory);
    }

    @Bean
    public DataSourceTransactionManager behaviorShardingTransactionManager(@Qualifier("behaviorShardingDataSource") DataSource dataSource) {
        return new DataSourceTransactionManager(dataSource);
    }


}
