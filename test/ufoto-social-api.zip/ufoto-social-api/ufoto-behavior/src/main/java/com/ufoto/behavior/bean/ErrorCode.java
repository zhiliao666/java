package com.ufoto.behavior.bean;

import java.io.Serializable;

public class ErrorCode implements Serializable {

    public static int ERROR_CODE_OUT_OF_LIKE = 1001;//like次数不够
    public static int ERROR_CODE_ALREADY_LIKED = 1002;//已经like
    public static int ERROR_CODE_USER_INFO_ERROR = 1003;//用户信息非法
    public static int ERROR_CODE_ILLEGAL_HEAD = 1004;//头像非法
    public static int ERROR_CODE_USER_NOT_EXIST = 1005;//用户不存在
    public static int ERROR_CODE_OUT_OF_SUPER_LIKE = 1001;//superlike次数不够
    private static int ERROR_CODE_OUT_OF_CANCEL = 1001;//rewind次数不够
    private static int ERROR_CODE_PAYLOAD_ERROR = 1001;//购买superlike回调参数错误
    private static int ERROR_CODE_DUPLICATE_REQUEST_ERROR = 1002;//购买superlike回调重复
    public static int ERROR_CODE_SUBSCRIPTION_DUPLICATE = 1006;//订阅回调重
    public static int ERROR_CODE_ALREADY_FRIENDS = 1006;//已经是好友 包括临时配对


    //不是好友
    public static final int errorCode401 = 401;
    //内用户删除(一方执行了dislike)
    public static final int errorCode402 = 402;
    //过期24小时自动删除
    public static final int errorCode403 = 403;
    //活动关闭
    public static final int errorCode4001 = 4001;
    //kiss超过当天最大数
    public static final int errorCode4002 = 4002;
    //已经增加过下载kiss
    public static final int errorCode4003 = 4003;
    //积分不够
    public static final int errorCode4004 = 4004;
    //用户积分获取超过当天最大数
    public static final int errorCode4005 = 4005;

    //色情图片
    public static final int errorCode9001 = 9001;
    //迁移失败
    public static final int errorCode5000 = 5000;

    public static final int OUT_OF_BALANCE = 8005;
    public static final int EXCHANGE_ERROR = 8006;
    public static final int GIFT_NOT_EXIST = 8007;

    public static final int SECRET_LETTER_COUNT_OVER_LIMIT = 8008;

    public static final int SECRET_LETTER_NOT_ENOUGH = 8009;

    public static final int USER_NO_GENDER = 8010;

    public static final int ILLEGALITY_LETTER = 8011;

    public static final int GIFT_SEND_ONLY_ONCE = 8020;
    public static final int GIFT_SEND_TIME_NOT_REMAIN = 8021;

    public static final int ONLINE_USERS_OVER_LIMIT = 9001;

    public static final int ACTIVITY_2019_INVALID_ID = 10001;//活动不存在
    public static final int ACTIVITY_2019_TASK_OVER_LIMIT = 10002;//超过当日激励赠送上限
    public static final int ACTIVITY_2019_NOT_PROCESSING = 10003;//活动不在进行中

}
