package com.ufoto.behavior.bean.es;

import com.fasterxml.jackson.annotation.JsonProperty;
import lombok.Builder;
import lombok.Data;
import lombok.experimental.Tolerate;

/**
 * @author luozq
 * @date 2020/2/28 09:46
 */
@Data
@Builder
public class BlackAttrDto {

    @JsonProperty("risk_level")
    private int riskLevel;

    private int banned;

    @Tolerate
    public BlackAttrDto() {

    }

}
