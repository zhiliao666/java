package com.ufoto.behavior.entity;

import lombok.Data;

import javax.persistence.Column;
import javax.persistence.Id;
import java.io.Serializable;

/**
 * <p>
 * Description:
 *
 * </p>
 *
 * @author Chan
 * @date 2020/2/26 17:40
 */
@Data
public class UfotoUserLike implements Serializable {
    @Id
    @Column(name = "id")
    private Long id;
    @Column(name = "t_u_id")
    private Long tUId;
    @Column(name = "f_u_id")
    private Long fUId;
    @Column(name = "type")
    private Integer type;
    @Column(name = "create_time")
    private Integer createTime;
}
