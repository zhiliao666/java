package com.ufoto.behavior.disruptor.constants;

/**
 * <p>
 * Author     : Chan
 * CreateDate : 2019/11/20 18:04
 * Description:
 * </p>
 */
public interface ConsumerId {
    //用户活跃时间
    String CONSUMER_USER_ACTIVITY = "C:USER_ACTIVITY";
    //用户地理位置
    String CONSUMER_USER_GEO = "C:USER_GEO";
    //统一的消费者
    String CONSUMER_UNITY = "C:UNITY";
    //用户滑动
    String CONSUMER_SNS_SLIDE = "C:SNS_SLIDE";
    //一键处理礼物
    String CONSUMER_GIFT_LIKE_DRAW = "C:GIFT_LIKE_DRAW";
    //superlike消耗金币
    String CONSUMER_SUPER_LIKE_CONSUME_COIN = "C:SUPER_LIKE_CONSUME_COIN";
}
