package com.ufoto.behavior.bean;

import lombok.Data;

import java.io.Serializable;

/**
 * <p>
 * Description:
 * 中间结果
 * </p>
 *
 * @author Chan
 * @date 2020/2/14 15:21
 */
@Data
public class SnsTransitResult implements Serializable {
    //--中间状态
    private boolean chatBot;//聊天机器人
    private boolean match;//match 状态
}
