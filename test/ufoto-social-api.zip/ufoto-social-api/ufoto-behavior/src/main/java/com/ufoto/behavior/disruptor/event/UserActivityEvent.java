package com.ufoto.behavior.disruptor.event;

import com.ufoto.lmax2.event.Event;
import lombok.Builder;
import lombok.Data;
import lombok.EqualsAndHashCode;

import java.io.Serializable;

/**
 * <p>
 * Author     : Chan
 * CreateDate : 2019/11/15 17:15
 * Description: 具体的时间-用户活跃时间
 * </p>
 */
@EqualsAndHashCode(callSuper = true)
@Data
@Builder
public class UserActivityEvent extends Event implements Serializable {
    private Long uid;
    private Integer timestamp;
}
