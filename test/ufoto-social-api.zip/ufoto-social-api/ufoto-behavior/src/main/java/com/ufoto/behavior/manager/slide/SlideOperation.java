package com.ufoto.behavior.manager.slide;

import com.ufoto.behavior.bean.SnsLikeRequest;

/**
 * <p>
 * Description:
 * 滑动操作
 * </p>
 *
 * @author Chan
 * @date 2020/2/11 13:34
 */
public interface SlideOperation {
    void slide(SnsLikeRequest likeRequest);
}
