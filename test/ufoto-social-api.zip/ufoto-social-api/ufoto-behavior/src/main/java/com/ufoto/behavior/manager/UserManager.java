package com.ufoto.behavior.manager;

import com.google.common.collect.Lists;
import com.google.common.collect.Maps;
import com.ufoto.behavior.constants.EGender;
import com.ufoto.common.utils.ApiResult;
import com.ufoto.feign.usercenter.UserCenterBusiness;
import com.ufoto.feign.usercenter.dto.FeedImageDelVo;
import com.ufoto.feign.usercenter.dto.FeedImageVisibleVo;
import com.ufoto.feign.usercenter.dto.UserBaseInfoDto;
import com.ufoto.feign.usercenter.dto.UserConditionDto;
import com.ufoto.feign.usercenter.dto.UserImageCountDto;
import com.ufoto.feign.usercenter.dto.UserImageCountVo;
import com.ufoto.feign.usercenter.dto.UserInfoDto;
import com.ufoto.logging.util.JSONUtil;
import lombok.extern.slf4j.Slf4j;
import org.springframework.core.env.Environment;
import org.springframework.stereotype.Component;
import org.springframework.util.CollectionUtils;

import java.util.Collection;
import java.util.List;
import java.util.Map;
import java.util.Objects;
import java.util.stream.Collectors;

/**
 * <p>
 * Author     : Chan
 * CreateDate : 2019-04-12 10:33
 * Description:
 * </p>
 */
@Slf4j
@Component
public class UserManager {

    private final static String USER_CENTER_WARN_TAG = "UserCenterWarn ";
    private final static String USER_CENTER_DEBUG_TAG = "UserCenterDebug ";
    private final UserCenterBusiness userCenterBusiness;
    private final Environment env;

    public UserManager(UserCenterBusiness userCenterBusiness, Environment env) {
        this.userCenterBusiness = userCenterBusiness;
        this.env = env;
    }

    public List<UserBaseInfoDto> queryUsers(List<Long> uids) {
        if (CollectionUtils.isEmpty(uids)) return Lists.newArrayList();
        final Integer batchSize = env.getProperty("user.batch.query", Integer.class, 2000);
        if (uids.size() < batchSize) {
            return queryUsersUnderLimit(uids);
        }
        return Lists.partition(uids, batchSize)
                .parallelStream()
                .map(this::queryUsersUnderLimit)
                .filter(lst -> !CollectionUtils.isEmpty(lst))
                .flatMap(Collection::stream)
                .collect(Collectors.toList());
    }

    private List<UserBaseInfoDto> queryUsersUnderLimit(List<Long> uids) {
        final ApiResult<List<UserBaseInfoDto>> userBaseInfoList = userCenterBusiness.getUserBaseInfoList(uids);
        log.debug(USER_CENTER_DEBUG_TAG + "#userInfoBusiness.getUserBaseInfoList({})#ApiResult({})", uids, JSONUtil.toJSON(userBaseInfoList));
        if (!Objects.equals(userBaseInfoList.getC(), ApiResult.successCode)) {
            log.warn(USER_CENTER_WARN_TAG + "#userInfoBusiness.getUserBaseInfoList({})#ApiResult({})", uids, JSONUtil.toJSON(userBaseInfoList));
            return Lists.newArrayList();
        }
        final List<UserBaseInfoDto> baseInfoListD = userBaseInfoList.getD();
        if (CollectionUtils.isEmpty(baseInfoListD)) return Lists.newArrayList();
        return baseInfoListD;
    }

    /**
     * 根据条件查询用户列表
     *
     * @param condition 条件
     * @return 列表
     */
    public List<UserBaseInfoDto> queryUsers(UserConditionDto condition) {
        final Integer batchSize = env.getProperty("user.batch.query", Integer.class, 2000);
        final List<Long> uids = condition.getUids();
        if (CollectionUtils.isEmpty(uids) || uids.size() < batchSize) {
            return queryUsersUnderLimit(condition);
        }
        return Lists.partition(uids, batchSize)
                .parallelStream()
                .map(ids -> {
                    UserConditionDto dto = new UserConditionDto();
                    dto.setUids(ids);
                    dto.setIsDelete(condition.getIsDelete());
                    dto.setLegitimateEmail(condition.getLegitimateEmail());
                    dto.setType(condition.getType());
                    return dto;
                })
                .map(this::queryUsersUnderLimit)
                .filter(lst -> !CollectionUtils.isEmpty(lst))
                .flatMap(Collection::stream)
                .collect(Collectors.toList());
    }

    /**
     * 批量查询小于一个批次
     *
     * @param condition 条件
     * @return 列表
     */
    private List<UserBaseInfoDto> queryUsersUnderLimit(UserConditionDto condition) {
        final ApiResult<List<UserBaseInfoDto>> listApiResult = userCenterBusiness.conditionLists(condition);
        log.debug(USER_CENTER_DEBUG_TAG + "#userInfoBusiness.conditionLists({})#ApiResult({})", condition, JSONUtil.toJSON(listApiResult));
        if (!Objects.equals(listApiResult.getC(), ApiResult.successCode)) {
            log.warn(USER_CENTER_WARN_TAG + "#userInfoBusiness.conditionLists({})#ApiResult({})", condition, JSONUtil.toJSON(listApiResult));
            return Lists.newArrayList();
        }
        final List<UserBaseInfoDto> listApiResultD = listApiResult.getD();
        if (CollectionUtils.isEmpty(listApiResultD)) return Lists.newArrayList();
        return listApiResultD;
    }

    /**
     * 查询单个用户
     *
     * @param uid 用户id
     * @return 用户
     */
    public UserBaseInfoDto queryUserOne(Long uid) {
        final ApiResult<UserBaseInfoDto> userBaseInfo = userCenterBusiness.getUserBaseInfo(uid);
        log.debug(USER_CENTER_DEBUG_TAG + "#userInfoBusiness.getUserBaseInfo({})#ApiResult({})", uid, JSONUtil.toJSON(userBaseInfo));
        if (!Objects.equals(userBaseInfo.getC(), ApiResult.successCode)) {
            log.warn(USER_CENTER_WARN_TAG + "#userInfoBusiness.getUserBaseInfo({})#ApiResult({})", uid, JSONUtil.toJSON(userBaseInfo));
            return null;
        }
        return userBaseInfo.getD();
    }

    /**
     * 查询单个用户
     *
     * @param uuid 用户id
     * @return 用户
     */
    public UserBaseInfoDto queryUserOneByUUid(String uuid) {
        final ApiResult<UserBaseInfoDto> userBaseInfoByUUid = userCenterBusiness.getUserBaseInfoByUUid(uuid);
        log.debug(USER_CENTER_DEBUG_TAG + "#userInfoBusiness.getUserBaseInfoByUUid({})#ApiResult({})", uuid, JSONUtil.toJSON(userBaseInfoByUUid));
        if (!Objects.equals(userBaseInfoByUUid.getC(), ApiResult.successCode)) {
            log.warn(USER_CENTER_WARN_TAG + "#userInfoBusiness.getUserBaseInfoByUUid({})#ApiResult({})", uuid, JSONUtil.toJSON(userBaseInfoByUUid));
            return null;
        }
        return userBaseInfoByUUid.getD();
    }

    /**
     * 查询用户性别
     *
     * @param uid 用户id
     * @return 性别
     */
    public Integer queryGender(Long uid) {
        final ApiResult<Integer> gender = userCenterBusiness.getGender(uid);
        log.debug(USER_CENTER_DEBUG_TAG + "#userInfoBusiness.getGender({})#ApiResult({})", uid, JSONUtil.toJSON(gender));
        if (!Objects.equals(gender.getC(), ApiResult.successCode)) {
            log.warn(USER_CENTER_WARN_TAG + "#userInfoBusiness.getGender({})#ApiResult({})", uid, JSONUtil.toJSON(gender));
            return EGender.OTHER.getType();
        }
        final Integer genderD = gender.getD();
        if (genderD == null) return 0;
        return genderD;
    }

    /**
     * 删除用户
     *
     * @param uid 用户id
     * @return 删除状态
     */
    public boolean deleteUser(Long uid) {
        final ApiResult<Boolean> deleteUser = userCenterBusiness.deleteUser(uid);
        log.debug(USER_CENTER_DEBUG_TAG + "#userInfoBusiness.deleteUser({})#ApiResult({})", uid, JSONUtil.toJSON(deleteUser));
        if (!Objects.equals(deleteUser.getC(), ApiResult.successCode)) {
            log.warn(USER_CENTER_WARN_TAG + "#userInfoBusiness.deleteUser({})#ApiResult({})", uid, JSONUtil.toJSON(deleteUser));
            return false;
        }
        return deleteUser.getD();
    }

    public List<UserBaseInfoDto> robots() {
        final ApiResult<List<UserBaseInfoDto>> listApiResult = userCenterBusiness.robots();
        log.debug(USER_CENTER_DEBUG_TAG + "#userInfoBusiness.robots()#ApiResult({})", JSONUtil.toJSON(listApiResult));
        if (!Objects.equals(listApiResult.getC(), ApiResult.successCode)) {
            log.warn(USER_CENTER_WARN_TAG + "#userInfoBusiness.robots()#ApiResult({})", JSONUtil.toJSON(listApiResult));
            return Lists.newArrayList();
        }
        final List<UserBaseInfoDto> listApiResultD = listApiResult.getD();
        if (CollectionUtils.isEmpty(listApiResultD)) return Lists.newArrayList();
        return listApiResultD;
    }

    public ApiResult<Boolean> updateFeedVisible(Long uid, List<FeedImageVisibleVo> visibleVoList) {
        return userCenterBusiness.updateFeedVisible(uid, visibleVoList);
    }

    public ApiResult<Boolean> deleteFeedImage(Long uid, List<FeedImageDelVo> delVoList) {
        return userCenterBusiness.deleteFeedImage(uid, delVoList);
    }

    public ApiResult<Boolean> slideCheck(Long uid) {
        return userCenterBusiness.slideCheck(uid);
    }

    public ApiResult<List<String>> localHeadImg() {
        return userCenterBusiness.localHeadImg();
    }

    public boolean userExist(Long uid) {
        final ApiResult<Boolean> apiResult = userCenterBusiness.userExist(uid);
        return Objects.equals(ApiResult.successCode, apiResult.getC()) && apiResult.getD();
    }

    public Map<Long, Integer> checkFirstImgStatus(List<Long> uids) {
        final ApiResult<Map<Long, Integer>> apiResult = userCenterBusiness.checkFirstImageState(uids);
        if (!Objects.equals(apiResult.getC(), ApiResult.successCode)) {
            return Maps.newHashMap();
        }
        return apiResult.getD();
    }

    public boolean nonGender(Long uid) {
        final UserBaseInfoDto user = queryUserOne(uid);
        return Objects.isNull(user) || user.getGender() == 0;
    }

    public List<UserImageCountDto> getImageCount(UserImageCountVo countVo) {
        final ApiResult<List<UserImageCountDto>> apiResult = userCenterBusiness.getImageCount(countVo);
        if (!Objects.equals(apiResult.getC(), ApiResult.successCode)) {
            return Lists.newArrayList();
        }
        return apiResult.getD();
    }

    public UserInfoDto userInfo(Long uid, Integer self) {
        final ApiResult<UserInfoDto> apiResult = userCenterBusiness.getUserInfo(uid, self);
        if (!Objects.equals(apiResult.getC(), ApiResult.successCode)
                || apiResult.getD() == null
                || apiResult.getD().getBaseInfo() == null) {
            log.warn(USER_CENTER_WARN_TAG + "#userInfoBusiness.getUserInfo({},{})#ApiResult({})", uid, self, JSONUtil.toJSON(apiResult));
            return null;
        }
        return apiResult.getD();
    }
}
