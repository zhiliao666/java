package com.ufoto.behavior.constants;

/**
 * <p>
 *
 * </p>
 *
 * @author created by chenzhou at 2018-08-06 15:01
 */
public enum EGender {

    OTHER(0),
    MALE(1),
    FEMALE(2);

    private int type;

    EGender(int type) {
        this.type = type;
    }

    public int getType() {
        return type;
    }

    public String getTypeStr() {
        return type + "";
    }
}
