package com.ufoto.behavior.disruptor.event;

import com.ufoto.behavior.bean.SnsLikeRequest;
import com.ufoto.behavior.bean.SnsTransitResult;
import com.ufoto.lmax2.event.Event;
import lombok.Builder;
import lombok.Data;
import lombok.EqualsAndHashCode;

/**
 * <p>
 * Description:
 *
 * </p>
 *
 * @author Chan
 * @date 2019/12/19 10:57
 */
@EqualsAndHashCode(callSuper = true)
@Data
@Builder
public class SnsSlideEvent extends Event {
    private SnsLikeRequest request;
    private SnsTransitResult transitResult;
}
