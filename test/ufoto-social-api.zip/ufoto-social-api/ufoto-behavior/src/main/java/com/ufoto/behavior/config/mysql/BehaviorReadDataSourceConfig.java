package com.ufoto.behavior.config.mysql;

import com.zaxxer.hikari.HikariDataSource;
import lombok.RequiredArgsConstructor;
import org.apache.ibatis.session.SqlSessionFactory;
import org.mybatis.spring.SqlSessionFactoryBean;
import org.mybatis.spring.SqlSessionTemplate;
import org.springframework.beans.BeanUtils;
import org.springframework.beans.factory.annotation.Qualifier;
import org.springframework.boot.context.properties.ConfigurationProperties;
import org.springframework.boot.jdbc.DataSourceBuilder;
import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;
import org.springframework.core.io.support.PathMatchingResourcePatternResolver;
import org.springframework.jdbc.datasource.DataSourceTransactionManager;
import tk.mybatis.spring.annotation.MapperScan;

import javax.sql.DataSource;


/**
 * 配置读数据源
 *
 * @author luozq
 * @date 2019/3/6/006
 */
@RequiredArgsConstructor
@Configuration
@MapperScan(basePackages = {"com.ufoto.behavior.mapper.read"}, sqlSessionTemplateRef = "behaviorReadSqlSessionTemplate")
public class BehaviorReadDataSourceConfig extends DataSourceConfig {

    private final BehaviorHikari beHaviorHikari;

    @Bean(destroyMethod = "shutdown")
    @ConfigurationProperties(prefix = "spring.datasource.read.behavior")
    public HikariDataSource behaviorReadDataSource() {
        final HikariDataSource dataSource = DataSourceBuilder.create().type(HikariDataSource.class).build();
        // 配置Hikari的相关配置参数
        BeanUtils.copyProperties(beHaviorHikari, dataSource);
        return dataSource;
    }

    @Bean(name = "behaviorReadSqlSessionFactory")
    public SqlSessionFactory sqlSessionFactory(@Qualifier("behaviorReadDataSource") DataSource dataSource) throws Exception {
        SqlSessionFactoryBean bean = new SqlSessionFactoryBean();
        // 设置mybatis配置文件路径
        bean.setMapperLocations(new PathMatchingResourcePatternResolver()
                .getResources("classpath*:mapper/behavior/read/**/*.xml"));
        return getSqlSessionFactory(dataSource, bean);
    }

    @Bean
    public DataSourceTransactionManager behaviorReadTransactionManager(@Qualifier("behaviorReadDataSource") DataSource dataSource) {
        return new DataSourceTransactionManager(dataSource);
    }

    @Bean
    public SqlSessionTemplate behaviorReadSqlSessionTemplate(@Qualifier("behaviorReadSqlSessionFactory") SqlSessionFactory sqlSessionFactory) {
        return new SqlSessionTemplate(sqlSessionFactory);
    }

}
