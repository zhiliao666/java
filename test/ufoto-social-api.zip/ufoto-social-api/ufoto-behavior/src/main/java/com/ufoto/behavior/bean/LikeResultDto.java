package com.ufoto.behavior.bean;

import java.io.Serializable;

/**
 * <p>
 * Author     : Chan
 * CreateDate : 2019-09-20 16:00
 * Description:
 * </p>
 */
public class LikeResultDto implements Serializable {
}
