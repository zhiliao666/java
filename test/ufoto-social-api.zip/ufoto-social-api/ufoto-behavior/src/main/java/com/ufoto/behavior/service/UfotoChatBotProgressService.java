package com.ufoto.behavior.service;

/**
 * <p>
 * Description:
 *
 * </p>
 *
 * @author Chan
 * @date 2020/2/12 15:37
 */
public interface UfotoChatBotProgressService {
    int selectCount(Long uid);
}
