package com.ufoto.robot;

import com.google.common.collect.Maps;
import com.ufoto.common.utils.ApiResult;
import com.ufoto.common.utils.JsonUtil;
import com.ufoto.feign.usercenter.UserCenterBusiness;
import com.ufoto.feign.usercenter.dto.UserBaseInfoDto;
import lombok.RequiredArgsConstructor;
import lombok.extern.slf4j.Slf4j;
import org.springframework.boot.CommandLineRunner;
import org.springframework.stereotype.Component;
import org.springframework.util.CollectionUtils;
import org.springframework.util.StopWatch;

import java.util.ArrayList;
import java.util.List;
import java.util.Map;
import java.util.Objects;
import java.util.Set;

/**
 * <p>
 * Author     : Chan
 * CreateDate : 2019-05-14 10:45
 * Description:
 * </p>
 */
@Slf4j
@RequiredArgsConstructor
@Component
public class RobotCommonCacheManager implements CommandLineRunner {

    private final static Map<Long, UserBaseInfoDto> robotMap = Maps.newConcurrentMap();
    private final UserCenterBusiness userCenterBusiness;


    @Override
    public void run(String... args) {
        StopWatch stopWatch = new StopWatch();
        stopWatch.start("robot init");
        try {
            //启动时先关闭机器人的开关
            final ApiResult<List<UserBaseInfoDto>> robotResult = userCenterBusiness.robots();
            if (Objects.equals(robotResult.getC(), ApiResult.successCode)) {
                initRobots(robotResult.getD());
            } else {
                throw new RuntimeException(JsonUtil.toJson(robotResult));
            }
        } catch (Exception e) {
            log.error(e.getMessage(), e);
        } finally {
            //初始化结束后开启开关
            stopWatch.stop();
            log.debug(stopWatch.prettyPrint());
        }
    }


    public void initRobots(List<UserBaseInfoDto> robots) {
        robotMap.clear();
        for (UserBaseInfoDto robot : robots) {
            robotMap.put(robot.getId(), robot);
        }
    }

    /**
     * 获取所有机器人
     */
    public Set<Long> getRobotIds() {
        return getRobotMap().keySet();
    }


    public List<Long> getRobotIdsList() {
        return new ArrayList<>(getRobotIds());
    }

    public Map<Long, UserBaseInfoDto> getRobotMap() {
        if (CollectionUtils.isEmpty(robotMap)) run();
        return robotMap;
    }
}
