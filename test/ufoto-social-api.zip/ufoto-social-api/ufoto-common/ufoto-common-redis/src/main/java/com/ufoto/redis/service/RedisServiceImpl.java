package com.ufoto.redis.service;

import com.google.common.collect.Lists;
import com.google.common.collect.Maps;
import com.google.common.collect.Sets;
import com.ufoto.redis.utils.RedisKeyUtil;
import lombok.RequiredArgsConstructor;
import org.springframework.beans.factory.annotation.Qualifier;
import org.springframework.core.env.Environment;
import org.springframework.data.geo.Circle;
import org.springframework.data.geo.Distance;
import org.springframework.data.geo.GeoResults;
import org.springframework.data.geo.Metric;
import org.springframework.data.geo.Point;
import org.springframework.data.redis.connection.RedisGeoCommands.GeoLocation;
import org.springframework.data.redis.core.Cursor;
import org.springframework.data.redis.core.HashOperations;
import org.springframework.data.redis.core.RedisCallback;
import org.springframework.data.redis.core.RedisTemplate;
import org.springframework.data.redis.core.ScanOptions;
import org.springframework.data.redis.core.ZSetOperations.TypedTuple;
import org.springframework.data.redis.core.script.DefaultRedisScript;
import org.springframework.data.redis.serializer.RedisSerializer;
import org.springframework.stereotype.Component;
import org.springframework.util.CollectionUtils;

import java.nio.charset.StandardCharsets;
import java.time.Duration;
import java.util.Arrays;
import java.util.Collection;
import java.util.Collections;
import java.util.Date;
import java.util.List;
import java.util.Map;
import java.util.Set;
import java.util.UUID;
import java.util.concurrent.TimeUnit;

@Component
@RequiredArgsConstructor
public class RedisServiceImpl implements RedisService {


    private final Environment env;
    /*
   修改redisTemplate 两边写入 从原先的redis写入 不读
   cluster 写入 读取
    */
    @Qualifier("redisTemplate")
    private final RedisTemplate<String, String> redisTemplate;

    private String setIntersectionLuaScript = "local input_set = ARGV\n" +
            "local result_table = {}\n" +
            "local result_index = 1\n" +
            "local ismember = 0\n" +
            "for i,input in ipairs(input_set) do\n" +
            "\tismember = redis.call('SISMEMBER',KEYS[1],input)\n" +
            "\tif ismember == 1 then\n" +
            "\t\tresult_table[result_index] = input\n" +
            "\t\tresult_index = result_index+1\n" +
            "\tend\n" +
            "end\n" +
            "return result_table\n";
    private DefaultRedisScript<List> setIntersectionScript = new DefaultRedisScript<>(setIntersectionLuaScript, List.class);

    private String setDiffLuaScript = "local input_set = ARGV\n" +
            "local result_table = {}\n" +
            "local result_index = 1\n" +
            "local ismember = 0\n" +
            "for i,input in ipairs(input_set) do\n" +
            "\tismember = redis.call('SISMEMBER',KEYS[1],input)\n" +
            "\tif ismember == 0 then\n" +
            "\t\tresult_table[result_index] = input\n" +
            "\t\tresult_index = result_index+1\n" +
            "\tend\n" +
            "end\n" +
            "return result_table\n";
    private DefaultRedisScript<List> setDiffScript = new DefaultRedisScript<>(setDiffLuaScript, List.class);

    @Override
    public long del(final String... keys) {
        final List<String> list = Arrays.asList(keys);
        final Long delete = redisTemplate.delete(list);
        return delete == null ? 0 : delete;
    }

    @Override
    public void delSet(Set<String> keys) {
        redisTemplate.delete(keys);
    }

    @Override
    public void set(String key, String value, long liveTime) {
        redisTemplate.opsForValue().set(key, value, liveTime, TimeUnit.SECONDS);
    }

    @Override
    public void set(String key, String value) {
        redisTemplate.opsForValue().set(key, value);
    }

    @Override
    public boolean setnx(String key, String value, long livetime) {
        return redisTemplate.opsForValue().setIfAbsent(key, value, livetime, TimeUnit.SECONDS);
    }

    @Override
    public String get(final String key) {
        return getConverter(redisTemplate.opsForValue().get(key));
    }

    @Override
    public long getBitLen(String key) {
        final Long execute = redisTemplate.execute((RedisCallback<Long>) connection -> connection.bitCount(key.getBytes(StandardCharsets.UTF_8)));
        return execute != null ? execute : 0;
    }

    //todo string integer 兼容性
    private String getConverter(Object obj) {
        return obj == null ? null : String.valueOf(obj);
    }

    @Override
    public Set<String> keys(String pattern) {
        return redisTemplate.keys(pattern);

    }

    @Override
    public boolean exists(final String key) {
        final Boolean hasKey = redisTemplate.hasKey(key);
        return hasKey == null ? false : hasKey;
    }

    @Override
    public byte[] dump(String key) {
        return redisTemplate.dump(key);
    }

    @Override
    public void restore(String key, byte[] dump, Long ttl, TimeUnit timeUnit, boolean replace) {
        redisTemplate.restore(key, dump, ttl, timeUnit, replace);
    }

    @Override
    public void restore(String key, byte[] dump, boolean replace) {
        restore(key, dump, 0L, TimeUnit.SECONDS, replace);
    }

    @Override
    public Long increment(String key) {
        return redisTemplate.opsForValue().increment(key, 1);
    }

    @Override
    public Long decrement(String key) {
        return redisTemplate.opsForValue().increment(key, -1);
    }

    @Override
    public void hMSet(String key, Map<String, String> map) {
        redisTemplate.opsForHash().putAll(key, map);
    }

    @Override
    public Map<String, String> hGetAll(String key) {
        final HashOperations<String, String, String> hash = redisTemplate.opsForHash();
        final Map<String, String> entries = hash.entries(key);
        if (CollectionUtils.isEmpty(entries)) {
            return Maps.newHashMap();
        }
        return entries;
    }

    @Override
    public void hDel(String key, String... obj) {
        redisTemplate.opsForHash().delete(key, Arrays.stream(obj).map(o -> (Object) o).toArray());
    }

    @Override
    public Long hIncrBy(String key, String field, Long increment) {
        return redisTemplate.opsForHash().increment(key, field, increment);
    }

    @Override
    public List<String> lrange(String key, long start, long end) {
        return redisTemplate.opsForList().range(key, start, end);
    }

    @Override
    public Long rpush(String key, String... members) {
        return redisTemplate.opsForList().rightPushAll(key, members);
    }

    @Override
    public Long lpush(String key, String... members) {
        return redisTemplate.opsForList().leftPushAll(key, members);
    }

    @Override
    public Long lsize(String key) {
        return redisTemplate.opsForList().size(key);
    }

    @Override
    public Long lrem(String key, long count, String value) {
        return redisTemplate.opsForList().remove(key, count, value);
    }

    @Override
    public String lpop(String key) {
        return redisTemplate.opsForList().leftPop(key);
    }

    @Override
    public String rpop(String key) {
        return redisTemplate.opsForList().rightPop(key);
    }

    @Override
    public boolean zadd(String key, String value, double score) {
        final Boolean add = redisTemplate.opsForZSet().add(key, value, score);
        return add != null ? add : false;
    }

    @Override
    public Long zremove(String key, Object... values) {
        return redisTemplate.opsForZSet().remove(key, values);
    }

    @Override
    public Double zincrementScore(String key, String value, double delta) {
        return redisTemplate.opsForZSet().incrementScore(key, value, delta);
    }

    @Override
    public Long zrank(String key, Object value) {
        return redisTemplate.opsForZSet().rank(key, value);
    }

    @Override
    public Long zreverseRank(String key, Object value) {
        return redisTemplate.opsForZSet().reverseRank(key, value);
    }

    @Override
    public Long zremoveRange(String key, long start, long end) {
        return redisTemplate.opsForZSet().removeRange(key, start, end);
    }

    @Override
    public Long zremoveRangeByScore(String key, double min, double max) {
        return redisTemplate.opsForZSet().removeRangeByScore(key, min, max);
    }

    @Override
    public Set<String> zrange(String key, long start, long end) {
        return redisTemplate.opsForZSet().range(key, start, end);
    }

    @Override
    public Set<TypedTuple<String>> zrangeWithScores(String key, long start,
                                                    long end) {
        return redisTemplate.opsForZSet().rangeWithScores(key, start, end);
    }

    @Override
    public Set<String> zrangeByScore(String key, double min, double max) {
        return redisTemplate.opsForZSet().rangeByScore(key, min, max);
    }

    @Override
    public Set<TypedTuple<String>> zrangeByScoreWithScores(String key,
                                                           double min, double max) {
        return redisTemplate.opsForZSet().rangeByScoreWithScores(key, min, max);
    }

    @Override
    public Long zcount(String key, double min, double max) {
        return redisTemplate.opsForZSet().count(key, min, max);
    }

    @Override
    public Long zsize(String key) {
        return redisTemplate.opsForZSet().size(key);
    }

    @Override
    public Long zCard(String key) {
        return redisTemplate.opsForZSet().zCard(key);
    }

    @Override
    public Double zscore(String key, String value) {
        return redisTemplate.opsForZSet().score(key, value);
    }

    @Override
    public Long zUnionAndStore(String key, Collection<String> keys, String target) {
        return redisTemplate.opsForZSet().unionAndStore(key, keys, target);
    }

    @Override
    public Set<String> zrevrange(String key, long start, long end) {
        return redisTemplate.opsForZSet().reverseRange(key, start, end);
    }

    @Override
    public Set<TypedTuple<String>> reverseRangeWithScores(String key,
                                                          long start, long end) {
        return redisTemplate.opsForZSet().reverseRangeWithScores(key, start, end);
    }

    @Override
    public Long sadd(String key, String... values) {
        return redisTemplate.opsForSet().add(key, values);
    }

    @Override
    public Long sCard(String key) {
        return redisTemplate.opsForSet().size(key);
    }

    @Override
    public Long sremove(String key, String... values) {
        return redisTemplate.opsForSet().remove(key, Arrays.stream(values).map(v -> (Object) v).toArray());
    }

    @Override
    public String srandomMember(String key) {
        return redisTemplate.opsForSet().randomMember(key);
    }

    @Override
    public Set<String> sMember(String key) {
        return redisTemplate.opsForSet().members(key);
    }

    @Override
    public Set<String> sMember(String key, boolean byScan) {
        final boolean ifSupportScan = env.getProperty("redisService.sMember.ifSupportScan", Boolean.class, true);
        return (ifSupportScan && byScan) ? sMembersByScan(key) : sMember(key);
    }

    public Set<String> sMembersByScan(String key) {
        Set<String> result = Sets.newHashSet();
        final Cursor<String> cursor = redisTemplate.opsForSet()
                .scan(key, ScanOptions.scanOptions()
                        .count(env.getProperty("redis.scan.iter.count", Long.class, 1000L))
                        .build());
        cursor.forEachRemaining(result::add);
        return result;
    }

    @Override
    public Set<String> sdistinctRandomMembers(String key, long count) {
        return redisTemplate.opsForSet().distinctRandomMembers(key, count);
    }

    @Override
    public List<String> srandomMembers(String key, long count) {
        return redisTemplate.opsForSet().randomMembers(key, count);
    }

    @Override
    public boolean expire(String key, long timeout, TimeUnit unit) {
        final Boolean expire = redisTemplate.expire(key, timeout, unit);
        return expire == null ? false : expire;
    }

    @Override
    public Boolean isMember(String key, String o) {
        final Boolean member = redisTemplate.opsForSet().isMember(key, o);
        return member == null ? Boolean.FALSE : member;
    }

    @Override
    public Long geoAdd(String key, Point point, String member) {
        return redisTemplate.opsForGeo().add(key, point, member);
    }

    @Override
    public List<String> geoHash(String key, String... members) {
        try {
            return redisTemplate.opsForGeo().hash(key, members);
        } catch (Exception e) {
            return Lists.newArrayList();
        }
    }

    @Override
    public GeoResults<GeoLocation<String>> geoRadius(String key, Circle within) {
        try {
            return redisTemplate.opsForGeo().radius(key, within);
        } catch (Exception e) {
            return new GeoResults<>(Lists.newArrayList());
        }
    }

    @Override
    public GeoResults<GeoLocation<String>> geoRadius(String key, String member, Distance distance) {
        try {
            return redisTemplate.opsForGeo().radius(key, member, distance);
        } catch (Exception e) {
            return new GeoResults<>(Lists.newArrayList());
        }
    }

    @Override
    public Distance geoDistance(String key, String member1, String member2) {
        try {
            return redisTemplate.opsForGeo().distance(key, member1, member2);
        } catch (Exception e) {
            return null;
        }
    }

    @Override
    public Distance geoDistance(String key, String member1, String member2, Metric metric) {
        try {
            return redisTemplate.opsForGeo().distance(key, member1, member2, metric);
        } catch (Exception e) {
            return null;
        }
    }

    @Override
    public Distance geoDistance(final String key, final String member,
                                final Double longitude, final Double latitude,
                                final Metric metric) {

        Object execute = redisTemplate.execute((RedisCallback<Object>) connection -> {
            String tempGeoMember = "\"getDistance:" + UUID.randomUUID() + "\"";
            String serilizedMember = "\"" + member + "\"";
            Point point = new Point(longitude, latitude);
            connection.geoAdd(key.getBytes(), point, tempGeoMember.getBytes());
            Distance result;
            try {
                result = connection.geoDist(key.getBytes(), tempGeoMember.getBytes(), serilizedMember.getBytes(), metric);
            } catch (Exception e) {
                result = new Distance(0d);
            }
            connection.zRem(key.getBytes(), tempGeoMember.getBytes());
            return result;
        });
        return (Distance) execute;
    }

    @Override
    public List<Point> geoPos(String key, String... members) {
        try {
            return redisTemplate.opsForGeo().position(key, members);
        } catch (Exception e) {
            return Lists.newArrayList();
        }
    }

    @Override
    public List<String> mget(List<String> keys) {
        return redisTemplate.opsForValue().multiGet(keys);
    }

    @Override
    public RedisTemplate<String, String> getRedisTemplate() {
        return redisTemplate;
    }

    @Override
    public RedisSerializer<String> getStringSerializer() {
        return redisTemplate.getStringSerializer();
    }

    @Override
    public String hget(String key, String field) {
        final Object o = redisTemplate.opsForHash().get(key, field);
        if (o == null) {
            return null;
        }
        return o.toString();
    }

    @Override
    public List<String> hmget(String key, List<String> hashKeys) {
        final HashOperations<String, String, String> hashOperations = redisTemplate.opsForHash();
        return hashOperations.multiGet(key, hashKeys);
    }

    @Override
    public void hset(String key, String field, String value) {
        redisTemplate.opsForHash().put(key, field, value);
    }

    @Override
    public List<Object> execPipelineForWrite(RedisCallback<Object> redisCallback) {
        return redisTemplate.executePipelined(redisCallback);
    }

    @Override
    public List<Object> execPipelineForRead(RedisCallback<Object> redisCallback) {
        return redisTemplate.executePipelined(redisCallback);
    }

    @Override
    public Set<String> setIntersection(String key, Set<String> mySet) {
        if (CollectionUtils.isEmpty(mySet)) {
            return mySet;
        }
        final Integer scriptSize = env.getProperty("redisService.setIntersection.scriptSize", Integer.class, 500);
        if (mySet.size() < scriptSize) {
            String[] inputArray = mySet.toArray(new String[]{});
            return Sets.newHashSet(redisTemplate.execute(setIntersectionScript, Collections.singletonList(key), inputArray));
        }

        List<String> myList = Lists.newArrayList(mySet);
        Set<String> result = Sets.newHashSet();
        final List objects = redisTemplate.executePipelined((RedisCallback<Object>) connection -> {
            for (String item : myList) {
                connection.sIsMember(key.getBytes(StandardCharsets.UTF_8),
                        RedisKeyUtil.serializeUid(item).getBytes(StandardCharsets.UTF_8));
            }
            return null;
        });
        for (int i = 0; i < myList.size(); i++) {
            final Object obj = objects.get(i);
            Boolean ifIn = obj == null ? Boolean.FALSE : (Boolean) obj;
            if (ifIn) {
                result.add(myList.get(i));
            }
        }
        return result;
    }

    @Override
    public Set<String> setDiff(String key, Set<String> mySet) {
        if (CollectionUtils.isEmpty(mySet)) {
            return mySet;
        }
        final Integer scriptSize = env.getProperty("redisService.setDiff.scriptSize", Integer.class, 500);
        if (mySet.size() < scriptSize) {
            String[] inputArray = mySet.toArray(new String[]{});
            return Sets.newHashSet(redisTemplate.execute(setDiffScript, Collections.singletonList(key), inputArray));
        }

        List<String> myList = Lists.newArrayList(mySet);
        Set<String> result = Sets.newHashSet();
        final List objects = redisTemplate.executePipelined((RedisCallback<Object>) connection -> {
            for (String item : myList) {
                connection.sIsMember(key.getBytes(StandardCharsets.UTF_8),
                        RedisKeyUtil.serializeUid(item).getBytes(StandardCharsets.UTF_8));
            }
            return null;
        });
        for (int i = 0; i < myList.size(); i++) {
            final Object obj = objects.get(i);
            Boolean ifIn = obj == null ? Boolean.FALSE : (Boolean) obj;
            if (!ifIn) {
                result.add(myList.get(i));
            }
        }
        return result;
    }

    @Override
    public List<TypedTuple<String>> zscan(String key) {
        List<TypedTuple<String>> tuples = Lists.newArrayList();
        ScanOptions options = ScanOptions.scanOptions().count(env.getProperty("redis.scan.iter.count", Long.class, 1000L)).match("*").build();
        final Cursor<TypedTuple<String>> cursor = redisTemplate.opsForZSet().scan(key, options);
        cursor.forEachRemaining(tuples::add);
        return tuples;
    }

    @Override
    public Set<String> hkeys(String key) {
        final HashOperations<String, String, Object> hash = redisTemplate.opsForHash();
        return hash.keys(key);
    }

    @Override
    public void expireAt(String key, Date date) {
        redisTemplate.expireAt(key, date);
    }

    @Override
    public long ttl(String key) {
        final Long expire = redisTemplate.getExpire(key);
        return expire != null ? expire : 0;
    }

    @Override
    public Boolean setIfAbsent(String key, String value, long seconds) {
        return redisTemplate.opsForValue().setIfAbsent(key, value, Duration.ofSeconds(seconds));
    }
}

