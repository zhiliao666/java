package com.ufoto.redis.service;

import org.springframework.data.geo.Circle;
import org.springframework.data.geo.Distance;
import org.springframework.data.geo.GeoResults;
import org.springframework.data.geo.Metric;
import org.springframework.data.geo.Point;
import org.springframework.data.redis.connection.RedisGeoCommands.GeoLocation;
import org.springframework.data.redis.core.RedisCallback;
import org.springframework.data.redis.core.RedisTemplate;
import org.springframework.data.redis.core.ZSetOperations.TypedTuple;
import org.springframework.data.redis.serializer.RedisSerializer;

import java.util.Collection;
import java.util.Date;
import java.util.List;
import java.util.Map;
import java.util.Set;
import java.util.concurrent.TimeUnit;

/**
 * redis 的操作开放接口
 *
 * @author zhangqh
 */
public interface RedisService {
    /**
     * 通过key删除
     *
     * @param keys
     */
    long del(String... keys);

    /**
     * 通过set 删除
     *
     * @param sets
     */
    void delSet(Set<String> sets);

    /**
     * 添加key value 并且设置存活时间
     *
     * @param key
     * @param value
     * @param liveTime 单位秒
     */
    void set(String key, String value, long liveTime);

    /**
     * 添加key value
     *
     * @param key
     * @param value
     */
    void set(String key, String value);

    /**
     * 添加key value
     *
     * @param key
     * @param value
     */
    boolean setnx(String key, String value, long livetime);

    /**
     * 获取redis value (String)
     *
     * @param key
     * @return
     */
    String get(String key);


    long getBitLen(String key);

    /**
     * 通过正则匹配keys
     *
     * @param pattern
     * @return
     */
    Set<String> keys(String pattern);

    /**
     * 检查key是否已经存在
     *
     * @param key
     * @return
     */
    boolean exists(String key);

    /**
     * 导出Key的内容
     *
     * @param key
     * @return
     */
    byte[] dump(String key);

    /**
     * 导入数据
     *
     * @param key
     * @param dump
     * @param ttl
     * @param timeUnit
     * @param replace
     */
    void restore(String key, byte[] dump, Long ttl, TimeUnit timeUnit, boolean replace);

    void restore(String key, byte[] dump, boolean replace);


    /**
     * 计数器
     *
     * @param key
     */
    Long increment(String key);

    Long decrement(String key);

    /*******************  hash  *********************/

    void hMSet(String key, Map<String, String> map);

    Map<String, String> hGetAll(String key);

    void hDel(String key, String... obj);

    Long hIncrBy(String key, String field, Long increment);

    /*******************  list *********************/

    /**
     * List 获取列表
     *
     * @param key
     * @param start
     * @param end
     */
    List<String> lrange(String key, long start, long end);

    /**
     * list  表尾push元素
     *
     * @param key
     * @param members
     */
    Long rpush(String key, String... members);


    /**
     * list  表头压入元素
     *
     * @param key
     * @param members
     */
    Long lpush(String key, String... members);

    /**
     * 获取list长度
     *
     * @param key
     * @return
     */
    Long lsize(String key);

    /**
     * 删除列表中对应元素
     *
     * @param key
     * @param count 大于0从表头开始搜索count个，小于0从表尾开始搜索count个，等于0删除所有
     * @param value
     * @return
     */
    Long lrem(String key, long count, String value);

    /**
     * 弹出表头第一个元素
     *
     * @param key
     * @return
     */
    String lpop(String key);


    /**
     * 弹出表尾第一个元素
     *
     * @param key
     * @return
     */
    String rpop(String key);

    /*******************  zset ********************/

    /**
     * 新增一个zset值
     *
     * @param key   键值
     * @param value 内容
     * @param score 分值
     * @return
     */
    boolean zadd(String key, String value, double score);

    /**
     * 从有序集合中移除一个或者多个元素
     *
     * @param key
     * @param value
     * @return
     */
    Long zremove(String key, Object... value);

    /**
     * 移除指定索引位置的成员，其中有序集成员按分数值递增(从小到大)顺序排列
     *
     * @param key
     * @param start
     * @param end
     * @return
     */
    Long zremoveRange(String key, long start, long end);

    /**
     * 根据指定的score值得范围来移除成员
     *
     * @param key
     * @param min
     * @param max
     * @return
     */
    Long zremoveRangeByScore(String key, double min, double max);

    /**
     * 增加元素的score值，并返回增加后的值
     *
     * @param key
     * @param value
     * @param delta
     * @return
     */
    Double zincrementScore(String key, String value, double delta);

    /**
     * 获取有序集中指定成员的排名，其中有序集成员按分数值递增(从小到大)顺序排列
     *
     * @param key
     * @param value
     * @return
     */
    Long zrank(String key, Object value);

    /**
     * 有序集中指定成员的排名，其中有序集成员按分数值递减(从大到小)顺序排列
     *
     * @param key
     * @param value
     * @return
     */
    Long zreverseRank(String key, Object value);

    /**
     * 通过索引区间返回有序集合成指定区间内的成员，其中有序集成员按分数值递增(从小到大)顺序排列
     *
     * @param key
     * @param start
     * @param end
     * @return
     */
    Set<String> zrange(String key, long start, long end);

    /**
     * 通过索引区间返回有序集合成指定区间内的成员，其中有序集成员按分数值递增(从大到小)顺序排列
     *
     * @param key
     * @param start
     * @param end
     * @return
     */
    Set<String> zrevrange(String key, long start, long end);

    /**
     * 通过索引区间返回有序集合成指定区间内的成员对象，其中有序集成员按分数值递增(从小到大)顺序排列
     *
     * @param key
     * @param start
     * @param end
     * @return
     */
    Set<TypedTuple<String>> zrangeWithScores(String key, long start, long end);

    /**
     * 通过索引区间返回有序集合成指定区间内的成员对象，其中有序集成员按分数值递减(从大到小)顺序排列
     *
     * @param key
     * @param start
     * @param end
     * @return
     */
    Set<TypedTuple<String>> reverseRangeWithScores(String key, long start, long end);

    /**
     * 通过分数返回有序集合指定区间内的成员，其中有序集成员按分数值递增(从小到大)顺序排列
     *
     * @param key
     * @param min
     * @param max
     * @return
     */
    Set<String> zrangeByScore(String key, double min, double max);

    /**
     * 通过分数返回有序集合指定区间内的成员对象，其中有序集成员按分数值递增(从小到大)顺序排列
     *
     * @param key
     * @param min
     * @param max
     * @return
     */
    Set<TypedTuple<String>> zrangeByScoreWithScores(String key, double min, double max);

    /**
     * 通过分数返回有序集合指定区间内的成员个数
     *
     * @param key
     * @param min
     * @param max
     * @return
     */
    Long zcount(String key, double min, double max);

    /**
     * 获取有序集合的成员数，内部调用的就是zCard方法
     *
     * @param key
     * @return
     */
    Long zsize(String key);

    /**
     * 获取有序集合的成员数
     *
     * @param key
     * @return
     */
    Long zCard(String key);

    /**
     * 获取指定成员的score值
     *
     * @param key
     * @param value
     * @return
     */
    Double zscore(String key, String value);

    /**
     * 将多个Zset 并集并且相加score
     *
     * @param key
     * @return
     */
    Long zUnionAndStore(String key, Collection<String> keys, String target);

    /*******************  set ********************/

    /**
     * 无序集合中添加元素，返回添加个数
     *
     * @param key
     * @param values
     * @return
     */
    Long sadd(String key, String... values);

    /**
     * 无序集合中元素个数
     *
     * @param key
     * @return
     */
    Long sCard(String key);

    /**
     * 移除集合中一个或多个成员
     *
     * @param key
     * @param values
     * @return
     */
    Long sremove(String key, String... values);

    /**
     * 随机获取key无序集合中的一个元素
     *
     * @param key
     * @return
     */
    String srandomMember(String key);

    /**
     * 获取key无序集合中的所有元素
     *
     * @param key
     * @return
     */
    Set<String> sMember(String key);

    /**
     * 获取key无序集合中的所有元素
     *
     * @param key
     * @param byScan 是否通过scan的方式来进行所有元素的获取
     * @return
     */
    Set<String> sMember(String key, boolean byScan);

    /**
     * 获取多个key无序集合中的元素（去重），count表示个数
     *
     * @param key
     * @param count
     * @return
     */
    Set<String> sdistinctRandomMembers(String key, long count);

    /**
     * 获取多个key无序集合中的元素，count表示个数
     *
     * @param key
     * @param count
     * @return
     */
    List<String> srandomMembers(String key, long count);

    /**
     * 设置过期时间
     *
     * @param key
     * @param timeout
     * @param unit
     * @return
     */
    boolean expire(String key, long timeout, TimeUnit unit);

    /**
     * 判断set中元素是否存在
     *
     * @param key
     * @param o
     * @return
     */
    Boolean isMember(String key, String o);

    /*******************  geo ********************/

    /**
     * 增加geo
     *
     * @param key
     * @param point  new Point(X,Y)
     * @param member 具体成员
     * @return
     */
    Long geoAdd(String key, Point point, String member);

    /**
     * Get Geohash representation of the position for one or more {@literal member}s
     *
     * @param key
     * @param members
     * @return
     */
    List<String> geoHash(String key, String... members);

    /**
     * Get the {@literal member}s within the boundaries of a given {@link Circle}
     *
     * @param key
     * @param within
     * @return
     */
    GeoResults<GeoLocation<String>> geoRadius(String key, Circle within);

    /**
     * Get the {@literal member}s within the circle defined by the {@literal members} coordinates and given
     * {@literal radius} applying {@link Metric}.
     *
     * @param key
     * @param member
     * @param distance
     * @return
     */
    GeoResults<GeoLocation<String>> geoRadius(String key, String member, Distance distance);


    /**
     * 返回两个member之间的距离
     *
     * @param key
     * @param member1
     * @param member2
     * @return
     */
    Distance geoDistance(String key, String member1, String member2);

    /**
     * 返回两个member之间的距离
     *
     * @param key
     * @param member1
     * @param member2
     * @return
     */
    Distance geoDistance(String key, String member1, String member2, Metric metric);


    /**
     * 返回member和坐标之间的距离
     *
     * @param key
     * @param member
     * @param longitude
     * @param latitude
     * @return
     */
    Distance geoDistance(String key, String member, Double longitude, Double latitude, Metric metric);

    /**
     * 返回member的位置
     *
     * @param key
     * @param members
     */
    List<Point> geoPos(String key, String... members);

    /**
     * 批量获取key对应的string
     *
     * @param keys
     * @return
     */
    List<String> mget(List<String> keys);

    RedisTemplate<String, String> getRedisTemplate();

    RedisSerializer<String> getStringSerializer();

    String hget(String key, String field);

    List<String> hmget(String key, List<String> hashKeys);

    void hset(String key, String field, String value);

    /**
     * 管道写入命令
     * 读取不需要使用
     *
     * @param redisCallback 管道命令
     * @return 执行结果
     */
    List<Object> execPipelineForWrite(RedisCallback<Object> redisCallback);

    /*******************  script ********************/

    List<Object> execPipelineForRead(RedisCallback<Object> redisCallback);

    /**
     * 输入Set和对应存储在Redis中的Set的key，返回他们之间的交集
     *
     * @param key   Redis中某个Set的key
     * @param mySet 输入用户Set
     * @return 两个Set的交集
     */
    Set<String> setIntersection(String key, Set<String> mySet);


    /**
     * 输入Set和对应存储在Redis中的Set的key，返回他们之间的差集，Set diff Key
     *
     * @param key   Redis中某个Set的key
     * @param mySet 输入用户Set
     * @return 两个Set的交集
     */
    Set<String> setDiff(String key, Set<String> mySet);

    List<TypedTuple<String>> zscan(String key);

    Set<String> hkeys(String key);

    void expireAt(String key, Date date);

    long ttl(String key);

    Boolean setIfAbsent(String key, String value, long seconds);
}
