package com.ufoto.lmax2.producer;

import com.lmax.disruptor.dsl.Disruptor;
import com.ufoto.lmax2.event.ContextEvent;

public class Producer<T> implements ContextProducer<T> {

    final private Disruptor<ContextEvent<T>> disruptor;

    public Producer(Disruptor<ContextEvent<T>> disruptor) {
        this.disruptor = disruptor;
    }

    @Override
    public void onData(T context) {
        publishEvent(context);
    }

    protected void publishEvent(T context) {
        disruptor.publishEvent((event, sequence) -> event.setContext(context));
    }
}
