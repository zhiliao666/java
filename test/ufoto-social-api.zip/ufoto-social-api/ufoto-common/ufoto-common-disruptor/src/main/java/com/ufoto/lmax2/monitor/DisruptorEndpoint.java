package com.ufoto.lmax2.monitor;

import org.springframework.boot.actuate.endpoint.annotation.Endpoint;
import org.springframework.boot.actuate.endpoint.annotation.ReadOperation;

import java.util.Map;

/**
 * <p>
 * Description:
 *
 * </p>
 *
 * @author Chan
 * @date 2020/1/26 22:37
 */
@Endpoint(id = "disruptor")
public class DisruptorEndpoint {

    private final DisruptorStatistics disruptorStatistics;

    public DisruptorEndpoint(DisruptorStatistics disruptorStatistics) {
        this.disruptorStatistics = disruptorStatistics;
    }

    @ReadOperation
    public Map<String, Object> statistics() {
        return disruptorStatistics.logStatistics();
    }

}
