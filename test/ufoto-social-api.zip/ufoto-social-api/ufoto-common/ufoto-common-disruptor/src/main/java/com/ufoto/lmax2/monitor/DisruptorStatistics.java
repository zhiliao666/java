package com.ufoto.lmax2.monitor;

import com.fasterxml.jackson.core.JsonProcessingException;
import com.fasterxml.jackson.databind.ObjectMapper;
import com.ufoto.lmax2.disruptor.LMaxDisruptor;
import com.ufoto.lmax2.monitor.bean.RingBufferMonitor;
import io.micrometer.core.instrument.Measurement;
import io.micrometer.core.instrument.Statistic;
import io.micrometer.core.instrument.simple.SimpleMeterRegistry;
import lombok.Data;
import lombok.extern.slf4j.Slf4j;
import org.springframework.context.ApplicationContext;
import org.springframework.scheduling.annotation.Scheduled;

import java.util.HashMap;
import java.util.Map;
import java.util.stream.Collectors;

/**
 * <p>
 * Author     : Chan
 * CreateDate : 2019/11/21 09:29
 * Description: 定时打印统计信息
 * </p>
 */
@Slf4j
public class DisruptorStatistics {

    private final ObjectMapper mapper;
    private final SimpleMeterRegistry simpleMeterRegistry;
    private final ApplicationContext applicationContext;

    public DisruptorStatistics(SimpleMeterRegistry simpleMeterRegistry,
                               ApplicationContext applicationContext) {
        this.simpleMeterRegistry = simpleMeterRegistry;
        this.applicationContext = applicationContext;
        this.mapper = new ObjectMapper();
    }

    @Scheduled(fixedRate = 600000)
    public void schedule() throws JsonProcessingException {
        log.warn(mapper.writeValueAsString(logStatistics()));
    }

    public Map<String, Object> logStatistics() {
        Map<String, Object> statMap = new HashMap<>();
        statMap.put("consumers", simpleMeterRegistry.getMeters().stream()
                .filter(item -> item.getId().getName().contains("disruptor"))
                .map(item -> {
                    ConsumerStatistics consumerStatistics = new ConsumerStatistics();
                    consumerStatistics.setName(item.getId().getName());
                    consumerStatistics.setConsumerId(item.getId().getTag("consumerId"));
                    Map<Statistic, Double> measure = new HashMap<>();
                    final Iterable<Measurement> measurements = item.measure();
                    measurements.forEach(measurement -> measure.put(measurement.getStatistic(), measurement.getValue()));
                    consumerStatistics.setMeasure(measure);
                    return consumerStatistics;
                })
                .collect(Collectors.toList()));
        final Map<String, LMaxDisruptor> disruptorMap = applicationContext.getBeansOfType(LMaxDisruptor.class);
        Map<String, RingBufferMonitor> monitorMap = new HashMap<>();
        disruptorMap.forEach((k, v) -> monitorMap.put(k, v.monitorRingBuffer()));
        statMap.put("ringBuffers", monitorMap);
        return statMap;

    }

    @Data
    public static class ConsumerStatistics {
        private String name;
        private String consumerId;
        private Map<Statistic, Double> measure;
    }

}
