package com.ufoto.lmax2.event;

import java.io.Serializable;

/**
 * <p>
 * Author     : Chan
 * CreateDate : 2019/11/27 09:57
 * Description: 事件的超类
 * </p>
 */
public abstract class Event implements Serializable {
}
