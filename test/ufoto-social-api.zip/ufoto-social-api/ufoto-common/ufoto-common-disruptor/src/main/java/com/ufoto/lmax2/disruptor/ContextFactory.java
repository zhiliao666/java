package com.ufoto.lmax2.disruptor;

import com.lmax.disruptor.EventFactory;
import com.ufoto.lmax2.event.ContextEvent;

/**
 * 事件工厂类,用于创建事件包装类的具体实现
 * @param <T> 具体事件类
 */
public class ContextFactory<T> implements EventFactory<ContextEvent<T>> {

    @Override
    public ContextEvent<T> newInstance() {
        return new ContextEvent<>();
    }
}
