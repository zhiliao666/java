package com.ufoto.lmax2.producer;

/**
 * 事件生产者 生产者基于此接口创建
 *
 * @param <T> 具体事件类
 */
public interface ContextProducer<T> {

    /**
     * 生产者发布一个事件
     *
     * @param context 具体的事件对象
     */
    void onData(T context);

}
