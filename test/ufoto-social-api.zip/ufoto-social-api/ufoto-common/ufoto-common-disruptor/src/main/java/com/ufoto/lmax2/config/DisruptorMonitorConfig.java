package com.ufoto.lmax2.config;

import com.ufoto.lmax2.monitor.DisruptorEndpoint;
import com.ufoto.lmax2.monitor.DisruptorStatistics;
import io.micrometer.core.instrument.simple.SimpleMeterRegistry;
import org.springframework.context.ApplicationContext;
import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;

/**
 * <p>
 * Description:
 *
 * </p>
 *
 * @author Chan
 * @date 2020/1/27 13:16
 */
@Configuration
public class DisruptorMonitorConfig {

    @Bean
    public DisruptorStatistics disruptorStatistics(SimpleMeterRegistry simpleMeterRegistry,
                                                   ApplicationContext applicationContext) {
        return new DisruptorStatistics(simpleMeterRegistry, applicationContext);
    }

    @Bean
    public DisruptorEndpoint disruptorEndpoint(DisruptorStatistics disruptorStatistics) {
        return new DisruptorEndpoint(disruptorStatistics);
    }

}
