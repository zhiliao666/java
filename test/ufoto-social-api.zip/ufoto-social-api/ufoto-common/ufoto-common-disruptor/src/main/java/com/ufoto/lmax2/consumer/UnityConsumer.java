package com.ufoto.lmax2.consumer;


import com.ufoto.lmax2.event.ContextEvent;
import com.ufoto.lmax2.event.Event;
import com.ufoto.lmax2.event.EventMap;
import com.ufoto.lmax2.event.UnityEvent;
import io.micrometer.core.instrument.simple.SimpleMeterRegistry;
import lombok.extern.slf4j.Slf4j;

import java.util.List;

/**
 * <p>
 * Author     : Chan
 * CreateDate : 2019/11/27 09:52
 * Description:
 * </p>
 */
@SuppressWarnings("unchecked")
@Slf4j
public class UnityConsumer extends Consumer<UnityEvent> {

    public UnityConsumer(String consumerId, SimpleMeterRegistry simpleMeterRegistry) {
        super(consumerId, simpleMeterRegistry);
    }

    @Override
    public void consume(UnityEvent event) {
        final List<EventMap> eventMaps = event.getEventMaps();
        if (eventMaps == null || eventMaps.isEmpty()) {
            log.debug("没有设置事件:{}", event);
            return;
        }

        eventMaps.parallelStream()
                .filter(eventMap -> {
                    boolean flag = true;
                    final Consumer<? extends Event> consumer = eventMap.getConsumer();
                    if (consumer == null) {
                        log.warn("没有设置事件与消费者之间的映射: {}", eventMap);
                        flag = false;
                    }
                    final Event actualEvent = eventMap.getEvent();
                    if (actualEvent == null) {
                        log.warn("没有设置具体的事件:{}", eventMap);
                        flag = false;
                    }
                    return flag;
                })
                .forEach(eventMap -> {
                    try {
                        ContextEvent contextEvent = new ContextEvent<>();
                        contextEvent.setContext(eventMap.getEvent());
                        eventMap.getConsumer().onEvent(contextEvent);
                    } catch (Exception e) {
                        log.error(e.getMessage(), e);
                    }
                });
    }
}
