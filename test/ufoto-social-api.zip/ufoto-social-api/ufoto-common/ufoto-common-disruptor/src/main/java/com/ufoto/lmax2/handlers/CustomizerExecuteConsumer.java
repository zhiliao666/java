package com.ufoto.lmax2.handlers;

import com.lmax.disruptor.dsl.Disruptor;
import com.ufoto.lmax2.event.ContextEvent;

/**
 * <p>
 * Author     : Chan
 * CreateDate : 2019/11/19 13:05
 * Description: 线性执行 事件可传递
 * </p>
 */
public class CustomizerExecuteConsumer<T> implements ContextConsumer<T> {

    private final Disruptor<ContextEvent<T>> disruptor;

    public CustomizerExecuteConsumer(Disruptor<ContextEvent<T>> disruptor) {
        this.disruptor = disruptor;
    }

    @Override
    public void customizer(ConsumerCustomizer<T> consumerCustomizer) {
        consumerCustomizer.consume(disruptor);
    }
}
