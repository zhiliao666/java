package com.ufoto.lmax2.disruptor;

import com.lmax.disruptor.ExceptionHandler;
import com.lmax.disruptor.RingBuffer;
import com.lmax.disruptor.SleepingWaitStrategy;
import com.lmax.disruptor.TimeoutException;
import com.lmax.disruptor.WaitStrategy;
import com.lmax.disruptor.dsl.Disruptor;
import com.lmax.disruptor.dsl.ProducerType;
import com.lmax.disruptor.util.Util;
import com.ufoto.lmax2.event.ContextEvent;
import com.ufoto.lmax2.handlers.ConsumerCustomizer;
import com.ufoto.lmax2.handlers.ContextConsumer;
import com.ufoto.lmax2.handlers.CustomizerExecuteConsumer;
import com.ufoto.lmax2.monitor.bean.RingBufferMonitor;
import com.ufoto.lmax2.producer.ContextProducer;
import com.ufoto.lmax2.producer.Producer;

import java.lang.reflect.Constructor;
import java.lang.reflect.InvocationTargetException;
import java.util.concurrent.ThreadFactory;
import java.util.concurrent.TimeUnit;

/**
 * 封装Disruptor
 * 一般来说 针对每个业务 需要创建一个Disruptor
 *
 * @param <T>
 */
@SuppressWarnings("unchecked")
public class LMaxDisruptor<T> {

    private static final int BUFFER_SIZE = 1024 * 1024; // 100K buffer by default
    private final Disruptor<ContextEvent<T>> disruptor;
    private final ContextProducer<T> producer;
    private final ContextConsumer<T> consumer;

    private LMaxDisruptor(Builder<T> builder) {
        ProducerType producerType = builder.producerType;
        ContextFactory<T> eventFactory = builder.eventFactory;
        int bufferSize = builder.bufferSize;
        WaitStrategy waitStrategy = builder.waitStrategy;
        ThreadFactory threadFactory = builder.threadFactory;
        ExceptionHandler<ContextEvent<T>> exceptionHandler = builder.exceptionHandler;
        this.disruptor = new Disruptor<>(
                eventFactory,
                Util.ceilingNextPowerOfTwo(bufferSize), // size of the ring buffer must be power of 2
                threadFactory, // Each disruptor runs in 1 thread
                producerType,
                waitStrategy
        );
        disruptor.setDefaultExceptionHandler(exceptionHandler);
        this.producer = new Producer<>(disruptor);
        try {
            /*
              创建disruptor时必须指定,consumer为消费者的具体执行方式,可参考{@link com.ufoto.lmax.consumers}
             */
            final Constructor<? extends ContextConsumer> constructor = builder.consumer.getConstructor(Disruptor.class);
            this.consumer = constructor.newInstance(disruptor);
        } catch (NoSuchMethodException | IllegalAccessException | InstantiationException | InvocationTargetException e) {
            throw new RuntimeException(e);
        }
    }

    public final void subscribeCustomizer(ConsumerCustomizer<T> consumerCustomizer) {
        consumer.customizer(consumerCustomizer);
    }

    public RingBuffer<ContextEvent<T>> startDisruptor() {
        return disruptor.start();
    }

    public RingBufferMonitor monitorRingBuffer() {
        final RingBuffer<ContextEvent<T>> ringBuffer = disruptor.getRingBuffer();
        return RingBufferMonitor.builder()
                .bufferSize(ringBuffer.getBufferSize())
                .cursor(ringBuffer.getCursor())
                .remainingCapacity(ringBuffer.remainingCapacity())
                .build();
    }

    public void shutdown() {
        disruptor.shutdown();
    }

    public void shutdown(long timeout, TimeUnit timeUnit) throws TimeoutException {
        disruptor.shutdown(timeout, timeUnit);
    }

    public void send(T context) {
        producer.onData(context);
    }

    public static <T> Builder<T> builder() {
        return new Builder<>();
    }

    public static class Builder<E> {

        private ProducerType producerType;
        private ContextFactory<E> eventFactory;
        private int bufferSize = BUFFER_SIZE;
        private WaitStrategy waitStrategy;
        private ThreadFactory threadFactory;
        private ExceptionHandler<ContextEvent<E>> exceptionHandler;
        private Class<? extends ContextConsumer> consumer;

        public Builder<E> producerType(ProducerType producerType) {
            this.producerType = producerType;
            return this;
        }

        public Builder<E> eventFactory(ContextFactory<E> eventFactory) {
            this.eventFactory = eventFactory;
            return this;
        }

        public Builder<E> bufferSize(int bufferSize) {
            this.bufferSize = bufferSize;
            return this;
        }

        public Builder<E> waitStrategy(WaitStrategy waitStrategy) {
            this.waitStrategy = waitStrategy;
            return this;
        }

        public Builder<E> threadFactory(ThreadFactory threadFactory) {
            this.threadFactory = threadFactory;
            return this;
        }

        public Builder<E> exceptionHandler(ExceptionHandler<ContextEvent<E>> exceptionHandler) {
            this.exceptionHandler = exceptionHandler;
            return this;
        }

        public Builder<E> consumer(Class<? extends ContextConsumer> consumer) {
            this.consumer = consumer;
            return this;
        }

        public LMaxDisruptor<E> build() {

            if (producerType == null) {
                this.producerType = ProducerType.MULTI;
            }
            if (eventFactory == null) {
                this.eventFactory = new ContextFactory<>();
            }
            if (waitStrategy == null) {
                this.waitStrategy = new SleepingWaitStrategy();
            }
            if (threadFactory == null) {
                this.threadFactory = new DefaultThreadFactory();
            }

            if (exceptionHandler == null) {
                this.exceptionHandler = new DefaultExceptionHandler<>();
            }

            if (consumer == null) {
                this.consumer = CustomizerExecuteConsumer.class;
            }

            return new LMaxDisruptor<>(this);
        }

    }
}
