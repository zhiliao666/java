package com.ufoto.lmax2.handlers;

import com.lmax.disruptor.dsl.Disruptor;
import com.ufoto.lmax2.event.ContextEvent;

/**
 * <p>
 * Author     : Chan
 * CreateDate : 2019/11/4 11:13
 * Description:
 * </p>
 */
public interface ConsumerCustomizer<T> {

    void consume(Disruptor<ContextEvent<T>> disruptor);

}
