package com.ufoto.lmax2.consumer;

/**
 * <p>
 * Description:
 *
 * </p>
 *
 * @author Chan
 * @date 2020/1/13 11:22
 */
public interface ClearEventHandler {

    default boolean clear() {
        return false;
    }

}
