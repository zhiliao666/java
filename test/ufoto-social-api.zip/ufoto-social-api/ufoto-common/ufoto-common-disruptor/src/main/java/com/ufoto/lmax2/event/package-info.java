/**
 * <p>
 * Author     : Chan
 * CreateDate : 2019/11/29 22:17
 * Description: 事件类
 * </p>
 */
package com.ufoto.lmax2.event;

