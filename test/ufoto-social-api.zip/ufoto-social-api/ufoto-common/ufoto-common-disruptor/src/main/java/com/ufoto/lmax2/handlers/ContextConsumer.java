package com.ufoto.lmax2.handlers;

/**
 * <p>
 * Author     : Chan
 * CreateDate : 2019/11/4 11:13
 * Description:
 * </p>
 */
public interface ContextConsumer<T> {

    void customizer(ConsumerCustomizer<T> consumerCustomizer);
}
