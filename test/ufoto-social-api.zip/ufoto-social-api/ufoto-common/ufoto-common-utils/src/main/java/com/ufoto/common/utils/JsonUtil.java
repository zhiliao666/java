package com.ufoto.common.utils;

import com.fasterxml.jackson.annotation.JsonProperty;
import com.fasterxml.jackson.core.type.TypeReference;
import com.fasterxml.jackson.databind.ObjectMapper;
import com.fasterxml.jackson.databind.type.TypeFactory;
import com.google.common.base.CaseFormat;
import com.google.common.collect.Maps;
import com.google.common.collect.Sets;
import com.ufoto.common.utils.factory.ObjectMapperFactory;
import lombok.extern.slf4j.Slf4j;
import org.apache.commons.lang3.reflect.FieldUtils;

import java.io.File;
import java.io.IOException;
import java.lang.reflect.Field;
import java.time.Instant;
import java.time.ZoneId;
import java.time.format.DateTimeFormatter;
import java.util.*;

/**
 * @author luozq
 * @date 2019/3/6/006
 */
@Slf4j
public class JsonUtil {

    private static ObjectMapper mapper = ObjectMapperFactory.getInstance();

    private final static TypeFactory TYPE_FACTORY = mapper.getTypeFactory();

    public static final DateTimeFormatter DATE_TIME_FORMATTER = DateTimeFormatter.ofPattern("yyyy-MM-dd HH:mm:ss");

    private static final Set<String> patternList = Sets.newHashSet("createTime", "updateTime", "modifyTime");

    /**
     * 对象转json字符串
     *
     * @param object 目标对象
     * @return json string
     */
    public static String toJson(Object object) {
        try {
            return mapper.writeValueAsString(object);
        } catch (Exception e) {
            log.error("toJson task occurs error, object:{}", object, e);
            throw new RuntimeException("json parse error, detail as follows:{}" + e.getMessage());
        }
    }


    public static Map<String, Object> objectToEsMap(Object obj, String ...param) throws IllegalAccessException {

        if (param.length > 0) {
            patternList.addAll(Arrays.asList(param));
        }
        Map<String, Object> map = Maps.newHashMap();
        Field[] fields = FieldUtils.getAllFields(obj.getClass());;
        for (Field field : fields) {
            // 驼峰下划线转换
            String fieldName = field.getName();
            JsonProperty jsonProperty = field.getDeclaredAnnotation(JsonProperty.class);
            String key;
            if (Objects.isNull(jsonProperty)) {
                key = CaseFormat.LOWER_CAMEL.to(CaseFormat.LOWER_UNDERSCORE, fieldName);
            } else {
                key = jsonProperty.value();
            }
            field.setAccessible(true);
            Object result = field.get(obj);
            // val 为空不写入es
            if (Objects.isNull(result)) {
                continue;
            }
            // 转换成es日期
            Class<?> type = field.getType();
            if (type.isAssignableFrom(Date.class)) {
                Date date = (Date) result;
                result = date.toInstant().atZone(ZoneId.systemDefault())
                        .toLocalDateTime().format(DATE_TIME_FORMATTER);
            } else if (patternList.contains(fieldName)) {
                // 时间戳转换成日期
                long time = Long.parseLong(result + "");
                result = Instant.ofEpochSecond(time).atZone(ZoneId.systemDefault())
                        .toLocalDateTime().format(DATE_TIME_FORMATTER);
            }
            map.put(key, result);
        }
        return map;
    }


    /**
     * json字符串转对象
     * 一般用于没有泛型的对象 例如ObjectBean
     *
     * @param json  json字符串
     * @param clazz 对象的class对象
     * @param <T>   实际对象类型,ObjectBean
     * @return 对象ObjectBean
     */
    public static <T> T toObject(String json, Class<T> clazz) {
        try {
            return mapper.readValue(json, clazz);
        } catch (Exception e) {
            log.error("toObject task occurs error, json:{}", json, e);
            throw new RuntimeException("json parse error, detail as follows:{}" + e.getMessage());
        }
    }

    /**
     * 当返回的是 List、Set、map等复杂对象的时候，需要传一个TypeReference
     *
     * @param json
     * @param type example: new TypeReference<Map<String,Object>>{}
     * @return
     */
    public static <T> T toObject(String json, TypeReference<T> type) {
        try {
            return mapper.readValue(json, type);
        } catch (Exception e) {
            log.error("toObject task occurs error, json:{}", json, e);
            throw new RuntimeException("json parse error, detail as follows:{}" + e.getMessage());
        }
    }

    /**
     * json字符串转list
     *
     * @param json         json字符串
     * @param genericClass list的泛型对象class，一般泛型对象不再具有泛型，例如List<ObjectBean>
     * @param <T>          泛型对象类型,ObjectBean
     * @return List<ObjectBean>
     */
    public static <T> List<T> toList(String json, Class<T> genericClass) {
        try {
            return mapper.readValue(json, TYPE_FACTORY.constructCollectionType(List.class, genericClass));
        } catch (IOException e) {
            log.error("toList task occurs error, json:{}", json, e);
            throw new RuntimeException("json parse error, detail as follows:{}" + e.getMessage());
        }
    }

    /**
     * json字符串转set
     *
     * @param json         json字符串
     * @param genericClass set的泛型对象class，一般泛型对象不再具有泛型，例如Set<ObjectBean>
     * @param <T>          泛型对象类型,ObjectBean
     * @return Set<ObjectBean>
     */
    public static <T> Set<T> toSet(String json, Class<T> genericClass) {
        try {
            return mapper.readValue(json, TYPE_FACTORY.constructCollectionType(Set.class, genericClass));
        } catch (IOException e) {
            log.error("toSet task occurs error, json:{}", json, e);
            throw new RuntimeException("json parse error, detail as follows:{}" + e.getMessage());
        }
    }

    /**
     * json字符串转map
     *
     * @param json       json字符串
     * @param keyClass   key的class对象
     * @param valueClass value的class对象
     * @param <K>        key的实际类型
     * @param <V>        value的实际类型，一般不再具有泛型
     * @return Map<K, V>
     */
    public static <K, V> Map<K, V> toMap(String json, Class<K> keyClass, Class<V> valueClass) {
        try {
            return mapper.readValue(json, TYPE_FACTORY.constructMapType(Map.class, keyClass, valueClass));
        } catch (IOException e) {
            log.error("toMap task occurs error, json:{}", json, e);
            throw new RuntimeException("json parse error, detail as follows:{}" + e.getMessage());
        }
    }

    /**
     * json字符串转map
     *
     * @param file       file文件
     * @param keyClass   key的class对象
     * @param valueClass value的class对象
     * @param <K>        key的实际类型
     * @param <V>        value的实际类型，一般不再具有泛型
     * @return Map<K, V>
     */
    public static <K, V> Map<K, V> toMap(File file, Class<K> keyClass, Class<V> valueClass) {
        try {
            return mapper.readValue(file, TYPE_FACTORY.constructMapType(Map.class, keyClass, valueClass));
        } catch (IOException e) {
            log.error("toMap task occurs error", e);
            throw new RuntimeException("json parse error, detail as follows:{}" + e.getMessage());
        }
    }

}
