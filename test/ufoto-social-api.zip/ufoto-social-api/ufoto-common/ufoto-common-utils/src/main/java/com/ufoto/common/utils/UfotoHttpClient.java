package com.ufoto.common.utils;

import lombok.extern.slf4j.Slf4j;
import org.apache.commons.io.IOUtils;
import org.apache.http.client.methods.CloseableHttpResponse;
import org.apache.http.client.methods.HttpGet;
import org.apache.http.client.methods.HttpPost;
import org.apache.http.entity.StringEntity;
import org.apache.http.impl.client.CloseableHttpClient;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;

import java.io.IOException;
import java.io.InputStream;
import java.net.URI;

/**
 *
 * @author zhangqh
 * @date 2017年12月15日
 */
@Component
@Slf4j
public class UfotoHttpClient {

    private static Logger logger = LoggerFactory.getLogger(UfotoHttpClient.class);

    @Autowired
    HttpConnectionManager connManager;

    /**
     * 普通的get方法
     * @param path
     * @return
     */
    public String get(String path) {
        CloseableHttpClient httpClient = connManager.getHttpClient();
        HttpGet httpget = new HttpGet(path);
        String json = null;
        CloseableHttpResponse response = null;
        try {
            response = httpClient.execute(httpget);
            InputStream in = response.getEntity().getContent();
            json = IOUtils.toString(in);
            in.close();
        } catch (UnsupportedOperationException e) {
            log.error(e.getMessage());
        } catch (IOException e) {
            log.error(e.getMessage());
        } finally {
            finallyClose(response);
        }
        return json;
    }

    private void finallyClose(CloseableHttpResponse response) {
        if (response != null) {
            try {
                response.close();
            } catch (IOException e) {
                log.error(e.getMessage());
            }
        }
    }

    /**
     * 带权限的 get
     * @param url
     * @param authorization
     * @return
     */
    public String httpGetByAuthorization(String url, String authorization) {
        String json = null;
        CloseableHttpResponse response = null;
        try {
            HttpGet hget = new HttpGet(url);
            hget.setHeader("Authorization", "Bearer " + authorization);
            response = connManager.getHttpClient().execute(hget);
            InputStream in = response.getEntity().getContent();
            json = IOUtils.toString(in);
            logger.debug(json);
            in.close();
        } catch (IOException e) {
            log.error(e.getMessage());
        } finally {
            finallyClose(response);
        }
        return json;
    }

    /**
     * HttpClient 发送post
     * @param url
     * @param data
     * @param authorization
     * @return
     */
    public String httpClientPost(String url, String data, String authorization) {
        HttpPost httpPost = new HttpPost(url);
        StringEntity entity;
        CloseableHttpResponse response = null;
        String json = null;
        try {
            entity = new StringEntity(data);
            httpPost.setEntity(entity);
            httpPost.setHeader("Accept", "application/json");
            httpPost.setHeader("Content-type", "application/json;charset=UTF-8");
            if (authorization != null && !"".equals(authorization)) {
                httpPost.setHeader("Authorization", authorization);
            }
            response = connManager.getHttpClient().execute(httpPost);
            //logger.debug(JSON.toJSONString(response));
            InputStream in = response.getEntity().getContent();
            json = IOUtils.toString(in);
            in.close();
        } catch (Exception e) {
            log.error(e.getMessage());
        } finally {
            finallyClose(response);
        }
        return json;
    }


    /**
     * HttpClient 发送post
     * @param uri
     * @param data
     * @return
     */
    public String postUri(URI uri, String data) {
        HttpPost httpPost = new HttpPost(uri);
        StringEntity entity;
        CloseableHttpResponse response = null;
        String json = null;
        try {
            entity = new StringEntity(data);
            httpPost.setEntity(entity);
            httpPost.setHeader("Accept", "application/json");
            httpPost.setHeader("Content-type", "application/json;charset=UTF-8");
            response = connManager.getHttpClient().execute(httpPost);
            if(response.getStatusLine().getStatusCode() != 200){
                log.error("TIM Internal error, statusCode:{}", response.getStatusLine().getStatusCode());
            }
            InputStream in = response.getEntity().getContent();
            json = IOUtils.toString(in);
            in.close();
        } catch (Exception e) {
            log.error(e.getMessage());
        } finally {
            finallyClose(response);
        }
        return json;
    }

}
