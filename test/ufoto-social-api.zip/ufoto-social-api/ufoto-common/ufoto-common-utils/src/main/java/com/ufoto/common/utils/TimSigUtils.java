package com.ufoto.common.utils;

import com.tencentyun.TLSSigAPIv2;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.core.env.Environment;
import org.springframework.stereotype.Component;

/**
 *
 * @Author Wang, Qing
 * @Date 2019/10/21 10:55
 * 获取sig接口
 */
@Component
public class TimSigUtils {

    private final Environment env;

    @Autowired
    public TimSigUtils(Environment env) {
        this.tlsSigAPIv2 = new TLSSigAPIv2(
            env.getProperty("tim.sdk.appid", Long.class),
            env.getProperty("tim.sdk.key", String.class)
        );
        this.env = env;
    }

    private TLSSigAPIv2 tlsSigAPIv2;

    public String getTimSig(String uid) {
        return tlsSigAPIv2
            .genSig(uid, env.getProperty("tim.sdk.sig.ttl", Long.class, 7 * 86400L));
    }

    public String getTimSig(String uid, Long ttl) {
        return tlsSigAPIv2.genSig(uid, ttl);
    }
}
