package com.ufoto.common.utils;

import com.google.common.base.Joiner;
import com.google.common.collect.Lists;
import lombok.extern.slf4j.Slf4j;
import org.apache.commons.collections.MapUtils;

import java.util.Calendar;
import java.util.Date;
import java.util.List;
import java.util.Map;
import java.util.Random;
import java.util.Set;
import java.util.concurrent.ConcurrentHashMap;
import java.util.function.Function;
import java.util.function.Predicate;

/**
 * <p>
 * Author     : Chan
 * CreateDate : 2018-12-26 14:55
 * Description:
 * </p>
 */
@Slf4j
public class CommonUtil {
    public static Boolean obj2Boolean(Object obj) {
        if (obj == null) {
            return false;
        }

        if (Boolean.class.isAssignableFrom(obj.getClass())) {
            return (Boolean) obj;
        }
        throw new RuntimeException("目标Obj不是Boolean类型，转换错误");
    }

    public static List obj2List(Object obj) {
        if (obj == null) {
            return Lists.newArrayList();
        }

        if (List.class.isAssignableFrom(obj.getClass())) {
            return (List) obj;
        }
        throw new RuntimeException("目标Obj不是Boolean类型，转换错误");
    }

    public static Double obj2Double(Object obj) {
        if (obj == null) {
            return 0d;
        }

        if (Double.class.isAssignableFrom(obj.getClass())) {
            return (Double) obj;
        }
        throw new RuntimeException("目标Obj不是Double类型，转换错误");
    }

    /**
     * String 转换成 Integer，格式不对返回null
     *
     * @return 可能为null
     */
    public static Integer safeString2Integer(String string) {
        try {
            return Integer.parseInt(string);
        } catch (NumberFormatException e) {
            return null;
        }
    }

    /**
     * String 转换成 Long，格式不对返回null
     *
     * @return 可能为null
     */
    public static Long safeString2Long(String string) {
        try {
            return Long.parseLong(string);
        } catch (NumberFormatException e) {
            return null;
        }
    }

    public static String addQuote(Object str) {
        return "\"" + str + "\"";
    }

    public static int[] randomCommon(int min, int max, int n) {
        int[] result = new int[n];
        int count = 0;
        while (count < n) {
            int num = (int) (Math.random() * (max - min)) + min;
            boolean flag = true;
            for (int j = 0; j < n; j++) {
                if (num == result[j]) {
                    flag = false;
                    break;
                }
            }
            if (flag) {
                result[count] = num;
                count++;
            }
        }
        return result;
    }

    public static String handleLangAndMap(String lang, Map<String, String> map) {
        if (MapUtils.isEmpty(map)) return lang;
        StringBuilder sb = new StringBuilder();
        sb.append(lang).append(":");
        final Set<String> keys = map.keySet();
        for (String key : keys) {
            sb.append(map.get(key)).append(":");
        }
        sb.deleteCharAt(sb.length() - 1);
        return sb.toString();
    }

    public static String handleGoodsTypeLangMap(Integer goodsType, String lang, Map<String, String> map) {
        if (MapUtils.isEmpty(map)) return lang;
        StringBuilder sb = new StringBuilder();
        sb.append(goodsType).append(":");
        sb.append(lang).append(":");
        final Set<String> keys = map.keySet();
        for (String key : keys) {
            sb.append(map.get(key)).append(":");
        }
        sb.deleteCharAt(sb.length() - 1);
        log.debug("handleGoodsTypeLangMap : {}", sb);
        return sb.toString();
    }

    public static Date age2Birth(Integer age) {
        if (age == null) return null;
        Calendar c = Calendar.getInstance();
        c.set(Calendar.MONTH, 0);
        c.set(Calendar.DAY_OF_MONTH, 1);
        c.set(Calendar.HOUR_OF_DAY, 0);
        c.set(Calendar.MINUTE, 0);
        c.set(Calendar.SECOND, 0);
        c.set(Calendar.YEAR, c.get(Calendar.YEAR) - age);
        return c.getTime();
    }

    public static Integer getRandomInt() {
        return new Random().nextInt(Integer.MAX_VALUE);
    }

    public static boolean isNumber(String s) {
        try {
            Double.parseDouble(s);
            return true;
        } catch (Exception e) {
            return false;
        }
    }

    public static String serializeUid(String uid) {
        if (uid == null) return null;
        return Joiner.on("").join("\"", uid, "\"");
    }

    public static <T> Predicate<T> distinctByKey(Function<? super T, ?> keyExtractor) {
        Set<Object> seen = ConcurrentHashMap.newKeySet();
        return t -> seen.add(keyExtractor.apply(t));
    }
}
