package com.ufoto.common.utils;

import org.apache.commons.lang3.StringUtils;

/**
 * <p>
 * Author     : Chan
 * CreateDate : 2019/11/19 17:04
 * Description:
 * </p>
 */
public class GeoUtil {

    private static final double GEO_LAT_MIN = -85.05112878;
    private static final double GEO_LAT_MAX = 85.05112878;
    private static final double GEO_LONG_MIN = -180;
    private static final double GEO_LONG_MAX = 180;

    public static boolean checkLongLat(String longitude, String latitude) {
        if (StringUtils.isBlank(longitude)
                || StringUtils.isBlank(latitude)) {
            return false;
        }
        try {
            double lg = Double.parseDouble(longitude);
            double la = Double.parseDouble(latitude);
            return la <= GEO_LAT_MAX && la >= GEO_LAT_MIN && lg >= GEO_LONG_MIN && lg <= GEO_LONG_MAX;
        } catch (NumberFormatException e) {
            return false;
        }
    }

}
