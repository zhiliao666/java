package com.ufoto.common.utils;

import lombok.Data;

import java.io.Serializable;

/**
 * api 返回结果包装类
 *
 * @author zhangqh
 * @date 2017年11月23日
 */
@Data
public class ApiResult<T> implements Serializable {
    public static final int successCode = 200;
    //系统异常
    public static final int errorCode500 = 500;
    //token失效
    public static final int errorCode301 = 301;
    //参数错误
    public static final int errorCode302 = 302;

    /**
     * 返回状态码 200 成功 301 token失效 500 系统异常
     */
    private Integer c;
    /**
     * 对应返回码说明
     */
    private String m;
    /**
     * 具体返回数据
     */
    private T d;

    /**
     * 自定义错误码
     *
     * @param errorCode code
     * @param errorMsg  msg
     * @return
     */
    public ApiResult<T> setError(int errorCode, String errorMsg) {
        this.c = errorCode;
        this.m = errorMsg;
        return this;
    }

    public ApiResult<T> setResult(T result) {
        this.c = successCode;
        this.m = "success";
        this.d = result;
        return this;
    }
}

