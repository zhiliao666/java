package com.ufoto.common.utils;

import com.fasterxml.jackson.core.type.TypeReference;
import com.fasterxml.jackson.databind.ObjectMapper;
import lombok.extern.slf4j.Slf4j;
import org.apache.commons.beanutils.PropertyUtils;
import org.apache.commons.lang3.ClassUtils;
import org.apache.commons.lang3.StringUtils;

import java.beans.PropertyDescriptor;
import java.lang.reflect.InvocationTargetException;
import java.lang.reflect.Method;
import java.lang.reflect.Modifier;
import java.util.Arrays;
import java.util.List;
import java.util.Map;
import java.util.Objects;

/**
 * <p>
 *
 * </p>
 *
 * @author created by chenzhou at 2018-06-06 11:51
 */
@Slf4j
public abstract class BeanUtil {

    /**
     * 拷贝对象的属性到另一个对象   参考BeanUtils.copyProperties()实现
     *
     * @param source           源对象
     * @param target           返回目标类
     * @param ignoreProperties 忽略属性名称
     * @return target
     */
    public static <T> T copyProperties(Object source, T target, String... ignoreProperties) {
        Objects.requireNonNull(source, "Source must not be null");
        Objects.requireNonNull(target, "Target must not be null");
        Class targetClass = target.getClass();
        Class sourceClass = source.getClass();

        PropertyDescriptor[] targetPds = PropertyUtils.getPropertyDescriptors(targetClass);
        PropertyDescriptor[] sourcePds = PropertyUtils.getPropertyDescriptors(sourceClass);

        List<String> ignoreList = (ignoreProperties != null ? Arrays.asList(ignoreProperties) : null);
        try {
            if (targetPds.length <= sourcePds.length) {
                for (PropertyDescriptor targetPd : targetPds) {
                    Method writeMethod = targetPd.getWriteMethod();
                    if (writeMethod == null || (ignoreList != null && ignoreList.contains(targetPd.getName())))
                        continue;
                    PropertyDescriptor sourcePd = PropertyUtils.getPropertyDescriptor(source, targetPd.getName());
                    if (sourcePd == null) continue;
                    Method readMethod = sourcePd.getReadMethod();
                    if (readMethod == null || !ClassUtils.isAssignable(writeMethod.getParameterTypes()[0], readMethod.getReturnType()))
                        continue;
                    readWriteInvoke(source, target, targetPd, writeMethod, readMethod);
                }
            } else {
                for (PropertyDescriptor sourcePd : sourcePds) {
                    Method readMethod = sourcePd.getReadMethod();
                    if (readMethod == null || (ignoreList != null && ignoreList.contains(sourcePd.getName()))) continue;
                    PropertyDescriptor targetPd = PropertyUtils.getPropertyDescriptor(targetClass, sourcePd.getName());
                    if (targetPd == null) continue;
                    Method writeMethod = targetPd.getWriteMethod();
                    if (writeMethod == null || !ClassUtils.isAssignable(writeMethod.getParameterTypes()[0], readMethod.getReturnType()))
                        continue;

                    readWriteInvoke(source, target, targetPd, writeMethod, readMethod);

                }
            }
        } catch (IllegalAccessException | InvocationTargetException | NoSuchMethodException e) {
            throw new RuntimeException(e);
        }
        return target;
    }

    private static <T> void readWriteInvoke(Object source, T target, PropertyDescriptor targetPd, Method writeMethod, Method readMethod) {
        try {
            if (!Modifier.isPublic(readMethod.getDeclaringClass().getModifiers())) {
                readMethod.setAccessible(true);
            }
            Object value = readMethod.invoke(source);
            if (!Modifier.isPublic(writeMethod.getDeclaringClass().getModifiers())) {
                writeMethod.setAccessible(true);
            }
            writeMethod.invoke(target, value);
        } catch (Throwable ex) {
            throw new RuntimeException("Could not copy property '" + targetPd.getName() + "' from source to target", ex);
        }
    }

    /**
     * 拷贝对象的属性到另一个对象 (只拷贝源对象参数值不为空的属性，如果为空则跳过)
     *
     * @param source           源对象
     * @param target           返回目标类
     * @param ignoreProperties 忽略属性名称
     * @return target
     */
    public static <T> T copyPropertiesByNotNull(Object source, T target, String... ignoreProperties) throws IllegalAccessException, NoSuchMethodException, InvocationTargetException {
        Objects.requireNonNull(source, "Source must not be null");
        Objects.requireNonNull(target, "Target must not be null");
        Class targetClass = target.getClass();
        Class sourceClass = source.getClass();

        PropertyDescriptor[] targetPds = PropertyUtils.getPropertyDescriptors(targetClass);
        PropertyDescriptor[] sourcePds = PropertyUtils.getPropertyDescriptors(sourceClass);

        List<String> ignoreList = (ignoreProperties != null ? Arrays.asList(ignoreProperties) : null);
        if (targetPds.length <= sourcePds.length) {
            for (PropertyDescriptor targetPd : targetPds) {
                Method writeMethod = targetPd.getWriteMethod();
                if (writeMethod == null || (ignoreList != null && ignoreList.contains(targetPd.getName()))) continue;
                PropertyDescriptor sourcePd = PropertyUtils.getPropertyDescriptor(sourceClass, targetPd.getName());
                if (sourcePd == null) continue;
                Method readMethod = sourcePd.getReadMethod();
                if (readMethod == null || !ClassUtils.isAssignable(writeMethod.getParameterTypes()[0], readMethod.getReturnType()))
                    continue;
                readWriteNotNullInvoke(source, target, targetPd, writeMethod, readMethod);
            }
        } else {
            for (PropertyDescriptor sourcePd : sourcePds) {
                Method readMethod = sourcePd.getReadMethod();
                if (readMethod == null || (ignoreList != null && ignoreList.contains(sourcePd.getName()))) continue;
                PropertyDescriptor targetPd = PropertyUtils.getPropertyDescriptor(targetClass, sourcePd.getName());
                if (targetPd == null) continue;
                Method writeMethod = targetPd.getWriteMethod();
                if (writeMethod == null || !ClassUtils.isAssignable(writeMethod.getParameterTypes()[0], readMethod.getReturnType()))
                    continue;

                readWriteNotNullInvoke(source, target, targetPd, writeMethod, readMethod);

            }
        }
        return target;
    }

    private static <T> void readWriteNotNullInvoke(Object source, T target, PropertyDescriptor targetPd, Method writeMethod, Method readMethod) {
        try {
            if (!Modifier.isPublic(readMethod.getDeclaringClass().getModifiers())) {
                readMethod.setAccessible(true);
            }
            Object value = readMethod.invoke(source);
            if (value == null || StringUtils.isBlank(value.toString())) return;
            if (!Modifier.isPublic(writeMethod.getDeclaringClass().getModifiers())) {
                writeMethod.setAccessible(true);
            }
            writeMethod.invoke(target, value);
        } catch (Throwable ex) {
            throw new RuntimeException("Could not copy property '" + targetPd.getName() + "' from source to target", ex);
        }
    }


    /**
     * bean to Map
     *
     * @param t   obj
     * @param <T> t
     * @return map
     */
    @SuppressWarnings("unchecked")
    public static <T> Map<String, Object> beanToMap(T t) {
        try {
            ObjectMapper mapper = new ObjectMapper();
            Map<String, Object> map = mapper.convertValue(t, new TypeReference<Map<String, Object>>() {
            });
            return map;
        } catch (Exception e) {
            log.error("beanToMap task occurs error, obj:{}", t, e);
            return null;
        }
    }
}
