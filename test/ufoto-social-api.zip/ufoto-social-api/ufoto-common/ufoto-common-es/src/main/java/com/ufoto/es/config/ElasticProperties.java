package com.ufoto.es.config;

import lombok.Data;
import org.springframework.boot.context.properties.ConfigurationProperties;
import org.springframework.stereotype.Component;

/**
 * elasticsearch 参数配置
 * @author luozq
 * @date 2019/9/12 10:06
 */
@Data
@Component
@ConfigurationProperties(prefix = "elastic.config")
public class ElasticProperties {

    private  String serviceName = "es";

    private  String region = "us-east-1";

    private  String awsEndpoint = "search-beta-ufoto-es-xeae6bnesjllun3zm2xizdqqui.us-east-1.es.amazonaws.com";

    /**
     * elastic http port
     */
    private int port = 9200;

    /**
     * 支持的协议, http, https
     */
    private String schema = "http";

    /**
     * elastic 环境, 分为以下三种(不区分大小写):
     *  开发环境: dev
     *  beta测试环境: beta
     *  prod线上环境: prod
     */
    private String env = "dev";

    /**
     * 连接超时时间
     */
    private  int connectTimeOut = 1000;
    /**
     * 连接超时时间
     */
    private  int socketTimeOut = 30000;
    /**
     * 获取连接的超时时间
     */
    private  int connectionRequestTimeOut = 500;

    /**
     * 最大连接数
     */
    private int maxConnectNum = 100;

    /**
     * 最大路由连接数
     */
    private int maxConnectPerRoute = 100;

    /**
     * elasticsearch 集群节点刷新时间，单位毫秒
     */
    private int sniffIntervalTime = 60000;
}
