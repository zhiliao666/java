package com.ufoto.es;
/*
 * File Created: Wednesday, 2020/02/26 16:52:22
 * Last Modified: Wednesday, 2020/02/26 16:53:04
 * 
 * description: 
 *  管理ES相关依赖及工具
 * Author: Chan
 * Modified By: Chan
 * Copyright 2020 - 2020 ufoto
 */
