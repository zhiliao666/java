package com.ufoto.es.config;

import lombok.extern.slf4j.Slf4j;
import org.elasticsearch.action.ActionListener;
import org.elasticsearch.action.ActionResponse;
import org.elasticsearch.action.DocWriteResponse;
import org.elasticsearch.action.bulk.BulkResponse;
import org.elasticsearch.action.support.replication.ReplicationResponse;
import org.elasticsearch.client.RequestOptions;
import org.elasticsearch.common.unit.TimeValue;
import org.elasticsearch.index.reindex.BulkByScrollResponse;
import org.elasticsearch.rest.RestStatus;

import java.util.stream.Stream;

/**
 * define and get elastic async listener
 * @author luozq
 * @date 2019/9/12 13:43
 */
@Slf4j
public class CustomElasticListener {

    /**
     * get the write listener, detail action as follows:
     * Index, Update, Delete
     * @param data data
     * @return listener
     */
    public static <T extends DocWriteResponse> ActionListener<T> getWriteListener(Object data) {
        return new ActionListener<T>() {
            @Override
            public void onResponse(DocWriteResponse response) {
                String index = response.getIndex();
                RestStatus status = response.status();
                ReplicationResponse.ShardInfo shardInfo = response.getShardInfo();
                String docId = response.getId();
                log.info("listener succeed, index:{}, docId:{}, status:{}, shardState:{}",
                        index, docId, status, shardInfo.status());
                // record fail msg
                if (shardInfo.getFailed() > 0) {
                    Stream.of(shardInfo.getFailures()).forEach(item ->
                            log.error("index:{}, docId:{}", index, docId, item.getCause()));
                }
            }

            @Override
            public void onFailure(Exception e) {
                // if exists error, write into log
                log.error("es action task occurs error, msg:{}", data, e);
            }
        };
    }

    /**
     * define and get action listener
     * @param data data
     * @param <T> t
     * @return action listener
     */
    public static <T extends ActionResponse> ActionListener<T> getActionListener(Object data) {
        return new ActionListener<T>() {
            @Override
            public void onResponse(T res) {
                if (res instanceof BulkResponse) {
                    BulkResponse responses = (BulkResponse) res;
                    TimeValue costTime = responses.getTook();
                    String failMsg = responses.buildFailureMessage();
                    boolean hasFailures = responses.hasFailures();
                    if (hasFailures) {
                        log.warn("bulk update task succeed, costTime:{}, hasFailures:{}, failMsg:{}",
                                costTime, failMsg, true);
                    }
                } else if (res instanceof BulkByScrollResponse) {
                    BulkByScrollResponse response = (BulkByScrollResponse) res;
                    log.info("bulk by scroll task succeed,  result: {}", response.toString());
                }

            }

            @Override
            public void onFailure(Exception e) {
                // if exists error, write into log
                log.error("es action task occurs error, msg:{}", data, e);

            }
        };
    }

    /**
     * set the head
     * @return request options
     */
    public static RequestOptions getReferOptions() {
        RequestOptions.Builder optionBuilder = RequestOptions.DEFAULT.toBuilder();
        optionBuilder.addHeader("content-type", "application/json");
        return optionBuilder.build();
    }
}
