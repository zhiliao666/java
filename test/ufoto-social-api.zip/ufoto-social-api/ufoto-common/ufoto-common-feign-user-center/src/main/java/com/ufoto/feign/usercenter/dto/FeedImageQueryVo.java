package com.ufoto.feign.usercenter.dto;

import lombok.Data;

import java.io.Serializable;
import java.util.List;

/**
 * @author luozq
 * @date 2019/9/23 16:29
 */
@Data
public class FeedImageQueryVo implements Serializable {

    /**
     * uid
     */
    private Long uid;

    /**
     * 0 不可见， 1 可见, 可不传(不传则是查询所有可见级别的图片)
     */
    private List<Integer> visibleList;

    /**
     * 0 默认，swipe图片， 1 DNA, 2 摇钱树, 3 贴纸活动, 可不传(不传则是获取所有来源的图片),
     */
    private List<Integer> typeList;

    private Integer startTime;//分页数据的起始时间
    /**
     * 0 自己， 1 他人
     */
    private Integer self;
    /**
     * query page
     */
    private Integer page = 1;

    /**
     * page size
     */
    private Integer pageSize = 10;

    //文件类型列表
    private List<Integer> fileTypeList;
}
