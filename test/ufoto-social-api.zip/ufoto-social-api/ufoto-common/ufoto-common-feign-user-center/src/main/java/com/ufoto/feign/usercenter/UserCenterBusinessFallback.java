package com.ufoto.feign.usercenter;

import com.ufoto.infrastructure.metric.feign.circuitbreaker.AbstractFallbackFactory;
import org.springframework.stereotype.Component;

/**
 * <p>
 * Author     : Chan
 * CreateDate : 2019-03-19 10:05
 * Description:
 * </p>
 */
@Component
public class UserCenterBusinessFallback extends AbstractFallbackFactory<UserCenterBusiness> {

    private final UserCenterBusinessHystrix userInfoControllerHystrix;

    public UserCenterBusinessFallback(UserCenterBusinessHystrix userInfoControllerHystrix) {
        this.userInfoControllerHystrix = userInfoControllerHystrix;
    }

    @Override
    protected UserCenterBusiness doCreate() {
        return userInfoControllerHystrix;
    }
}
