package com.ufoto.feign.usercenter.dto;

import lombok.Data;

import java.io.Serializable;
import java.util.List;

@Data
public class UserConditionDto implements Serializable {
    private List<Long> uids;//id列表
    private Integer isDelete;//是否已删除
    private Integer legitimateEmail;//邮箱是否合法
    private Integer type;//用户类型0 robot 1 fb 2 gg
    private List<Integer> types;//机器人 0 101 102 103 104
    private Integer gender;
}
