package com.ufoto.feign.usercenter;


import com.ufoto.common.utils.ApiResult;
import com.ufoto.feign.usercenter.dto.AdditionalUserInfoVo;
import com.ufoto.feign.usercenter.dto.BaseUserInfoEditVo;
import com.ufoto.feign.usercenter.dto.FeedImageDelVo;
import com.ufoto.feign.usercenter.dto.FeedImageVisibleVo;
import com.ufoto.feign.usercenter.dto.UfotoUserReportVo;
import com.ufoto.feign.usercenter.dto.UserAdditionalInfoDo;
import com.ufoto.feign.usercenter.dto.UserBaseInfoDto;
import com.ufoto.feign.usercenter.dto.UserCallBackInfoDto;
import com.ufoto.feign.usercenter.dto.UserConditionDto;
import com.ufoto.feign.usercenter.dto.UserImageCountDto;
import com.ufoto.feign.usercenter.dto.UserImageCountVo;
import com.ufoto.feign.usercenter.dto.UserInfoDto;
import com.ufoto.feign.usercenter.dto.UserInfoEditVo;
import com.ufoto.feign.usercenter.dto.UserLoginCallBackVo;
import org.springframework.cloud.openfeign.FeignClient;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestParam;

import java.util.List;
import java.util.Map;

/**
 * <p>
 * Author     : Chan
 * CreateDate : 2019-03-19 10:05
 * Description:
 * </p>
 */
@FeignClient(name = "UFOTO-USER-CENTER", fallbackFactory = UserCenterBusinessFallback.class)
public interface UserCenterBusiness {
    /**
     * 登录回调
     *
     * @param callBackVo 回调产生的信息
     * @return 用户信息
     */
    @PostMapping("/v1/user/login/callback")
    ApiResult<UserCallBackInfoDto> loginCallback(@RequestBody UserLoginCallBackVo callBackVo);


    @GetMapping("/v1/user/{uid}/getUserBaseInfo")
    ApiResult<UserBaseInfoDto> getUserBaseInfo(@PathVariable(value = "uid") Long uid);

    /**
     * 根据用户id列表获取用户基本信息
     *
     * @param idList 用户id列表
     * @return 用户列表信息
     */
    @PostMapping("/v1/user/getUserBaseInfoList")
    ApiResult<List<UserBaseInfoDto>> getUserBaseInfoList(@RequestBody List<Long> idList);

    /**
     * 登出
     *
     * @param uid
     * @return
     */
    @GetMapping("/v1/user/{uid}/logout")
    ApiResult<Boolean> logout(@PathVariable(value = "uid") Long uid);

    /**
     * 获取用户额外信息: 工作, 教育, 兴趣信息
     *
     * @return 获取额外信息
     */
    @GetMapping("/v1/user/{uid}/getUserAdditionalInfo")
    ApiResult<UserAdditionalInfoDo> getUserAdditionalInfo(@PathVariable(value = "uid") Long uid);


    /**
     * 编辑用户基本信息
     *
     * @param editVo 用户基本信息
     * @return true: 编辑成功, false: 编辑失败
     */
    @PostMapping("/v1/user/editUserBaseInfo")
    ApiResult<Boolean> editUserBaseInfo(@RequestBody BaseUserInfoEditVo editVo);


    /**
     * 编辑用户额外信息
     *
     * @param userInfoVo 用户额外信息
     * @return true: 编辑成功, false: 编辑失败
     */
    @PostMapping("/v1/user/editUserAdditionalInfo")
    ApiResult<Boolean> editUserAdditionalInfo(@RequestBody AdditionalUserInfoVo userInfoVo);

    /**
     * 根据用户id查询用户所有信息
     *
     * @param uid 用户id
     * @return 用户信息查询结果
     */
    @PostMapping("/v1/user/{uid}/getUserInfo")
    ApiResult<UserInfoDto> getUserInfo(@PathVariable(value = "uid") Long uid, @RequestParam("self") Integer self);

    /**
     * 编辑用户信息
     *
     * @param userInfoVo
     * @return
     */
    @PostMapping("/v1/user/editUserInfo")
    ApiResult<Boolean> editUserInfo(@RequestBody UserInfoEditVo userInfoVo);

    @PostMapping("/v2/user/editUserInfo")
    ApiResult<UserBaseInfoDto> editUserInfoV2(@RequestBody UserInfoEditVo userInfoVo);

    /**
     * 根据用户uuid查询用户基本信息
     *
     * @param uuid 用户uuid
     * @return 获取基本信息
     */
    @GetMapping("/v1/user/getUserBaseInfoByUUid")
    ApiResult<UserBaseInfoDto> getUserBaseInfoByUUid(@RequestParam(value = "uuid", required = false) String uuid);

    /**
     * 获取机器人列表
     *
     * @return 机器人
     */
    @PostMapping("/v1/user/conditions")
    ApiResult<List<UserBaseInfoDto>> conditionLists(@RequestBody UserConditionDto userConditionDto);

    @GetMapping("/v1/user/{uid}/gender")
    ApiResult<Integer> getGender(@PathVariable(value = "uid") Long uid);

    @DeleteMapping("/v1/user/{uid}")
    ApiResult<Boolean> deleteUser(@PathVariable(value = "uid") long uid);

    @GetMapping("/v1/user/robots")
    ApiResult<List<UserBaseInfoDto>> robots();

    @GetMapping("/v1/user/{f_uid}/bind/{t_uuid}")
    ApiResult<Boolean> bindVisitor(@PathVariable(value = "f_uid") Long fUid,
                                   @PathVariable(value = "t_uuid") String tUUid);

    @PostMapping("/v1/user/{uid}/feed/visible")
    ApiResult<Boolean> updateFeedVisible(@PathVariable(value = "uid") Long uid,
                                         @RequestBody List<FeedImageVisibleVo> visibleVoList);

    @PostMapping("/v1/user/{uid}/feed/delete")
    ApiResult<Boolean> deleteFeedImage(@PathVariable(value = "uid") Long uid,
                                       @RequestBody List<FeedImageDelVo> delVoList);

    @GetMapping("/v1/user/{uid}/feed/slide/check")
    ApiResult<Boolean> slideCheck(@PathVariable("uid") Long uid);

    @GetMapping("/v1/user/feed/local/head/img")
    ApiResult<List<String>> localHeadImg();

    @GetMapping(path = "/v1/user/{uid}/exist")
    ApiResult<Boolean> userExist(@PathVariable("uid") Long uid);

    /**
     * @param idList
     * @return map, key: uid, value: first_img in ufoto_user_image status
     */
    @PostMapping("/v1/user/feed/firstImg/state")
    ApiResult<Map<Long, Integer>> checkFirstImageState(@RequestBody List<Long> idList);

    @PostMapping("/v1/user/{uid}/report/{reportUid}")
    ApiResult<Boolean> saveReportInfo(@PathVariable("uid") Long uid,
                                      @PathVariable("reportUid") Long reportUid,
                                      @RequestBody UfotoUserReportVo reportVo);

    @GetMapping("/v1/user/getRandomUsername")
    ApiResult<List<String>> getRandomUsername(@RequestParam("size") Integer size);

    @PostMapping("/v1/user/feed/image/count")
    ApiResult<List<UserImageCountDto>> getImageCount(@RequestBody UserImageCountVo countVo);

}
