package com.ufoto.feign.usercenter.dto;

import com.fasterxml.jackson.annotation.JsonProperty;
import lombok.Data;
import org.springframework.format.annotation.DateTimeFormat;

import java.io.Serializable;
import java.util.Date;

/**
 * 登录回调返回结果集
 *
 * @author luozq
 * @date 2019/3/7/007
 */
@Data
public class UserCallBackInfoDto implements Serializable {

    /**
     * 用户id
     */
    @JsonProperty("uid")
    private Long uId;
    /**
     * 聊天需要token
     */
    private String token;
    /**
     * 用户头像
     */
    private String headImg;

    private String firstImg;
    /**
     * 用户类型 1 FB用户 2 Gmail用户
     */
    private Integer type;
    /**
     * 性别 1 男 2 女
     */
    private Integer gender;
    /**
     * 用户名称
     */
    private String userName;
    /**
     * 生日时间
     */
    @DateTimeFormat(pattern = "yyyy-MM-dd")
    private Date birthTime;
    /**
     * 是否新用户
     */
    private boolean ifNewUser;

    /**
     * 来源
     */
    private Integer fromType;
    /**
     * 语言
     */
    private String lang;

    private Integer age;
}
