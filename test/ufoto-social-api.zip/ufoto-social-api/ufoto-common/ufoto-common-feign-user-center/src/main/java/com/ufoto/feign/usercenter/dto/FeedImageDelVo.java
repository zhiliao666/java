package com.ufoto.feign.usercenter.dto;

import lombok.Data;

import java.io.Serializable;

/**
 * @author luozq
 * @date 2019/9/23 17:12
 */
@Data
public class FeedImageDelVo implements Serializable {

    private Long id;

    private Long uid;
}
