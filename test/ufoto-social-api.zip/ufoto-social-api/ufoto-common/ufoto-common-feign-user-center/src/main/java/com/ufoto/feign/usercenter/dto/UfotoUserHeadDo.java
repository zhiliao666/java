package com.ufoto.feign.usercenter.dto;

import com.fasterxml.jackson.annotation.JsonProperty;
import lombok.Data;

import java.io.Serializable;
import java.util.Objects;

/**
 * @author luozq
 * @date 2019/3/8/008
 */
@Data
public class UfotoUserHeadDo implements Serializable {

    /**
     * 创建时间
     */
    private Integer createTime;
    /**
     * id
     */
    private Long id;
    /**
     * 头图url
     */
    private String url;
    /**
     * 序号，从0开始
     */
    private Integer num;
    /**
     * 审核状态 默认0 未审核, 1 审核通过, 2 非法图片, 3 审核异常
     */
    private Integer status;
    /**
     * 用户id
     */
    @JsonProperty("uId")
    private Long uId;

    @Override
    public boolean equals(Object o) {
        if (this == o) {
            return true;
        }
        if (o == null || getClass() != o.getClass()) {
            return false;
        }
        UfotoUserHeadDo headDo = (UfotoUserHeadDo) o;
        return Objects.equals(url, headDo.url) &&
                Objects.equals(uId, headDo.uId);
    }

    @Override
    public int hashCode() {
        return Objects.hash(url, uId);
    }
}
