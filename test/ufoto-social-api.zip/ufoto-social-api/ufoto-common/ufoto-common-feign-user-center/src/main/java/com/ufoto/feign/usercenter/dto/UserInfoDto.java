package com.ufoto.feign.usercenter.dto;


import lombok.Data;

import java.io.Serializable;
import java.util.List;

/**
 * 用户所有信息
 *
 * @author luozq
 * @date 2019/3/20/020
 */
@Data
public class UserInfoDto implements Serializable {

    /**
     * 用户基本信息
     */
    private UserBaseInfoDto baseInfo;
    /**
     * 用户拓展信息
     */
    private UserAdditionalInfoDo additionInfo;
    /**
     * 用户头图列表
     */
    private List<UfotoUserHeadDo> headList;
}
