package com.ufoto.feign.usercenter.dto;

import lombok.Data;

import java.io.Serializable;
import java.util.List;

/**
 * @author luozq
 * @date 2019/12/24 13:55
 */
@Data
public class UserImageCountVo implements Serializable {

    /**
     * uid 列表
     */
    private List<Long> uidList;
    /**
     * 鉴黄状态, 0 default, 1 合法的, 2 非法的， 3 复审，4 申诉
     */
    private List<Integer> states;

    /**
     * 0 不可见， 1 可见
     */
    private List<Integer> visibleList;
}
