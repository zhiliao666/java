package com.ufoto.feign.usercenter.dto;

import lombok.Data;

import java.io.Serializable;
import java.util.List;

/**
 * 用户登录回调传参
 *
 * @author luozq
 * @date 2019/3/7/007
 */
@Data
public class UserLoginCallBackVo extends UfotoAppUserDo implements Serializable {
    /**
     * 用户类型 1 fb用户
     */
    public static final Integer FB_TYPE = 1;
    /**
     * 用户类型 2 gmail用户
     */
    public static final Integer GMAIL_TYPE = 2;
    /**
     * 第三方用户唯一标识
     */
    private String uuid;
    /**
     * 教育程度信息列表
     */
    private List<UfotoUserEducationDo> educations;
    /**
     * 工作信息列表
     */
    private List<UfotoUserWorkDo> works;
    /**
     * 用户兴趣信息
     */
    private List<String> likes;
    /**
     * 描述信息
     */
    private String description;
    /**
     * 3独立app，4社交活动，5挑战活动
     */
    private Integer appFlag;
    /**
     * faceBook，google 验证token
     */
    private String accessToken;
    /**
     * 3独立app，4社交活动，5挑战活动
     */
    private Integer tokenVersion;
    /**
     * 迁移之前的uuid
     */
    private String preUuid;
    /**
     * 是否迁移账号, 0 否, 1 是
     */
    private Integer ifMigrate;
    /**
     * 1 社交版本登录 2 版本2（开始接入）
     */
    private Integer version;

    private Boolean ifNewUser = Boolean.FALSE;

    private Boolean ifTest = Boolean.FALSE;

    private String ip;

    private String fcmToken;//fcmToken  聊天用

    private String visitorSign;
    private Long uid;
}
