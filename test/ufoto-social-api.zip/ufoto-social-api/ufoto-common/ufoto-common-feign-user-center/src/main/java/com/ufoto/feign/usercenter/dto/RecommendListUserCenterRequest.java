package com.ufoto.feign.usercenter.dto;

import lombok.Data;

import java.io.Serializable;
import java.util.List;

/**
 * <p>
 * Author     : Chan
 * CreateDate : 2019-10-15 10:11
 * Description:
 * </p>
 */
@Data
public class RecommendListUserCenterRequest implements Serializable {
    private List<Long> uids;
    private String apiVersion;//新增feed流 兼容 v1 v2
    private String lang;
}
