package com.ufoto.feign.usercenter.dto;

import lombok.Data;

import java.io.Serializable;

/**
 * @author luozq
 * @date 2019/12/24 13:52
 */
@Data
public class UserImageCountDto implements Serializable {

    /**
     * uid
     */
    private Long uid;

    /**
     * 状态
     */
    private Integer status;
    /**
     * 数量
     */
    private Integer count;
}
