package com.ufoto.feign.usercenter.dto;

import lombok.Data;

/**
 * 用户兴趣信息
 *
 * @author luozq
 * @date 2019/3/13/013
 */
@Data
public class UserLikeTagDo {

    /**
     * 用户id
     */
    private Long uId;

    /**
     * 兴趣标签
     */
    private String likeTag;
    /**
     * 0 所有人可见, 1 仅自己可见
     */
    private Integer status;
}
