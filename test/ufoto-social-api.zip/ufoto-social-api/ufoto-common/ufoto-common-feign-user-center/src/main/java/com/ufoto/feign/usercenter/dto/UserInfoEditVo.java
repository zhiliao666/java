package com.ufoto.feign.usercenter.dto;

import lombok.Data;

import java.io.Serializable;

/**
 * 编辑用户信息
 *
 * @author luozq
 * @date 2019/3/7/007
 */
@Data
public class UserInfoEditVo implements Serializable {
    /**
     * 基础信息
     */
    private BaseUserInfoEditVo baseInfo;
    /**
     * 额外信息
     */
    private AdditionalUserInfoVo additionalInfo;
}
