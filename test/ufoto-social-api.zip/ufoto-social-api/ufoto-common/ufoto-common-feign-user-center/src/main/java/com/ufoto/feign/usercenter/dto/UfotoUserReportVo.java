package com.ufoto.feign.usercenter.dto;

import lombok.Data;

/**
 * @author luozq
 * @date 2019/3/28/028
 */
@Data
public class UfotoUserReportVo {
    /**
     * 创建时间
     */
    private Integer createTime;
    /**
     * 举报的用户id
     */
    private Long reportUid;
    /**
     * id
     */
    private Integer id;
    /**
     * 举报详情
     */
    private String detail;
    /**
     * 举报类型 1.非法照片 2.感觉这是垃圾
     * 3.其他原因 4. 需要人工审核
     */
    private Integer type;
    /**
     * 举报人id
     */
    private Long uid;

    private Integer source;

    private String content;
}
