package com.ufoto.feign.usercenter.dto;

import lombok.Data;

import java.io.Serializable;

/**
 * 用户基本信息编辑
 *
 * @author luozq
 * @date 2019/3/13/013
 */
@Data
public class BaseUserInfoEditVo extends UfotoAppUserDo implements Serializable {

}
