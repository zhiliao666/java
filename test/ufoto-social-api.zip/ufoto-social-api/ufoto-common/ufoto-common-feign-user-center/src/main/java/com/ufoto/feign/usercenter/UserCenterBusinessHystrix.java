package com.ufoto.feign.usercenter;

import com.ufoto.common.utils.ApiResult;
import com.ufoto.common.utils.JsonUtil;
import com.ufoto.feign.usercenter.dto.AdditionalUserInfoVo;
import com.ufoto.feign.usercenter.dto.BaseUserInfoEditVo;
import com.ufoto.feign.usercenter.dto.FeedImageDelVo;
import com.ufoto.feign.usercenter.dto.FeedImageVisibleVo;
import com.ufoto.feign.usercenter.dto.UfotoUserReportVo;
import com.ufoto.feign.usercenter.dto.UserAdditionalInfoDo;
import com.ufoto.feign.usercenter.dto.UserBaseInfoDto;
import com.ufoto.feign.usercenter.dto.UserCallBackInfoDto;
import com.ufoto.feign.usercenter.dto.UserConditionDto;
import com.ufoto.feign.usercenter.dto.UserImageCountDto;
import com.ufoto.feign.usercenter.dto.UserImageCountVo;
import com.ufoto.feign.usercenter.dto.UserInfoDto;
import com.ufoto.feign.usercenter.dto.UserInfoEditVo;
import com.ufoto.feign.usercenter.dto.UserLoginCallBackVo;
import org.springframework.stereotype.Component;

import java.util.List;
import java.util.Map;

/**
 * <p>
 * Author     : Chan
 * CreateDate : 2019-03-19 10:06
 * Description:
 * </p>
 */
@Component
public class UserCenterBusinessHystrix implements UserCenterBusiness {
    @Override
    public ApiResult<UserCallBackInfoDto> loginCallback(UserLoginCallBackVo callBackVo) {
        return new ApiResult<UserCallBackInfoDto>().setError(ApiResult.errorCode500, "Hystrix Exception: " + JsonUtil.toJson(callBackVo));
    }

    @Override
    public ApiResult<UserBaseInfoDto> getUserBaseInfo(Long uid) {
        return new ApiResult<UserBaseInfoDto>().setError(ApiResult.errorCode500, "Hystrix Exception: " + uid);
    }

    @Override
    public ApiResult<Boolean> logout(Long uid) {
        return new ApiResult<Boolean>().setError(ApiResult.errorCode500, "Hystrix Exception: " + uid);
    }

    @Override
    public ApiResult<List<UserBaseInfoDto>> getUserBaseInfoList(List<Long> idList) {
        return new ApiResult<List<UserBaseInfoDto>>().setError(ApiResult.errorCode500, "Hystrix Exception: " + idList);
    }

    @Override
    public ApiResult<UserAdditionalInfoDo> getUserAdditionalInfo(Long uid) {
        return new ApiResult<UserAdditionalInfoDo>().setError(ApiResult.errorCode500, "Hystrix Exception: " + uid);
    }

    @Override
    public ApiResult<Boolean> editUserBaseInfo(BaseUserInfoEditVo editVo) {
        return new ApiResult<Boolean>().setError(ApiResult.errorCode500, "Hystrix Exception: " + JsonUtil.toJson(editVo));
    }

    @Override
    public ApiResult<Boolean> editUserAdditionalInfo(AdditionalUserInfoVo userInfoVo) {
        return new ApiResult<Boolean>().setError(ApiResult.errorCode500, "Hystrix Exception: " + JsonUtil.toJson(userInfoVo));
    }

    @Override
    public ApiResult<UserInfoDto> getUserInfo(Long uid, Integer self) {
        return new ApiResult<UserInfoDto>().setError(ApiResult.errorCode500, "Hystrix Exception: " + uid + "," + self);
    }

    @Override
    public ApiResult<Boolean> editUserInfo(UserInfoEditVo userInfoVo) {
        return new ApiResult<Boolean>().setError(ApiResult.errorCode500, "Hystrix Exception: " + JsonUtil.toJson(userInfoVo));
    }

    @Override
    public ApiResult<UserBaseInfoDto> editUserInfoV2(UserInfoEditVo userInfoVo) {
        return new ApiResult<UserBaseInfoDto>().setError(ApiResult.errorCode500, "Hystrix Exception: " + JsonUtil.toJson(userInfoVo));
    }

    @Override
    public ApiResult<UserBaseInfoDto> getUserBaseInfoByUUid(String uuid) {
        return new ApiResult<UserBaseInfoDto>().setError(ApiResult.errorCode500, "Hystrix Exception: " + uuid);
    }

    @Override
    public ApiResult<List<UserBaseInfoDto>> conditionLists(UserConditionDto userConditionDto) {
        return new ApiResult<List<UserBaseInfoDto>>().setError(ApiResult.errorCode500, "Hystrix Exception: " + JsonUtil.toJson(userConditionDto));
    }

    @Override
    public ApiResult<Integer> getGender(Long uid) {
        return new ApiResult<Integer>().setError(ApiResult.errorCode500, "Hystrix Exception: " + uid);
    }

    @Override
    public ApiResult<Boolean> deleteUser(long uid) {
        return new ApiResult<Boolean>().setError(ApiResult.errorCode500, "Hystrix Exception: " + uid);
    }

    @Override
    public ApiResult<List<UserBaseInfoDto>> robots() {
        return new ApiResult<List<UserBaseInfoDto>>().setError(ApiResult.errorCode500, "Hystrix Exception");
    }

    @Override
    public ApiResult<Boolean> bindVisitor(Long fUid, String tUUid) {
        return new ApiResult<Boolean>().setError(ApiResult.errorCode500, "Hystrix Exception: fUid:" + fUid + ",tUUid:" + tUUid);
    }

    @Override
    public ApiResult<Boolean> updateFeedVisible(Long uid, List<FeedImageVisibleVo> visibleVoList) {
        return new ApiResult<Boolean>().setError(ApiResult.errorCode500, "Hystrix uid: " + uid + ",visibleVoList: " + JsonUtil.toJson(visibleVoList));
    }

    @Override
    public ApiResult<Boolean> deleteFeedImage(Long uid, List<FeedImageDelVo> delVoList) {
        return new ApiResult<Boolean>().setError(ApiResult.errorCode500, "Hystrix uid: " + uid + ",delVoList: " + JsonUtil.toJson(delVoList));
    }

    @Override
    public ApiResult<Boolean> slideCheck(Long uid) {
        return new ApiResult<Boolean>().setError(ApiResult.errorCode500, "Hystrix uid:" + uid);
    }

    @Override
    public ApiResult<List<String>> localHeadImg() {
        return new ApiResult<List<String>>().setError(ApiResult.errorCode500, "Hystrix");
    }

    @Override
    public ApiResult<Boolean> userExist(Long uid) {
        return new ApiResult<Boolean>().setError(ApiResult.errorCode500, "Hystrix uid:" + uid);
    }

    @Override
    public ApiResult<Map<Long, Integer>> checkFirstImageState(List<Long> idList) {
        return new ApiResult<Map<Long, Integer>>().setError(ApiResult.errorCode500, "Hystrix idList:" + idList);
    }

    @Override
    public ApiResult<Boolean> saveReportInfo(Long uid, Long reportUid, UfotoUserReportVo reportVo) {
        return new ApiResult<Boolean>().setError(ApiResult.errorCode500, "Hystrix saveReportInfo:" + reportVo);
    }

    @Override
    public ApiResult<List<String>> getRandomUsername(Integer size) {
        return new ApiResult<List<String>>().setError(ApiResult.errorCode500, "Hystrix getRandomUsername");
    }

    @Override
    public ApiResult<List<UserImageCountDto>> getImageCount(UserImageCountVo countVo) {
        return new ApiResult<List<UserImageCountDto>>().setError(ApiResult.errorCode500, "Hystrix getImageCount");
    }
}
