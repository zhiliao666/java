package com.ufoto.feign.usercenter.dto;

import com.fasterxml.jackson.annotation.JsonProperty;
import lombok.Data;

import java.io.Serializable;

/**
 * @author luozq
 * @date 2019/9/23 16:26
 */
@Data
public class FeedImageVo implements Serializable {

    /**
     * user id
     */
    @JsonProperty("uid")
    private Long uid;

    /**
     * url
     */
    private String url;

    /**
     * the source of image coming from,  0 默认，swipe图片， 1 DNA, 2 摇钱树, 3 贴纸活动,
     */
    private Integer type;

    /**
     * image visible type: 0 不可见， 1 可见
     */
    @JsonProperty("isVisible")
    private Integer isVisible;

    private Integer width;

    private Integer height;

    private Double duration;

    private Long size;

    private String videoUrl;
    //默认 0 feed图片， 1 gif， 2 video
    private Integer fileType = 0;
}
