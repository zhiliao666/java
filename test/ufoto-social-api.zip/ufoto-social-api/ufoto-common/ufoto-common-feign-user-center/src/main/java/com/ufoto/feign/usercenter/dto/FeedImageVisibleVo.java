package com.ufoto.feign.usercenter.dto;

import lombok.Data;

import java.io.Serializable;

/**
 * @author luozq
 * @date 2019/9/23 17:15
 */
@Data
public class FeedImageVisibleVo implements Serializable {

    /**
     * uid
     */
    private Long uid;

    private Long id;

    /**
     * 0 不可见， 1 可见
     */
    private Integer isVisible;
}
