package com.ufoto.feign.usercenter.dto;

import lombok.Data;

import java.util.List;

/**
 * @author luozq
 * @date 2019/3/13/013
 */
@Data
public class AdditionalUserInfoVo {

    private Long uId;

    /**
     * 用户教育信息列表
     */
    private List<UfotoUserEducationDo> educations;
    /**
     * 用户工作信息列表
     */
    private List<UfotoUserWorkDo> works;

    private List<UserLikeTagDo> likes;

}
