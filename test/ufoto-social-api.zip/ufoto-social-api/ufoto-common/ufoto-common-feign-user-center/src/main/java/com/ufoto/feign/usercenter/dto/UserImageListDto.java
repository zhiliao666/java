package com.ufoto.feign.usercenter.dto;

import lombok.Data;

import java.io.Serializable;
import java.util.List;

/**
 * <p>
 * Author     : Chan
 * CreateDate : 2019-10-12 18:29
 * Description:
 * </p>
 */
@Data
public class UserImageListDto implements Serializable {
    private List<Long> idList;
    private List<Integer> statusList;
}
