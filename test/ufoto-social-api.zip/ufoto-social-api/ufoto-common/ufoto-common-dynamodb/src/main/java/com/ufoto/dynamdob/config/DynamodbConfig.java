package com.ufoto.dynamdob.config;

import com.amazonaws.auth.AWSStaticCredentialsProvider;
import com.amazonaws.auth.BasicAWSCredentials;
import com.amazonaws.regions.Regions;
import com.amazonaws.services.dynamodbv2.AmazonDynamoDB;
import com.amazonaws.services.dynamodbv2.AmazonDynamoDBClientBuilder;
import com.amazonaws.services.dynamodbv2.datamodeling.DynamoDBMapper;
import com.amazonaws.services.dynamodbv2.document.DynamoDB;
import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;
import org.springframework.core.env.Environment;

import java.util.Objects;

/**
 * dynamodb 配置
 * @author luozq
 * @date 4/17/19 11:45 AM
 */
@Configuration
public class DynamodbConfig {

    private Environment env;

    public DynamodbConfig(Environment env) {
        this.env = env;
    }


    @Bean
    public AmazonDynamoDB amazonDynamoDB () {
        String property = env.getProperty("spring.profiles.active");
        // 线上使用机器授权进行授权
        if (Objects.equals(property, "prod") || Objects.equals(property, "beta")) {
            return AmazonDynamoDBClientBuilder
                    .standard()
                    .build();
        }
        // 其他环境则使用秘钥进行授权
        BasicAWSCredentials creds = new BasicAWSCredentials("AKIAIJEE2EMJYQHADYBA",
                "xq8sF1OrmNcGL15XlFB4LN1QGHFKFencbjs1hE50");
        return AmazonDynamoDBClientBuilder
                .standard()
                .withCredentials(new AWSStaticCredentialsProvider(creds))
                .withRegion(Regions.US_EAST_1)
                .build();
    }


    @Bean
    public DynamoDB dynamoDB (AmazonDynamoDB amazonDynamoDB) {
        return new DynamoDB(amazonDynamoDB);
    }

    @Bean
    public DynamoDBMapper dynamoDBMapper(AmazonDynamoDB amazonDynamoDB) {
        return new DynamoDBMapper(amazonDynamoDB);
    }

}
