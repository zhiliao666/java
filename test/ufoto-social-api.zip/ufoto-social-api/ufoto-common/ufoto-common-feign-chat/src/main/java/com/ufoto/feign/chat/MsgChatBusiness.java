package com.ufoto.feign.chat;


import com.ufoto.common.utils.ApiResult;
import org.springframework.cloud.openfeign.FeignClient;
import org.springframework.stereotype.Component;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.ResponseBody;

@Component
@FeignClient(value = "UFOTO-CLOUD-CHAT", fallbackFactory = MsgChatBusinessFallbackFactory.class)
public interface MsgChatBusiness {

    /**
     * 发送消息
     *
     * @param fromUid
     * @param toUid
     * @param msg
     * @param msgType  1 聊天文本消息 2 surper like推送 3 配对成功推送 4 图片消息（msg对应的为图片地址）6 语音消息  默认值 1
     * @param chatType 0 正常消息（默认）1 临时消息
     * @return
     */
    @RequestMapping(value = "/fcmMsg/sendMsg", method = RequestMethod.GET)
    @ResponseBody
    ApiResult<String> sendMsg(
            @RequestParam(value = "fromUid") Long fromUid,
            @RequestParam(value = "toUid") Long toUid,
            @RequestParam(value = "msg") String msg,
            @RequestParam(value = "msgType") Integer msgType,
            @RequestParam(value = "chatType") Integer chatType);
}
