package com.ufoto.feign.chat;

import com.ufoto.common.utils.ApiResult;
import org.springframework.stereotype.Component;

@Component
public class MsgChatBusinessHystrix implements MsgChatBusiness {

    @Override
    public ApiResult<String> sendMsg(Long fromUid, Long toUid, String msg,
                                     Integer msgType, Integer chatType) {
        return new ApiResult<String>().setError(ApiResult.errorCode500, "垄断器异常");
    }
}
