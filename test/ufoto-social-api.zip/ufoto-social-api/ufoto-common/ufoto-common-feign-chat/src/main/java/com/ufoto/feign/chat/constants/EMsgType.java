package com.ufoto.feign.chat.constants;

/**
 * <p>
 *
 * </p>
 *
 * @author created by chenzhou at 2018-08-14 13:47
 */
public enum EMsgType {
    TEXT(1, "普通消息（也就是文本）"),
    SUPER_LIKE_PUSH(2, "super like推送消息"),
    NORMAL_MATCH_SUCCESS(3, "配对成功推送消息"),
    IMAGE(4, "图片消息"),
    LIKE_PUSH(5, "用户like推送消息"),
    AUDIO(6, "语音消息"),
    LAST_CHAT_MESSAGE(201, "最后一条消息"),
    GIF(7, "gif消息"),
    /*
    客户端用于腾讯IM的好友资料变更的通知，服务器忽略这个类型
     */
    TIM_PROFILE_UPDATE(11, "腾讯IM的好友资料变更的通知"),

    RANDOM_MATCH_LIKE_PUSH(701, "临时随机匹配like通知"),
    RANDOM_MATCH_DISLIKE_PUSH(702, "临时随机匹配dislike通知"),
    RANDOM_MATCH_SUCCESS(703, "临时随机匹配成功通知"),
    RANDOM_MATCH_FRIENDS(704, "临时随机匹配转正式好友通知"),
    RANDOM_MATCH_FRIENDS_EXPIRE(708, "临时好友即将到期通知"),
    RANDOM_MATCH_FRIENDS_UNMATCH(709, "正式好友unmatch通知"),
    GAME_INVITE(801, "游戏邀请消息"),
    GAME_INVITE_FAILURE(802, "游戏邀请失败"),
    GAME_SQUARE(803, "新版游戏邀请"),
    VOICE_CHAT(601, "语音聊天"),
    RANDOM_VOICE_CHAT(602, "临时匹配语音聊天"),
    PUSH_MECHANISM(901, "推送机制"),
    COIN_TASK_INCOME(902, "金币收入消息"),
    COIN_TASK_EXPENSE(903, "金币支出消息"),
    MATCH_SIMILAR(904, "匹配度消息"),
    GIFT(905, "礼物消息--双方聊天消息"),
    GIFT_NOTIFY(906, "礼物消息-通知消息"),//滑动页面送礼

    EVENT_PUSH_MESSAGE(1001, "事件推送"),
    REGISTERED_PUSH_MESSAGE(1002, "注册推送"),
    COIN_TREE_START_PUSH_MESSAGE(1003, "摇钱树游戏准备开始"),
    COIN_TREE_PROGRESS_BAR_ROBOT(1004, "匹配进度条结束房间未满给机器人通知"),
    COIN_TREE_NEW_PLAYER_NOTI(1005, "新玩家进入通知"),
    COIN_TREE_SCORE_CAL(1006, "分数结算");


    private int msgType;
    private String desc;

    EMsgType(int msgType, String desc) {
        this.msgType = msgType;
        this.desc = desc;
    }

    public int getMsgType() {
        return msgType;
    }

    public String getDesc() {
        return desc;
    }
}
