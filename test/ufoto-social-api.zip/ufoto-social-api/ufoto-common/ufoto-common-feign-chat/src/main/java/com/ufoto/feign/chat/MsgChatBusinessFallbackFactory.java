package com.ufoto.feign.chat;

import com.ufoto.infrastructure.metric.feign.circuitbreaker.AbstractFallbackFactory;
import org.springframework.stereotype.Component;

/**
 * <p>
 * Author     : Chan
 * CreateDate : 2018/10/29 14:11
 * Description:
 * </p>
 */
@Component
public class MsgChatBusinessFallbackFactory extends AbstractFallbackFactory<MsgChatBusiness> {

    private final MsgChatBusinessHystrix msgChatBusinessHystrix;

    public MsgChatBusinessFallbackFactory(MsgChatBusinessHystrix msgChatBusinessHystrix) {
        this.msgChatBusinessHystrix = msgChatBusinessHystrix;
    }

    @Override
    protected MsgChatBusiness doCreate() {
        return msgChatBusinessHystrix;
    }
}
