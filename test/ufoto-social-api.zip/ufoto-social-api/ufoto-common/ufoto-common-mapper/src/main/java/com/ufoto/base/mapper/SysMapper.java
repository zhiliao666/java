package com.ufoto.base.mapper;

import tk.mybatis.mapper.common.Mapper;
import tk.mybatis.mapper.common.MySqlMapper;

/**
 * <p>
 * Description:
 *
 * </p>
 *
 * @author Chan
 * @date 2020/2/6 15:20
 */
public interface SysMapper<T> extends Mapper<T>, MySqlMapper<T> {
}
