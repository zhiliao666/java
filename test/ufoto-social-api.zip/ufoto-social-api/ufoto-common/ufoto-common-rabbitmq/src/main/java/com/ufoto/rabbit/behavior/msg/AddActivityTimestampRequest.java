package com.ufoto.rabbit.behavior.msg;

import lombok.Data;

import java.io.Serializable;

/**
 * Created by echo on 4/8/19.
 */
@Data
public class AddActivityTimestampRequest implements Serializable {
    Long uid;
    Integer timestamp;
}
