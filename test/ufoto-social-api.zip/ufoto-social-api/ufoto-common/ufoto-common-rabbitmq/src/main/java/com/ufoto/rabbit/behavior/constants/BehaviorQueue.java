package com.ufoto.rabbit.behavior.constants;

/**
 * Created by echo on 3/19/19.
 */
public interface BehaviorQueue {
    String QUEUE_ADD_REDIS_USER_REPORT = "Q-addRedisUserReport";
    String QUEUE_USER_CANCEL = "Q-userCancel";
    String QUEUE_CANCEL_MATCH = "Q-cancelMatch";
    String QUEUE_USER_EDIT_HEAD = "Q-userEditHead";
    String QUEUE_USER_EDIT_CAN_BE_RECOMMENDED = "Q-userEditCanBeRecommended";
    String QUEUE_USER_EDIT_NOT_RECOMMENDED = "Q-userEditNotRecommended";
    String QUEUE_RECOMMEND_TOOL_ERROR = "Q-recommendToolError";
    String QUEUE_ADD_DELETE_USER = "Q-addDeleteUser";

    String QUEUE_ADD_REDIS_USER_BE_UNLIKED = "Q-addRedisUserBeUnLiked";
    String QUEUE_ADD_REDIS_USER_BE_LIKED = "Q-addRedisUserBeLiked";
    String QUEUE_ADD_REDIS_USER_BE_SUPER_LIKED = "Q-addRedisUserBeSuperLiked";
    String QUEUE_ADD_REDIS_USER_GENDER = "Q-addRedisUserGender";
    String QUEUE_ADD_REDIS_USER_RECOMMENDED = "Q-addRedisUserRecommended";
    String QUEUE_ADD_REDIS_REGION_USER = "Q-addRedisRegionUser";
    String QUEUE_ADD_REDIS_USER_ACTIVITY_TIMESTAMP = "Q-addRedisUserActivityTimestamp";
    String QUEUE_ADD_REDIS_USER = "Q-addRedisUser";
    String QUEUE_ADD_REDIS_USER_BIRTH_TIMESTAMP = "Q-addRedisUserBirthTimestamp";
    String QUEUE_ADD_REDIS_ILLEGAL_USER = "Q-addRedisIllegalUser";
    String QUEUE_ADD_REDIS_ILLEGAL_USER_OR_FIRST = "Q-addRedisIllegalUserOrFirst";
    String QUEUE_REMOVE_REDIS_ILLEGAL_USER = "Q-removeRedisIllegalUser";
    String QUEUE_REMOVE_REDIS_ILLEGAL_USER_OR_FIRST = "Q-removeRedisIllegalUserOrFirst";
    String QUEUE_USER_EDIT_SHOW_ME_GENDER = "Q-userEditShowMeGender";

    String QUEUE_DELETE_USER = "Q-deleteUser";

    String QUEUE_GIFT_RECORD = "Q-giftRecord";
    String QUEUE_REFRESH_CACHE_GOODS_LIST = "Q-refreshCacheGoodsList";

    String QUEUE_NEW_USER_MAIL = "Q-newUserMail";

    String QUEUE_USER_AGE = "Q-userAge";
    String QUEUE_USER_SUBSCRIPTION = "Q-userSubscription";

    String QUEUE_USER_CENTER_GEO = "Q-userGeo";

    String QUEUE_RANDOM_MATCH = "Q-randomMatch";

    String QUEUE_IOS_BILLING_QUEUE = "Q_IOS_BILLING_QUEUE";

    String QUEUE_USER_EDIT = "Q-userEdit";

    String QUEUE_UPDATE_MATCH_NUM = "Q-updateMatchNum";
}

