package com.ufoto.rabbit.config;

import com.ufoto.common.utils.JsonUtil;
import com.ufoto.rabbit.BusinessMsg;
import com.ufoto.rabbit.behavior.constants.ActionType;
import lombok.extern.slf4j.Slf4j;
import org.springframework.amqp.core.Message;
import org.springframework.amqp.core.MessageProperties;
import org.springframework.amqp.core.MessagePropertiesBuilder;
import org.springframework.amqp.rabbit.core.RabbitTemplate;
import org.springframework.amqp.support.converter.MessageConverter;

/**
 * <p>
 * Author     : Chan
 * CreateDate : 2019-05-17 09:58
 * Description:
 * </p>
 */
@Slf4j
public class RabbitProducer {

    private final RabbitTemplate rabbitTemplate;

    public RabbitProducer(RabbitTemplate rabbitTemplate) {
        this.rabbitTemplate = rabbitTemplate;
    }

    /**
     * 发送消息
     *
     * @param exchange   exchange
     * @param routingKey routing
     * @param payload    message must implement Serializable
     */
    public void produce(String exchange, String routingKey, Object payload) {
        try {
            MessageConverter messageConverter = rabbitTemplate.getMessageConverter();
            Message message = messageConverter.toMessage(payload, MessagePropertiesBuilder
                    .fromProperties(new MessageProperties())
                    .setContentType(MessageProperties.CONTENT_TYPE_SERIALIZED_OBJECT)
                    .build());
            rabbitTemplate.send(exchange, routingKey, message);
        } catch (Exception e) {
            log.error(String.format("ERROR_RABBIT_PRODUCER: exchange:%s,routingKey:%s,payload:%s",
                    exchange, routingKey, JsonUtil.toJson(payload)), e);
        }
    }

    public void produce(String exchange, String routingKey, Object payload, Integer expireTime) {
        try {
            MessageConverter messageConverter = rabbitTemplate.getMessageConverter();
            Message message = messageConverter.toMessage(payload, MessagePropertiesBuilder
                    .fromProperties(new MessageProperties())
                    .setContentType(MessageProperties.CONTENT_TYPE_SERIALIZED_OBJECT)
                    .setExpiration(expireTime + "")
                    .build());
            rabbitTemplate.send(exchange, routingKey, message);
        } catch (Exception e) {
            log.error(String.format("ERROR_RABBIT_PRODUCER: exchange:%s,routingKey:%s,payload:%s",
                    exchange, routingKey, JsonUtil.toJson(payload)), e);
        }
    }

    public void produceByJson(String exchange, String routingKey, Object payload) {
        try {
            MessageConverter messageConverter = rabbitTemplate.getMessageConverter();
            Message message = messageConverter.toMessage(payload, MessagePropertiesBuilder
                    .fromProperties(new MessageProperties())
                    .setContentType(MessageProperties.CONTENT_TYPE_JSON)
                    .build());
            rabbitTemplate.send(exchange, routingKey, message);
        } catch (Exception e) {
            log.error(String.format("ERROR_RABBIT_PRODUCER: exchange:%s,routingKey:%s,payload:%s",
                    exchange, routingKey, JsonUtil.toJson(payload)), e);
        }
    }

    public void produceWithActionType(ActionType actionType, BusinessMsg message) {
        this.produceByJson(actionType.getExchange(), actionType.getRoutingKey(), message);
    }
}
