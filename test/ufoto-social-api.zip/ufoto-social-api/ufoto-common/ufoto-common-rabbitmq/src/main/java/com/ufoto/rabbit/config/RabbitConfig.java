package com.ufoto.rabbit.config;

import org.springframework.amqp.rabbit.core.RabbitTemplate;
import org.springframework.boot.autoconfigure.condition.ConditionalOnMissingBean;
import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;

/**
 * <p>
 * Description:
 *
 * </p>
 *
 * @author Chan
 * @date 2020/2/10 14:19
 */
@Configuration
public class RabbitConfig {

    @Bean
    @ConditionalOnMissingBean
    public RabbitMessageConverter rabbitMessageConverter() {
        return new RabbitMessageConverter();
    }

    @Bean
    @ConditionalOnMissingBean
    public RabbitProducer rabbitProducer(RabbitTemplate rabbitTemplate) {
        return new RabbitProducer(rabbitTemplate);
    }
}
