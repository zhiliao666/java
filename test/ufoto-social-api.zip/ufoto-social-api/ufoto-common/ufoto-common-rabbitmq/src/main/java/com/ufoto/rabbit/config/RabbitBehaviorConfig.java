package com.ufoto.rabbit.config;

import com.ufoto.rabbit.behavior.constants.BehaviorExchange;
import com.ufoto.rabbit.behavior.constants.BehaviorQueue;
import com.ufoto.rabbit.behavior.constants.BehaviorRoutingKey;
import org.springframework.amqp.core.Binding;
import org.springframework.amqp.core.BindingBuilder;
import org.springframework.amqp.core.DirectExchange;
import org.springframework.amqp.core.FanoutExchange;
import org.springframework.amqp.core.Queue;
import org.springframework.beans.factory.annotation.Qualifier;
import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;

/**
 * <p>
 * Description:
 *
 * </p>
 *
 * @author Chan
 * @date 2020/2/14 15:02
 */
@Configuration
public class RabbitBehaviorConfig {

    @Bean(BehaviorExchange.EX_SOCIAL_SNS_SLIDE)
    public FanoutExchange exSocialSnsSlide() {
        return new FanoutExchange(BehaviorExchange.EX_SOCIAL_SNS_SLIDE);
    }

    @Bean(BehaviorExchange.EX_SOCIAL_SNS_SLIDE_MATCH)
    public FanoutExchange exSocialSnsSlideMatch() {
        return new FanoutExchange(BehaviorExchange.EX_SOCIAL_SNS_SLIDE_MATCH);
    }


    @Configuration
    public static class RabbitRecommendConfig {
        @Bean(BehaviorExchange.SWEETCHAT_DIRECT_RECOMMEND)
        public DirectExchange exchange() {
            return new DirectExchange(BehaviorExchange.SWEETCHAT_DIRECT_RECOMMEND);
        }


        @Bean
        @Qualifier(BehaviorQueue.QUEUE_ADD_REDIS_USER_ACTIVITY_TIMESTAMP)
        public Queue addRedisUserActivityTimestamp() {
            return new Queue(BehaviorQueue.QUEUE_ADD_REDIS_USER_ACTIVITY_TIMESTAMP);
        }

        @Bean
        public Binding bindingAddRedisUserActivityTimestamp(@Qualifier(BehaviorExchange.SWEETCHAT_DIRECT_RECOMMEND) DirectExchange exchange,
                                                            @Qualifier(BehaviorQueue.QUEUE_ADD_REDIS_USER_ACTIVITY_TIMESTAMP) Queue queue) {
            return BindingBuilder.bind(queue).to(exchange).with(BehaviorRoutingKey.ROUTE_KEY_ADD_REDIS_USER_ACTIVITY_TIMESTAMP);
        }
    }

    @Configuration
    public static class RabbitUserCenterConfig {

        @Bean(BehaviorExchange.SOCIAL_DIRECT_USERCENTER)
        public DirectExchange userCenterExchange() {
            return new DirectExchange(BehaviorExchange.SOCIAL_DIRECT_USERCENTER);
        }

        @Bean(BehaviorQueue.QUEUE_USER_CENTER_GEO)
        public Queue userGeoQueue() {
            return new Queue(BehaviorQueue.QUEUE_USER_CENTER_GEO);
        }

        @Bean
        public Binding bindUserGeo(@Qualifier(BehaviorExchange.SOCIAL_DIRECT_USERCENTER) DirectExchange exchange,
                                   @Qualifier(BehaviorQueue.QUEUE_USER_CENTER_GEO) Queue queue) {
            return BindingBuilder.bind(queue).to(exchange).with(BehaviorRoutingKey.ROUTING_KEY_USER_CENTER_GEO);
        }

    }
}
