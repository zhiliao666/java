package com.ufoto.rabbit.behavior.constants;

/**
 * <p>
 * Author     : Chan
 * CreateDate : 2019-03-18 18:37
 * Description:
 * </p>
 */
public interface BehaviorRoutingKey {
    String ROUTE_KEY_ADD_REDIS_USER_REPORT = "recommendTool.addRedisUserReport";
    String ROUTE_KEY_USER_CANCEL = "recommendTool.userCancel";
    String ROUTE_KEY_CANCEL_MATCH = "recommendTool.cancelMatch";
    String ROUTE_KEY_USER_EDIT_HEAD = "recommendTool.userEditHead";
    String ROUTE_KEY_USER_EDIT_CAN_BE_RECOMMENDED = "recommendTool.userEditCanBeRecommended";
    String ROUTE_KEY_USER_EDIT_NOT_RECOMMENDED = "recommendTool.userEditNotRecommended";
    String ROUTE_KEY_RECOMMEND_TOOL_ERROR = "recommendTool.error";
    String ROUTE_KEY_ADD_DELETE_USER = "recommendTool.addDeleteUser";

    String ROUTE_KEY_ADD_REDIS_USER_BE_UNLIKED = "recommendTool.addRedisUserBeUnLiked";
    String ROUTE_KEY_ADD_REDIS_USER_BE_LIKED = "recommendTool.addRedisUserBeLiked";
    String ROUTE_KEY_ADD_REDIS_USER_BE_SUPER_LIKED = "recommendTool.addRedisUserBeSuperLiked";
    String ROUTE_KEY_ADD_REDIS_USER_GENDER = "recommendTool.addRedisUserGender";
    String ROUTE_KEY_ADD_REDIS_USER_RECOMMENDED = "recommendTool.addRedisUserRecommended";
    String ROUTE_KEY_ADD_REDIS_REGION_USER = "recommendTool.addRedisRegionUser";
    String ROUTE_KEY_ADD_REDIS_USER_ACTIVITY_TIMESTAMP = "recommendTool.addRedisUserActivityTimestamp";
    String ROUTE_KEY_ADD_REDIS_USER = "recommendTool.addRedisUser";
    String ROUTE_KEY_ADD_REDIS_USER_BIRTH_TIMESTAMP = "recommendTool.addRedisUserBirthTimestamp";
    String ROUTE_KEY_ADD_REDIS_ILLEGAL_USER = "recommendTool.addRedisIllegalUser";
    String ROUTE_KEY_ADD_REDIS_ILLEGAL_USER_OR_FIRST = "recommendTool.addRedisIllegalUserOrFirst";
    String ROUTE_KEY_REMOVE_REDIS_ILLEGAL_USER = "recommendTool.removeRedisIllegalUser";
    String ROUTE_KEY_REMOVE_REDIS_ILLEGAL_USER_OR_FIRST = "recommendTool.removeRedisIllegalUserOrFirst";
    String ROUTE_KEY_USER_EDIT_SHOW_ME_GENDER = "recommendTool.userEditShowMeGender";

    String ROUTE_KEY_USER_EDIT = "recommendTool.userEdit";

    String ROUTE_KEY_DELETE_USER = "api.deleteUser";

    String ROUTE_KEY_GIFT_RECORD = "recommendTool.giftRecord";
    String ROUTE_KEY_REFRESH_CACHE_GOODS_LIST = "api.refreshCacheGoodsList";

    String ROUTING_KEY_NEW_USER_MAIL = "api.newUserMail";

    String ROUTE_KEY_USER_AGE = "recommendTool.userAge";
    String ROUTE_KEY_USER_SUBSCRIPTION = "user.subscription";

    String ROUTING_KEY_USER_CENTER_GEO = "usercenter.userGeo";

    String ROUTING_KEY_RANDOM_MATCH = "match.RandomMatch";

    String ROUTING_KEY_CHAT_IOS_CALLBACK = "chat_ios_callback";

    String ES_APPVERSION_ROUTE_KEY = "ES.APPVERSION.ROUTE.KEY";

    String ROUTE_KEY_UPDATE_MATCH_NUM = "recommendTool.updateMatchNum";
}
