package com.ufoto.rabbit;

import java.io.Serializable;

/**
 * <p>
 * Description:
 *
 * </p>
 *
 * @author Chan
 * @date 2020/2/14 14:51
 */
public class BusinessMsg implements Serializable {
}
