package com.ufoto.rabbit.behavior.constants;

/**
 * <p>
 * Description:
 *
 * </p>
 *
 * @author Chan
 * @date 2019/12/18 15:34
 */
public enum ActionType {

    ACTION_LIKE("LIKE", "滑动like操作", BehaviorExchange.EX_SOCIAL_SNS_SLIDE, BehaviorExchange.EX_SOCIAL_SNS_SLIDE_MATCH),
    ACTION_SUPER_LIKE("SUPER_LIKE", "滑动superlike操作", BehaviorExchange.EX_SOCIAL_SNS_SLIDE, BehaviorExchange.EX_SOCIAL_SNS_SLIDE_MATCH),
    ACTION_DISLIKE("DISLIKE", "滑动dislike操作", BehaviorExchange.EX_SOCIAL_SNS_SLIDE, BehaviorExchange.EX_SOCIAL_SNS_SLIDE_MATCH);

    private String type;
    private String desc;
    private String exchange;
    private String matchExchange;

    ActionType(String type, String desc, String exchange, String matchExchange) {
        this.type = type;
        this.desc = desc;
        this.exchange = exchange;
        this.matchExchange = matchExchange;
    }

    public String getType() {
        return type;
    }

    public String getDesc() {
        return desc;
    }

    public String getExchange() {
        return exchange;
    }

    public String getRoutingKey() {
        return "";
    }

    public String getMatchExchange() {
        return matchExchange;
    }
}
