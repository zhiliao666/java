package com.ufoto.rabbit.behavior.constants;

/**
 * <p>
 * Description:
 *
 * </p>
 *
 * @author Chan
 * @date 2020/2/14 14:38
 */
public interface BehaviorExchange {
    String EX_SOCIAL_SNS_SLIDE = "social.sns.slide";
    String EX_SOCIAL_SNS_SLIDE_MATCH = "social.sns.slide.match";
    String SWEETCHAT_DIRECT_RECOMMEND = "sweetchat.direct.recommend";
    String SOCIAL_DIRECT_USERCENTER = "social.direct.usercenter";
    String EX_SOCIAL_SUPER_LIKE_CONSUME_COIN = "social.superlike.consume.coin";
}
