package com.ufoto.rabbit.behavior.msg;

import com.ufoto.rabbit.BusinessMsg;
import lombok.Builder;
import lombok.Data;
import lombok.EqualsAndHashCode;

/**
 * <p>
 * Description:
 *
 * </p>
 *
 * @author Chan
 * @date 2020/2/14 14:26
 */
@EqualsAndHashCode(callSuper = true)
@Data
@Builder
public class SnsSlideMsg extends BusinessMsg {

    private Long uid;
    private Long targetUid;
    /**
     * {@link com.ufoto.rabbit.behavior.constants.ActionType}
     */
    private String action;
    private boolean ifMatch;
    private boolean ifChatBot;

}
