package com.ufoto.friendchat.entity.tim.result;

import com.alibaba.fastjson.annotation.JSONField;
import lombok.Builder;
import lombok.Data;

/**
 *
 * @Author Wang, Qing
 * @Date 2019/10/26 16:16
 */
@Data
@Builder
public class TIMCallbackResult {

    public static final String OK = "OK";

    public static final String FAIL = "FAIL";

    /**
     * 请求处理的结果，OK 表示处理成功，FAIL 表示失败
     */
    @JSONField(name = "ActionStatus")
    private String actionStatus;

    /**
     * 错误信息
     */
    @JSONField(name = "ErrorInfo")
    private String errorInfo;

    /**
     * 错误码，0为允许发言；1为拒绝发言。若业务希望拒绝发言的同时，将错误码 ErrorCode 和 ErrorInfo 传递至客户端，
     * 请将错误码 ErrorCode 设置在 [120001, 130000] 区间内
     */
    @JSONField(name = "ErrorCode")
    private Integer errorCode;
}
