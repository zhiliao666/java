package com.ufoto.friendchat.factory;

import com.ufoto.friendchat.entity.SimilarDto;
import com.ufoto.friendchat.entity.SingleMatchSimilar;
import com.ufoto.friendchat.entity.UfotoAppUser;
import lombok.extern.slf4j.Slf4j;
import org.joda.time.DateTime;
import org.springframework.stereotype.Component;

import java.util.List;

/**
 * <p>
 * Author     : Chan
 * CreateDate : 2019-01-16 10:37
 * Description:
 * </p>
 */
@Slf4j
@Component
public class BirthdayMonthDaySimilarFactory implements MatchSimilarFactory {
    @Override
    public SingleMatchSimilar doSimilar(SimilarDto similarDto) {
        final List<UfotoAppUser> users = similarDto.getUsers();
        DateTime dd1 = getUserDatetime(users.get(0));
        DateTime dd2 = getUserDatetime(users.get(1));
        if (dd1 == null || dd2 == null) {
            return null;
        }
        final String m1 = dd1.monthOfYear().getAsString();
        final String d1 = dd1.dayOfMonth().getAsString();
        final String m2 = dd2.monthOfYear().getAsString();
        final String d2 = dd2.dayOfMonth().getAsString();
        log.debug("sameMonthDay,user1:{},d1:{},user2:{},d2:{}", users.get(0).getId(), dd1, users.get(1).getId(), dd2);
        if (!(m1 + d1).equals(m2 + d2)) {
            return null;
        }
        return getSingleMatchSimilar(similarDto, new String[]{m1 + "." + d1}, new String[]{m2 + "." + d2});
    }
}
