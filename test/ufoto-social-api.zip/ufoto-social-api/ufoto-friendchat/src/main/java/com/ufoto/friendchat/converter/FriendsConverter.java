package com.ufoto.friendchat.converter;

import com.ufoto.friendchat.entity.UfotoUserFriends;
import com.ufoto.friendchat.entity.es.UfotoUserFriendsDto;
import com.ufoto.friendchat.utils.BeanUtil;

import java.util.List;
import java.util.stream.Collectors;

import static com.ufoto.friendchat.constants.Constants.FORMAL_FRIEND_STATUS;

/**
 * @Author Wang, Qing
 * @Date 2019/9/6 15:30
 */
public class FriendsConverter {

    public static List<UfotoUserFriendsDto> fromFormal(List<UfotoUserFriends> ufotoUserFriendsList) {
        return ufotoUserFriendsList.stream().map(userFriend -> {
            UfotoUserFriendsDto ufotoUserFriendsDto = new UfotoUserFriendsDto();
            ufotoUserFriendsDto.setUid(userFriend.getuId());
            ufotoUserFriendsDto.setFid(userFriend.getfId());
            ufotoUserFriendsDto.setCreateTime(userFriend.getCreateTime());
            ufotoUserFriendsDto.setState(FORMAL_FRIEND_STATUS);
            ufotoUserFriendsDto.setFIsDelete(userFriend.getfIsDelete().intValue());
            ufotoUserFriendsDto.setIsDelete(userFriend.getIsDelete().intValue());
            ufotoUserFriendsDto.setFromType(userFriend.getFromType().intValue());
            ufotoUserFriendsDto.setIsTop(userFriend.getIsTop().intValue());

            return ufotoUserFriendsDto;
        }).collect(Collectors.toList());
    }
}
