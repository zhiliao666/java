package com.ufoto.friendchat.mapper.read;

import com.ufoto.friendchat.entity.BaseUfotoMatchSimilar;
import org.apache.ibatis.annotations.Param;

import java.util.List;

/**
 * <p>
 * Author     : Chan
 * CreateDate : 2019-01-15 14:32
 * Description:
 * </p>
 */
public interface UfotoMatchSimilarMapper {

    List<BaseUfotoMatchSimilar> selectMatchSimilarByLang(@Param("langs") List<String> langs);
}
