package com.ufoto.friendchat.util.constant;

/**
 * @author luozq
 * @date 2020/3/6 17:42
 */
public interface ElasticConstant {

    /**
     * ufoto_user_friends
     */
    String UFOTO_USER_FRIENDS = "ufoto_user_friends";
}

