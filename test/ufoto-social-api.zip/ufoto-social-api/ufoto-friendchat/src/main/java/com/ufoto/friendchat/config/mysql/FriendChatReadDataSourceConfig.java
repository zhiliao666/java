package com.ufoto.friendchat.config.mysql;

import com.zaxxer.hikari.HikariDataSource;
import lombok.RequiredArgsConstructor;
import org.apache.ibatis.session.SqlSessionFactory;
import org.mybatis.spring.SqlSessionFactoryBean;
import org.mybatis.spring.SqlSessionTemplate;
import org.springframework.beans.BeanUtils;
import org.springframework.beans.factory.annotation.Qualifier;
import org.springframework.boot.context.properties.ConfigurationProperties;
import org.springframework.boot.jdbc.DataSourceBuilder;
import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;
import org.springframework.core.io.support.PathMatchingResourcePatternResolver;
import org.springframework.jdbc.datasource.DataSourceTransactionManager;
import tk.mybatis.spring.annotation.MapperScan;

import javax.sql.DataSource;


/**
 * 配置读数据源
 *
 * @author luozq
 * @date 2019/3/6/006
 */
@RequiredArgsConstructor
@Configuration
@MapperScan(basePackages = {"com.ufoto.friendchat.mapper.read"}, sqlSessionTemplateRef = "friendchatReadSqlSessionTemplate")
public class FriendChatReadDataSourceConfig extends DataSourceConfig {

    private final FriendChatHikari friendchatHikari;

    @Bean(destroyMethod = "shutdown")
    @ConfigurationProperties(prefix = "spring.datasource.read.friendchat")
    public HikariDataSource friendchatReadDataSource() {
        final HikariDataSource dataSource = DataSourceBuilder.create().type(HikariDataSource.class).build();
        // 配置Hikari的相关配置参数
        BeanUtils.copyProperties(friendchatHikari, dataSource);
        return dataSource;
    }

    @Bean(name = "friendchatReadSqlSessionFactory")
    public SqlSessionFactory sqlSessionFactory(@Qualifier("friendchatReadDataSource") DataSource dataSource) throws Exception {
        SqlSessionFactoryBean bean = new SqlSessionFactoryBean();
        // 设置mybatis配置文件路径
        bean.setMapperLocations(new PathMatchingResourcePatternResolver()
                .getResources("classpath*:mapper/friendchat/read/**/*.xml"));
        return getSqlSessionFactory(dataSource, bean);
    }

    @Bean
    public DataSourceTransactionManager friendchatReadTransactionManager(@Qualifier("friendchatReadDataSource") DataSource dataSource) {
        return new DataSourceTransactionManager(dataSource);
    }

    @Bean
    public SqlSessionTemplate friendchatReadSqlSessionTemplate(@Qualifier("friendchatReadSqlSessionFactory") SqlSessionFactory sqlSessionFactory) {
        return new SqlSessionTemplate(sqlSessionFactory);
    }

}
