package com.ufoto.friendchat.factory;

import com.ufoto.friendchat.entity.SimilarDto;
import com.ufoto.friendchat.entity.SingleMatchSimilar;
import com.ufoto.friendchat.entity.UfotoAppUser;
import lombok.extern.slf4j.Slf4j;
import org.springframework.stereotype.Component;

import java.util.List;
import java.util.Objects;

/**
 * <p>
 * Author     : Chan
 * CreateDate : 2019-01-16 12:23
 * Description:
 * </p>
 */
@Slf4j
@Component
public class CountryHomeCountrySimilarFactory implements MatchSimilarFactory {
    @Override
    public SingleMatchSimilar doSimilar(SimilarDto similarDto) {
        final List<UfotoAppUser> users = similarDto.getUsers();
        final String c1 = users.get(0).getCountryCode();
        final String c2 = users.get(1).getCountryCode();
        log.debug("sameCountry,user1:{},c1:{},user2:{},c2:{}", users.get(0).getId(), c1, users.get(1).getId(), c2);
        if (hasNull(c1, c2)) return null;
        if (!Objects.equals(c1, c2)) {
            return null;
        }
        return getSingleMatchSimilar(similarDto);
    }
}
