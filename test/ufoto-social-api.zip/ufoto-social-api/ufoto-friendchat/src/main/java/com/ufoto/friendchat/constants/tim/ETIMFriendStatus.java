package com.ufoto.friendchat.constants.tim;

/**
 *
 * @Author Wang, Qing
 * @Date 2019/10/24 15:31
 */
public enum ETIMFriendStatus {
    LIKE("1"),
    DISLIKE("2"),
    SUPERLIKE("3"),
    UNMATCH("4");

    public String getStatus() {
        return status;
    }

    private String status;

    ETIMFriendStatus(String status) {
        this.status = status;
    }
}
