package com.ufoto.friendchat.entity.tim;

import com.alibaba.fastjson.annotation.JSONField;
import lombok.Builder;
import lombok.Data;

import java.util.List;

/**
 *
 * @Author Wang, Qing
 * @Date 2019/10/26 10:20
 * 详情见：https://cloud.tencent.com/document/product/269/2720
 */
@Data
@Builder
public class TIMImageElem {

    /**
     * 图片序列号。后台用于索引图片的键值。
     */
    @JSONField(name = "UUID")
    private String uuid;

    /**
     * 图片格式。JPG = 1，GIF = 2，PNG = 3，BMP = 4，其他 = 255。
     */
    @JSONField(name = "ImageFormat")
    private Integer imageFormat;

    /**
     * 原图、缩略图或者大图下载信息。
     */
    @JSONField(name = "ImageInfoArray")
    private List<TIMImageInfo> TIMImageInfoList;
}
