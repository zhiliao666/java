package com.ufoto.friendchat.service.impl;

import com.google.common.collect.Lists;
import com.ufoto.friendchat.entity.BaseUfotoMatchSimilar;
import com.ufoto.friendchat.entity.UfotoMatchSimilar;
import com.ufoto.friendchat.entity.UfotoMatchSimilarExample;
import com.ufoto.friendchat.mapper.read.UfotoMatchSimilarMapper;
import com.ufoto.friendchat.service.UfotoMatchSimilarService;
import com.ufoto.friendchat.utils.BeanUtil;
import lombok.RequiredArgsConstructor;
import org.springframework.stereotype.Service;
import org.springframework.util.CollectionUtils;

import java.util.List;
import java.util.Set;
import java.util.stream.Collectors;

/**
 * <p>
 * Author     : Chan
 * CreateDate : 2019-01-15 14:33
 * Description:
 * </p>
 */
@Service
@RequiredArgsConstructor
public class UfotoMatchSimilarServiceImpl implements UfotoMatchSimilarService {

    private final UfotoMatchSimilarMapper ufotoMatchSimilarMapper;

    @Override
    public List<UfotoMatchSimilar> querySimilars(Set<String> langSet) {
        UfotoMatchSimilarExample ufotoMatchSimilarExample = new UfotoMatchSimilarExample();
        ufotoMatchSimilarExample.createCriteria().andIsDeleteEqualTo(0).andLangIn(Lists.newArrayList(langSet));
        ufotoMatchSimilarExample.setOrderByClause(" category,priority asc ");
        final List<BaseUfotoMatchSimilar> baseUfotoMatchSimilars = ufotoMatchSimilarMapper.selectMatchSimilarByLang(Lists.newArrayList(langSet));
        if (CollectionUtils.isEmpty(baseUfotoMatchSimilars)) {
            return Lists.newArrayList();
        }
        return baseUfotoMatchSimilars.stream().map(baseUfotoMatchSimilar ->
                BeanUtil.copyPropertiesByNotNull(baseUfotoMatchSimilar, new UfotoMatchSimilar()))
                .collect(Collectors.toList());
    }
}
