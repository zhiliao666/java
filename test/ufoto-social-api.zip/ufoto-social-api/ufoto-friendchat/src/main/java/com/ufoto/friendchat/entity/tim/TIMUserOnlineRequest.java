package com.ufoto.friendchat.entity.tim;

import com.alibaba.fastjson.annotation.JSONField;
import lombok.Builder;
import lombok.Data;

/**
 *
 * @Author Wang, Qing
 * @Date 2019/10/26 15:16
 */
@Data
@Builder
public class TIMUserOnlineRequest {

    /**
     * 回调命令
     */
    @JSONField(name = "CallbackCommand")
    private String callbackCommand;

    /**
     * 用户上下线的信息
     */
    @JSONField(name = "Info")
    private TIMUserOnlineInfo info;
}
