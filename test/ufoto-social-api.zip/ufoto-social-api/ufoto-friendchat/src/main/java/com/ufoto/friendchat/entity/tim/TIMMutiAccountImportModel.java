package com.ufoto.friendchat.entity.tim;

import com.alibaba.fastjson.annotation.JSONField;
import lombok.Builder;
import lombok.Data;

import java.util.List;

/**
 *
 * @Author Wang, Qing
 * @Date 2019/11/14 13:52
 */
@Builder
@Data
public class TIMMutiAccountImportModel {
    @JSONField(name = "Accounts")
    private List<String> uids;
}
