package com.ufoto.friendchat.entity;

import lombok.Data;

import java.util.List;
import java.util.Map;

/**
 * <p>
 * Author     : Chan
 * CreateDate : 2019-01-15 18:04
 * Description:
 * </p>
 */
@Data
public class SimilarDto {
    private List<UfotoAppUser> users;
    private Map<Long, List<Integer>> interestMap;
    private List<UfotoMatchSimilar> similars;
    private List<UfotoMatchSimilar> targetSimilars;
    private List<SingleMatchSimilar> finalResults;
    private List<SingleMatchSimilar> targetFinalResults;
}
