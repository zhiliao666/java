package com.ufoto.friendchat.service;

import com.ufoto.friendchat.entity.UfotoMatchSimilar;

import java.util.List;
import java.util.Set;

/**
 * <p>
 * Author     : Chan
 * CreateDate : 2019-01-15 14:33
 * Description:
 * </p>
 */
public interface UfotoMatchSimilarService {

    List<UfotoMatchSimilar> querySimilars(Set<String> langSet);
}
