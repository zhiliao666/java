package com.ufoto.friendchat.constants.tim;

/**
 *
 * @Author Wang, Qing
 * @Date 2019/11/6 17:15
 */
public enum ETIMUserVipStatus {

    IS_NOT_VIP(0, "非会员"),
    IS_VIP(1, "会员");

    ETIMUserVipStatus(Integer status, String desc) {
        this.status = status;
        this.desc = desc;
    }

    private Integer status;

    public Integer getStatus() {
        return status;
    }

    public void setStatus(Integer status) {
        this.status = status;
    }

    public String getDesc() {
        return desc;
    }

    public void setDesc(String desc) {
        this.desc = desc;
    }

    private String desc;

}
