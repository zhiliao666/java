package com.ufoto.friendchat.entity;

import javax.persistence.Column;
import javax.persistence.Id;
import javax.persistence.Table;

@Table(name = "ufoto_country")
public class UfotoCountry {
    /**
     * id
     */
    @Id
    private Integer id;

    /**
     * 地区对应国际代码
     */
    @Column(name = "country_code")
    private String countryCode;

    /**
     * 地区
     */
    @Column(name = "country_name")
    private String countryName;

    /**
     * 地区汉语名称
     */
    @Column(name = "chinese_name")
    private String chineseName;

    /**
     * 0不区分多语言，1区分多语言
     */
    private String type;

    /**
     * 多语言
     */
    @Column(name = "multi_lang_data")
    private String multiLangData;

    /**
     * 获取id
     *
     * @return id - id
     */
    public Integer getId() {
        return id;
    }

    /**
     * 设置id
     *
     * @param id id
     */
    public void setId(Integer id) {
        this.id = id;
    }

    /**
     * 获取地区对应国际代码
     *
     * @return country_code - 地区对应国际代码
     */
    public String getCountryCode() {
        return countryCode;
    }

    /**
     * 设置地区对应国际代码
     *
     * @param countryCode 地区对应国际代码
     */
    public void setCountryCode(String countryCode) {
        this.countryCode = countryCode;
    }

    /**
     * 获取地区
     *
     * @return country_name - 地区
     */
    public String getCountryName() {
        return countryName;
    }

    /**
     * 设置地区
     *
     * @param countryName 地区
     */
    public void setCountryName(String countryName) {
        this.countryName = countryName;
    }

    /**
     * 获取地区汉语名称
     *
     * @return chinese_name - 地区汉语名称
     */
    public String getChineseName() {
        return chineseName;
    }

    /**
     * 设置地区汉语名称
     *
     * @param chineseName 地区汉语名称
     */
    public void setChineseName(String chineseName) {
        this.chineseName = chineseName;
    }

    /**
     * 获取0不区分多语言，1区分多语言
     *
     * @return type - 0不区分多语言，1区分多语言
     */
    public String getType() {
        return type;
    }

    /**
     * 设置0不区分多语言，1区分多语言
     *
     * @param type 0不区分多语言，1区分多语言
     */
    public void setType(String type) {
        this.type = type;
    }

    /**
     * 获取多语言
     *
     * @return multi_lang_data - 多语言
     */
    public String getMultiLangData() {
        return multiLangData;
    }

    /**
     * 设置多语言
     *
     * @param multiLangData 多语言
     */
    public void setMultiLangData(String multiLangData) {
        this.multiLangData = multiLangData;
    }
}