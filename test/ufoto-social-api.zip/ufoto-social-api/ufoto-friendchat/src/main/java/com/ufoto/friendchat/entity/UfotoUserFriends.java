package com.ufoto.friendchat.entity;

import javax.persistence.*;

@Table(name = "ufoto_user_friends")
public class UfotoUserFriends {
    @Id
    private Long id;

    /**
     * 用户id
     */
    @Column(name = "u_id")
    private Long uId;

    /**
     * 朋友用户id
     */
    @Column(name = "f_id")
    private Long fId;

    /**
     * 好友来源 0 正常匹配 1 临时匹配活动
     */
    @Column(name = "from_type")
    private Byte fromType;

    /**
     * 是否置顶 0 未置顶 1 置顶
     */
    @Column(name = "is_top")
    private Byte isTop;

    /**
     * 是否删除 0未删除 1 删除
     */
    @Column(name = "is_delete")
    private Byte isDelete;

    /**
     * 好友是否删除我 0 未删除 1 已删除
     */
    @Column(name = "f_is_delete")
    private Byte fIsDelete;

    /**
     * 创建时间
     */
    @Column(name = "create_time")
    private Integer createTime;

    /**
     * 修改时间
     */
    @Column(name = "update_time")
    private Integer updateTime;

    /**
     * @return id
     */
    public Long getId() {
        return id;
    }

    /**
     * @param id
     */
    public void setId(Long id) {
        this.id = id;
    }

    /**
     * 获取用户id
     *
     * @return u_id - 用户id
     */
    public Long getuId() {
        return uId;
    }

    /**
     * 设置用户id
     *
     * @param uId 用户id
     */
    public void setuId(Long uId) {
        this.uId = uId;
    }

    /**
     * 获取朋友用户id
     *
     * @return f_id - 朋友用户id
     */
    public Long getfId() {
        return fId;
    }

    /**
     * 设置朋友用户id
     *
     * @param fId 朋友用户id
     */
    public void setfId(Long fId) {
        this.fId = fId;
    }

    /**
     * 获取好友来源 0 正常匹配 1 临时匹配活动
     *
     * @return from_type - 好友来源 0 正常匹配 1 临时匹配活动
     */
    public Byte getFromType() {
        return fromType;
    }

    /**
     * 设置好友来源 0 正常匹配 1 临时匹配活动
     *
     * @param fromType 好友来源 0 正常匹配 1 临时匹配活动
     */
    public void setFromType(Byte fromType) {
        this.fromType = fromType;
    }

    /**
     * 获取是否置顶 0 未置顶 1 置顶
     *
     * @return is_top - 是否置顶 0 未置顶 1 置顶
     */
    public Byte getIsTop() {
        return isTop;
    }

    /**
     * 设置是否置顶 0 未置顶 1 置顶
     *
     * @param isTop 是否置顶 0 未置顶 1 置顶
     */
    public void setIsTop(Byte isTop) {
        this.isTop = isTop;
    }

    /**
     * 获取是否删除 0未删除 1 删除
     *
     * @return is_delete - 是否删除 0未删除 1 删除
     */
    public Byte getIsDelete() {
        return isDelete;
    }

    /**
     * 设置是否删除 0未删除 1 删除
     *
     * @param isDelete 是否删除 0未删除 1 删除
     */
    public void setIsDelete(Byte isDelete) {
        this.isDelete = isDelete;
    }

    /**
     * 获取好友是否删除我 0 未删除 1 已删除
     *
     * @return f_is_delete - 好友是否删除我 0 未删除 1 已删除
     */
    public Byte getfIsDelete() {
        return fIsDelete;
    }

    /**
     * 设置好友是否删除我 0 未删除 1 已删除
     *
     * @param fIsDelete 好友是否删除我 0 未删除 1 已删除
     */
    public void setfIsDelete(Byte fIsDelete) {
        this.fIsDelete = fIsDelete;
    }

    /**
     * 获取创建时间
     *
     * @return create_time - 创建时间
     */
    public Integer getCreateTime() {
        return createTime;
    }

    /**
     * 设置创建时间
     *
     * @param createTime 创建时间
     */
    public void setCreateTime(Integer createTime) {
        this.createTime = createTime;
    }

    /**
     * 获取修改时间
     *
     * @return update_time - 修改时间
     */
    public Integer getUpdateTime() {
        return updateTime;
    }

    /**
     * 设置修改时间
     *
     * @param updateTime 修改时间
     */
    public void setUpdateTime(Integer updateTime) {
        this.updateTime = updateTime;
    }
}