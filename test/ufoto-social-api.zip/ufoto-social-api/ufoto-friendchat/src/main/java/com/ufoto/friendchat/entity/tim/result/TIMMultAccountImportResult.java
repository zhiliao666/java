package com.ufoto.friendchat.entity.tim.result;

import com.alibaba.fastjson.annotation.JSONField;
import lombok.Builder;
import lombok.Data;

import java.util.List;

/**
 *
 * @Author Wang, Qing
 * @Date 2019/10/23 09:51
 */
@Data
@Builder
public class TIMMultAccountImportResult {

    @JSONField(name = "FailAccounts")
    List<String> failAccounts;

    @JSONField(name = "ActionStatus")
    private String actionStatus;

    @JSONField(name = "ErrorCode")
    private Integer errorCode;

    @JSONField(name = "ErrorInfo")
    private String errorInfo;
}
