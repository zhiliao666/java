package com.ufoto.friendchat.entity.tim;

import com.alibaba.fastjson.annotation.JSONField;
import lombok.Builder;
import lombok.Data;

/**
 *
 * @Author Wang, Qing
 * @Date 2019/10/26 10:34
 * 详情见：https://cloud.tencent.com/document/product/269/2720
 */
@Data
@Builder
public class TIMImageInfo {

    /**
     * 图片类型： 1-原图，2-大图，3-缩略图。
     */
    @JSONField(name = "Type")
    private Integer type;

    /**
     * 图片数据大小，单位：字节。
     */
    @JSONField(name = "Size")
    private Integer size;

    /**
     * 图片宽度。
     */
    @JSONField(name = "Width")
    private Integer width;

    /**
     * 图片高度。
     */
    @JSONField(name = "Height")
    private Integer height;

    /**
     * 图片下载地址。
     */
    @JSONField(name = "URL")
    private String url;
}
