package com.ufoto.friendchat.factory;

import com.ufoto.friendchat.entity.SimilarDto;
import com.ufoto.friendchat.entity.SingleMatchSimilar;
import com.ufoto.friendchat.entity.UfotoAppUser;
import lombok.extern.slf4j.Slf4j;
import org.joda.time.DateTime;
import org.springframework.stereotype.Component;

import java.util.List;

/**
 * <p>
 * Author     : Chan
 * CreateDate : 2019-01-16 10:36
 * Description:
 * </p>
 */
@Slf4j
@Component
public class BirthdayYearSimilarFactory implements MatchSimilarFactory {
    @Override
    public SingleMatchSimilar doSimilar(SimilarDto similarDto) {
        final List<UfotoAppUser> users = similarDto.getUsers();
        DateTime dd1 = getUserDatetime(users.get(0));
        DateTime dd2 = getUserDatetime(users.get(1));
        if (dd1 == null || dd2 == null) {
            return null;
        }
        final String y1 = dd1.year().getAsString();
        final String y2 = dd2.year().getAsString();
        log.debug("sameYear,user1:{},d1:{},user2:{},d2:{}", users.get(0).getId(), dd1, users.get(1).getId(), dd2);
        if (!y1.equals(y2)) {
            return null;
        }
        return getSingleMatchSimilar(similarDto, new String[]{y1}, new String[]{y2});
    }
}
