package com.ufoto.friendchat.constants;

import java.util.Objects;

/**
 * <p>
 * 临时配对的状态
 * </p>
 *
 * @author created by chenzhou at 2018-08-01 13:38
 */
public enum ETempFriendStatus {
    TEMP_MATCH(0, "临时匹配成功"),
    USER_DISLIKE(1, "用户删除(一方执行了dislike"),
    EXPIRE_24_AUTO_DELETE(2, "过期24小时自动删除"),
    MAKE_FRIENDS(3, "转为朋友正常配对");

    private Integer status;
    private String description;

    ETempFriendStatus(Integer status, String description) {
        this.status = status;
        this.description = description;
    }

    public Integer getStatus() {
        return status;
    }

    public String getDescription() {
        return description;
    }

    public static Boolean contains(Integer status) {
        if (Objects.equals(status, TEMP_MATCH.getStatus()) ||
                Objects.equals(status, USER_DISLIKE.getStatus()) ||
                Objects.equals(status, EXPIRE_24_AUTO_DELETE.getStatus()) ||
                Objects.equals(status, MAKE_FRIENDS.getStatus())) {
            return true;
        }
        return false;
    }
}
