package com.ufoto.friendchat.constants.tim;

/**
 *
 * @Author Wang, Qing
 * @Date 2019/10/26 16:22
 */
public enum ETIMCallbackCommand {

    CALLBACK_BEFORE_SEND_MSG("C2C.CallbackBeforeSendMsg"),
    CALLBACK_AFTER_SEND_MSG("C2C.CallbackAfterSendMsg"),
    CALLBACK_STATE_CHANGE("State.StateChange");


    private String command;

    ETIMCallbackCommand(String command) {
        this.command = command;
    }

    public String getCommand() {
        return command;
    }
}
