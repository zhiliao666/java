package com.ufoto.friendchat.converter;

import com.ufoto.feign.usercenter.dto.UserBaseInfoDto;
import com.ufoto.friendchat.entity.UfotoAppUser;
import com.ufoto.friendchat.utils.BeanUtil;

import java.util.List;
import java.util.stream.Collectors;

/**
 * <p>
 * Author     : Chan
 * CreateDate : 2019-03-20 18:32
 * Description:
 * </p>
 */
public class UserCenterConverter {

    public static List<UfotoAppUser> userBaseInfos2UfotoAppUsers(List<UserBaseInfoDto> userBaseInfos) {
        return userBaseInfos.stream().map(userBaseInfo -> BeanUtil.copyPropertiesByNotNull(userBaseInfo, new UfotoAppUser())).collect(Collectors.toList());
    }
}
