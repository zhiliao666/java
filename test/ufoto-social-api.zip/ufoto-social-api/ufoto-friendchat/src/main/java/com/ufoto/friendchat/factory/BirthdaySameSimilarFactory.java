package com.ufoto.friendchat.factory;

import com.ufoto.friendchat.entity.SimilarDto;
import com.ufoto.friendchat.entity.SingleMatchSimilar;
import com.ufoto.friendchat.entity.UfotoAppUser;
import lombok.extern.slf4j.Slf4j;
import org.joda.time.DateTime;
import org.joda.time.format.DateTimeFormat;
import org.springframework.stereotype.Component;

import java.util.List;
import java.util.Locale;

/**
 * <p>
 * Author     : Chan
 * CreateDate : 2019-01-16 10:37
 * Description:
 * </p>
 */
@Slf4j
@Component
public class BirthdaySameSimilarFactory implements MatchSimilarFactory {
    @Override
    public SingleMatchSimilar doSimilar(SimilarDto similarDto) {
        final List<UfotoAppUser> users = similarDto.getUsers();
        DateTime dd1 = getUserDatetime(users.get(0));
        DateTime dd2 = getUserDatetime(users.get(1));
        if (dd1 == null || dd2 == null) {
            return null;
        }
        String s1 = dd1.toString(DateTimeFormat.mediumDate().withLocale(Locale.forLanguageTag(users.get(0).getLang())));
        String s2 = dd2.toString(DateTimeFormat.mediumDate().withLocale(Locale.forLanguageTag(users.get(1).getLang())));
        log.debug("sameBirthday,user1:{},d1:{},user2:{},d2:{}", users.get(0).getId(), dd1, users.get(1).getId(), dd2);
        if (!s1.equals(s2)) {
            return null;
        }
        return getSingleMatchSimilar(similarDto, new String[]{s1}, new String[]{s2});
    }
}
