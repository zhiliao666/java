package com.ufoto.friendchat.constants.tim;

/**
 *
 * @Author Wang, Qing
 * @Date 2019/10/23 17:44
 * 好友分组，不可修改
 */
public enum  ETIMFriendGroup {
    temp,
    formal
}
