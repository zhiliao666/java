package com.ufoto.friendchat.service;

import com.ufoto.common.utils.ApiResult;

/**
 * Created by Wang, Qing
 * 2020/2/26
 */
public interface UfotoUserFriendsService {

    /**
     * 返回任意2个人当前的关系是不是好友(包含正式好友和临时匹配好友)
     *
     * @param toUid
     * @param uid
     * @return
     */
    ApiResult<Boolean> isFriends(Long toUid, Long uid);

    void doNormalFriendMatch(Long uid, Long fUid);

}
