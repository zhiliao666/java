package com.ufoto.friendchat.entity.tim;

import com.alibaba.fastjson.annotation.JSONField;
import lombok.Builder;
import lombok.Data;

import java.util.List;

/**
 *
 * @Author Wang, Qing
 * @Date 2019/10/23 14:35
 */
@Data
@Builder
public class TIMUpdateFriendItem {

    @JSONField(name = "To_Account")
    private String tUid;

    @JSONField(name = "SnsItem")
    private List<TIMCustomItem> timCustomItemList;

}
