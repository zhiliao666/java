package com.ufoto.friendchat.factory;

import com.ufoto.friendchat.constants.EConstellation;
import com.ufoto.friendchat.entity.SimilarDto;
import com.ufoto.friendchat.entity.SingleMatchSimilar;
import com.ufoto.friendchat.entity.UfotoAppUser;
import com.ufoto.friendchat.utils.ConstellationUtil;
import lombok.extern.slf4j.Slf4j;
import org.joda.time.DateTime;
import org.springframework.context.MessageSource;
import org.springframework.stereotype.Component;

import java.util.List;

/**
 * <p>
 * Author     : Chan
 * CreateDate : 2019-01-16 12:18
 * Description: 同象星座
 * </p>
 */
@Slf4j
@Component
public class BirthdayConstellationIsomorphicSimilarFactory implements MatchSimilarFactory {

    private final MessageSource messageSource;

    public BirthdayConstellationIsomorphicSimilarFactory(MessageSource messageSource) {
        this.messageSource = messageSource;
    }

    @Override
    public SingleMatchSimilar doSimilar(SimilarDto similarDto) {
        final List<UfotoAppUser> users = similarDto.getUsers();
        DateTime dd1 = getUserDatetime(users.get(0));
        DateTime dd2 = getUserDatetime(users.get(1));
        if (dd1 == null || dd2 == null) {
            return null;
        }
        final EConstellation c1 = ConstellationUtil.getConstellation(dd1.toDate());
        final EConstellation c2 = ConstellationUtil.getConstellation(dd2.toDate());
        log.debug("isomorphic,user1:{},iso1:{},user2:{},iso2:{}", users.get(0).getId(), c2.getIsomorphic(), users.get(1).getId(), c2.getIsomorphic());
        if (!c1.getIsomorphic().equals(c2.getIsomorphic())) {
            return null;
        }
        return getSingleMatchSimilar(similarDto, new String[]{ConstellationUtil.getIsomorphic(messageSource, c1.getIsomorphic(), users.get(0).getLang())},
                new String[]{ConstellationUtil.getIsomorphic(messageSource, c2.getIsomorphic(), users.get(1).getLang())});
    }
}
