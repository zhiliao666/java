package com.ufoto.friendchat.manager;

import com.google.common.base.Joiner;
import com.google.common.collect.Lists;
import com.google.common.collect.Sets;
import com.ufoto.common.utils.CollectorsUtil;
import com.ufoto.common.utils.JsonUtil;
import com.ufoto.common.utils.SpringContextUtil;
import com.ufoto.feign.chat.MsgChatBusiness;
import com.ufoto.friendchat.constants.Constants;
import com.ufoto.friendchat.constants.EMatchSimilarType;
import com.ufoto.friendchat.constants.EMsgType;
import com.ufoto.friendchat.constants.ESupportLanguage;
import com.ufoto.friendchat.entity.*;
import com.ufoto.friendchat.factory.MatchSimilarFactory;
import com.ufoto.friendchat.service.UfotoMatchSimilarService;
import com.ufoto.friendchat.service.UfotoUserInterestTagService;
import com.ufoto.redis.service.RedisService;
import lombok.RequiredArgsConstructor;
import lombok.extern.slf4j.Slf4j;
import org.apache.commons.lang3.RandomUtils;
import org.apache.commons.lang3.StringUtils;
import org.springframework.core.env.Environment;
import org.springframework.scheduling.annotation.Async;
import org.springframework.stereotype.Component;
import org.springframework.util.CollectionUtils;

import java.util.*;
import java.util.stream.Collectors;

import static com.ufoto.friendchat.constants.Constants.REDIS_MATCH_SIMILAR_RECORD;

/**
 * Created by Wang, Qing
 * 2020/3/9
 */
@Component
@RequiredArgsConstructor
@Slf4j
public class MatchSimilarManager {

    final RedisService redisService;

    final UserManagerFriendChat userManager;

    final Environment env;

    final MsgChatBusiness msgChatBusiness;

    final UfotoMatchSimilarService ufotoMatchSimilarService;

    final UfotoUserInterestTagService ufotoUserInterestTagService;

    private static List<String> supportLangs =
            Arrays.stream(ESupportLanguage.values())
                    .filter(s -> s != ESupportLanguage.IN && s != ESupportLanguage.RU)
                    .map(ESupportLanguage::getLang).collect(Collectors.toList());

    public void syncSimilar(Long uid, Long targetUid) {
        handleSimilar(uid, targetUid);
    }

    @Async
    public void similar(Long uid, Long targetUid) {
        handleSimilar(uid, targetUid);
    }

    private void handleSimilar(Long uid, Long targetUid) {
        if (uid == null || targetUid == null) {
            return;
        }
        final String similarRecordKey = Joiner.on(":").join(Math.min(uid, targetUid), Math.max(uid, targetUid));
        final String key = REDIS_MATCH_SIMILAR_RECORD + similarRecordKey;
        try {
            if (!redisService.setIfAbsent(key, "1", 300)) {
                //说明已经存在了  不再继续执行
                log.warn("{}, similarRecordKey:{}", "WARN_MATCH_SIMILAR_DUPLICATE", similarRecordKey);
                return;
            }
            //条件
            final List<Long> uids = Lists.newArrayList(uid, targetUid);
            final List<UfotoAppUser> ufotoAppUsers = userManager.queryUsers(uids);
            if (CollectionUtils.isEmpty(ufotoAppUsers) || ufotoAppUsers.size() != 2) {
                return;
            }
            final Boolean checkSocial = env.getProperty("match.similar.social", Boolean.class, Boolean.FALSE);
            if (checkSocial) {
                boolean ifSocial = true;
                List<Integer> supportLoginSources = Lists.newArrayList(Constants.USER_FROM_TYPE_3, Constants.USRE_FROM_TYPE_SNAP, Constants.USRE_FROM_TYPE_SNAP_LITE, Constants.USRE_FROM_TYPE_IOS);
                for (UfotoAppUser user : ufotoAppUsers) {
                    if (!supportLoginSources.contains(user.getLoginSource())) {
                        ifSocial = false;
                        break;
                    }
                }
                if (!ifSocial) {
                    log.debug("matchSimilarNotSocialUsers:{}", JsonUtil.toJson(ufotoAppUsers));
                    redisService.del(key);
                    return;
                }
            }
            ufotoAppUsers.forEach(u -> {
                if (!isSupportLang(u.getLang())) {
                    u.setLang(ESupportLanguage.EN.getLang());
                }
            });
            //获取用户语言
            final Map<Long, String> langMap = ufotoAppUsers.stream().collect(
                    CollectorsUtil.toMap(UfotoAppUser::getId, UfotoAppUser::getLang));
            Set<String> langSet = Sets.newHashSet(langMap.values());
            //查询文案
            final List<UfotoMatchSimilar> ufotoMatchSimilars = ufotoMatchSimilarService.querySimilars(langSet);
            if (CollectionUtils.isEmpty(ufotoMatchSimilars)) return;

            //按分类 类型分组
            final Map<Integer, Map<Integer, List<UfotoMatchSimilar>>> categorySimilarMap = ufotoMatchSimilars.parallelStream()
                    .filter(ufotoMatchSimilar -> ufotoMatchSimilar.getLang().equals(langMap.get(uid)))
                    .collect(CollectorsUtil.groupingBy(UfotoMatchSimilar::getCategory,
                            CollectorsUtil.groupingBy(UfotoMatchSimilar::getType)));
            //targetMap
            Map<Integer, Map<Integer, List<UfotoMatchSimilar>>> targetCategorySimilarMap;
            if (langSet.size() == 2) {
                targetCategorySimilarMap = ufotoMatchSimilars.parallelStream()
                        .filter(ufotoMatchSimilar -> ufotoMatchSimilar.getLang().equals(langMap.get(targetUid)))
                        .collect(CollectorsUtil.groupingBy(UfotoMatchSimilar::getCategory,
                                CollectorsUtil.groupingBy(UfotoMatchSimilar::getType)));
            } else {
                targetCategorySimilarMap = categorySimilarMap;
            }

            final Map<String, ? extends Class<? extends MatchSimilarFactory>> factoryMap = Arrays.stream(
                    EMatchSimilarType.values()).collect(CollectorsUtil.toMap(s -> similarKey(s.getCategory(), s.getType()), EMatchSimilarType::getFactory));

            //条件
            Map<Long, List<Integer>> interests = ufotoUserInterestTagService.queryCategoryIdByUids(uids);
            //条件
            final Map<Long, UfotoAppUser> tempUserMap = ufotoAppUsers.stream().collect(Collectors.toMap(UfotoAppUser::getId, u -> u));
            SimilarDto similarDto = new SimilarDto();
            similarDto.setUsers(Lists.newArrayList(tempUserMap.get(uid), tempUserMap.get(targetUid)));
            similarDto.setInterestMap(interests);
            similarDto.setFinalResults(Lists.newArrayList());
            similarDto.setTargetFinalResults(Lists.newArrayList());
            //处理
            for (Map.Entry<Integer, Map<Integer, List<UfotoMatchSimilar>>> entry : categorySimilarMap.entrySet()) {
                //type<-->list
                final Map<Integer, List<UfotoMatchSimilar>> value = entry.getValue();
                for (Map.Entry<Integer, List<UfotoMatchSimilar>> typeEntry : value.entrySet()) {
                    final Class<? extends MatchSimilarFactory> factory = factoryMap.get(similarKey(entry.getKey(), typeEntry.getKey()));
                    if (factory == null) continue;
                    final List<UfotoMatchSimilar> typeValues = typeEntry.getValue();
                    similarDto.setSimilars(typeValues);
                    similarDto.setTargetSimilars(targetCategorySimilarMap.get(entry.getKey()).get(typeEntry.getKey()));
                    final SingleMatchSimilar singleMatchSimilar = SpringContextUtil.getBean(factory).doSimilar(similarDto);
                    if (singleMatchSimilar != null) {
                        similarDto.getFinalResults().add(singleMatchSimilar);
                        similarDto.getTargetFinalResults().add(singleMatchSimilar);
                        //每个取分类一条
                        break;
                    }
                }
                if (similarDto.getFinalResults().size() == 2) {
                    //所有分类取两条
                    break;
                }
            }
            //发送消息
            final String matchSimilar = getMatchSimilar(similarDto.getFinalResults(), false);
            final String targetMatchSimilar = getMatchSimilar(similarDto.getTargetFinalResults(), true);
            log.debug("uid:{},targetUid:{},matchSimilar:{},targetMatchSimilar:{}", uid, targetUid, matchSimilar, targetMatchSimilar);
            msgChatBusiness.sendMsg(uid, targetUid, targetMatchSimilar, EMsgType.MATCH_SIMILAR.getMsgType(), 0);
            msgChatBusiness.sendMsg(targetUid, uid, matchSimilar, EMsgType.MATCH_SIMILAR.getMsgType(), 0);
        } catch (Exception e) {
            log.error("{}, {}", "ERROR_MATCH_SIMILAR", e);
            redisService.del(key);
        }
    }

    private boolean isSupportLang(String lang) {
        if (StringUtils.isBlank(lang)) return false;
        return supportLangs.contains(lang);
    }

    private String getMatchSimilar(List<SingleMatchSimilar> finalResults, boolean isTarget) {
        MatchSimilar matchSimilar = new MatchSimilar();
        final OptionalDouble optionalDouble = finalResults.stream().mapToInt(SingleMatchSimilar::getRate).average();
        if (optionalDouble.isPresent()) {
            matchSimilar.setRate((int) optionalDouble.getAsDouble());
        } else {
            matchSimilar.setRate(RandomUtils.nextInt(60, 100));
        }
        matchSimilar.setSimilar(finalResults.stream().map(singleMatchSimilar ->
                isTarget ? singleMatchSimilar.getTargetDescriptions() : singleMatchSimilar.getDescriptions())
                .flatMap(Collection::stream).collect(Collectors.toList()));
        return JsonUtil.toJson(matchSimilar);
    }

    private String similarKey(Integer category, Integer type) {
        return Joiner.on("-").join(category, type);
    }

}
