package com.ufoto.friendchat.utils;

import com.google.common.base.Joiner;
import com.google.common.collect.Lists;
import com.ufoto.common.utils.DateUtil;
import com.ufoto.friendchat.constants.ESupportLanguage;
import lombok.extern.slf4j.Slf4j;
import org.apache.commons.lang3.StringUtils;
import org.springframework.util.CollectionUtils;

import java.util.*;
import java.util.concurrent.ConcurrentHashMap;
import java.util.function.Function;
import java.util.function.Predicate;
import java.util.stream.Collectors;

/**
 * <p>
 * Author     : Chan
 * CreateDate : 2018-12-26 14:55
 * Description:
 * </p>
 */
@Slf4j
public class CommonUtil {

    private static List<String> supportLangs =
            Arrays.stream(ESupportLanguage.values())
                    .filter(s -> s != ESupportLanguage.IN && s != ESupportLanguage.RU)
                    .map(ESupportLanguage::getLang).collect(Collectors.toList());

    public static Boolean obj2Boolean(Object obj) {
        if (obj == null) {
            return false;
        }

        if (Boolean.class.isAssignableFrom(obj.getClass())) {
            return (Boolean) obj;
        }
        throw new RuntimeException("目标Obj不是Boolean类型，转换错误");
    }

    public static List obj2List(Object obj) {
        if (obj == null) {
            return Lists.newArrayList();
        }

        if (List.class.isAssignableFrom(obj.getClass())) {
            return (List) obj;
        }
        throw new RuntimeException("目标Obj不是Boolean类型，转换错误");
    }

    public static Double obj2Double(Object obj) {
        if (obj == null) {
            return 0d;
        }

        if (Double.class.isAssignableFrom(obj.getClass())) {
            return (Double) obj;
        }
        throw new RuntimeException("目标Obj不是Double类型，转换错误");
    }

    /**
     * String 转换成 Integer，格式不对返回null
     *
     * @return 可能为null
     */
    public static Integer safeString2Integer(String string) {
        try {
            return Integer.parseInt(string);
        } catch (NumberFormatException e) {
            return null;
        }
    }

    /**
     * String 转换成 Long，格式不对返回null
     *
     * @return 可能为null
     */
    public static Long safeString2Long(String string) {
        try {
            return Long.parseLong(string);
        } catch (NumberFormatException e) {
            return null;
        }
    }

    public static String addQuote(Object str) {
        return "\"" + str + "\"";
    }

    public static String getLang(String lang) {
        if (StringUtils.isBlank(lang) || !supportLangs.contains(lang)) {
            return ESupportLanguage.EN.getLang();
        }
        return lang;
    }

    public static boolean isSupportLang(String lang) {
        if (StringUtils.isBlank(lang)) return false;
        return supportLangs.contains(lang);
    }

    public static int[] randomCommon(int min, int max, int n) {
        int[] result = new int[n];
        int count = 0;
        while (count < n) {
            int num = (int) (Math.random() * (max - min)) + min;
            boolean flag = true;
            for (int j = 0; j < n; j++) {
                if (num == result[j]) {
                    flag = false;
                    break;
                }
            }
            if (flag) {
                result[count] = num;
                count++;
            }
        }
        return result;
    }

    public static String getGiftCacheKey(Integer goodsType, String lang, String page) {
        return Joiner.on(":").join("goods", "giftList", goodsType, lang, StringUtils.isBlank(page) ? 0 : page);
    }

    public static int getRankRefreshEndTime(int rankRefreshType) {
        if (rankRefreshType == 1) { // daily
            //获取当前时间的零点即为结束时间
            return DateUtil.getCurrentDayZero();
        } else if (rankRefreshType == 2) { //weekly
            //获取当前周的周一的零点
            return DateUtil.getCurrentMondayZero();
        } else if (rankRefreshType == 4) { // monthly
            //获取当前月的1号的零点
            return DateUtil.getCurrentMonthFirstDayZero();
        } else if (rankRefreshType == 3) {
            return DateUtil.getCurrentSecondIntValue();
        }
        return 0;
    }

    public static int getRankRefreshStartTime(int rankRefreshType) {
        if (rankRefreshType == 1) { // daily
            //结束时间往前推24小时
            return DateUtil.getBeforeCurrentDayZero();
        } else if (rankRefreshType == 2) { //weekly
            //结束时间往前推7天
            return DateUtil.getBeforeCurrentMondayZero();
        } else if (rankRefreshType == 4) { // monthly
            //获取上个月的1号零点
            return DateUtil.getBeforeCurrentMonthFirstDayZero();
        }
        return 0;
    }

    public static String handleLangAndMap(String lang, Map<String, String> map) {
        if (CollectionUtils.isEmpty(map)) return lang;
        StringBuilder sb = new StringBuilder();
        sb.append(lang).append(":");
        final Set<String> keys = map.keySet();
        for (String key : keys) {
            sb.append(map.get(key)).append(":");
        }
        sb.deleteCharAt(sb.length() - 1);
        return sb.toString();
    }

    public static String handleGoodsTypeLangMap(Integer goodsType, String lang, Map<String, String> map) {
        if (CollectionUtils.isEmpty(map)) return lang;
        StringBuilder sb = new StringBuilder();
        sb.append(goodsType).append(":");
        sb.append(lang).append(":");
        final Set<String> keys = map.keySet();
        for (String key : keys) {
            sb.append(map.get(key)).append(":");
        }
        sb.deleteCharAt(sb.length() - 1);
        log.debug("handleGoodsTypeLangMap : {}", sb);
        return sb.toString();
    }

    public static Date age2Birth(Integer age) {
        if (age == null) return null;
        Calendar c = Calendar.getInstance();
        c.set(Calendar.MONTH, 0);
        c.set(Calendar.DAY_OF_MONTH, 1);
        c.set(Calendar.HOUR_OF_DAY, 0);
        c.set(Calendar.MINUTE, 0);
        c.set(Calendar.SECOND, 0);
        c.set(Calendar.YEAR, c.get(Calendar.YEAR) - age);
        return c.getTime();
    }

    public static Integer getRandomInt() {
        return new Random().nextInt(Integer.MAX_VALUE);
    }

    public static boolean isNumber(String s) {
        try {
            Double.parseDouble(s);
            return true;
        } catch (Exception e) {
            return false;
        }
    }

    public static String serializeUid(String uid) {
        if (uid == null) return null;
        return Joiner.on("").join("\"", uid, "\"");
    }

    public static <T> Predicate<T> distinctByKey(Function<? super T, ?> keyExtractor) {
        Set<Object> seen = ConcurrentHashMap.newKeySet();
        return t -> seen.add(keyExtractor.apply(t));
    }
}
