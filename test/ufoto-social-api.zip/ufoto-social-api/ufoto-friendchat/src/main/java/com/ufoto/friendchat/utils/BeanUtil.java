package com.ufoto.friendchat.utils;

import org.apache.commons.lang3.StringUtils;
import org.springframework.beans.BeanUtils;
import org.springframework.util.Assert;
import org.springframework.util.ClassUtils;

import java.beans.PropertyDescriptor;
import java.lang.reflect.Method;
import java.lang.reflect.Modifier;
import java.util.Arrays;
import java.util.List;

/**
 * <p>
 *
 * </p>
 *
 * @author created by chenzhou at 2018-06-06 11:51
 */
public class BeanUtil {

    /**
     * 拷贝对象的属性到另一个对象   参考BeanUtils.copyProperties()实现
     *
     * @param source           源对象
     * @param target           返回目标类
     * @param ignoreProperties 忽略属性名称
     * @return target
     */
    public static <T> T copyProperties(Object source, T target, String... ignoreProperties) {
        Assert.notNull(source, "Source must not be null");
        Assert.notNull(target, "Target must not be null");
        Class targetClass = target.getClass();
        Class sourceClass = source.getClass();

        PropertyDescriptor[] targetPds = BeanUtils.getPropertyDescriptors(targetClass);
        PropertyDescriptor[] sourcePds = BeanUtils.getPropertyDescriptors(sourceClass);

        List<String> ignoreList = (ignoreProperties != null ? Arrays.asList(ignoreProperties) : null);
        if (targetPds.length <= sourcePds.length) {
            for (PropertyDescriptor targetPd : targetPds) {
                Method writeMethod = targetPd.getWriteMethod();
                if (writeMethod == null || (ignoreList != null && ignoreList.contains(targetPd.getName()))) continue;
                PropertyDescriptor sourcePd = BeanUtils.getPropertyDescriptor(sourceClass, targetPd.getName());
                if (sourcePd == null) continue;
                Method readMethod = sourcePd.getReadMethod();
                if (readMethod == null || !ClassUtils.isAssignable(writeMethod.getParameterTypes()[0], readMethod.getReturnType()))
                    continue;
                readWriteInvoke(source, target, targetPd, writeMethod, readMethod);
            }
        } else {
            for (PropertyDescriptor sourcePd : sourcePds) {
                Method readMethod = sourcePd.getReadMethod();
                if (readMethod == null || (ignoreList != null && ignoreList.contains(sourcePd.getName()))) continue;
                PropertyDescriptor targetPd = BeanUtils.getPropertyDescriptor(targetClass, sourcePd.getName());
                if (targetPd == null) continue;
                Method writeMethod = targetPd.getWriteMethod();
                if (writeMethod == null || !ClassUtils.isAssignable(writeMethod.getParameterTypes()[0], readMethod.getReturnType()))
                    continue;

                readWriteInvoke(source, target, targetPd, writeMethod, readMethod);

            }
        }
        return target;
    }

    private static <T> void readWriteInvoke(Object source, T target, PropertyDescriptor targetPd, Method writeMethod, Method readMethod) {
        try {
            if (!Modifier.isPublic(readMethod.getDeclaringClass().getModifiers())) {
                readMethod.setAccessible(true);
            }
            Object value = readMethod.invoke(source);
            if (!Modifier.isPublic(writeMethod.getDeclaringClass().getModifiers())) {
                writeMethod.setAccessible(true);
            }
            writeMethod.invoke(target, value);
        } catch (Throwable ex) {
            throw new RuntimeException("Could not copy property '" + targetPd.getName() + "' from source to target", ex);
        }
    }

    /**
     * 拷贝对象的属性到另一个对象 (只拷贝源对象参数值不为空的属性，如果为空则跳过)
     *
     * @param source           源对象
     * @param target           返回目标类
     * @param ignoreProperties 忽略属性名称
     * @return target
     */
    public static <T> T copyPropertiesByNotNull(Object source, T target, String... ignoreProperties) {
        Assert.notNull(source, "Source must not be null");
        Assert.notNull(target, "Target must not be null");
        Class targetClass = target.getClass();
        Class sourceClass = source.getClass();

        PropertyDescriptor[] targetPds = BeanUtils.getPropertyDescriptors(targetClass);
        PropertyDescriptor[] sourcePds = BeanUtils.getPropertyDescriptors(sourceClass);

        List<String> ignoreList = (ignoreProperties != null ? Arrays.asList(ignoreProperties) : null);
        if (targetPds.length <= sourcePds.length) {
            for (PropertyDescriptor targetPd : targetPds) {
                Method writeMethod = targetPd.getWriteMethod();
                if (writeMethod == null || (ignoreList != null && ignoreList.contains(targetPd.getName()))) continue;
                PropertyDescriptor sourcePd = BeanUtils.getPropertyDescriptor(sourceClass, targetPd.getName());
                if (sourcePd == null) continue;
                Method readMethod = sourcePd.getReadMethod();
                if (readMethod == null || !ClassUtils.isAssignable(writeMethod.getParameterTypes()[0], readMethod.getReturnType()))
                    continue;
                readWriteNotNullInvoke(source, target, targetPd, writeMethod, readMethod);
            }
        } else {
            for (PropertyDescriptor sourcePd : sourcePds) {
                Method readMethod = sourcePd.getReadMethod();
                if (readMethod == null || (ignoreList != null && ignoreList.contains(sourcePd.getName()))) continue;
                PropertyDescriptor targetPd = BeanUtils.getPropertyDescriptor(targetClass, sourcePd.getName());
                if (targetPd == null) continue;
                Method writeMethod = targetPd.getWriteMethod();
                if (writeMethod == null || !ClassUtils.isAssignable(writeMethod.getParameterTypes()[0], readMethod.getReturnType()))
                    continue;

                readWriteNotNullInvoke(source, target, targetPd, writeMethod, readMethod);

            }
        }
        return target;
    }

    private static <T> void readWriteNotNullInvoke(Object source, T target, PropertyDescriptor targetPd, Method writeMethod, Method readMethod) {
        try {
            if (!Modifier.isPublic(readMethod.getDeclaringClass().getModifiers())) {
                readMethod.setAccessible(true);
            }
            Object value = readMethod.invoke(source);
            if (value == null || StringUtils.isBlank(value.toString())) return;
            if (!Modifier.isPublic(writeMethod.getDeclaringClass().getModifiers())) {
                writeMethod.setAccessible(true);
            }
            writeMethod.invoke(target, value);
        } catch (Throwable ex) {
            throw new RuntimeException("Could not copy property '" + targetPd.getName() + "' from source to target", ex);
        }
    }
}
