package com.ufoto.friendchat.factory;

import com.ufoto.friendchat.entity.SimilarDto;
import com.ufoto.friendchat.entity.SingleMatchSimilar;
import com.ufoto.friendchat.entity.UfotoAppUser;
import com.ufoto.friendchat.manager.CountryCodeNameManager;
import com.ufoto.friendchat.utils.CommonUtil;
import lombok.extern.slf4j.Slf4j;
import org.apache.commons.lang3.StringUtils;
import org.springframework.stereotype.Component;

import java.util.List;

/**
 * <p>
 * Author     : Chan
 * CreateDate : 2019-07-23 15:20
 * Description:
 * </p>
 */
@Slf4j
@Component
public class DistanceCountryCountrySimilarFactory implements MatchSimilarFactory {
    private final CountryCodeNameManager countryCodeNameManager;

    public DistanceCountryCountrySimilarFactory(CountryCodeNameManager countryCodeNameManager) {
        this.countryCodeNameManager = countryCodeNameManager;
    }

    @Override
    public SingleMatchSimilar doSimilar(SimilarDto similarDto) {
        final List<UfotoAppUser> users = similarDto.getUsers();
        final UfotoAppUser u1 = users.get(0);
        final UfotoAppUser u2 = users.get(1);
        final String c1 = u1.getCountryCode();
        final String c2 = u2.getCountryCode();
        log.info("DistanceCountryCountry,user1:{},user2:{}", c1, c2);
        if (hasNull(c1, c2)) return null;
        final String countryName1 = countryCodeNameManager.getCountryName(c1, CommonUtil.getLang(u1.getLang()));
        final String countryName2 = countryCodeNameManager.getCountryName(c2, CommonUtil.getLang(u2.getLang()));
        if (StringUtils.isBlank(countryName1) || StringUtils.isBlank(countryName2)) return null;
        return getSingleMatchSimilar(similarDto, new String[]{countryName2}, new String[]{countryName1});
    }
}
