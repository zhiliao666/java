package com.ufoto.friendchat.manager;

import com.alibaba.fastjson.JSON;
import com.alibaba.fastjson.JSONObject;
import com.google.common.collect.Lists;
import com.ufoto.common.utils.CommonUtil;
import com.ufoto.common.utils.DateUtil;
import com.ufoto.common.utils.TimSigUtils;
import com.ufoto.common.utils.UfotoHttpClient;
import com.ufoto.friendchat.constants.tim.ETIMFriendAddSource;
import com.ufoto.friendchat.constants.tim.ETIMFriendGroup;
import com.ufoto.friendchat.constants.tim.ETIMFriendTop;
import com.ufoto.friendchat.entity.UfotoUserFriends;
import com.ufoto.friendchat.entity.tim.TIMAddFriendItem;
import com.ufoto.friendchat.entity.tim.TIMAddFriendModel;
import com.ufoto.friendchat.entity.tim.TIMCustomItem;
import com.ufoto.friendchat.entity.tim.TIMMutiAccountImportModel;
import com.ufoto.friendchat.entity.tim.result.TIMFriendResult;
import com.ufoto.friendchat.entity.tim.result.TIMMultAccountImportResult;
import lombok.extern.slf4j.Slf4j;
import org.apache.http.client.utils.URIBuilder;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.core.env.Environment;
import org.springframework.stereotype.Component;

import java.net.URI;
import java.net.URISyntaxException;
import java.util.List;
import java.util.Objects;

import static com.ufoto.friendchat.constants.TIMConstants.TIM_CUSTOM_TOP;
import static com.ufoto.friendchat.constants.TIMErrorCode.error_30003;
import static com.ufoto.friendchat.constants.TIMErrorCode.error_40003;
import static com.ufoto.friendchat.constants.tim.ETIMFriendTop.IS_TOP;

/**
 *
 * @Author Wang, Qing
 * @Date 2019/10/23 09:30
 * tim 加好友管理类
 */
@Component
@Slf4j
public class TIMApiManager {

    public static final String TIM_IMPORT_FRIEND = "https://console.tim.qq.com/v4/sns/friend_import";

    public static final String TIM_UPDATE_FRIEND = "https://console.tim.qq.com/v4/sns/friend_update";

    public static final String TIM_DELETE_FRIEND = "https://console.tim.qq.com/v4/sns/friend_delete";

    public static final String TIM_UPDATE_PROFILE = "https://console.tim.qq.com/v4/profile/portrait_set";

    public static final String TIM_MULT_ACCOUNT_IMPORT = "https://console.tim.qq.com/v4/im_open_login_svc/multiaccount_import";

    private String sdkAppId;

    private String adminUser;

    private String adminSig;

    private final TimSigUtils timSigUtils;

    private final Environment env;

    @Autowired
    public TIMApiManager(Environment env,
                         TimSigUtils timSigUtils) {
        this.sdkAppId = env.getProperty("tim.sdk.appid", String.class);
        this.adminUser = env.getProperty("tim.admin", String.class);
        this.adminSig = timSigUtils.getTimSig(adminUser, 180 * 86400L);
        this.timSigUtils = timSigUtils;
        this.env = env;
    }

    @Autowired
    UfotoHttpClient ufotoHttpClient;

    /**
     * 添加正式好友的时候同步tim
     * @param userFriendsList
     */
    public void addFromalFriend(List<UfotoUserFriends> userFriendsList) {
        for (UfotoUserFriends ufotoUserFriends : userFriendsList) {
            doPostImportFriend(buildTIMFriendModel(ufotoUserFriends));
        }
    }

    private void doPostImportFriend(TIMAddFriendModel timAddFriendModel) {
        URI uri = getImportFriendUri();
        TIMFriendResult timFriendResult = postImportFriend(uri, timAddFriendModel);
        if (Objects.nonNull(timFriendResult) && needRetry(timFriendResult.getErrorCode(), Lists
                .newArrayList(timAddFriendModel.getFUid(),
                        timAddFriendModel.getTIMAddFriendItem().get(0).getTUid()))) {
            timFriendResult = postImportFriend(uri, timAddFriendModel);
        }

        if (Objects.nonNull(timFriendResult) && timFriendResult.getErrorCode() != 0) {
            log.warn("{}, URI:{}, timAddFriendModel:{}, timFriendResult:{}",
                    "WARN_TIM_IMPORT_FRIEND_ERROR", uri.toString(),
                    JSONObject.toJSONString(timAddFriendModel),
                    JSONObject.toJSONString(timFriendResult));
        }
    }

    private boolean needRetry(Integer errorCode, List<String> uids) {
        if (Objects.equals(errorCode, error_30003) || Objects.equals(errorCode, error_40003)) {
            log.warn("{}, errorCode:{}, uids:{}", "WARN_TIM_INVALID_ACCOUNT", errorCode, uids);
            multiAccountImport(uids);
            return true;
        }
        if (env.getProperty("tim.retry.code", List.class).contains(errorCode + "")) {
            return true;
        }
        return false;
    }

    /**
     * 批量导用户
     * v4/im_open_login_svc/multiaccount_import
     * https://cloud.tencent.com/document/product/269/4919
     */
    private void multiAccountImport(List<String> uids) {
        TIMMutiAccountImportModel importModel = TIMMutiAccountImportModel.builder()
                .uids(uids)
                .build();
        doPostMultiAccountImport(importModel);
    }

    private void doPostMultiAccountImport(TIMMutiAccountImportModel importModel) {
        TIMMultAccountImportResult accountImportResult = postMultAccountImport(getMultAccountUri(),
                importModel);
        URI uri = getImportFriendUri();
        if (Objects.nonNull(accountImportResult) && needRetry(accountImportResult.getErrorCode(),
                importModel.getUids())) {
            accountImportResult = postMultAccountImport(uri, importModel);
        }

        if (Objects.nonNull(accountImportResult) && accountImportResult.getErrorCode() != 0) {
            log.warn("{}, URI:{}, importModel:{}, accountImportResult:{}",
                    "WARN_TIM_MULT_ACCOUNT_IMPORT_ERROR", uri.toString(),
                    JSONObject.toJSONString(importModel),
                    JSONObject.toJSONString(accountImportResult));
        }
    }

    private TIMMultAccountImportResult postMultAccountImport(URI uri,
                                                             TIMMutiAccountImportModel importModel) {
        return JSONObject
                .parseObject(ufotoHttpClient.postUri(
                        uri,
                        JSON.toJSONString(importModel)),
                        TIMMultAccountImportResult.class);
    }

    private URI getMultAccountUri() {
        return getUri(TIM_MULT_ACCOUNT_IMPORT);
    }


    private TIMFriendResult postImportFriend(URI uri, TIMAddFriendModel timAddFriendModel) {
        return JSONObject
                .parseObject(ufotoHttpClient.postUri(
                        uri,
                        JSON.toJSONString(timAddFriendModel)),
                        TIMFriendResult.class);
    }

    private URI getImportFriendUri() {
        return getUri(TIM_IMPORT_FRIEND);
    }

    private URI getUri(String timUpdateFriend) {
        URI uri = null;
        try {
            URIBuilder uriBuilder = new URIBuilder(timUpdateFriend);
            uriBuilder.addParameter("sdkappid", sdkAppId);
            uriBuilder.addParameter("identifier", adminUser);
            uriBuilder.addParameter("usersig", adminSig);
            uriBuilder.addParameter("random", CommonUtil.getRandomInt() + "");
            uriBuilder.addParameter("contenttype", "json");
            uri = uriBuilder.build();
        } catch (URISyntaxException e) {
            log.error(e.getMessage());
        }
        return uri;
    }

    private TIMAddFriendModel buildTIMFriendModel(UfotoUserFriends ufotoUserFriends) {
        TIMCustomItem timCustomItem = null;
        if (topFriend(ufotoUserFriends)) {
            timCustomItem = TIMCustomItem.builder()
                    .tag(TIM_CUSTOM_TOP)
                    .value(IS_TOP.getValue())
                    .build();
        } else {
            timCustomItem = TIMCustomItem.builder()
                    .tag(TIM_CUSTOM_TOP)
                    .value(ETIMFriendTop.IS_NOT_TOP.getValue())
                    .build();
        }
        TIMAddFriendItem timAddFriendItem = TIMAddFriendItem.builder()
                .tUid(ufotoUserFriends.getfId() + "")
                .groupNames(Lists.newArrayList(ETIMFriendGroup.formal.toString()))
                .addSource(ETIMFriendAddSource.FORMAL_FRIEND.getValue())
                .createTime(DateUtil.getCurrentSecondIntValue())
                .build();
        TIMAddFriendModel timAddFriendModel = TIMAddFriendModel.builder()
                .fUid(ufotoUserFriends.getuId() + "")
                .TIMAddFriendItem(Lists.newArrayList(timAddFriendItem)).build();

        if (Objects.nonNull(timAddFriendItem)) {
            timAddFriendItem.setTIMCustomItem(Lists.newArrayList(timCustomItem));
        }
        return timAddFriendModel;
    }

    private boolean topFriend(UfotoUserFriends ufotoUserFriends) {
        return ufotoUserFriends.getIsTop() != null && ufotoUserFriends.getIsTop() == 1;
    }

}
