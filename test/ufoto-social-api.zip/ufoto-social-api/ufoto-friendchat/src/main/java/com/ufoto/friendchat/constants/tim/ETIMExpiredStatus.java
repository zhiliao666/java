package com.ufoto.friendchat.constants.tim;

/**
 *
 * @Author Wang, Qing
 * @Date 2019/10/25 16:08
 */
public enum ETIMExpiredStatus {

    EXPIRED("1");

    private String status;

    public String getStatus() {
        return status;
    }

    public void setStatus(String status) {
        this.status = status;
    }

    ETIMExpiredStatus(String status) {
        this.status = status;
    }
}
