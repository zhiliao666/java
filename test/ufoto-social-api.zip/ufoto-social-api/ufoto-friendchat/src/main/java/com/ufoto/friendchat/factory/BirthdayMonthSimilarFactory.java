package com.ufoto.friendchat.factory;

import com.ufoto.friendchat.entity.SimilarDto;
import com.ufoto.friendchat.entity.SingleMatchSimilar;
import com.ufoto.friendchat.entity.UfotoAppUser;
import lombok.extern.slf4j.Slf4j;
import org.joda.time.DateTime;
import org.springframework.stereotype.Component;

import java.util.List;
import java.util.Locale;

/**
 * <p>
 * Author     : Chan
 * CreateDate : 2019-01-16 10:35
 * Description:
 * </p>
 */
@Slf4j
@Component
public class BirthdayMonthSimilarFactory implements MatchSimilarFactory {
    @Override
    public SingleMatchSimilar doSimilar(SimilarDto similarDto) {
        final List<UfotoAppUser> users = similarDto.getUsers();
        DateTime dd1 = getUserDatetime(users.get(0));
        DateTime dd2 = getUserDatetime(users.get(1));
        if (dd1 == null || dd2 == null) {
            return null;
        }
        final String m1 = dd1.monthOfYear().getAsString();
        final String m2 = dd2.monthOfYear().getAsString();
        log.debug("sameMonth,user1:{},d1:{},user2:{},d2:{}", users.get(0).getId(), dd1, users.get(1).getId(), dd2);
        if (!m1.equals(m2)) {
            return null;
        }
        return getSingleMatchSimilar(similarDto, new String[]{dd1.toString("MMM", Locale.forLanguageTag(users.get(0).getLang()))},
                new String[]{dd2.toString("MMM", Locale.forLanguageTag(users.get(1).getLang()))});
    }
}
