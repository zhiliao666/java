package com.ufoto.friendchat.entity.tim;

import com.alibaba.fastjson.annotation.JSONField;
import lombok.Builder;
import lombok.Data;

/**
 *
 * @Author Wang, Qing
 * @Date 2019/10/21 15:10
 */
@Data
@Builder
public class TIMMsgCustomElem {

    /**
     * 自定义消息数据。 不作为 APNs 的 payload 字段下发，故从 payload 中无法获取 Data 字段。
     */
    @JSONField(name = "Data")
    private String data;

    /**
     * 自定义消息描述信息；当接收方为 iOS 或 Android 后台在线时，做离线推送文本展示。
     */
    @JSONField(name = "Desc")
    private String desc;

    /**
     *	扩展字段；当接收方为 iOS 系统且应用处在后台时，此字段作为 APNs 请求包 Payloads 中的 Ext 键值下发，Ext 的协议格式由业务方确定，APNs 只做透传。
     */
    @JSONField(name = "Ext")
    private String ext;

    /**
     * 自定义 APNs 推送铃音。
     */
    @JSONField(name = "Sound")
    private String sound;

}
