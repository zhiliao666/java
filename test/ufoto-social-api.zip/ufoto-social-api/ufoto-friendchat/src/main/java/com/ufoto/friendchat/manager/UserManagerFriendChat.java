package com.ufoto.friendchat.manager;

import com.google.common.collect.Lists;
import com.ufoto.common.utils.ApiResult;
import com.ufoto.common.utils.JsonUtil;
import com.ufoto.feign.usercenter.UserCenterBusiness;
import com.ufoto.feign.usercenter.dto.UserBaseInfoDto;
import com.ufoto.friendchat.converter.UserCenterConverter;
import com.ufoto.friendchat.entity.UfotoAppUser;
import lombok.RequiredArgsConstructor;
import lombok.extern.slf4j.Slf4j;
import org.springframework.core.env.Environment;
import org.springframework.stereotype.Component;
import org.springframework.util.CollectionUtils;

import java.util.Collection;
import java.util.List;
import java.util.Objects;
import java.util.stream.Collectors;

/**
 * <p>
 * Author     : Chan
 * CreateDate : 2019-04-12 10:33
 * Description:
 * </p>
 */
@Slf4j
@Component
@RequiredArgsConstructor
public class UserManagerFriendChat {

    private final static String USER_CENTER_WARN_TAG = "UserCenterWarn ";
    private final static String USER_CENTER_DEBUG_TAG = "UserCenterDebug ";
    private final UserCenterBusiness userCenterBusiness;
    private final Environment env;

    public List<UfotoAppUser> queryUsers(List<Long> uids) {
        if (CollectionUtils.isEmpty(uids)) return Lists.newArrayList();
        final Integer batchSize = env.getProperty("user.batch.query", Integer.class, 2000);
        if (uids.size() < batchSize) {
            return queryUsersUnderLimit(uids);
        }
        return Lists.partition(uids, batchSize)
                .parallelStream()
                .map(this::queryUsersUnderLimit)
                .filter(lst -> !CollectionUtils.isEmpty(lst))
                .flatMap(Collection::stream)
                .collect(Collectors.toList());
    }

    private List<UfotoAppUser> queryUsersUnderLimit(List<Long> uids) {
        final ApiResult<List<UserBaseInfoDto>> userBaseInfoList = userCenterBusiness.getUserBaseInfoList(uids);
        log.debug(USER_CENTER_DEBUG_TAG + "#userInfoBusiness.getUserBaseInfoList({})#ApiResult({})", uids, JsonUtil.toJson(userBaseInfoList));
        if (!Objects.equals(userBaseInfoList.getC(), ApiResult.successCode)) {
            log.warn(USER_CENTER_WARN_TAG + "#userInfoBusiness.getUserBaseInfoList({})#ApiResult({})", uids, JsonUtil.toJson(userBaseInfoList));
            return Lists.newArrayList();
        }
        final List<UserBaseInfoDto> baseInfoListD = userBaseInfoList.getD();
        if (CollectionUtils.isEmpty(baseInfoListD)) return Lists.newArrayList();
        return UserCenterConverter.userBaseInfos2UfotoAppUsers(baseInfoListD);
    }

    /**
     * 查询单个用户
     *
     * @param uid 用户id
     * @return 用户
     */
    public UserBaseInfoDto queryUserOne(Long uid) {
        final ApiResult<UserBaseInfoDto> userBaseInfo = userCenterBusiness.getUserBaseInfo(uid);
        log.debug(USER_CENTER_DEBUG_TAG + "#userInfoBusiness.getUserBaseInfo({})#ApiResult({})", uid, JsonUtil.toJson(userBaseInfo));
        if (!Objects.equals(userBaseInfo.getC(), ApiResult.successCode)) {
            log.warn(USER_CENTER_WARN_TAG + "#userInfoBusiness.getUserBaseInfo({})#ApiResult({})", uid, JsonUtil.toJson(userBaseInfo));
            return null;
        }
        return userBaseInfo.getD();
    }

}
