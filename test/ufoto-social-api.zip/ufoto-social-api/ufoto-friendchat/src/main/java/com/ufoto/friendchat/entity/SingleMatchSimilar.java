package com.ufoto.friendchat.entity;

import lombok.Data;

import java.util.List;

/**
 * <p>
 * Author     : Chan
 * CreateDate : 2019-01-15 18:19
 * Description:
 * </p>
 */
@Data
public class SingleMatchSimilar {
    private Integer rate;
    private List<String> descriptions;
    private List<String> targetDescriptions;
}
