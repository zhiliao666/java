package com.ufoto.friendchat.factory;

import com.ufoto.common.utils.JsonUtil;
import com.ufoto.friendchat.entity.SimilarDto;
import com.ufoto.friendchat.entity.SingleMatchSimilar;
import com.ufoto.friendchat.entity.UfotoAppUser;
import com.ufoto.friendchat.utils.DistanceUtil;
import lombok.extern.slf4j.Slf4j;
import org.springframework.stereotype.Component;

import java.util.List;

/**
 * <p>
 * Author     : Chan
 * CreateDate : 2019-01-16 12:23
 * Description:
 * </p>
 */
@Slf4j
@Component
public class DistanceCountryDistanceSimilarFactory implements MatchSimilarFactory {
    @Override
    public SingleMatchSimilar doSimilar(SimilarDto similarDto) {
        final List<UfotoAppUser> users = similarDto.getUsers();
        log.info("DistanceCountryDistance,users:{}", JsonUtil.toJson(users));
        final Double latitude = users.get(0).getLatitude();
        if (latitude == null) return null;
        final Double longitude = users.get(0).getLongitude();
        if (longitude == null) return null;
        final Double latitude1 = users.get(1).getLatitude();
        if (latitude1 == null) return null;
        final Double longitude1 = users.get(1).getLongitude();
        if (longitude1 == null) return null;

        final double distance = Math.ceil(DistanceUtil.distance(longitude, latitude, longitude1, latitude1) / 1000);
        return getSingleMatchSimilar(similarDto, new String[]{(int) distance + ""}, new String[]{(int) distance + ""});
    }
}
