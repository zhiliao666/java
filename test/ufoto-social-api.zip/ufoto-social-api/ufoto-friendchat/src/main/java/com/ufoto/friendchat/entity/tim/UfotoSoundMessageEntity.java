package com.ufoto.friendchat.entity.tim;

import lombok.Builder;
import lombok.Data;

@Data
@Builder
public class UfotoSoundMessageEntity {

    private String text;

    private String url;

    private Integer length;
}
