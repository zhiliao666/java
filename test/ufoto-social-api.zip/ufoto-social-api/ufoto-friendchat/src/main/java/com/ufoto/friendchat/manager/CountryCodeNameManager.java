package com.ufoto.friendchat.manager;

import com.alibaba.fastjson.JSONObject;
import com.google.common.collect.Maps;
import com.ufoto.friendchat.constants.ESupportLanguage;
import com.ufoto.friendchat.entity.CountryNameMultiLanguage;
import com.ufoto.friendchat.mapper.read.UfotoCountryMapper;
import lombok.extern.slf4j.Slf4j;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.CommandLineRunner;
import org.springframework.jdbc.core.JdbcTemplate;
import org.springframework.stereotype.Component;
import org.springframework.util.StringUtils;

import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.concurrent.atomic.AtomicReference;

/**
 * <p>
 * Author     : Chan
 * CreateDate : 2019-07-23 16:31
 * Description:
 * </p>
 */
@Slf4j
@Component
public class CountryCodeNameManager implements CommandLineRunner {


    @Autowired
    UfotoCountryMapper countryMapper;

    //{countryCode:{lang:countryName}}
    private final Map<String, Map<String, String>> countryCodeLangName;

    public CountryCodeNameManager() {
        countryCodeLangName = Maps.newHashMap();
    }


    private static Map<String, String> countryWithCode = new HashMap<>();

    @Autowired
    JdbcTemplate jdbcTemplate;

    private void runCountryCode() {
        List<Map<String, Object>> results = jdbcTemplate.queryForList("select country_code, country_name from ufoto_country where type='0'");
        results.forEach(r -> {
            AtomicReference<String> key = new AtomicReference<>();
            AtomicReference<String> value = new AtomicReference<>();
            r.entrySet().forEach(e -> {
                if (e.getKey().equalsIgnoreCase("country_code")) {
                    key.set((String) e.getValue());
                }
                if (e.getKey().equalsIgnoreCase("country_name")) {
                    value.set((String) e.getValue());
                }
            });
            countryWithCode.put(key.get(), value.get());
        });
    }


    @Override
    public synchronized void run(String... args) {
        log.debug("开始加载国家码和国家名称映射关系...");
        countryCodeLangName.clear();
        countryWithCode.clear();

        List<CountryNameMultiLanguage> countryNameMultiLanguages = countryMapper.selectMultiLang();
        countryNameMultiLanguages.forEach(l -> {
            Map<String, String> map = JSONObject.parseObject(l.getMultiLangData(), Map.class);
            countryCodeLangName.put(l.getCountryCode(), map);
        });

        runCountryCode();
        log.debug("国家码和国家名称映射关系加载成功...");
    }

    public String getCountryName(String countryCode, String lang) {
        if (StringUtils.isEmpty(countryCode)) {
            return null;
        }
        countryCode = countryCode.toUpperCase();
        String name;
        if (countryCodeLangName.containsKey(countryCode)) {
            final Map<String, String> map = countryCodeLangName.get(countryCode);
            name = map.get(lang);
            if (StringUtils.isEmpty(name)) {
                return map.get(ESupportLanguage.EN.getLang());
            }
        } else {
            name = countryWithCode.get(countryCode);
        }
        return name;
    }
}
