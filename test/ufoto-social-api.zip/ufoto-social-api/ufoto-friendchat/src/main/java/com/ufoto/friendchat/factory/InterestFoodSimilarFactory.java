package com.ufoto.friendchat.factory;

import com.ufoto.friendchat.constants.EMatchSimilarType;
import com.ufoto.friendchat.entity.SimilarDto;
import com.ufoto.friendchat.entity.SingleMatchSimilar;
import org.springframework.stereotype.Component;

/**
 * <p>
 * Author     : Chan
 * CreateDate : 2019-01-16 12:21
 * Description:
 * </p>
 */
@Component
public class InterestFoodSimilarFactory implements MatchSimilarFactory {
    @Override
    public SingleMatchSimilar doSimilar(SimilarDto similarDto) {
        return getInterestSingleMatchSimilar(similarDto, EMatchSimilarType.INTEREST_FOOD.getType());
    }
}
