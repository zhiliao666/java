package com.ufoto.friendchat.factory;

import com.ufoto.friendchat.entity.SimilarDto;
import com.ufoto.friendchat.entity.SingleMatchSimilar;
import com.ufoto.friendchat.entity.UfotoAppUser;
import lombok.extern.slf4j.Slf4j;
import org.joda.time.DateTime;
import org.springframework.stereotype.Component;

import java.util.List;

/**
 * <p>
 * Author     : Chan
 * CreateDate : 2019-01-15 18:56
 * Description: 判断是否是同一天
 * </p>
 */
@Slf4j
@Component
public class BirthdayDaySimilarFactory implements MatchSimilarFactory {
    @Override
    public SingleMatchSimilar doSimilar(SimilarDto similarDto) {
        final List<UfotoAppUser> users = similarDto.getUsers();
        DateTime dd1 = getUserDatetime(users.get(0));
        DateTime dd2 = getUserDatetime(users.get(1));
        if (dd1 == null || dd2 == null) {
            return null;
        }
        final String d1 = dd1.dayOfMonth().getAsString();
        final String d2 = dd2.dayOfMonth().getAsString();
        log.debug("sameDay,user1:{},day1:{},user2:{},day2:{}", users.get(0).getId(), d1, users.get(1).getId(), d2);
        if (!d1.equals(d2)) {
            return null;
        }
        return getSingleMatchSimilar(similarDto, new String[]{d1}, new String[]{d2});
    }
}
