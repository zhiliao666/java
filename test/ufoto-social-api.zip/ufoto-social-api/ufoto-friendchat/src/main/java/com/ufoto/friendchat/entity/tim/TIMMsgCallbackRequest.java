package com.ufoto.friendchat.entity.tim;

import com.alibaba.fastjson.annotation.JSONField;
import lombok.Builder;
import lombok.Data;

import java.util.List;

/**
 *
 * @Author Wang, Qing
 * @Date 2019/10/26 15:16
 */
@Data
@Builder
public class TIMMsgCallbackRequest {

    /**
     * 回调命令
     */
    @JSONField(name = "CallbackCommand")
    private String callbackCommand;

    /**
     * 发送者
     */
    @JSONField(name = "From_Account")
    private String fUid;

    /**
     * 接收者
     */
    @JSONField(name = "To_Account")
    private String tUid;

    /**
     * 消息序列号，用于标记该条消息
     */
    @JSONField(name = "MsgSeq")
    private Integer msgSeq;

    /**
     * 消息随机数，用于标记该条消息
     */
    @JSONField(name = "MsgRandom")
    private Long msgRandom;

    @JSONField(name = "MsgTime")
    private Integer msgTime;

    /**
     * 消息体
     */
    @JSONField(name = "MsgBody")
    private List<TIMMsgBodyEntity> msgBody;
}
