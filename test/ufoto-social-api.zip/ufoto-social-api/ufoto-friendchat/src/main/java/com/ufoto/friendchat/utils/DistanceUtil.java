package com.ufoto.friendchat.utils;

import com.ufoto.feign.usercenter.dto.UserBaseInfoDto;
import com.ufoto.friendchat.entity.UfotoAppUser;
import org.apache.commons.lang3.RandomUtils;

/**
 * <p>
 * Author     : Chan
 * CreateDate : 2018/10/25 20:42
 * Description:
 * </p>
 */
public class DistanceUtil {
    /**
     * 单位米
     *
     * @return
     */
    public static double distance(double long1, double lat1, double long2, double lat2) {
        double a, b, R;
        R = 6378137; // 地球半径
        lat1 = lat1 * Math.PI / 180.0;
        lat2 = lat2 * Math.PI / 180.0;
        a = lat1 - lat2;
        b = (long1 - long2) * Math.PI / 180.0;
        double d;
        double sa2, sb2;
        sa2 = Math.sin(a / 2.0);
        sb2 = Math.sin(b / 2.0);
        d = 2 * R * Math.asin(Math.sqrt(sa2 * sa2 + Math.cos(lat1) * Math.cos(lat2) * sb2 * sb2));
        return d;
    }

    public static double distance(UfotoAppUser user1, UfotoAppUser user2) {
        try {
            return distance(user1.getLongitude(), user1.getLatitude(), user2.getLongitude(), user2.getLatitude());
        } catch (Exception e) {
            return RandomUtils.nextInt(30000, 100000);
        }
    }

    public static Double distance(UserBaseInfoDto user1, UserBaseInfoDto user2) {
        try {
            return distance(user1.getLongitude(), user1.getLatitude(), user2.getLongitude(), user2.getLatitude());
        } catch (Exception e) {
            return null;
        }
    }
}
