package com.ufoto.friendchat.entity;

/**
 * <p>
 * Author     : Chan
 * CreateDate : 2019-01-15 14:32
 * Description:
 * </p>
 */
public class UfotoMatchSimilarExample extends BaseUfotoMatchSimilarExample {
}
