package com.ufoto.friendchat.constants.tim;

/**
 * @Author: Wang, Qing
 * @Date: 2019-07-22 16:56
 */
public enum ETIMFriendTop {

    IS_NOT_TOP("0", "未置顶"),
    IS_TOP("1", "置顶");

    public String getValue() {
        return value;
    }

    public String getDesc() {
        return desc;
    }

    ETIMFriendTop(String value, String desc) {
        this.value = value;
        this.desc = desc;
    }

    private String value;

    private String desc;
}
