package com.ufoto.friendchat.constants;

/**
 * 常量池
 *
 */
public class TIMConstants {

    /**
     * TIM sig key前缀
     */
    public static final String TIM_SIG_KEY_PREFIX = "TIM_SIG_KEY_PREFIX_";

    /**
     * TIM
     * 24小时过期状态
     * 0 默认 未过期 1 过期
     */
    public static final String TIM_CUSTOM_STATUS = "Tag_SNS_Custom_Status";

    /**
     * TIM 我的操作
     * 1 like 2 dislike 3 superlike 4 unmatch
     */
    public static final String TIM_CUSTOM_MY_STATUS = "Tag_SNS_Custom_Mystatus";

    /**
     * TIM 对方操作
     * 1 like 2 dislike 3 superlike 4 unmatch
     */
    public static final String TIM_CUSTOM_TO_STATUS = "Tag_SNS_Custom_Tostatus";

    /**
     * TIM 置顶操作
     */
    public static final String TIM_CUSTOM_TOP = "Tag_SNS_Custom_Top";

    /**
     * TIM 更新分组字段
     */
    public static final String TIM_SNS_IM_GROUP = "Tag_SNS_IM_Group";

    /**
     * 会员状态
     */
    public static final String TIM_USER_VIP_STATUS = "Tag_Profile_IM_Level";

    public static final String FROM_SERVER= "FROM_SERVER";

    public static final String WRONG_SDK_APP_ID = "WRONG_SDK_APP_ID";
}
