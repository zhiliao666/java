package com.ufoto.friendchat.entity.tim;

import com.alibaba.fastjson.annotation.JSONField;
import lombok.Builder;
import lombok.Data;

/**
 *
 * @Author Wang, Qing
 * @Date 2019/10/22 17:43
 */
@Data
@Builder
public class TIMCustomItem {

    @JSONField(name = "Tag")
    private String tag;

    @JSONField(name = "Value")
    private Object value;
}
