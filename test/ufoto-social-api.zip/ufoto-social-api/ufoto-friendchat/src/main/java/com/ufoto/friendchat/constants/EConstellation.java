package com.ufoto.friendchat.constants;

/**
 * <p>
 * Author     : Chan
 * CreateDate : 2018/10/22 16:27
 * Description:
 * </p>
 */
public enum EConstellation {
    AQUARIUS("Air"),
    PISCES("Water"),
    ARIES("Fire"),
    TAURUS("Earth"),
    GEMINI("Air"),
    CANCER("Water"),
    LEO("Fire"),
    VIRGO("Earth"),
    LIBRA("Air"),
    SCORPIO("Water"),
    SAGITTARIUS("Fire"),
    CAPRICORN("Earth");

    private String isomorphic;

    EConstellation(String isomorphic) {
        this.isomorphic = isomorphic;
    }

    public String getIsomorphic() {
        return isomorphic;
    }}
