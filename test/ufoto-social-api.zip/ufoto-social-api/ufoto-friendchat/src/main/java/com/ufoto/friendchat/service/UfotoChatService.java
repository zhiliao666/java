package com.ufoto.friendchat.service;

/**
 * <p>
 * Description:
 *
 * </p>
 *
 * @author Chan
 * @date 2020/3/9 13:47
 */
public interface UfotoChatService {
    void sendMsg(Long fromUid, Long toUid, String msg, Integer msgType);
}
