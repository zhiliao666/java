package com.ufoto.friendchat.mapper.read;

import com.ufoto.friendchat.entity.UserInterestCategory;
import org.apache.ibatis.annotations.*;
import org.apache.ibatis.type.JdbcType;

import java.util.List;

/**
 * <p>
 *
 * </p>
 *
 * @author created by chenzhou at 2018-07-02 18:27
 */
@Mapper
public interface UfotoUserInterestTagMapper {

    @Select("<script>" +
            "select uid,category_id from ufoto_user_interest_tag where 1=1 and uid in " +
            "<foreach item='item' index='index' collection='uids' open='(' separator=',' close=')'>" +
            "#{item}" +
            "</foreach> GROUP BY uid,category_id" +
            "</script>")
    @Results({
            @Result(column = "uid", property = "uid", jdbcType = JdbcType.BIGINT),
            @Result(column = "category_id", property = "category", jdbcType = JdbcType.BIGINT),
    })
    List<UserInterestCategory> queryCategoryIdByUids(@Param("uids") List<Long> uids);
}
