package com.ufoto.friendchat.entity;

import com.fasterxml.jackson.annotation.JsonIgnore;
import com.ufoto.friendchat.constants.EChoice;

public class UfotoAppUser extends BaseUfotoAppUser {

    private static final long serialVersionUID = 1L;

    private String token; //聊天需要token

    /**
     * 注意：无version的代表挑战活动登录 version=1代表社交活动登录（可能存在是挑战活动的） version=2时候 则 appFlag=3独立app，4社交活动，5挑战活动
     */
    private Integer version; //1 社交版本登录 2 版本2（开始接入）
    private Integer loginSource;//用于实时记录应用来源


    private Integer appFlag; //3独立app，4社交活动，5挑战活动
    private String accessToken; //faceBook，google 验证token
    private String lang;//语言
    private Integer legitimateEmail; //3独立app，4社交活动，5挑战活动

    private Integer tokenVersion; //3独立app，4社交活动，5挑战活动
    private Integer friendStatus;
    private Integer friendType;
    private String visitorSign;
    @JsonIgnore
    private Long uid;

    public String getVisitorSign() {
        return visitorSign;
    }

    public void setVisitorSign(String visitorSign) {
        this.visitorSign = visitorSign;
    }

    public Long getUid() {
        return uid;
    }

    public void setUid(Long uid) {
        this.uid = uid;
    }

    public Integer getFriendType() {
        return friendType;
    }

    public void setFriendType(Integer friendType) {
        this.friendType = friendType;
    }

    public Integer getFriendStatus() {
        return friendStatus;
    }

    public void setFriendStatus(Integer friendStatus) {
        this.friendStatus = friendStatus;
    }

    private String preUuid;//迁移之前的uuid
    private Integer ifMigrate = EChoice.No.getFlag();//是否迁移账号

    public String getPreUuid() {
        return preUuid;
    }

    public void setPreUuid(String preUuid) {
        this.preUuid = preUuid;
    }

    public Integer getIfMigrate() {
        return ifMigrate;
    }

    public void setIfMigrate(Integer ifMigrate) {
        this.ifMigrate = ifMigrate;
    }

    public Integer getTokenVersion() {
        return tokenVersion;
    }

    public void setTokenVersion(Integer tokenVersion) {
        this.tokenVersion = tokenVersion;
    }

    public Integer getLegitimateEmail() {
        return legitimateEmail;
    }

    public void setLegitimateEmail(Integer legitimateEmail) {
        this.legitimateEmail = legitimateEmail;
    }

    public String getLang() {
        return lang;
    }

    public void setLang(String lang) {
        this.lang = lang;
    }

    public String getAccessToken() {
        return accessToken;
    }

    public void setAccessToken(String accessToken) {
        this.accessToken = accessToken;
    }

    public Integer getLoginSource() {
        return loginSource;
    }

    public void setLoginSource(Integer loginSource) {
        this.loginSource = loginSource;
    }

    /**
     * @return the appFlag
     */
    public Integer getAppFlag() {
        return appFlag;
    }

    /**
     * @param appFlag the appFlag to set
     */
    public void setAppFlag(Integer appFlag) {
        this.appFlag = appFlag;
    }

    /**
     * @return the version
     */
    public Integer getVersion() {
        return version;
    }

    /**
     * @param version the version to set
     */
    public void setVersion(Integer version) {
        this.version = version;
    }

    /**
     * @return the token
     */
    public String getToken() {
        return token;
    }

    /**
     * @param token the token to set
     */
    public void setToken(String token) {
        this.token = token;
    }

}
