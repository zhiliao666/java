package com.ufoto.friendchat.constants;

/**
 * <p>
 * Author     : Chan
 * CreateDate : 2019-01-15 14:43
 * Description: 相似度分类
 * </p>
 */
public enum EMatchSimilarCategory {
    BIRTHDAY(1),//出生年月日
    INTEREST(2),//兴趣
    COUNTRY_HOME(3),//国家 家乡
    NO_CASE(4);//兜底  不区分类别

    private int category;

    EMatchSimilarCategory(int category) {
        this.category = category;
    }

    public int getCategory() {
        return category;
    }}
