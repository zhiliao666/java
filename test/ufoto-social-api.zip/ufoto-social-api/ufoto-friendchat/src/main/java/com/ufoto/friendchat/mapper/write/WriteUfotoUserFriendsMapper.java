package com.ufoto.friendchat.mapper.write;

import com.ufoto.base.mapper.SysMapper;
import com.ufoto.friendchat.entity.UfotoUserFriends;
import org.apache.ibatis.annotations.Mapper;

@Mapper
public interface WriteUfotoUserFriendsMapper extends SysMapper<UfotoUserFriends> {

}