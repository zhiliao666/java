package com.ufoto.friendchat.service.impl;

import com.ufoto.feign.chat.MsgChatBusiness;
import com.ufoto.friendchat.service.UfotoChatService;
import lombok.RequiredArgsConstructor;
import org.springframework.stereotype.Component;

/**
 * <p>
 * Description:
 *
 * </p>
 *
 * @author Chan
 * @date 2020/3/9 13:48
 */
@RequiredArgsConstructor
@Component
public class UfotoChatServiceImpl implements UfotoChatService {

    private final MsgChatBusiness msgChatBusiness;

    @Override
    public void sendMsg(Long fromUid, Long toUid, String msg, Integer msgType) {
        msgChatBusiness.sendMsg(fromUid, toUid, msg, msgType, 0);
    }

}
