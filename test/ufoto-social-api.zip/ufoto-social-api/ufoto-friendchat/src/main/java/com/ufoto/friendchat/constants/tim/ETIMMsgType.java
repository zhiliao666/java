package com.ufoto.friendchat.constants.tim;

/**
 * TIM 消息对象类型，目前支持的消息对象包括：
 * TIMTextElem(文本消息)，TIMFaceElem(表情消息)，TIMLocationElem(位置消息)，TIMCustomElem(自定义消息)
 * @Author Wang, Qing
 * @Date 2019/10/21 15:07
 */
public enum ETIMMsgType {
    TIMTextElem,
    TIMFaceElem,
    TIMLocationElem,
    TIMCustomElem,
    TIMSoundElem,
    TIMVideoFileElem,
    TIMImageElem
}
