package com.ufoto.friendchat.entity;

import lombok.Data;

/**
 * @Author: Wang, Qing
 * @Date: 2019-07-24 15:38
 */
@Data
public class CountryNameMultiLanguage {

    private String countryCode;

    private String multiLangData;
}
