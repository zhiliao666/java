package com.ufoto.friendchat.entity.tim;

import lombok.Builder;
import lombok.Data;

/**
 *
 * @Author Wang, Qing
 * @Date 2019/10/26 15:16
 */
@Data
@Builder
public class TIMMsgCallbackResponse {

    private Boolean isServerMsg = false;

    private String msgId;

    private String timRes;

    private Integer time;

    private Long fUid;

    private Long tUid;
}
