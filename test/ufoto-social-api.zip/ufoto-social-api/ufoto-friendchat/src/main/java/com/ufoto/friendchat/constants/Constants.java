package com.ufoto.friendchat.constants;

/**
 * Created by Wang, Qing
 * 2020/3/6
 */
public class Constants {

    /**
     * 未删除状态 0
     */
    public static int IS_DELETE_0 = 0;

    /**
     * 删除状态 1
     */
    public static int IS_DELETE_1 = 1;

    public static final String Q_USER_MATCH = "Q-user-match";

    public static final int FORMAL_FRIEND_STATUS = 0;//es服务只有一张表，0表示活跃的好友

    public static final int OLD_FRIEND_STATUS = 1;//1表示不活跃好友

    /**
     * 推送通知消息 2
     */
    public static int CHAT_TYPE_2 = 2;

    //匹配度记录  redis_match_similar_record
    public static final String REDIS_MATCH_SIMILAR_RECORD = "redis_match_similar_record:";

    /**
     * 注册用户来源 1 爱自拍
     */
    public static int USER_FROM_TYPE_1 = 1;
    /**
     * 注册用户来源 2 情人节活动
     */
    public static int USER_FROM_TYPE_2 = 2;
    /**
     * 注册用户来源 3 独立社交APP
     */
    public static int USER_FROM_TYPE_3 = 3;
    /**
     * 注册用户来源 4 社交活动
     */
    public static int USER_FROM_TYPE_4 = 4;

    /**
     * 注册用户来源 5 挑战活动
     */
    public static int USER_FROM_TYPE_5 = 5;
    /**
     * Sweet Chat Lite -> from_type 设为7
     */
    public static int USER_FROM_TYPE_7 = 7;
    /**
     * SweetMeet - Free chat&Dating –> from_type 设为 8
     */
    public static int USER_FROM_TYPE_8 = 8;
    /**
     * 注册用户来源 0 其他
     */
    public static int USER_FROM_TYPE_0 = 0;

    public static int USRE_FROM_TYPE_SNAP = 10;
    public static int USRE_FROM_TYPE_SNAP_LITE = 11;

    /**
     * IOS from type
     */
    public static int USRE_FROM_TYPE_IOS = 13;
}
