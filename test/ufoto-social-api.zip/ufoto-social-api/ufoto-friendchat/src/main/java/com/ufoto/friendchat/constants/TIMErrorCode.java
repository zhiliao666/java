package com.ufoto.friendchat.constants;

/**
 *
 * @Author Wang, Qing
 * @Date 2019/10/23 11:48
 */
public class TIMErrorCode {

    /**
     * UserSig 过期，请重新获取有效的 UserSig 后再重新登录。
     */
    public static final int error_6206 = 6206;

    /**
     * Err_SNS_Invalid_Account 用户不存在
     */
    public static final int error_30003 = 30003;

    /**
     * Err_Profile_Invalid_Account
     */
    public static final int error_40003 = 40003;


}
