package com.ufoto.friendchat.mapper.read;

import org.apache.ibatis.annotations.Mapper;
import org.apache.ibatis.annotations.Param;

/**
 * Created by Wang, Qing
 * 2020/2/26
 */
@Mapper
public interface UfotoUserFriendsMapper {

    Integer isFriends(@Param("uid") Long uid, @Param("fid") Long fid);
}
