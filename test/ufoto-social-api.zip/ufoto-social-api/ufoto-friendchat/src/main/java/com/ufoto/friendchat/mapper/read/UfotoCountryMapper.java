package com.ufoto.friendchat.mapper.read;

import com.ufoto.base.mapper.SysMapper;
import com.ufoto.friendchat.entity.CountryNameMultiLanguage;
import com.ufoto.friendchat.entity.UfotoCountry;
import org.apache.ibatis.annotations.Mapper;

import java.util.List;

@Mapper
public interface UfotoCountryMapper extends SysMapper<UfotoCountry> {

    List<CountryNameMultiLanguage> selectMultiLang();
}