package com.ufoto.friendchat.constants;

/**
 * @Author: Wang, Qing
 * @Date: 2019-07-22 16:56
 * !!!每加一种type，腾讯那边addSource加一个
 */
public enum ETempFriendType {

    RANDOM_MATCH_CHAT(1, "临时文字聊天匹配"),
    RANDOM_MATCH_GAME(2, "游戏临时好友"),
    RANDOM_MATCH_VOICE(3, "临时语音匹配"),
    SECRET_LETTER(4, "神秘邮局匹配好友"),
    COIN_TREE(5, "摇钱树活动匹配好友"),
    LETTER_BOARD(6, "照片墙匹配好友");

    public Integer getTempFriendType() {
        return tempFriendType;
    }

    public String getDesc() {
        return desc;
    }

    ETempFriendType(Integer tempFriendType, String desc) {
        this.tempFriendType = tempFriendType;
        this.desc = desc;
    }

    private Integer tempFriendType;

    private String desc;
}
