package com.ufoto.friendchat.entity.tim.result;

import com.alibaba.fastjson.annotation.JSONField;
import lombok.Builder;
import lombok.Data;

/**
 *
 * @Author Wang, Qing
 * @Date 2019/10/23 09:52
 */
@Data
@Builder
public class TIMFriendResultItem {

    @JSONField(name = "To_Account")
    private String tUid;

    @JSONField(name = "ResultCode")
    private Integer resultCode;

    @JSONField(name = "ResultInfo")
    private String resultInfo;
}
