package com.ufoto.friendchat.entity;

import lombok.Data;

/**
 * <p>
 * Author     : Chan
 * CreateDate : 2019-01-15 17:19
 * Description:
 * </p>
 */
@Data
public class UserInterestCategory {
    private int category;
    private Long uid;
}
