package com.ufoto.friendchat.entity.tim;

import com.alibaba.fastjson.annotation.JSONField;
import lombok.Builder;
import lombok.Data;

/**
 *
 * @Author Wang, Qing
 * @Date 2019/10/21 15:22
 */
@Data
@Builder
public class TIMMsgBodyEntity {

    @JSONField(name = "MsgType")
    private String msgType;

    @JSONField(name = "MsgContent")
    private Object elem;
}
