package com.ufoto.friendchat.constants.tim;

import com.ufoto.friendchat.constants.ETempFriendType;

import java.util.Objects;

/**
 * @Author: Wang, Qing
 * @Date: 2019-07-22 16:56
 */
public enum ETIMFriendAddSource {

    RING("AddSource_Type_ring"),
    GAME("AddSource_Type_game"),
    WINK("AddSource_Type_wink"),
    SECRET_LETTER("AddSource_Type_letter"),
    COIN_TREE("AddSource_Type_ctree"),
    LETTER_BOARD("AddSource_Type_bLetter"),
    FORMAL_FRIEND("AddSource_Type_formal"),
    OTHER("AddSource_Type_other"),
    OLD_FRIEND("AddSource_Type_old");

    public static String getTempFriendType(Integer isGameFriend) {
        if (Objects.equals(isGameFriend, ETempFriendType.RANDOM_MATCH_VOICE.getTempFriendType())) {
            return RING.value;
        }
        if (Objects.equals(isGameFriend, ETempFriendType.RANDOM_MATCH_CHAT.getTempFriendType())) {
            return WINK.value;
        }
        if (Objects.equals(isGameFriend, ETempFriendType.RANDOM_MATCH_GAME.getTempFriendType())) {
            return GAME.value;
        }
        if (Objects.equals(isGameFriend, ETempFriendType.SECRET_LETTER.getTempFriendType())) {
            return SECRET_LETTER.value;
        }
        if (Objects.equals(isGameFriend, ETempFriendType.COIN_TREE.getTempFriendType())) {
            return COIN_TREE.value;
        }
        if (Objects.equals(isGameFriend, ETempFriendType.LETTER_BOARD.getTempFriendType())) {
            return LETTER_BOARD.value;
        }
        return OTHER.value;
    }

    public String getValue() {
        return value;
    }

    ETIMFriendAddSource(String value) {
        this.value = value;
    }

    private String value;

}
