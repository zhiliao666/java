package com.ufoto.friendchat.entity.tim;

import com.alibaba.fastjson.annotation.JSONField;
import lombok.Builder;
import lombok.Data;

import java.util.List;

/**
 *
 * @Author Wang, Qing
 * @Date 2019/10/24 17:21
 */
@Data
@Builder
public class TIMDeleteFriendModel {

    @JSONField(name = "From_Account")
    private String fUid;

    @JSONField(name = "To_Account")
    private List<String> tUid;

    @JSONField(name = "DeleteType")
    private String deleteType;
}
