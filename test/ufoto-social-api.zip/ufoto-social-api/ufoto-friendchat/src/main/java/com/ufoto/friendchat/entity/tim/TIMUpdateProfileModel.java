package com.ufoto.friendchat.entity.tim;

import com.alibaba.fastjson.annotation.JSONField;
import lombok.Builder;
import lombok.Data;

import java.util.List;

/**
 *
 * @Author Wang, Qing
 * @Date 2019/10/22 17:33
 */
@Data
@Builder
public class TIMUpdateProfileModel {

    @JSONField(name = "From_Account")
    private String fUid;

    @JSONField(name = "ProfileItem")
    private List<TIMCustomItem> TIMProfileItem;
}
