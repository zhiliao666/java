package com.ufoto.friendchat.service;

import java.util.List;
import java.util.Map;

/**
 * Created by Wang, Qing
 * 2020/3/9
 */
public interface UfotoUserInterestTagService {

    Map<Long, List<Integer>> queryCategoryIdByUids(List<Long> uids);
}
