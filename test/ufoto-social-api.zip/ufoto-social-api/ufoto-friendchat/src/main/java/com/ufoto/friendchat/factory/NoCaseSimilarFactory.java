package com.ufoto.friendchat.factory;

import com.ufoto.friendchat.entity.SimilarDto;
import com.ufoto.friendchat.entity.SingleMatchSimilar;
import lombok.extern.slf4j.Slf4j;
import org.springframework.stereotype.Component;

/**
 * <p>
 * Author     : Chan
 * CreateDate : 2019-01-16 11:48
 * Description:
 * </p>
 */
@Slf4j
@Component
public class NoCaseSimilarFactory implements MatchSimilarFactory {
    @Override
    public SingleMatchSimilar doSimilar(SimilarDto similarDto) {
        log.info("sameRandom,user1:{},user2:{}", similarDto.getUsers().get(0), similarDto.getUsers().get(1));
        return getSingleMatchSimilar(similarDto);
    }
}
