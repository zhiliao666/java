package com.ufoto.friendchat.utils;

import com.ufoto.friendchat.constants.EConstellation;
import org.apache.commons.lang3.StringUtils;
import org.apache.commons.lang3.time.DateFormatUtils;
import org.springframework.context.MessageSource;

import java.util.Date;
import java.util.Locale;

/**
 * <p>
 * Author     : Chan
 * CreateDate : 2018/10/22 16:19
 * Description: 星座
 * </p>
 */
public class ConstellationUtil {

    /**
     * 获取多语言版本的星座
     *
     * @param messageSource 源
     * @param birthday      生日
     * @param lang          语言
     * @return 星座
     */
    public static String getConstellation(MessageSource messageSource, Date birthday, String lang) {
        return messageSource.getMessage(getConstellation(birthday).name(), null, StringUtils.isNotBlank(lang) ?
                Locale.forLanguageTag(lang) : Locale.getDefault());
    }

    public static String getConstellation(MessageSource messageSource, String constellationKey, String lang) {
        return messageSource.getMessage(constellationKey, null, StringUtils.isNotBlank(lang) ?
                Locale.forLanguageTag(lang) : Locale.getDefault());
    }

    /**
     * 根据生日获取星座
     *
     * @param birthday yyyy-MM-dd HH:mm:ss
     * @return 星座对应的枚举 {@link EConstellation}
     */
    public static EConstellation getConstellation(Date birthday) {
        final String birth = DateFormatUtils.format(birthday, "Mdd");
        int intBirth = Integer.parseInt(birth);
        if (intBirth >= 120 && intBirth <= 218) {
            return EConstellation.AQUARIUS;
        } else if (intBirth >= 219 && intBirth <= 320) {
            return EConstellation.PISCES;
        } else if (intBirth >= 321 && intBirth <= 419) {
            return EConstellation.ARIES;
        } else if (intBirth >= 420 && intBirth <= 520) {
            return EConstellation.TAURUS;
        } else if (intBirth >= 521 && intBirth <= 620) {
            return EConstellation.GEMINI;
        } else if (intBirth >= 621 && intBirth <= 722) {
            return EConstellation.CANCER;
        } else if (intBirth >= 723 && intBirth <= 822) {
            return EConstellation.LEO;
        } else if (intBirth >= 823 && intBirth <= 922) {
            return EConstellation.VIRGO;
        } else if (intBirth >= 923 && intBirth <= 1022) {
            return EConstellation.LIBRA;
        } else if (intBirth >= 1023 && intBirth <= 1121) {
            return EConstellation.SCORPIO;
        } else if (intBirth >= 1122 && intBirth <= 1221) {
            return EConstellation.SAGITTARIUS;
        } else if ((intBirth >= 1222 && intBirth <= 1231) || (intBirth >= 11 && intBirth <= 119)) {
            return EConstellation.CAPRICORN;
        }
        throw new RuntimeException("生日有误");
    }

    public static String getIsomorphic(MessageSource messageSource, String isomorphic, String lang) {
        return messageSource.getMessage(isomorphic, null, StringUtils.isNotBlank(lang) ?
                Locale.forLanguageTag(lang) : Locale.getDefault());
    }
}
