package com.ufoto.friendchat.entity.tim;

import com.alibaba.fastjson.annotation.JSONField;
import lombok.Builder;
import lombok.Data;

import java.util.List;

/**
 *
 * @Author Wang, Qing
 * @Date 2019/10/23 14:33
 */
@Data
@Builder
public class TIMUpdateFriendModel {

    @JSONField(name = "From_Account")
    private String fUid;

    @JSONField(name = "UpdateItem")
    private List<TIMUpdateFriendItem> friendUpdateItemList;
}
