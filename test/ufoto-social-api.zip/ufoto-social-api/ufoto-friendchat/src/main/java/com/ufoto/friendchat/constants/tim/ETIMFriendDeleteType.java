package com.ufoto.friendchat.constants.tim;

/**
 *
 * @Author Wang, Qing
 * @Date 2019/10/24 17:02
 */
public enum ETIMFriendDeleteType {

    SINGLE("Delete_Type_Single"),
    BOTH("Delete_Type_Both");

    ETIMFriendDeleteType(String type) {
        this.type = type;
    }

    private String type;

    public String getType() {
        return type;
    }

    public void setType(String type) {
        this.type = type;
    }
}
