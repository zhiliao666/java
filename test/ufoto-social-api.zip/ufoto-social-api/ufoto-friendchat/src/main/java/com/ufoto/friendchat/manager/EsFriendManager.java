package com.ufoto.friendchat.manager;

import com.ufoto.common.utils.JsonUtil;
import com.ufoto.es.config.CustomElasticListener;
import com.ufoto.friendchat.entity.es.UfotoUserFriendsDto;
import com.ufoto.friendchat.util.constant.ElasticConstant;
import lombok.RequiredArgsConstructor;
import lombok.extern.slf4j.Slf4j;
import org.elasticsearch.action.bulk.BulkItemResponse;
import org.elasticsearch.action.bulk.BulkRequest;
import org.elasticsearch.action.bulk.BulkResponse;
import org.elasticsearch.action.index.IndexRequest;
import org.elasticsearch.client.RestHighLevelClient;
import org.elasticsearch.common.xcontent.XContentType;
import org.springframework.stereotype.Component;
import org.springframework.util.CollectionUtils;

import java.util.List;
import java.util.Objects;
import java.util.stream.Collectors;


/**
 *
 * @author luozq
 * @date 2020/3/6
 */
@Slf4j
@Component
@RequiredArgsConstructor
public class EsFriendManager {

    private final RestHighLevelClient restHighLevelClient;

    /**
     * save user friend data to es ufoto_user_like index
     * @param voList param
     * @return true; success ,false: failed
     */
    public Boolean batchSave(List<UfotoUserFriendsDto> voList) {
        List<UfotoUserFriendsDto> legalList = filterFriendList(voList);
        if (CollectionUtils.isEmpty(legalList)) {
            return false;
        }
        try {
            BulkRequest request = new BulkRequest(ElasticConstant.UFOTO_USER_FRIENDS);
            legalList.stream()
                    .map(this::buildIndexQuery)
                    .forEach(request::add);

            BulkResponse response = restHighLevelClient.bulk(request, CustomElasticListener.getReferOptions());
            log.info("friend save task msg, as follows: param {}, response: {}, fail_msg: {}",
                    JsonUtil.toJson(voList), response.getTook().millis(), response.buildFailureMessage());
            return true;
        } catch (Exception e) {
            log.error("batch save ufoto_user_friends task occurs error, list:{}, e:{}",
                    JsonUtil.toJson(legalList), e);
            return false;
        }

    }


    private IndexRequest buildIndexQuery(UfotoUserFriendsDto updateVo) {
        String docId = updateVo.getUid() + "_" + updateVo.getFid();
        IndexRequest request = new IndexRequest(ElasticConstant.UFOTO_USER_FRIENDS);
        try {
            request.source(JsonUtil.objectToEsMap(updateVo), XContentType.JSON);
        } catch (Exception e) {
            String jsonStr = JsonUtil.toJson(updateVo);
            log.warn("{}, es object to map task occurs error, data:{}", "ES_JSON_PARSE_ERROR", jsonStr, e);
            request.source(jsonStr, XContentType.JSON);
        }
        request.id(docId);
        return request;
    }

    /**
     * deal with illegal friend list
     * @param voList friend list
     * @return legal friend list
     */
    private List<UfotoUserFriendsDto> filterFriendList(List<UfotoUserFriendsDto> voList) {
        List<UfotoUserFriendsDto> illegalList = voList.stream()
                .filter(item -> Objects.isNull(item.getUid()) || Objects.isNull(item.getFid()))
                .collect(Collectors.toList());
        if (!CollectionUtils.isEmpty(illegalList)) {
            log.warn("{}, bath update friend info, illegal user info as follows, list:{}",
                    "ILLEGAL_UPDATE_FRIEND_INFO", JsonUtil.toJson(illegalList));
        }
        return voList.stream()
                .filter(item -> Objects.nonNull(item.getUid()) && Objects.nonNull(item.getFid()))
                .collect(Collectors.toList());
    }
}
