package com.ufoto.friendchat.entity;

import lombok.Data;

import java.util.List;

/**
 * <p>
 * Author     : Chan
 * CreateDate : 2019-01-15 14:39
 * Description: 匹配度消息 904
 * </p>
 */
@Data
public class MatchSimilar {
    private Integer rate;
    private List<String> similar;
}
