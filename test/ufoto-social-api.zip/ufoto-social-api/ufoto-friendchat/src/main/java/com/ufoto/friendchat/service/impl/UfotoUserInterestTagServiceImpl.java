package com.ufoto.friendchat.service.impl;

import com.google.common.collect.Lists;
import com.google.common.collect.Maps;
import com.ufoto.friendchat.entity.UserInterestCategory;
import com.ufoto.friendchat.mapper.read.UfotoUserInterestTagMapper;
import com.ufoto.friendchat.service.UfotoUserInterestTagService;
import lombok.RequiredArgsConstructor;
import org.springframework.stereotype.Service;
import org.springframework.util.CollectionUtils;

import java.util.List;
import java.util.Map;

/**
 * Created by Wang, Qing
 * 2020/3/9
 */
@Service
@RequiredArgsConstructor
public class UfotoUserInterestTagServiceImpl implements UfotoUserInterestTagService {

    final UfotoUserInterestTagMapper ufotoUserInterestTagMapper;

    @Override
    public Map<Long, List<Integer>> queryCategoryIdByUids(List<Long> uids) {
        final List<UserInterestCategory> interestCategories = ufotoUserInterestTagMapper.queryCategoryIdByUids(uids);
        if (CollectionUtils.isEmpty(interestCategories)) {
            return Maps.newLinkedHashMap();
        }
        Map<Long, List<Integer>> result = Maps.newLinkedHashMap();
        interestCategories.forEach(userInterestCategory ->
                result.merge(userInterestCategory.getUid(), Lists.newArrayList(userInterestCategory.getCategory()),
                        (o, n) -> {
                            o.addAll(n);
                            return o;
                        }));
        return result;
    }
}
