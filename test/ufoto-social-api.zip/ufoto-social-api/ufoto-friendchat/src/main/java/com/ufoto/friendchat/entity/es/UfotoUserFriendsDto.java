package com.ufoto.friendchat.entity.es;

import com.fasterxml.jackson.annotation.JsonInclude;
import com.fasterxml.jackson.annotation.JsonProperty;
import com.fasterxml.jackson.databind.PropertyNamingStrategy;
import com.fasterxml.jackson.databind.annotation.JsonNaming;
import lombok.Data;

import static com.fasterxml.jackson.annotation.JsonInclude.Include.NON_NULL;

/**
 * @author luozq
 * @date 2019/8/22 16:34
 */
@Data
@JsonNaming(PropertyNamingStrategy.SnakeCaseStrategy.class)
@JsonInclude(NON_NULL)
public class UfotoUserFriendsDto {

    /**
     * myself id
     */
    @JsonProperty("u_id")
    private Long uid;

    /**
     * friend id
     */
    @JsonProperty("f_id")
    private Long fid;

    /**
     * 0 match normal, 1 match temporary
     */
    private Integer fromType;

    /**
     * 0 not top, 1 top
     */
    @JsonProperty("is_top")
    private Integer isTop;

    /**
     * I delete friend, 0 not delete, 1 deleted
     */
    private Integer isDelete;

    /**
     * friend delete me, 0 not delete , 1 delete
     */
    @JsonProperty("f_is_delete")
    private Integer fIsDelete;

    /**
     * crate time, unit: seconds
     */
    private Integer createTime;

    /**
     * update time, unit: seconds
     */
    private Integer updateTime;

    /**
     * 0 对应ufoto_user_friends, 1 来自ufoto_user_old_friends
     */
    private Integer state;
}
