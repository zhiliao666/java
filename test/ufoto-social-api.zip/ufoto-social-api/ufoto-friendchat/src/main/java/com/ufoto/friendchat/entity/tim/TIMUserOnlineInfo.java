package com.ufoto.friendchat.entity.tim;

import com.alibaba.fastjson.annotation.JSONField;
import lombok.Builder;
import lombok.Data;

import java.util.Objects;

/**
 *
 * @Author Wang, Qing
 * @Date 2019/10/30 13:53
 */
@Data
@Builder
public class TIMUserOnlineInfo {

    /**
     * 用户上线或者下线的动作，Login 表示上线（TCP 建立），Logout 表示下线（TCP 断开），Disconnect 表示网络断开（TCP 断开）
     */
    @JSONField(name = "Action")
    private String action;

    /**
     * 用户 Identifier
     */
    @JSONField(name = "To_Account")
    private String tUid;

    /**
     * 用户上下线触发的原因：
     * Login 的原因有 Register：App TCP 连接建立；
     * Logout 的原因有 Unregister：App 用户注销帐号导致 TCP 断开；
     * Disconnect 的原因有 LinkClose：即时通信 IM 检测到 App TCP 连接断开；TimeOut：即时通信 IM 检测到 App 心跳包超时，认为 TCP 已断开（客户端杀后台或 Crash）
     */
    @JSONField(name = "Reason")
    private String reason;

    public boolean isOnline() {
        return Objects.equals(action, "Login");
    }

}
