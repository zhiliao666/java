package com.ufoto.friendchat.constants;

/**
 * <p>
 * Author     : Chan
 * CreateDate : 2018/10/10 10:59
 * Description:
 * </p>
 */
public enum ESupportLanguage {
    EN("en"),
    HI("hi"),
    ES("es"),
    PT("pt"),
    AR("ar"),//阿拉伯语
    IN("in"),
    RU("ru");//俄语

    private String lang;

    ESupportLanguage(String lang) {
        this.lang = lang;
    }

    public String getLang() {
        return lang;
    }

    public static boolean contains(String lang){
        ESupportLanguage[] language = ESupportLanguage.values();
        for (int i = 0; i < language.length; i++) {
            if(language[i].getLang().equalsIgnoreCase(lang)){
                return true;
            }
        }
        return false;
    }
}
