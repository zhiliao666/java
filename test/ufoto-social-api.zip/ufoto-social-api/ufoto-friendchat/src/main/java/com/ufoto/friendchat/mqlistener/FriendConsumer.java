package com.ufoto.friendchat.mqlistener;

import com.rabbitmq.client.Channel;
import com.ufoto.friendchat.service.UfotoUserFriendsService;
import com.ufoto.rabbit.behavior.msg.SnsSlideMsg;
import com.ufoto.rabbit.config.RabbitConsumerExecutor;
import lombok.RequiredArgsConstructor;
import lombok.extern.slf4j.Slf4j;
import org.springframework.amqp.core.ExchangeTypes;
import org.springframework.amqp.rabbit.annotation.Exchange;
import org.springframework.amqp.rabbit.annotation.Queue;
import org.springframework.amqp.rabbit.annotation.QueueBinding;
import org.springframework.amqp.rabbit.annotation.RabbitListener;
import org.springframework.amqp.support.AmqpHeaders;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.messaging.handler.annotation.Header;
import org.springframework.messaging.handler.annotation.Payload;
import org.springframework.stereotype.Component;

import static com.ufoto.friendchat.constants.Constants.Q_USER_MATCH;
import static com.ufoto.rabbit.behavior.constants.BehaviorExchange.EX_SOCIAL_SNS_SLIDE_MATCH;


@Slf4j
@RequiredArgsConstructor
@Component
public class FriendConsumer {

    @Autowired
    UfotoUserFriendsService ufotoUserFriendsService;

    @RabbitListener(bindings = {
            @QueueBinding(exchange = @Exchange(name = EX_SOCIAL_SNS_SLIDE_MATCH, type = ExchangeTypes.FANOUT),
                    value = @Queue(name = Q_USER_MATCH,
                            durable = "true", exclusive = "false"))
    })
    public void userMatchListener(@Payload SnsSlideMsg snsSlideMsg, Channel channel,
                                  @Header(AmqpHeaders.DELIVERY_TAG) long deliveryTag) {
        RabbitConsumerExecutor.execute(channel, deliveryTag, () -> ufotoUserFriendsService.doNormalFriendMatch(snsSlideMsg.getUid(), snsSlideMsg.getTargetUid()));
    }

}
