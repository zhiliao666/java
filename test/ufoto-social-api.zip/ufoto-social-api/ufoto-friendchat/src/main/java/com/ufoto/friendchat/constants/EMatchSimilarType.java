package com.ufoto.friendchat.constants;

import com.ufoto.friendchat.factory.*;

/**
 * <p>
 * Author     : Chan
 * CreateDate : 2019-01-15 14:47
 * Description: 匹配度类型  与EMatchSimilarCategory关联
 * </p>
 */
public enum EMatchSimilarType {
    DISTANCE_COUNTRY_DISTANCE(-1, 1, 1, "DISTANCE SIMILAR", DistanceCountryDistanceSimilarFactory.class),
    DISTANCE_COUNTRY_COUNTRY(0, 1, 1, "COUNTRY SIMILAR", DistanceCountryCountrySimilarFactory.class),
    BIRTHDAY_DAY(1, 1, 4, "You two were born on %s！", BirthdayDaySimilarFactory.class),
    BIRTHDAY_MONTH(1, 2, 5, "%s is the luckiest month of you!", BirthdayMonthSimilarFactory.class),
    BIRTHDAY_YEAR(1, 3, 3, "You two were born in %s!", BirthdayYearSimilarFactory.class),
    BIRTHDAY_MONTH_DAY(1, 4, 2, "Wow, you're birthday twins!", BirthdayMonthDaySimilarFactory.class),
    BIRTHDAY_SAME(1, 5, 1, "Amazing! Super birthday twins--%s.%s.%s!", BirthdaySameSimilarFactory.class),
    BIRTHDAY_CONSTELLATION_(1, 6, 6, "You two are %s!", BirthdayConstellationSimilarFactory.class),
    BIRTHDAY_CONSTELLATION_ISOMORPHIC(1, 7, 7, "You're the same %s signs!", BirthdayConstellationIsomorphicSimilarFactory.class),
    BIRTHDAY_GENERATION(1, 8, 8, "Oh, you're the %ss generation!", BirthdayGenerationSimilarFactory.class),

    INTEREST_SPORT(2, 1, 11, "Both of you are fond of sports!", InterestSportSimilarFactory.class),
    INTEREST_MUSIC(2, 2, 13, "You are both keen on music!", InterestMusicSimilarFactory.class),
    INTEREST_BOOK(2, 5, 10, "Both of you love reading!", InterestBookSimilarFactory.class),
    INTEREST_FOOD(2, 3, 14, "You have the same philosophy of food!", InterestFoodSimilarFactory.class),
    INTEREST_CITY(2, 6, 9, "Both of you like travelling!", InterestCitySimilarFactory.class),
    INTEREST_MOVIE(2, 4, 12, "Watching movies is your common passion!", InterestMovieSimilarFactory.class),

    COUNTRY_HOME_CITY(3, 1, 15, "You have the same hometown!", CountryHomeCitySimilarFactory.class),
    COUNTRY_HOME_COUNTRY(3, 2, 16, "You come from the same country!", CountryHomeCountrySimilarFactory.class),
    COUNTRY_HOME_COUNTRY2(3, 2, 16, "You celebrate the similar culture!", CountryHomeCountrySimilarFactory.class),

    NO_CASE_1(4, 1, 17, "You two have a lot in common!", NoCaseSimilarFactory.class),
    NO_CASE_2(4, 1, 17, "You're not far away from each other！", NoCaseSimilarFactory.class),
    NO_CASE_3(4, 1, 17, "You may become best friends!", NoCaseSimilarFactory.class),
    NO_CASE_4(4, 1, 17, "Fate brought you together！", NoCaseSimilarFactory.class),
    NO_CASE_5(4, 1, 17, "You look good together!", NoCaseSimilarFactory.class),
    NO_CASE_6(4, 1, 17, "You guys make a cute couple!", NoCaseSimilarFactory.class),
    NO_CASE_7(4, 1, 17, "There's chemistry between you!", NoCaseSimilarFactory.class),
    NO_CASE_8(4, 1, 17, "You're perfectly matchable!", NoCaseSimilarFactory.class);

    private int category;
    private int type;
    private int priority;
    private String description;
    private Class<? extends MatchSimilarFactory> factory;

    EMatchSimilarType(int category, int type, int priority, String description, Class<? extends MatchSimilarFactory> factory) {
        this.category = category;
        this.type = type;
        this.priority = priority;
        this.description = description;
        this.factory = factory;
    }

    public Class<? extends MatchSimilarFactory> getFactory() {
        return factory;
    }

    public String getDescription() {
        return description;
    }

    public int getCategory() {
        return category;
    }

    public int getType() {
        return type;
    }

    public int getPriority() {
        return priority;
    }
}
