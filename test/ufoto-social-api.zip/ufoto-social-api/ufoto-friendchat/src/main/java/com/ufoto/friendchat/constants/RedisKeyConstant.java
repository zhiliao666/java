package com.ufoto.friendchat.constants;

/**
 * redis相关key
 *
 * @author zhangqh
 * @date 2017年11月23日
 */
public class RedisKeyConstant {
    /**
     * zset
     * 格式
     * u_match {minUId}:{maxUid} score
     * score为配对时间及每次查询时更新此score时间 以做为此配对的活跃时间
     * 数据保留指定天数 可作为定时器来做 每天清理一次 删除score小于指定时间的值
     */
    public static final String REDIS_USER_MATCHING_ZET_KEY = "u_match";

    /**
     * 匹配之后 friends_temp配对状态维护
     * hash(uid1<uid2)
     * random_after_match_status_friends uid1:uid2 status
     */
    public static final String REDIS_RANDOM_AFTER_MATCH_STATUS_FRIENDS = "random_after_match_status_friends";

    /**
     * 用户匹配存储SET，
     * 格式：
     * 1000：1001
     * 1002：1003
     * ...
     * 1002：1017
     * 数值较小的在左边
     */
    public final static String REDIS_USER_MATCHING_SET_KEY = "user_matching";

}
