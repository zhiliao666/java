package com.ufoto.friendchat.service.impl;

import com.google.common.collect.Lists;
import com.ufoto.common.utils.ApiResult;
import com.ufoto.common.utils.DateUtil;
import com.ufoto.feign.chat.MsgChatBusiness;
import com.ufoto.friendchat.constants.Constants;
import com.ufoto.friendchat.constants.ETempFriendStatus;
import com.ufoto.friendchat.constants.RedisKeyConstant;
import com.ufoto.friendchat.consumer.SayHiConsumer;
import com.ufoto.friendchat.converter.FriendsConverter;
import com.ufoto.friendchat.entity.UfotoUserFriends;
import com.ufoto.friendchat.manager.EsFriendManager;
import com.ufoto.friendchat.manager.MatchSimilarManager;
import com.ufoto.friendchat.manager.TIMApiManager;
import com.ufoto.friendchat.mapper.read.UfotoUserFriendsMapper;
import com.ufoto.friendchat.mapper.write.WriteUfotoUserFriendsMapper;
import com.ufoto.friendchat.service.UfotoUserFriendsService;
import com.ufoto.redis.service.RedisService;
import lombok.RequiredArgsConstructor;
import lombok.extern.slf4j.Slf4j;
import org.springframework.stereotype.Service;

import java.util.List;
import java.util.Objects;

import static com.ufoto.friendchat.constants.EMsgType.NORMAL_MATCH_SUCCESS;
import static com.ufoto.friendchat.constants.RedisKeyConstant.REDIS_RANDOM_AFTER_MATCH_STATUS_FRIENDS;


/**
 * Created by Wang, Qing
 * 2020/2/26
 */
@Service
@RequiredArgsConstructor
@Slf4j
public class UfotoUserFriendsServiceImpl implements UfotoUserFriendsService {

    private final RedisService redisService;

    private final UfotoUserFriendsMapper ufotoUserFriendsMapper;

    private final WriteUfotoUserFriendsMapper writeUfotoUserFriendsMapper;

    private final TIMApiManager timApiManager;

    private final EsFriendManager esFriendManager;

    private final MsgChatBusiness msgChatBusiness;

    private final MatchSimilarManager matchSimilarManager;

    private final SayHiConsumer sayHiConsumer;

    @Override
    public ApiResult<Boolean> isFriends(Long toUid, Long uid) {

        Integer count = ufotoUserFriendsMapper.isFriends(uid, toUid);
        if (Objects.nonNull(count) && count > 0) {
            //是正是好友
            return new ApiResult<Boolean>().setResult(true);
        }

        String result = redisService.hget(REDIS_RANDOM_AFTER_MATCH_STATUS_FRIENDS, Math.min(toUid, uid) + ":" + Math.max(toUid, uid));
        if (Objects.isNull(result)) {
            return new ApiResult<Boolean>().setResult(false);
        }

        Integer status = Integer.valueOf(result);
        if (ETempFriendStatus.contains(status)) {
            return new ApiResult<Boolean>().setResult(true);
        }
        return new ApiResult<Boolean>().setResult(false);
    }

    @Override
    public void doNormalFriendMatch(Long uid, Long tUid) {

        redisService.sadd(RedisKeyConstant.REDIS_USER_MATCHING_SET_KEY, createMatchUidGroup(uid, tUid));
        UfotoUserFriends ufotoUserFriends1 = new UfotoUserFriends();
        ufotoUserFriends1.setuId(uid);
        ufotoUserFriends1.setfId(tUid);
        ufotoUserFriends1.setIsTop((byte) 0);
        ufotoUserFriends1.setIsDelete((byte) Constants.IS_DELETE_0);
        ufotoUserFriends1.setfIsDelete((byte) Constants.IS_DELETE_0);
        ufotoUserFriends1.setFromType((byte) 0);
        ufotoUserFriends1.setCreateTime(DateUtil.getCurrentSecondIntValue());
        ufotoUserFriends1.setUpdateTime(DateUtil.getCurrentSecondIntValue());
        UfotoUserFriends ufotoUserFriends2 = new UfotoUserFriends();
        ufotoUserFriends2.setuId(tUid);
        ufotoUserFriends2.setfId(uid);
        ufotoUserFriends2.setIsTop((byte) 0);
        ufotoUserFriends2.setIsDelete((byte) Constants.IS_DELETE_0);
        ufotoUserFriends2.setfIsDelete((byte) Constants.IS_DELETE_0);
        ufotoUserFriends2.setFromType((byte) 0);
        ufotoUserFriends2.setCreateTime(DateUtil.getCurrentSecondIntValue());
        ufotoUserFriends2.setUpdateTime(DateUtil.getCurrentSecondIntValue());

        List<UfotoUserFriends> friendsList = Lists.newArrayList(ufotoUserFriends1, ufotoUserFriends2);
        //同步mysql
        writeUfotoUserFriendsMapper.insertList(friendsList);

        //同步腾讯
        timApiManager.addFromalFriend(friendsList);

        //同步es
        Boolean result = esFriendManager.batchSave(FriendsConverter.fromFormal(friendsList));
        if (!result) {
            log.warn("WARN_FRIENDS_ES_DELETE_FAILED", FriendsConverter.fromFormal(friendsList));
        }

        msgChatBusiness.sendMsg(uid, tUid, "", NORMAL_MATCH_SUCCESS.getMsgType(), Constants.CHAT_TYPE_2);

        msgChatBusiness.sendMsg(tUid, uid, "", NORMAL_MATCH_SUCCESS.getMsgType(), Constants.CHAT_TYPE_2);

        matchSimilarManager.syncSimilar(uid, tUid);

        sayHiConsumer.sayHi(uid, tUid);
    }

    private String createMatchUidGroup(Long uid1, Long uid2) {
        return uid1 < uid2 ? uid1 + ":" + uid2 : uid2 + ":" + uid1;
    }
}
