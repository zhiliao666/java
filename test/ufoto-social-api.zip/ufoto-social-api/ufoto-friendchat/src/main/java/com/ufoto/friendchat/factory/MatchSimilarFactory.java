package com.ufoto.friendchat.factory;

import com.google.common.collect.Lists;
import com.ufoto.common.utils.CommonUtil;
import com.ufoto.friendchat.constants.EMatchSimilarCategory;
import com.ufoto.friendchat.entity.SimilarDto;
import com.ufoto.friendchat.entity.SingleMatchSimilar;
import com.ufoto.friendchat.entity.UfotoAppUser;
import com.ufoto.friendchat.entity.UfotoMatchSimilar;
import org.apache.commons.lang3.ArrayUtils;
import org.apache.commons.lang3.RandomUtils;
import org.apache.commons.lang3.StringUtils;
import org.joda.time.DateTime;
import org.springframework.util.CollectionUtils;

import java.util.*;
import java.util.stream.Collectors;

/**
 * <p>
 * Author     : Chan
 * CreateDate : 2019-01-15 18:06
 * Description:
 * </p>
 */
public interface MatchSimilarFactory {

    String placeholder = "%s";

    SingleMatchSimilar doSimilar(SimilarDto similarDto);

    default SingleMatchSimilar getSingleMatchSimilar(SimilarDto similarDto, String[]... place) {
        final List<UfotoMatchSimilar> similars = similarDto.getSimilars();
        final List<UfotoMatchSimilar> targetSimilars = similarDto.getTargetSimilars();
        SingleMatchSimilar singleMatchSimilar = new SingleMatchSimilar();
        singleMatchSimilar.setRate(100 - similars.get(0).getPriority());
        singleMatchSimilar.setDescriptions(Lists.newArrayList());
        singleMatchSimilar.setTargetDescriptions(Lists.newArrayList());
        final Integer category = similars.get(0).getCategory();
        final List<String> descriptions = similars.stream().map(UfotoMatchSimilar::getDescription).collect(Collectors.toList());
        final List<String> targetDescriptions = targetSimilars.stream().map(UfotoMatchSimilar::getDescription).collect(Collectors.toList());
        final int finalSize = similarDto.getFinalResults().size();
        if (Objects.equals(EMatchSimilarCategory.NO_CASE.getCategory(), category) && finalSize == 0) {
            //如果是兜底的分类 判断当前结果
            final int[] randomCommon = CommonUtil.randomCommon(0, similars.size(), 2);
            for (int i = 0; i < 2; i++) {
                final int index = randomCommon[i];
                singleMatchSimilar.getDescriptions().add(descriptions.get(index));
                singleMatchSimilar.getTargetDescriptions().add(targetDescriptions.get(index));
            }
            return singleMatchSimilar;
        } else {
            final int index = RandomUtils.nextInt(0, similars.size());
            String desc = descriptions.get(index);
            if (desc.contains(placeholder) && ArrayUtils.isNotEmpty(place) && ArrayUtils.isNotEmpty(place[0])) {
                desc = String.format(desc, Arrays.stream(place[0]).toArray());
            }
            singleMatchSimilar.getDescriptions().add(desc);
            String targetDesc = targetDescriptions.get(index);
            if (targetDesc.contains(placeholder) && ArrayUtils.isNotEmpty(place) && ArrayUtils.isNotEmpty(place[1])) {
                targetDesc = String.format(targetDesc, Arrays.stream(place[1]).toArray());
            }
            singleMatchSimilar.getTargetDescriptions().add(targetDesc);
            return singleMatchSimilar;
        }
    }

    default DateTime getUserDatetime(UfotoAppUser user) {
        final Date d1 = user.getBirthTime();
        if (d1 == null) {
            return null;
        }
        return new DateTime(d1.getTime());
    }

    default SingleMatchSimilar getInterestSingleMatchSimilar(SimilarDto similarDto, int interestType) {
        final Map<Long, List<Integer>> interestMap = similarDto.getInterestMap();
        if (CollectionUtils.isEmpty(interestMap) || interestMap.size() != 2) {
            return null;
        }
        boolean isSame = true;
        for (List<Integer> value : interestMap.values()) {
            if (!value.contains(interestType)) {
                isSame = false;
                break;
            }
        }
        if (!isSame) {
            return null;
        }
        return getSingleMatchSimilar(similarDto);
    }

    default boolean hasNull(String... args) {
        if (ArrayUtils.isEmpty(args)) throw new IllegalArgumentException("args can not be empty");
        for (String arg : args) {
            if (StringUtils.isBlank(arg)) return true;
        }
        return false;
    }
}
