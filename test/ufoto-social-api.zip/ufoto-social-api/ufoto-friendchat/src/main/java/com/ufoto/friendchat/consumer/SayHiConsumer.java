package com.ufoto.friendchat.consumer;

import com.ufoto.feign.chat.MsgChatBusiness;
import com.ufoto.feign.usercenter.dto.UserBaseInfoDto;
import com.ufoto.friendchat.constants.EMsgType;
import com.ufoto.friendchat.manager.UserManagerFriendChat;
import lombok.RequiredArgsConstructor;
import org.apache.commons.lang3.StringUtils;
import org.springframework.stereotype.Component;

import java.util.EnumSet;
import java.util.Map;
import java.util.stream.Collectors;

/**
 * <p>
 * Description:
 *
 * </p>
 *
 * @author Chan
 * @date 2020/2/14 15:47
 */
@Component
@RequiredArgsConstructor
public class SayHiConsumer {
    private final Map<String, String> hiMap = EnumSet.allOf(EHi.class)
            .stream().collect(Collectors.toMap(EHi::getLang, EHi::getText));
    private final UserManagerFriendChat userManager;
    private final MsgChatBusiness msgChatBusiness;

    public void sayHi(Long uid, Long tUid) {
        final UserBaseInfoDto appUser = userManager.queryUserOne(uid);
        if (appUser == null) {
            return;
        }
        String lang = appUser.getLang();
        lang = StringUtils.isBlank(lang) ? EHi.EN.getLang() : lang.toLowerCase();
        msgChatBusiness.sendMsg(uid, tUid,
                hiMap.getOrDefault(lang, EHi.EN.getText()),
                EMsgType.TEXT.getMsgType(),
                0);
    }

    enum EHi {
        EN("en", "Hi"),
        HI("hi", "नमस्ते"),
        ES("es", "Hola"),
        PT("pt", "Oi"),
        AR("ar", "مرحبا"),//阿拉伯语
        IN("in", "Hai"),
        RU("ru", "Здравствуй");//俄语

        private String lang;
        private String text;

        EHi(String lang, String text) {
            this.lang = lang;
            this.text = text;
        }

        public String getLang() {
            return lang;
        }

        public String getText() {
            return text;
        }
    }
}
