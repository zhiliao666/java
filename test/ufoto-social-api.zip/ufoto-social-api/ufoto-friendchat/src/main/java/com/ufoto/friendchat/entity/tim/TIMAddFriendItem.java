package com.ufoto.friendchat.entity.tim;

import com.alibaba.fastjson.annotation.JSONField;
import lombok.Builder;
import lombok.Data;

import java.util.List;

/**
 *
 * @Author Wang, Qing
 * @Date 2019/10/22 17:36
 */
@Data
@Builder
public class TIMAddFriendItem {

    @JSONField(name = "To_Account")
    private String tUid;

    @JSONField(name = "Remark")
    private String remark;

    @JSONField(name = "RemarkTime")
    private Integer remarkTime;

    @JSONField(name = "GroupName")
    private List<String> groupNames;

    @JSONField(name = "AddSource")
    private String addSource;

    @JSONField(name = "AddWording")
    private String addWording;

    @JSONField(name = "AddTime")
    private Integer createTime;

    @JSONField(name = "CustomItem")
    List<TIMCustomItem> TIMCustomItem;
}
