package com.ufoto.friendchat.factory;

import com.ufoto.friendchat.entity.SimilarDto;
import com.ufoto.friendchat.entity.SingleMatchSimilar;
import com.ufoto.friendchat.entity.UfotoAppUser;
import lombok.extern.slf4j.Slf4j;
import org.springframework.stereotype.Component;

import java.util.List;
import java.util.Objects;

/**
 * <p>
 * Author     : Chan
 * CreateDate : 2019-01-16 12:23
 * Description:
 * </p>
 */
@Slf4j
@Component
public class CountryHomeCitySimilarFactory implements MatchSimilarFactory {
    @Override
    public SingleMatchSimilar doSimilar(SimilarDto similarDto) {
        final List<UfotoAppUser> users = similarDto.getUsers();
        final String hometown1 = users.get(0).getHometown();
        final String hometown2 = users.get(1).getHometown();
        log.debug("sameHometown,user1:{},h1:{},user2:{},h2:{}", users.get(0).getId(), hometown1, users.get(1).getId(), hometown2);
        if (hasNull(hometown1, hometown2)) {
            //如果有null 返回null
            return null;
        }
        if (!Objects.equals(hometown1, hometown2)) {
            return null;
        }
        return getSingleMatchSimilar(similarDto);
    }
}
