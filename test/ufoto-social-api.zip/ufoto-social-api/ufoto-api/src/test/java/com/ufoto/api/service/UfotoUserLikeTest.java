package com.ufoto.api.service;

import com.ufoto.api.ApiApplicationTests;
import com.ufoto.behavior.entity.UfotoUserLikeFrom;
import com.ufoto.behavior.service.UfotoUserLikeService;
import org.junit.Test;
import org.springframework.beans.factory.annotation.Autowired;

/**
 * <p>
 * Description:
 *
 * </p>
 *
 * @author Chan
 * @date 2020/2/12 13:01
 */
public class UfotoUserLikeTest extends ApiApplicationTests {

    @Autowired
    private UfotoUserLikeService ufotoUserLikeService;

    @Test
    public void testSelectCount() {
        UfotoUserLikeFrom like = new UfotoUserLikeFrom();
        like.setFUId(123L);
        like.setTUId(124L);
        final int count = ufotoUserLikeService.selectCount(like);
        System.out.println("count: " + count);
    }
}
