package com.ufoto.api.service;

import com.google.common.collect.Lists;
import com.ufoto.api.ApiApplicationTests;
import com.ufoto.behavior.entity.UfotoUserLike;
import com.ufoto.behavior.manager.EsManager;
import com.ufoto.common.utils.JsonUtil;
import com.ufoto.friendchat.entity.es.UfotoUserFriendsDto;
import com.ufoto.friendchat.manager.EsFriendManager;
import lombok.extern.slf4j.Slf4j;
import org.junit.Test;
import org.springframework.beans.factory.annotation.Autowired;

/**
 * @author luozq
 * @date 2020/3/6 18:15
 */
@Slf4j
public class EsTest extends ApiApplicationTests {

    @Autowired
    private EsManager esManager;

    @Autowired
    private EsFriendManager esFriendManager;

    @Test
    public void test1() {
        UfotoUserLike like = new UfotoUserLike();
        like.setFUId(100L);
        like.setTUId(401206955667882076L);
        like.setCreateTime(1583736833);
        like.setType(0);
        esManager.insert(like);
    }

    @Test
    public void test2() {
        UfotoUserFriendsDto friendsDto = new UfotoUserFriendsDto();
        friendsDto.setCreateTime(1583491576);
        friendsDto.setUpdateTime(1583491576);
        friendsDto.setState(0);
        friendsDto.setFid(442638120727347236L);
        friendsDto.setUid(442637933812383762L);
        friendsDto.setFromType(0);
        friendsDto.setIsDelete(0);
        friendsDto.setFIsDelete(0);
        esFriendManager.batchSave(Lists.newArrayList(friendsDto));
    }
}
