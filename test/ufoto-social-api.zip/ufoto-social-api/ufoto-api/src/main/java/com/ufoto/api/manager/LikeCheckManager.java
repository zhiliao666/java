package com.ufoto.api.manager;

import com.ufoto.account.api.AccountCoinQuotaManage;
import com.ufoto.account.api.AccountLikeAndSuperLikeQuotaManage;
import com.ufoto.api.constants.EChoice;
import com.ufoto.api.constants.ELikeSource;
import com.ufoto.api.exception.LikeCheckException;
import com.ufoto.behavior.bean.ErrorCode;
import com.ufoto.behavior.bean.SnsLikeRequest;
import com.ufoto.behavior.manager.UserManager;
import com.ufoto.common.utils.ApiResult;
import com.ufoto.friendchat.service.UfotoUserFriendsService;
import lombok.RequiredArgsConstructor;
import org.springframework.stereotype.Component;

import java.util.Objects;

/**
 * <p>
 * Description:
 *
 * </p>
 *
 * @author Chan
 * @date 2020/2/19 17:05
 */
@RequiredArgsConstructor
@Component
public class LikeCheckManager {
    private final AccountLikeAndSuperLikeQuotaManage accountLikeAndSuperLikeQuotaManage;
    private final AccountCoinQuotaManage accountCoinQuotaManage;
    private final UserManager userManager;
    private final UfotoUserFriendsService ufotoUserFriendsService;

    public void checkLike(SnsLikeRequest likeRequest) {
        checkSelf(likeRequest.getUid(), likeRequest.getTargetUid());
        checkLikeQuota(likeRequest.getUid(), likeRequest.getSource());
        checkSlide(likeRequest.getUid());
        isFriends(likeRequest.getUid(), likeRequest.getTargetUid());
    }

    public void checkSuperLike(SnsLikeRequest likeRequest) {
        checkSelf(likeRequest.getUid(), likeRequest.getTargetUid());
        checkSlide(likeRequest.getUid());
        isFriends(likeRequest.getUid(), likeRequest.getTargetUid());
        final Integer useCoin = likeRequest.getUseCoin();
        if (Objects.equals(useCoin, EChoice.Yes.getChoice())) {
            checkCoinWhenSuperLike(likeRequest);
        } else {
            checkSuperLikeQuota(likeRequest.getUid());
        }
    }

    public void checkDislike(SnsLikeRequest likeRequest) {

    }

    private void checkCoinWhenSuperLike(SnsLikeRequest likeRequest) {
        final ApiResult<Boolean> apiResult = accountCoinQuotaManage.checkSuperLikeExchange(likeRequest.getUid(),
                likeRequest.getLang(), likeRequest.getCp());
        if (!Objects.equals(apiResult.getC(), ApiResult.successCode) || !apiResult.getD()) {
            throw new LikeCheckException("not enough coins", ErrorCode.OUT_OF_BALANCE);
        }
    }

    public void checkSelf(Long uid, Long targetUid) {
        if (Objects.equals(uid, targetUid)) {
            throw new LikeCheckException("you can't not like yourself", ErrorCode.ERROR_CODE_ALREADY_LIKED);
        }
    }

    public void checkLikeQuota(Long uid, Integer source) {
        // 账号服务 判断like 额度  checkLikeQuota
        if (!Objects.equals(source, ELikeSource.slide.getSource())) {
            return;
        }
        final ApiResult<Boolean> apiResult = accountLikeAndSuperLikeQuotaManage.checkLikeQuota(uid);
        if (!Objects.equals(apiResult.getC(), ApiResult.successCode) || !apiResult.getD()) {
            throw new LikeCheckException("out of like", ErrorCode.ERROR_CODE_OUT_OF_LIKE);
        }
    }

    public void checkSlide(Long uid) {
        final ApiResult<Boolean> slideCheck = userManager.slideCheck(uid);
        if (!Objects.equals(slideCheck.getC(), ApiResult.successCode) || !slideCheck.getD()) {
            throw new LikeCheckException(slideCheck.getM(), slideCheck.getC());
        }
    }

    private void isFriends(Long uid, Long targetUid) {
        final ApiResult<Boolean> apiResult = ufotoUserFriendsService.isFriends(uid, targetUid);
        if (Objects.equals(apiResult.getC(), ApiResult.successCode)
                && apiResult.getD()) {
            throw new LikeCheckException("already friends", ErrorCode.ERROR_CODE_ALREADY_FRIENDS);
        }
    }

    public void checkSuperLikeQuota(Long uid) {
        final ApiResult<Boolean> apiResult = accountLikeAndSuperLikeQuotaManage.checkSuperLikeQuota(uid);
        if (!Objects.equals(ApiResult.successCode, apiResult.getC()) || !apiResult.getD()) {
            throw new LikeCheckException(apiResult.getM(), apiResult.getC());
        }
    }
}
