package com.ufoto.api.exception;

/**
 * <p>
 * Description:
 *
 * </p>
 *
 * @author Chan
 * @date 2020/2/19 17:06
 */
public class LikeCheckException extends RuntimeException {
    private Integer code;

    public LikeCheckException(Integer code) {
        this.code = code;
    }

    public LikeCheckException(String message, Integer code) {
        super(message);
        this.code = code;
    }

    public LikeCheckException(String message, Throwable cause, Integer code) {
        super(message, cause);
        this.code = code;
    }

    public LikeCheckException(Throwable cause, Integer code) {
        super(cause);
        this.code = code;
    }

    public LikeCheckException(String message, Throwable cause, boolean enableSuppression, boolean writableStackTrace, Integer code) {
        super(message, cause, enableSuppression, writableStackTrace);
        this.code = code;
    }

    public Integer getCode() {
        return code;
    }
}
