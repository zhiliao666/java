package com.ufoto.api.utils;

import com.ufoto.behavior.constants.EAppPackage;
import com.ufoto.api.constants.EPlatform;
import lombok.extern.slf4j.Slf4j;
import org.apache.commons.lang3.StringUtils;

import javax.servlet.http.HttpServletRequest;

/**
 * <p>
 * Author     : Chan
 * CreateDate : 2019-03-08 15:57
 * Description: <link>https://www.tapd.cn/20692501/documents/show/1120692501001001012</link>
 * c=1-1-10.14-3-24.12
 * 代表用户使用的网络是WIFI,操作系统是Android，对应的版本是
 * Android10.14，使用的app是sweetchat，对应使用的版本是24.12
 * </p>
 */
@Slf4j
public class HeaderUtil {

    /**
     * retrieve uid from request
     *
     * @param request request
     * @return uid
     */
    public static Long getUid(HttpServletRequest request) {
        final String uid = request.getHeader("uid");
        if (StringUtils.isBlank(uid)) return null;
        return Long.valueOf(uid);
    }

    /**
     * retrieve package from request
     *
     * @param request request
     * @return packageName
     */
    public static String getPackage(HttpServletRequest request) {
        String pn = EAppPackage.sweetchat.getPackageName();
        try {
            final String c = request.getHeader("c");
            final String[] strings = c.split("-");
            for (EAppPackage value : EAppPackage.values()) {
                if (value.getType().contains(strings[3])) {
                    pn = value.getPackageName();
                    break;
                }
            }
        } catch (Exception e) {
            log.warn(e.getMessage(), e);
        }
        return pn;
    }

    //获取平台信息
    public static int getPlatform(HttpServletRequest request) {
        try {
            final String c = request.getHeader("c");
            final String[] split = c.split("-");
            return Integer.parseInt(split[1]);
        } catch (Exception e) {
            log.error(e.getMessage(), e);
        }
        return EPlatform.android;
    }

}
