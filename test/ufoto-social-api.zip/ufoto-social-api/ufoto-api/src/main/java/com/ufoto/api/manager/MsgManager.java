package com.ufoto.api.manager;

import com.google.common.collect.Lists;
import com.ufoto.behavior.disruptor.consumer.SuperLikeConsumeCoinConsumer;
import com.ufoto.behavior.disruptor.event.CoinMsgEvent;
import com.ufoto.lmax2.disruptor.LMaxDisruptor;
import com.ufoto.lmax2.event.EventMap;
import com.ufoto.lmax2.event.UnityEvent;
import lombok.RequiredArgsConstructor;
import lombok.extern.slf4j.Slf4j;
import org.springframework.stereotype.Component;

/**
 * <p>
 * Description:
 *
 * </p>
 *
 * @author Chan
 * @date 2020/2/27 13:08
 */
@Slf4j
@RequiredArgsConstructor
@Component
public class MsgManager {

    private final LMaxDisruptor<UnityEvent> unityEventLMaxDisruptor;
    private final SuperLikeConsumeCoinConsumer superLikeConsumeCoinConsumer;

    public void sendConsumeCoin(CoinMsgEvent coinMsg) {
        unityEventLMaxDisruptor.send(UnityEvent.builder()
                .eventMaps(Lists.newArrayList(
                        EventMap.builder()
                                .event(coinMsg)
                                .consumer(superLikeConsumeCoinConsumer)
                                .build()
                ))
                .build());
    }

}
