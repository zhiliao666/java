package com.ufoto.api.controller;

import com.ufoto.account.api.AccountCoinQuotaManage;
import com.ufoto.account.api.AccountLikeAndSuperLikeQuotaManage;
import com.ufoto.account.dto.coin.SuperLikeCostDto;
import com.ufoto.api.constants.EChoice;
import com.ufoto.api.constants.ELikeSource;
import com.ufoto.api.exception.LikeCheckException;
import com.ufoto.api.manager.LikeCheckManager;
import com.ufoto.api.manager.MsgManager;
import com.ufoto.behavior.bean.LikeResultDto;
import com.ufoto.behavior.bean.SnsLikeRequest;
import com.ufoto.behavior.bean.SnsLikeResult;
import com.ufoto.behavior.constants.ELikeType;
import com.ufoto.behavior.disruptor.event.CoinMsgEvent;
import com.ufoto.behavior.manager.slide.SlideContext;
import com.ufoto.common.utils.ApiResult;
import com.ufoto.common.utils.DateUtil;
import lombok.RequiredArgsConstructor;
import lombok.extern.slf4j.Slf4j;
import org.springframework.core.env.Environment;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.RestController;

import java.util.Objects;

/**
 * <p>
 * Description:
 *
 * </p>
 *
 * @author Chan
 * @date 2020/2/10 10:32
 */
@Slf4j
@RequiredArgsConstructor
@RestController
@RequestMapping("/{v}/sns")
public class SnsActController {

    private final SlideContext slideContext;
    private final AccountLikeAndSuperLikeQuotaManage accountLikeAndSuperLikeQuotaManage;
    private final AccountCoinQuotaManage accountCoinQuotaManage;
    private final Environment env;
    private final LikeCheckManager likeCheckManager;
    private final MsgManager msgManager;

    @RequestMapping(path = "/{uid}/like/{targetUid}", method = RequestMethod.POST)
    public ApiResult<LikeResultDto> like(@PathVariable Long uid, @PathVariable String targetUid,
                                         @RequestParam(name = "source", required = false, defaultValue = "1") int source,
                                         @RequestParam(required = false,
                                                 defaultValue = "sweetchat.localdatingtinder.meet") String cp,
                                         @RequestParam(required = false, defaultValue = "1") Integer userType) {
        // 组装参数
        SnsLikeRequest likeRequest = new SnsLikeRequest();
        likeRequest.setUid(uid);
        likeRequest.setFUid(targetUid);
        likeRequest.setType(ELikeType.LIKE);
        likeRequest.setSource(source);
        likeRequest.setCp(cp);
        likeRequest.setUserType(userType);
        try {
            likeRequest.setTargetUid(Long.parseLong(targetUid));
            likeCheckManager.checkLike(likeRequest);
            // 用户行为服务-- 如果以上校验通过 则表明两人是陌生人 执行滑动like操作
            slideContext.slideOperation(likeRequest);
        } catch (LikeCheckException e) {
            // 有任何校验异常 直接返回客户端 -- 下同
            return new ApiResult<LikeResultDto>().setError(e.getCode(), e.getMessage());
        } catch (NumberFormatException e) {
            // 出现此类异常，一般目标用户是卡片 此类功能已停用 -- 下同
            log.error("likeRequest:{},error:{}", likeRequest, e.getMessage());
        }
        // 以上操作正确完 账号服务
        // 消耗 like 额度consumeLikeQuota
        final ApiResult<Integer> apiResult = accountLikeAndSuperLikeQuotaManage.consumeLikeQuota(uid,
                Objects.equals(source, ELikeSource.slide.getSource()));
        if (!Objects.equals(apiResult.getC(), ApiResult.successCode)) {
            // 如果消费失败 记录日志
            // TODO 对于remain的值如何处理
            log.error("ConsumerLikeQuotaError: {}", uid);
        }
        return new ApiResult<LikeResultDto>().setResult(
                SnsLikeResult.builder()
                        .isMatched(false)
                        .limit(env.getProperty("like.free.limit", Integer.class, 100))
                        .buyRemain(0)
                        .remain(apiResult.getD())
                        .ttl(DateUtil.getTTL())
                        .build()
        );
    }

    @RequestMapping(path = "/{uid}/superlike/{targetUid}", method = RequestMethod.POST)
    public ApiResult<LikeResultDto> superLike(@PathVariable Long uid,
                                              @PathVariable String targetUid,
                                              @RequestParam(required = false, defaultValue = "0") Integer useCoin,
                                              @RequestParam(required = false, defaultValue = "en") String lang,
                                              @RequestParam(required = false,
                                                      defaultValue = "sweetchat.localdatingtinder.meet") String cp) {

        SnsLikeRequest likeRequest = new SnsLikeRequest();
        likeRequest.setUid(uid);
        likeRequest.setFUid(targetUid);
        likeRequest.setType(ELikeType.SUPER_LIKE);
        likeRequest.setLang(lang);
        likeRequest.setUseCoin(useCoin);
        likeRequest.setCp(cp);

        try {
            likeRequest.setTargetUid(Long.parseLong(targetUid));
            likeCheckManager.checkSuperLike(likeRequest);
            slideContext.slideOperation(likeRequest);
        } catch (LikeCheckException e) {
            return new ApiResult<LikeResultDto>().setError(e.getCode(), e.getMessage());
        } catch (NumberFormatException e) {
            log.error("likeRequest:{},error:{}", likeRequest, e.getMessage());
        }
        SuperLikeCostDto superLikeRemain = SuperLikeCostDto.builder().build();
        if (Objects.equals(useCoin, EChoice.Yes.getChoice())) {
            final ApiResult<SuperLikeCostDto> consumeResult = accountCoinQuotaManage.consumeCoinForSuperLike(uid, lang, cp);
            if (Objects.equals(consumeResult.getC(), ApiResult.successCode)) {
                superLikeRemain = consumeResult.getD();
                msgManager.sendConsumeCoin(
                        CoinMsgEvent.builder()
                                .uid(superLikeRemain.getUid())
                                .coin(superLikeRemain.getPrice())
                                .amount(superLikeRemain.getAccount())
                                .build()
                );
            } else {
                log.warn("consumeCoinForSuperLikeError: {}", consumeResult);
            }
        } else {
            final ApiResult<SuperLikeCostDto> superLikeRemainResult = accountLikeAndSuperLikeQuotaManage.consumeSuperLikeQuota(uid);
            if (Objects.equals(superLikeRemainResult.getC(), ApiResult.successCode)) {
                superLikeRemain = superLikeRemainResult.getD();
            } else {
                log.warn("consumeSuperLikeQuotaError: {}", superLikeRemainResult);
            }
        }
        return new ApiResult<LikeResultDto>().setResult(SnsLikeResult.builder().isMatched(false)
                .limit(env.getProperty("superlike.free.limit", Integer.class, 1))
                .buyRemain(superLikeRemain.getPaidSuperLikeRemain())
                .remain(superLikeRemain.getFreeSuperLikeRemain())
                .ttl(DateUtil.getTTL()).build());
    }

    @RequestMapping(path = "/{uid}/dislike/{targetUid}", method = RequestMethod.POST)
    public ApiResult<LikeResultDto> dislike(@PathVariable Long uid, @PathVariable String targetUid,
                                            @RequestParam(required = false,
                                                    defaultValue = "sweetchat.localdatingtinder.meet") String cp) {

        SnsLikeRequest likeRequest = new SnsLikeRequest();
        likeRequest.setUid(uid);
        likeRequest.setFUid(targetUid);
        likeRequest.setType(ELikeType.DISLIKE);
        likeRequest.setCp(cp);
        try {
            likeRequest.setTargetUid(Long.parseLong(targetUid));
            // 目前来看 dislike不需要校验
            likeCheckManager.checkDislike(likeRequest);
            slideContext.slideOperation(likeRequest);
        } catch (LikeCheckException e) {
            return new ApiResult<LikeResultDto>().setError(e.getCode(), e.getMessage());
        } catch (NumberFormatException e) {
            log.error("likeRequest:{},error:{}", likeRequest, e.getMessage());
        }
        // 按之前逻辑 返回like相关数据
        return new ApiResult<LikeResultDto>().setResult(SnsLikeResult.builder().isMatched(false)
                .limit(env.getProperty("like.free.limit", Integer.class, 100)).buyRemain(0)
                .remain(accountLikeAndSuperLikeQuotaManage.getFreeLikeRemain(uid).getD())
                .ttl(DateUtil.getTTL()).build());
    }
}
