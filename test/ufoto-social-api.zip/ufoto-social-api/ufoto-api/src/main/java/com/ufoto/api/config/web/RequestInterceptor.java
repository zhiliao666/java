package com.ufoto.api.config.web;

import com.ufoto.api.utils.HeaderUtil;
import com.ufoto.behavior.manager.UserRequestInterceptorManager;
import lombok.extern.slf4j.Slf4j;
import org.apache.commons.lang3.StringUtils;
import org.slf4j.MDC;
import org.springframework.stereotype.Component;
import org.springframework.web.servlet.handler.HandlerInterceptorAdapter;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import java.util.UUID;


@Slf4j
@Component
public class RequestInterceptor extends HandlerInterceptorAdapter {

    private final UserRequestInterceptorManager userRequestInterceptorManager;

    public RequestInterceptor(UserRequestInterceptorManager userRequestInterceptorManager) {
        this.userRequestInterceptorManager = userRequestInterceptorManager;
    }

    @Override
    public boolean preHandle(HttpServletRequest request,
                             HttpServletResponse response, Object handler) throws Exception {
        String requestId = request.getHeader("request-id");
        if (StringUtils.isBlank(requestId)) {
            requestId = UUID.randomUUID().toString();
        }
        MDC.put("traceId", requestId);
        handleUserAct(request);
        return true;
    }

    @Override
    public void afterCompletion(HttpServletRequest request, HttpServletResponse response, Object handler, Exception ex) throws Exception {
        MDC.remove("traceId");
    }

    private void handleUserAct(HttpServletRequest request) {
        try {
            Long uid = HeaderUtil.getUid(request);
            final String uidParam = request.getParameter("uid");
            if (uid == null && StringUtils.isNotBlank(uidParam)) {
                uid = Long.parseLong(uidParam);
            }
            if (uid == null) {
                return;
            }
            final String latitude = request.getParameter("latitude");
            final String longitude = request.getParameter("longitude");
            userRequestInterceptorManager.requestManager(uid, latitude, longitude);
        } catch (Exception e) {
            log.error(e.getMessage(), e);
        }
    }

}
