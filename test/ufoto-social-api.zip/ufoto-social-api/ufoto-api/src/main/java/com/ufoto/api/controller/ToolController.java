package com.ufoto.api.controller;

import com.ufoto.behavior.manager.UserManager;
import com.ufoto.feign.usercenter.dto.UserBaseInfoDto;
import lombok.RequiredArgsConstructor;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import java.util.List;

/**
 * File Created: Friday, 2020/02/21 14:33:29
 * Last Modified: Friday, 2020/02/21 14:49:21
 * <p>
 * description:
 * <p>
 * Author: Chan Modified By: Chan Copyright 2020 - 2020 ufoto
 */
@RequiredArgsConstructor
@RequestMapping("/tool")
@RestController
public class ToolController {

    private final UserManager userManager;

    @RequestMapping("/robots")
    public Object robots() {
        List<UserBaseInfoDto> list = userManager.robots();
        return list.subList(0, 3);
    }

}
