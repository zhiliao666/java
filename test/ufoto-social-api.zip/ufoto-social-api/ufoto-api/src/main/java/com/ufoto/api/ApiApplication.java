package com.ufoto.api;

import com.ufoto.cache.EnableUfotoCache;
import com.ufoto.logging.proxy.UfotoLogFactory;
import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;
import org.springframework.boot.autoconfigure.jdbc.DataSourceAutoConfiguration;
import org.springframework.cloud.client.discovery.EnableDiscoveryClient;
import org.springframework.cloud.openfeign.EnableFeignClients;
import org.springframework.context.annotation.ComponentScan;

/**
 * @author luozq
 * @date 2020/1/14
 */
@EnableUfotoCache
@EnableDiscoveryClient
@EnableFeignClients(basePackages = {"com.ufoto"})
@SpringBootApplication(exclude = DataSourceAutoConfiguration.class)
@ComponentScan(basePackages = {"com.ufoto"})
public class ApiApplication {

    public static void main(String[] args) {
        UfotoLogFactory.enableDefaultLogFormat();
        SpringApplication.run(ApiApplication.class, args);
    }

}
