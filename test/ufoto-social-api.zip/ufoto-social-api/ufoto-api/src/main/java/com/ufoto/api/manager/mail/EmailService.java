package com.ufoto.api.manager.mail;


public interface EmailService {
    /**
     * 发送邮件
     *
     * @param subject 邮件主题
     * @param text    邮件内容
     * @param from    发送者
     * @param to      接收者
     * @return
     */
    void sendEmailText(String subject, String text, String from, String to, Boolean isHtml);

    /**
     * 异步发送邮件
     *
     * @param subject 邮件主题
     * @param text    邮件内容
     * @param from    发送者
     * @param to      接收者
     */
    void asyncSendEmailText(String subject, String text, String from, String to);
}
