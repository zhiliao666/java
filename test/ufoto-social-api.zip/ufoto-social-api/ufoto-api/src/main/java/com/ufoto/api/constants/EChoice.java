package com.ufoto.api.constants;

/**
 * <p>
 * Description:
 *
 * </p>
 *
 * @author Chan
 * @date 2020/2/20 14:12
 */
public enum EChoice {
    No(0),
    Yes(1);
    private int choice;

    EChoice(int choice) {
        this.choice = choice;
    }

    public int getChoice() {
        return choice;
    }
}
