package com.ufoto.api.manager.mail;

/**
 * @auther: zhangjq
 * @date: 2018/11/20 21:20
 * @description:
 */
public class MailThreadLocal {
    private static final ThreadLocal<Integer> currentMailId = new ThreadLocal<>();

    public static Integer getCurrentMailId() {
        return currentMailId.get() != null ? currentMailId.get() : 0;

    }

    public static void setCurrentMailId(Integer currentMail) {
        if (currentMail != null) {
            currentMailId.set(currentMail);
        } else {
            currentMailId.set(0);
        }
    }

}
