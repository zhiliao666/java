package com.ufoto.api.config.web;

import com.ufoto.web.CustomRequestMappingHandlerMapping;
import lombok.RequiredArgsConstructor;
import org.springframework.context.annotation.Configuration;
import org.springframework.web.servlet.config.annotation.InterceptorRegistry;
import org.springframework.web.servlet.config.annotation.WebMvcConfigurationSupport;
import org.springframework.web.servlet.mvc.method.annotation.RequestMappingHandlerMapping;


/**
 * MVC配置
 *
 * @author zhangqh
 * @date 2017年8月23日
 */
@RequiredArgsConstructor
@Configuration
public class WebMvcConfig extends WebMvcConfigurationSupport {
    private final RequestInterceptor requestInterceptor;

    @Override
    protected RequestMappingHandlerMapping createRequestMappingHandlerMapping() {
        return new CustomRequestMappingHandlerMapping();
    }

    @Override
    public void addInterceptors(InterceptorRegistry registry) {
        registry.addInterceptor(requestInterceptor).addPathPatterns("/**");
    }
}
