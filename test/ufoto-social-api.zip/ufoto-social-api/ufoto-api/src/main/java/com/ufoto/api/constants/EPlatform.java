package com.ufoto.api.constants;

/**
 * <p>
 * Author     : Chan
 * CreateDate : 2019-08-27 15:40
 * Description:
 * </p>
 */
public interface EPlatform {
    int android = 1;
    int ios = 2;
    int other = 0;
}
