package com.ufoto.api.config.web.error;

import com.github.benmanes.caffeine.cache.Caffeine;
import com.github.benmanes.caffeine.cache.LoadingCache;
import com.ufoto.api.manager.mail.EmailService;
import com.ufoto.common.utils.ApiResult;
import com.ufoto.common.utils.DateUtil;
import com.ufoto.common.utils.JsonUtil;
import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.RequiredArgsConstructor;
import lombok.extern.slf4j.Slf4j;
import org.apache.commons.io.IOUtils;
import org.apache.commons.lang3.exception.ExceptionUtils;
import org.springframework.core.env.Environment;
import org.springframework.dao.DuplicateKeyException;
import org.springframework.util.CollectionUtils;
import org.springframework.web.bind.annotation.ExceptionHandler;
import org.springframework.web.bind.annotation.RestControllerAdvice;
import org.springframework.web.method.HandlerMethod;

import javax.servlet.ServletInputStream;
import javax.servlet.http.HttpServletRequest;
import java.io.IOException;
import java.nio.charset.StandardCharsets;
import java.util.Map;

/**
 * <p>
 * Description:
 * 处理全局controller异常
 * </p>
 *
 * @author Chan
 * @date 2020/3/2 16:56
 */
@Slf4j
@RequiredArgsConstructor
@RestControllerAdvice
public class GlobalExceptionControllerAdvice {

    private final EmailService emailService;
    private final Environment env;
    private static final int interval = 600;//seconds
    private final static LoadingCache<String, Stat> errorCountMap = Caffeine.newBuilder().build(key -> null);

    @AllArgsConstructor
    @Data
    public static class Stat {
        private int count;
        private Long time;
    }

    @ExceptionHandler({Exception.class})
    public ApiResult<Object> handleException(HttpServletRequest request, Exception e, HandlerMethod handlerMethod) {
        try {
            processEmail(request, e, handlerMethod);
        } catch (Exception ex) {
            log.warn(ex.getMessage(), ex);
        }
        return new ApiResult<>().setError(ApiResult.errorCode500, e.getMessage());
    }

    private void processEmail(HttpServletRequest request,
                              Exception e, HandlerMethod handlerMethod) {
        final String url = request.getRequestURL().toString();
        final String methodName = methodName(handlerMethod);
        final Integer count = shouldSendEmailWithCount(methodName, e);
        if (count == -1) {
            return;
        }
        String profile = env.getProperty("spring.profiles.active");
        String[] emailToArr;
        String toEmail = env.getProperty("monitor.email.to");
        if (toEmail != null && toEmail.contains(",")) {
            emailToArr = toEmail.split(",");
        } else {
            emailToArr = new String[1];
            emailToArr[0] = toEmail;
        }

        StringBuilder content = new StringBuilder();
        content
                .append("请求url: ").append(url).append(System.lineSeparator())
                .append("Http状态码: ").append(ApiResult.errorCode500).append(System.lineSeparator())
                .append("异常方法: ").append(methodName).append(System.lineSeparator())
                .append("错误次数: ").append(count).append(System.lineSeparator())
                .append("请求参数 ").append(parseParameters(request)).append(System.lineSeparator())
                .append("请求body: ").append(parseBody(request)).append(System.lineSeparator())
                .append("错误详情: ").append(ExceptionUtils.getStackTrace(e)).append(System.lineSeparator());

        String title = String.format("环境[%s]异常 请求方法[%s]", profile, methodName);

        for (String s : emailToArr) {
            emailService.asyncSendEmailText(title, content.toString(), null, s);
        }
    }

    private Integer shouldSendEmailWithCount(String methodName, Exception e) {
        if (e instanceof DuplicateKeyException) {
            return -1;
        }
        final Stat stat = errorCountMap.get(methodName);
        if (stat == null) {
            errorCountMap.put(methodName, new Stat(1, DateUtil.getCurrentSecond()));
            return 1;
        } else {
            Long now = DateUtil.getCurrentSecond();
            Long time = stat.getTime();
            final int count = stat.getCount();
            if (now - time > interval) {
                errorCountMap.invalidate(methodName);
                return count + 1;
            } else {
                stat.setCount(count + 1);
                return -1;
            }
        }
    }

    private String parseBody(HttpServletRequest request) {
        try {
            final ServletInputStream inputStream = request.getInputStream();
            return IOUtils.toString(inputStream, StandardCharsets.UTF_8);
        } catch (IOException e) {
            log.error(e.getMessage(), e);
            return "";
        }
    }

    private String parseParameters(HttpServletRequest request) {
        final Map<String, String[]> parameterMap = request.getParameterMap();
        if (!CollectionUtils.isEmpty(parameterMap)) {
            return JsonUtil.toJson(parameterMap);
        }
        return "";
    }

    private String methodName(HandlerMethod method) {
        return method.getBeanType().getName() + "#" + method.getMethod().getName();
    }
}
