package com.ufoto.api.manager.mail;

import lombok.RequiredArgsConstructor;
import lombok.extern.slf4j.Slf4j;
import org.apache.commons.lang3.StringUtils;
import org.springframework.core.env.Environment;
import org.springframework.mail.javamail.MimeMessageHelper;
import org.springframework.scheduling.annotation.Async;
import org.springframework.stereotype.Service;

import javax.mail.internet.MimeMessage;


@RequiredArgsConstructor
@Service("emailService")
@Slf4j
public class EmailServiceImpl implements EmailService {
    private final Environment environment;
    private final EduJavaMailSenderImpl mailSender;

    @Override
    public void sendEmailText(String subject, String text, String from, String to, Boolean isHtml) {
        MimeMessage mimeMessage = mailSender.createMimeMessage();
        MimeMessageHelper message;
        try {
            message = new MimeMessageHelper(mimeMessage, true, "UTF-8");
            String replyTo = environment.getProperty("ufoto.mail.replyTo", String.class, "sweetchat@ufotosoft.com");
            message.setFrom(from);
            message.setTo(to);
            message.setSubject(subject);
            if (isHtml) {
                message.setText(text, true);
            } else {
                message.setText(text);
            }
            message.setReplyTo(replyTo);
            mailSender.send(mimeMessage);
            log.info("邮件发送成功");
        } catch (Exception e) {
            if (e.getMessage().contains("559 Invalid rcptto")) {
                log.warn("WARN_INVALID_ADDR: {}", to);
            } else {
                log.error("邮件发送失败:" + e.getMessage(), e);
            }
        }
    }

    @Async
    @Override
    public void asyncSendEmailText(String subject, String text, String from,
                                   String to) {
        if (StringUtils.isBlank(from)) {
            MailThreadLocal.setCurrentMailId(0);
            from = mailSender.getUsername();
        }
        sendEmailText(subject, text, from, to, false);
    }
}
