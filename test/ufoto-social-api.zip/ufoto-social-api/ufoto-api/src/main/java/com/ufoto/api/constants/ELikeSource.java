package com.ufoto.api.constants;

/**
 * <p>
 * Description:
 *
 * </p>
 *
 * @author Chan
 * @date 2020/2/11 13:25
 */
public enum ELikeSource {
    slide(1),
    wholikeme(2);

    private int source;

    ELikeSource(int source) {
        this.source = source;
    }

    public int getSource() {
        return source;
    }
}
