<!-- toc -->

- [1. 架构--ufoto-api](#1-架构--ufoto-api)
- [2. 对外提供接口](#2-对外提供接口)
  * [2.1 like](#21-like)
  * [2.2 superlike](#22-superlike)
  * [2.3 dislike](#23-dislike)

<!-- tocstop -->

# 1. 架构--ufoto-api
请求入口，主要负责各种逻辑与数据组装

# 2. 对外提供接口

## 2.1 like
    com.ufoto.api.controller.SnsActController#like
    逻辑如下:
    1. 校验是否是自己
    2. 校验like余额--ufoto-account
    3. 校验有性别和firstImg，并且firstImg合法--ufoto-account
    4. 校验是否是好友--ufoto-friendchat
    5. 调用ufoto-behavior服务处理具体逻辑
    6. 调用ufoto-account尝试消耗like余额
    7. 组装响应体，其中余额数据从ufoto-account获取

## 2.2 superlike
    com.ufoto.api.controller.SnsActController#superLike
    1. 校验是否是自己
    2. 校验like余额--ufoto-account
    3. 校验有性别和firstImg，并且firstImg合法--ufoto-account
    4. 校验是否是好友--ufoto-friendchat
    5. 若使用金币，尝试校验金币余额；反之校验superlike余额--ufoto-account
    6. 调用ufoto-behavior服务处理具体逻辑
    7. 若使用金币，尝试消耗金币，并发送调用ufoto-behavior发送金币消耗的通知；反之消耗superlike余额
    8. 组装响应体，其中余额数据从ufoto-account获取

## 2.3 dislike
    com.ufoto.api.controller.SnsActController#dislike
    1. 调用ufoto-behavior服务处理具体逻辑
    2. 组装响应体，其中包括like的相关余额数据
