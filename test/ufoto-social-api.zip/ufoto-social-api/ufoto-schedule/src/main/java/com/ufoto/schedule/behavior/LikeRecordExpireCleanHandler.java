package com.ufoto.schedule.behavior;

import com.ufoto.behavior.manager.EsManager;
import com.ufoto.behavior.service.UfotoUserLikeService;
import com.xxl.job.core.biz.model.ReturnT;
import com.xxl.job.core.handler.IJobHandler;
import com.xxl.job.core.handler.annotation.JobHandler;
import lombok.RequiredArgsConstructor;
import lombok.extern.slf4j.Slf4j;
import org.springframework.core.env.Environment;
import org.springframework.stereotype.Component;

/**
 * <p>
 * Description:
 *
 * </p>
 *
 * @author Chan
 * @date 2020/2/19 15:34
 */
@RequiredArgsConstructor
@Slf4j
@JobHandler("likeRecordExpireCleanHandler")
@Component
public class LikeRecordExpireCleanHandler extends IJobHandler {

    private final UfotoUserLikeService ufotoUserLikeService;
    private final Environment env;
    private final EsManager esManager;

    @Override
    public ReturnT<String> execute(String param) throws Exception {
        // 单位 天
        final Integer fixedTime = env.getProperty("like.remain.fixed.time.records", Integer.class, 30);
        // 单位 秒
        final int fixedTimeSecond = fixedTime * 86400;
        //execute db
        ufotoUserLikeService.remainFixedTimeRecords(fixedTimeSecond);
        // execute es
        esManager.delete(fixedTimeSecond);
        return new ReturnT<>(200, "success");
    }
}
