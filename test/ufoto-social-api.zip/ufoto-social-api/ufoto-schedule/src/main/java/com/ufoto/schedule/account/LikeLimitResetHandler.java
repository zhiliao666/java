package com.ufoto.schedule.account;

import com.ufoto.account.api.AccountLikeAndSuperLikeQuotaManage;
import com.xxl.job.core.biz.model.ReturnT;
import com.xxl.job.core.handler.IJobHandler;
import com.xxl.job.core.handler.annotation.JobHandler;
import lombok.extern.slf4j.Slf4j;
import org.springframework.stereotype.Component;

/**
 * @author luozq
 * @date 2020/2/10 10:17
 */
@Slf4j
@JobHandler("likeLimitResetHandler")
@Component
public class LikeLimitResetHandler extends IJobHandler {

    private final AccountLikeAndSuperLikeQuotaManage accountLikeAndSuperLikeQuotaManage;

    public LikeLimitResetHandler(AccountLikeAndSuperLikeQuotaManage accountLikeAndSuperLikeQuotaManage) {
        this.accountLikeAndSuperLikeQuotaManage = accountLikeAndSuperLikeQuotaManage;
    }

    @Override
    public ReturnT<String> execute(String s) throws Exception {
        accountLikeAndSuperLikeQuotaManage.resetLikeAndSuperLikeQuota();
        return new ReturnT<>(200, "success");
    }
}
