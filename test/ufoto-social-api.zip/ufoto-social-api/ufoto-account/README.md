<!-- TOC -->

- [账号中心模块稳定](#账号中心模块稳定)
  - [功能描述](#功能描述)
  - [对外接口](#对外接口)
    - [like, superLike 额度校验](#like-superlike-额度校验)
    - [消费 like 额度](#消费-like-额度)
    - [消费 superLike 额度](#消费-superlike-额度)
    - [获取免费的 like 剩余次数](#获取免费的-like-剩余次数)
    - [获取 superLike 的免费次数和付费次数](#获取-superlike-的免费次数和付费次数)
    - [金币额度校验](#金币额度校验)
    - [金币消费](#金币消费)
  - [mq消息消费](#mq消息消费)
    - [swipe 行为消费](#swipe-行为消费)
      - [like, superLike 产生的魅力值消费](#like-superlike-产生的魅力值消费)
      - [like, superLike 每日任务消费](#like-superlike-每日任务消费)

<!-- /TOC -->
# 账号中心模块稳定

## 功能描述

1. like, superLike 额度管理
2. 金币 coin 管理
3. 魅力值 管理
4. vip 管理

## 对外接口

### like, superLike 额度校验

> 接口: com.ufoto.account.api.AccountLikeAndSuperLikeQuotaManage.checkLikeAndSuperLikeQuota
> 业务描述: 根据 参数uid 和 ifLike(判断是 like 还是 superLike) 判断 like 或者 superLike 额度是否足够, 如果是 like 校验, 如果是 vip 直接放行; 如果是机器人也直接放行;

返回值描述:

```json
{
    "c": 200,
    "m": "success",
    "d": true
}

```

> d: true: 额度足够, false: 额度不够

### 消费 like 额度

> 接口: com.ufoto.account.api.AccountLikeAndSuperLikeQuotaManage#consumeLikeQuota
> 业务描述: 根据 uid, 判断额度是否足够, 如果不够, 返回 code 1001;
> 如果额度足够, 扣减每日免费 like 额度;

返回值描述:

```json
{
    "c": 200,
    "m": "success",
    "d": true
}

```

> 1. c: 200 消费成功, 1001: 额度不够, 500: 异常
> 2. d: true: 消费成功, false: 消费失败

### 消费 superLike 额度

> 接口: com.ufoto.account.api.AccountLikeAndSuperLikeQuotaManage#consumeSuperLikeQuota
> 业务描述: 根据 uid, 判断superLike额度是否足够, 如果不够, 返回 code 1001;
> 如果额度足够, 扣减每日免费 superLike 额度, 不够则扣减付费superLike额度

返回值描述:

```json
{
    "c": 200,
    "m": "success",
    "d": true
}

```

> 1. c: 200 消费成功, 1001: 额度不够, 500: 异常
> 2. d: true: 消费成功, false: 消费失败

### 获取免费的 like 剩余次数

> 接口: com.ufoto.account.api.AccountLikeAndSuperLikeQuotaManage#getFreeLikeRemain
> 业务描述: 根据 uid 获取免费 like 额度

返回值描述:

```json
{
    "c": 200,
    "m": "success",
    "d": 100
}

```

> 1. c: 200: 获取成功, 其他都是获取失败
> 2. d: Integer, 免费 like 额度

### 获取 superLike 的免费次数和付费次数

> 接口: com.ufoto.account.api.AccountLikeAndSuperLikeQuotaManage#getSuperLikeRemain
> 业务描述: 根据 uid 获取免费 superLike 额度 和付费的 superLike 额度

返回值描述:

```json
{
    "c": 200,
    "m": "success",
    "d": {
        "uid": 100,
        "freeSuperLikeRemain": 1,
        "paidSuperLikeRemain": 1
    }
}
```

字段解释:

字段 | 类型 | 备注
---------|----------|---------
 uid | Long | uid
 freeSuperLikeRemain | Integer | superLike 免费额度
 paidSuperLikeRemain | Integer | superLike 付费额度

### 金币额度校验

> 接口: com.ufoto.account.api.AccountCoinQuotaManage#checkCoinQuota
> 业务描述: 根据 uid 和 price 校验金币额度是否足够;

返回值描述:

```json
{
    "c": 200,
    "m": "success",
    "d": true
}

```

> 1. c: 200: 获取成功, 其他都是获取失败
> 2. d: true: 额度足够, false: 额度不够

### 金币消费

> 接口: com.ufoto.account.api.AccountCoinQuotaManage#consumeCoinQuota
> 业务描述: 根据 uid 和 商品信息 进行金币消费;

返回值描述:

```json
{
    "c": 200,
    "m": "success",
    "d": true
}
```

> 1. c: 200: 获取成功, 其他都是获取失败
> 2. true: 消费成功, false: 消费失败

## mq消息消费

### swipe 行为消费

> 1. 交换器: soical.sns.slide;
> 2. 对应 rabbitmq 模式: 广播模式

消息数据格式:

```json
{
    "uid": 1,
    "targetUid": 2,
    "action": "like",
    "ifMatch": false,
    "ifChatBot": false
}
```

字段解释:

字段 | 类型 | 备注
---------|----------|---------
 uid | Long | uid
 targetUid | Long | 对方 uid
 action | Long | like, dislike, superLike, 不区分大小写
 ifMatch | Long | true: 产生 match, false: 未产生 match
 ifChatBot | Long | true: targetUid 是机器人, false: targetUid 不是机器人

#### like, superLike 产生的魅力值消费

> 待定

#### like, superLike 每日任务消费

> 待定
