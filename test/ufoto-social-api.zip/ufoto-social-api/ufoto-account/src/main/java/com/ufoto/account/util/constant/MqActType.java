package com.ufoto.account.util.constant;

import com.ufoto.account.util.factory.ActFactory;
import com.ufoto.account.util.factory.DisLikeActFactoryImpl;
import com.ufoto.account.util.factory.LikeAndSuperLikeActContentImpl;
import com.ufoto.rabbit.behavior.constants.ActionType;

/**
 * @author luozq
 * @date 2020/2/17 16:54
 */
public enum MqActType {

    /**
     * like
     */
    LIKE(ActionType.ACTION_LIKE.getType(), LikeAndSuperLikeActContentImpl.class),

    /**
     * disLike
     */
    DISLIKE(ActionType.ACTION_DISLIKE.getType(), DisLikeActFactoryImpl.class),

    /**
     * superLike
     */
    SUPER_LIKE(ActionType.ACTION_SUPER_LIKE.getType(), LikeAndSuperLikeActContentImpl.class);

    private String actionType;

    private Class<? extends ActFactory> factoryClass;

    MqActType(String actionType, Class<? extends ActFactory> factoryClass) {
        this.actionType = actionType;
        this.factoryClass = factoryClass;
    }

    public String getActionType() {
        return actionType;
    }

    public void setActionType(String actionType) {
        this.actionType = actionType;
    }

    public Class<? extends ActFactory> getFactoryClass() {
        return factoryClass;
    }

    public void setFactoryClass(Class<? extends ActFactory> factoryClass) {
        this.factoryClass = factoryClass;
    }
}
