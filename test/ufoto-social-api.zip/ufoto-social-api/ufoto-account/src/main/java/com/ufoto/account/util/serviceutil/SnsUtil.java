package com.ufoto.account.util.serviceutil;

import com.ufoto.common.utils.SpringContextUtil;
import com.ufoto.robot.RobotCommonCacheManager;

import java.util.Set;

/**
 * @author luozq
 * @date 2020/2/7 17:44
 */
public class SnsUtil {

    private SnsUtil() {

    }

    /**
     * 校验是否是机器人
     *
     * @param uid uid
     * @return true 机器人, false 不是机器人
     */
    public static boolean checkIfRobot(Long uid) {
        RobotCommonCacheManager bean = SpringContextUtil.getBean(RobotCommonCacheManager.class);
        Set<Long> robotList = bean.getRobotIds();
        return robotList.contains(uid);
    }
}
