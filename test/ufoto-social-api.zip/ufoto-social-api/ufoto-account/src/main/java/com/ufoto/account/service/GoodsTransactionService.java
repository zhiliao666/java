package com.ufoto.account.service;


import com.ufoto.account.dto.quota.GoodsTransactionDto;

/**
 * @author luozq
 * @date 2020/2/10 14:50
 */
public interface GoodsTransactionService {
    /**
     * save
     * @param dto dto
     */
    void saveTransaction(GoodsTransactionDto dto);
}
