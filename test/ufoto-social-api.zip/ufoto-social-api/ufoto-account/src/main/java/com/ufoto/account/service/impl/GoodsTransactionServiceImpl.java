package com.ufoto.account.service.impl;

import com.ufoto.account.mapper.write.GoodsTransactionMapper;
import com.ufoto.account.dto.quota.GoodsTransactionDto;
import com.ufoto.account.service.GoodsTransactionService;
import lombok.extern.slf4j.Slf4j;
import org.springframework.stereotype.Service;

/**
 * @author luozq
 * @date 2020/2/10 14:50
 */
@Slf4j
@Service
public class GoodsTransactionServiceImpl implements GoodsTransactionService {

    private final GoodsTransactionMapper goodsTransactionMapper;

    public GoodsTransactionServiceImpl(GoodsTransactionMapper goodsTransactionMapper) {
        this.goodsTransactionMapper = goodsTransactionMapper;
    }

    @Override
    public void saveTransaction(GoodsTransactionDto goodsTransactionDto) {
        goodsTransactionMapper.saveTransaction(goodsTransactionDto);
    }
}
