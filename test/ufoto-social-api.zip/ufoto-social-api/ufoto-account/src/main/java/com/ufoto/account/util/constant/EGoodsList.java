//package com.ufoto.account.util.constant;
//
//import com.ufoto.account.util.factory.GiftGoodsFactory;
//import com.ufoto.account.util.factory.GoodsFactory;
//
///**
// *
// * @author luozq
// * @date 2020/2/6
// */
//public enum EGoodsList {
//
//    /**
//     * 礼物
//     */
//    GIFT("gift", "礼物", GiftGoodsFactory.class);
//
//    private String goodsNo;
//    private String desc;
//    private Class<? extends GoodsFactory> factory;
//
//    EGoodsList(String goodsNo, String desc, Class<? extends GoodsFactory> factory) {
//        this.goodsNo = goodsNo;
//        this.desc = desc;
//        this.factory = factory;
//    }
//
//    public String getGoodsNo() {
//        return goodsNo;
//    }
//
//    public String getDesc() {
//        return desc;
//    }
//
//    public Class<? extends GoodsFactory> getFactory() {
//        return factory;
//    }
//}
