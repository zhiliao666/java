package com.ufoto.account.config.datasource;

import com.ufoto.base.mapper.plugins.CRUDInterceptor;
import org.apache.ibatis.plugin.Interceptor;
import org.apache.ibatis.session.SqlSessionFactory;
import org.mybatis.spring.SqlSessionFactoryBean;

import javax.sql.DataSource;

/**
 * <p>
 * Description:
 *
 * </p>
 *
 * @author Chan
 * @date 2020/2/7 16:23
 */
public abstract class DataSourceConfig {

    protected SqlSessionFactory getSqlSessionFactory(DataSource dataSource,
                                                     SqlSessionFactoryBean bean) throws Exception {
        org.apache.ibatis.session.Configuration configuration = new org.apache.ibatis.session.Configuration();
        configuration.setMapUnderscoreToCamelCase(true);
        bean.setConfiguration(configuration);
        bean.setDataSource(dataSource);
        bean.setPlugins(new Interceptor[]{new CRUDInterceptor()});
        return bean.getObject();
    }
}
