package com.ufoto.account.util.manage;

import com.ufoto.robot.RobotCommonCacheManager;
import lombok.RequiredArgsConstructor;
import lombok.extern.slf4j.Slf4j;
import org.springframework.stereotype.Component;

import java.util.Objects;

/**
 * @author luozq
 * @date 2020/2/26 17:28
 */
@Slf4j
@Component
@RequiredArgsConstructor
public class RobotManage {

    private final RobotCommonCacheManager robotManageService;

    /**
     * 判断是否是机器人
     *
     * @param uid uid
     * @return
     */
    public boolean ifRobot(Long uid) {
        return robotManageService.getRobotIds().stream()
                .anyMatch(item -> Objects.equals(item, uid));
    }

}
