package com.ufoto.account.dto.action;

import lombok.Builder;
import lombok.Data;

import java.io.Serializable;

/**
 * @author luozq
 * @date 2020/2/27 14:03
 */
@Data
@Builder
public class InitCharmDto implements Serializable {

    private Long uid;

    private Long count;

    private Double price;
}
