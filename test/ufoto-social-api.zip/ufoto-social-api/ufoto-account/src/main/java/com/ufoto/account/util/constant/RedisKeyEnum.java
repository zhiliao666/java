package com.ufoto.account.util.constant;

/**
 * @author luozq
 * @date 2020/2/7 15:02
 */
public enum RedisKeyEnum {

    /**
     * 用户使用免费LIKE次数
     */
    FREE_LIKE_USED_ZSET_KEY("user_free_like_used", "zSet", "用户使用免费LIKE次数"),

    /**
     * 用户订阅set
     */
    SUBSCRIPTION_USER_SET("subscription_user_set", "set", "用户订阅set"),

    /**
     * 用户使用免费 SUPER LIKE 次数
     */
    FREE_SUPERLIKE_USED_ZSET_KEY("user_free_super_like_used", "zSet", "用户使用免费 SUPER LIKE 次数"),

    /**
     * 用户剩余购买的superLike次数
     */
    USER_PAID_SUPER_LIKE_REMAIN_ZSET_KEY("user_paid_super_like_remain", "zSet", "用户剩余购买的superLike次数"),

    /**
     * 用户使用免费 CANCEL 次数
     */
    FREE_CANCEL_USED_ZSET_KEY("user_free_cancel_used", "zSet", "用户使用免费 CANCEL 次数"),

    /**
     * 用户当天参加临时匹配次数
     */
    RANDOM_MATCH_USED("user_random_match_used", "zSet", "用户当天参加临时匹配次数"),

    /**
     * 用户当天参加临时语音匹配
     */
    RANDOM_VOICE_CHAT_USED("user_random_voice_chat_used", "zSet", "用户当天参加临时语音匹配"),

    /**
     * 用户金币账户
     */
    REDIS_USER_COIN_AMOUNT("user_coin_amount", "zSet", "用户金币账户");


    private String key;

    private String keyType;

    private String remark;

    RedisKeyEnum(String key, String keyType, String remark) {
        this.key = key;
        this.keyType = keyType;
        this.remark = remark;
    }

    @Override
    public String toString() {
        return key;
    }
}
