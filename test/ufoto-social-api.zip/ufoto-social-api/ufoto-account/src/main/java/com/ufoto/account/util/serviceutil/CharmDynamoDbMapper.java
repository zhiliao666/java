package com.ufoto.account.util.serviceutil;

import com.amazonaws.services.dynamodbv2.datamodeling.DynamoDBMapper;
import com.amazonaws.services.dynamodbv2.document.DynamoDB;
import com.amazonaws.services.dynamodbv2.document.Item;
import com.amazonaws.services.dynamodbv2.document.KeyAttribute;
import com.amazonaws.services.dynamodbv2.document.Table;
import com.amazonaws.services.dynamodbv2.document.spec.UpdateItemSpec;
import com.amazonaws.services.dynamodbv2.document.utils.ValueMap;
import com.amazonaws.services.dynamodbv2.model.ReturnValue;
import com.ufoto.account.dto.other.DynamoDbUserCharmDto;
import com.ufoto.common.utils.JsonUtil;
import lombok.extern.slf4j.Slf4j;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.core.env.Environment;
import org.springframework.scheduling.annotation.Async;
import org.springframework.stereotype.Component;

import java.util.Objects;

/**
 * 对dynamodb表user_center_mapping表进行操作
 * @author luozq
 * @date 4/17/19 1:53 PM
 */
@Slf4j
@Component
public class CharmDynamoDbMapper {

    private DynamoDB dynamodb;

    private DynamoDBMapper dynamodbmapper;

    private Environment env;

    private String charmTableName = "ufoto_user_charms_";

    @Autowired
    public CharmDynamoDbMapper(DynamoDB dynamoDb,
                               DynamoDBMapper dynamoDbMapper,
                               Environment env) {
        this.dynamodb = dynamoDb;
        this.dynamodbmapper = dynamoDbMapper;
        this.env = env;
        charmTableName = charmTableName + env.getProperty("spring.profiles.active");
    }


    /**
     * 根据uuid查询用户uid
     * @param uid uid
     * @return uid
     */
    public DynamoDbUserCharmDto selectCharmByUid(Long uid) {
        if (Objects.isNull(uid)) {
            return null;
        }
        try {
            Table table = dynamodb.getTable(charmTableName);
            Item item = table.getItem(new KeyAttribute("uid", uid));
            if (item == null) {
                return null;
            }
            return JsonUtil.toObject(item.toJSON(), DynamoDbUserCharmDto.class);

        } catch (Exception e) {
            log.error("dynamodb 查询异常, uid:{}, e:{}", uid, e);
            return null;
        }

    }

    /**
     * 保存用户映射关系
     * @param mappingDo uuid和uid的映射关系
     */
    @Async
    public void saveUserCharm(DynamoDbUserCharmDto mappingDo) {
        log.info("save mapping, do:{}", JsonUtil.toJson(mappingDo));
        if (mappingDo == null) {
            return;
        }
        try {
            Table table = dynamodb.getTable(charmTableName);
            Item item = Item.fromJSON(JsonUtil.toJson(mappingDo));
            table.putItem(item);
        } catch (Exception e) {
            log.error("dynamodb 数据插入异常, do:{}, e:{}",  JsonUtil.toJson(mappingDo), e);
        }
    }

    /**
     * 值递增
     * @param uid uid
     * @param field field
     * @param incr step
     */
    public void incrementCharmByField(Long uid, String field, Integer incr) {
        try {
            UpdateItemSpec updateItemSpec = new UpdateItemSpec()
                    .withPrimaryKey("uid", uid)
                    .withUpdateExpression("set " + field + " = " + field + " + :val")
                    .withValueMap(new ValueMap().withNumber(":val", incr))
                    .withReturnValues(ReturnValue.UPDATED_NEW);
            Table table = dynamodb.getTable(charmTableName);
            table.updateItem(updateItemSpec);
        } catch (Exception e) {
            log.error("dynamodb incrementCharmByField task occurs error, uid:{}, field:{}, incr:{}",
                    uid, field, incr, e);
        }
    }


    /**
     * 删除映射关系 uuid 必传
     * @param uid uid
     */
    public void delUserCharm(Long uid) {
       if (Objects.isNull(uid)) {
           return;
       }
        try {
            Table table = dynamodb.getTable(charmTableName);
            table.deleteItem("uid",uid);
        } catch (Exception e) {
            log.error("dynamodb 数据删除异常, uid:{}, e:{}", uid, e);
        }
    }


}
