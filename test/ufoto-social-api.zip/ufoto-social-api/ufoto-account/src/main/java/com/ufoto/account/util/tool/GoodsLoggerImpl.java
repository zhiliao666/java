//package com.ufoto.account.util.tool;
//
//import ch.qos.logback.classic.spi.ILoggingEvent;
//import com.ufoto.logging.kafka.KafkaAppenderConfig;
//import com.ufoto.logging.layout.KafkaLayout;
//import com.ufoto.logging.proxy.UfotoLogFactory;
//import com.ufoto.utils.logging.AppMdcEncoderLayout;
//import org.apache.commons.lang3.StringUtils;
//import org.slf4j.Logger;
//import org.springframework.stereotype.Component;
//
//
///**
// *
// * @author luozq
// * @date 2020/2/6
// */
//@Component
//public class GoodsLoggerImpl implements GoodsLogger {
//    private static Logger logger = UfotoLogFactory.getLogger("coin.goods")
//            .enableCustomStatus()
//            .withFileName("coin-goods/coin_goods")
//            .withLayout(new AppMdcEncoderLayout(null))
//            .enableKafkaAppender()
//            .withKafkaAppenderConfig(KafkaAppenderConfig.<ILoggingEvent>builder()
//                    .topic("coin_goods")
//                    .kafkaLayout(new KafkaLayout())
//                    .build())
//            .build();
//
//    @Override
//    public void log(String msg) {
//        if (StringUtils.isNotBlank(msg)) {
//            logger.info(msg);
//        }
//    }
//}
