package com.ufoto.account.util.manage;

import com.ufoto.account.dto.quota.UfotoGoodsList;
import com.ufoto.account.mapper.read.BenefitReadMapper;
import lombok.RequiredArgsConstructor;
import lombok.extern.slf4j.Slf4j;
import org.springframework.stereotype.Component;
import org.springframework.util.StringUtils;

import java.util.List;
import java.util.Optional;

/**
 * 商品列表管理
 * @author luozq
 * @date 2020/2/26 11:01
 */
@Slf4j
@Component
@RequiredArgsConstructor
public class GoodsManage {

    private final BenefitReadMapper benefitReadMapper;

    /**
     * 获取商品列表
     * @return goods list
     */
    public List<UfotoGoodsList> getAllGoods() {
        return benefitReadMapper.getAllGoods();
    }

    /**
     * 获取对应商品编号和语言的商品, 没有则获取对应英语的商品
     * @param goodsNo 商品编号
     * @param lang 语言
     * @return 商品
     */
    public UfotoGoodsList getGoodsByParam(String goodsNo, String lang) {
        List<UfotoGoodsList> goods = getAllGoods();
        Optional<UfotoGoodsList> opt = goods.stream().filter(item -> StringUtils.endsWithIgnoreCase(goodsNo, item.getGoodsNo()))
                .filter(item -> StringUtils.endsWithIgnoreCase(lang, item.getLang())).findFirst();
        if (opt.isPresent()) {
            return opt.get();
        }
        opt = goods.stream().filter(item -> StringUtils.endsWithIgnoreCase(goodsNo, item.getGoodsNo()))
                .filter(item -> StringUtils.endsWithIgnoreCase("en", item.getLang())).findFirst();
        return opt.orElse(null);
    }
}
