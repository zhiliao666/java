package com.ufoto.account.dto.other;

import com.amazonaws.services.dynamodbv2.datamodeling.DynamoDBHashKey;
import lombok.Builder;
import lombok.Data;
import lombok.experimental.Tolerate;

/**
 *
 * @Author Wang, Qing
 * @Date 2019/10/15 13:40
 */
@Data
@Builder
public class DynamoDbUserCharmDto {

    @DynamoDBHashKey(attributeName = "uid")
    private Long uid;
    private Long likeNum;
    private Long superLikeNum;
    private Long facePkNum;
    private Long recGiftNum;
    private Long charmNum;

    @Tolerate
    public DynamoDbUserCharmDto() {

    }

    public boolean haveLikeNum() {
        return likeNum > 0L;
    }

    public boolean haveSupLikeNum() {
        return superLikeNum > 0L;
    }

    public boolean haveFacePkNum() {
        return facePkNum > 0L;
    }
}
