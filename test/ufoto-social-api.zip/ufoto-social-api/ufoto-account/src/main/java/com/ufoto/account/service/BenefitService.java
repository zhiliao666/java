package com.ufoto.account.service;

import com.ufoto.account.dto.quota.GoodsTransactionDto;
import com.ufoto.rabbit.behavior.msg.SnsSlideMsg;

/**
 * @author luozq
 * @date 2020/2/17 16:45
 */
public interface BenefitService {
    /**
     * deal like act
     * @param msgDto msg dto
     */
    void dealWithLikeAct(SnsSlideMsg msgDto);

    /**
     * save transaction
     * @param transaction transaction
     * @return true: success, false: fail
     */
    boolean saveGoodsTransaction(GoodsTransactionDto transaction);
}
