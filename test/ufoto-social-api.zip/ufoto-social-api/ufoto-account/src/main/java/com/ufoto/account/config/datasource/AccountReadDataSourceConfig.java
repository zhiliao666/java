package com.ufoto.account.config.datasource;

import com.zaxxer.hikari.HikariDataSource;
import lombok.RequiredArgsConstructor;
import org.apache.ibatis.session.SqlSessionFactory;
import org.mybatis.spring.SqlSessionFactoryBean;
import org.mybatis.spring.SqlSessionTemplate;
import org.springframework.beans.BeanUtils;
import org.springframework.beans.factory.annotation.Qualifier;
import org.springframework.boot.context.properties.ConfigurationProperties;
import org.springframework.boot.jdbc.DataSourceBuilder;
import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;
import org.springframework.core.io.support.PathMatchingResourcePatternResolver;
import org.springframework.jdbc.datasource.DataSourceTransactionManager;
import tk.mybatis.spring.annotation.MapperScan;

import javax.sql.DataSource;


/**
 * 配置读数据源
 *
 * @author luozq
 * @date 2019/3/6/006
 */
@RequiredArgsConstructor
@Configuration
@MapperScan(basePackages = {"com.ufoto.account.mapper.read"}, sqlSessionTemplateRef = "accountReadSqlSessionTemplate")
public class AccountReadDataSourceConfig extends DataSourceConfig {

    private final AccountHikari accountHikari;

    @Bean(value = "accountReadDataSource", destroyMethod = "shutdown")
    @ConfigurationProperties(prefix = "spring.datasource.read.account")
    public HikariDataSource accountReadDataSource() {
        final HikariDataSource dataSource = DataSourceBuilder.create().type(HikariDataSource.class).build();
        // 配置Hikari的相关配置参数
        BeanUtils.copyProperties(accountHikari, dataSource);
        return dataSource;
    }

    @Bean(name = "accountReadSqlSessionFactory")
    public SqlSessionFactory sqlSessionFactory(@Qualifier("accountReadDataSource") DataSource dataSource) throws Exception {
        SqlSessionFactoryBean bean = new SqlSessionFactoryBean();
        // 设置mybatis配置文件路径
        bean.setMapperLocations(new PathMatchingResourcePatternResolver()
                .getResources("classpath*:mapper/account/read/**/*.xml"));
        return getSqlSessionFactory(dataSource, bean);
    }

    @Bean
    public DataSourceTransactionManager accountReadTransactionManager(@Qualifier("accountReadDataSource") DataSource dataSource) {
        return new DataSourceTransactionManager(dataSource);
    }

    @Bean
    public SqlSessionTemplate accountReadSqlSessionTemplate(@Qualifier("accountReadSqlSessionFactory") SqlSessionFactory sqlSessionFactory) {
        return new SqlSessionTemplate(sqlSessionFactory);
    }

}
