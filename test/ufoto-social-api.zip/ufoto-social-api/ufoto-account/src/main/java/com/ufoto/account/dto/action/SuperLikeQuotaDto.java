package com.ufoto.account.dto.action;

import lombok.Builder;
import lombok.Data;

/**
 * @author luozq
 * @date 2020/2/10 10:09
 */
@Data
@Builder
public class SuperLikeQuotaDto {

    private Long uid;

    /**
     * 免费 superLIke 剩余次数
     */
    private Integer freeSuperLikeRemain;

    /**
     * 付费 superLike 剩余次数
     */
    private Integer paidSuperLikeRemain;
}
