package com.ufoto.account.util.constant;

import com.ufoto.rabbit.behavior.constants.ActionType;

/**
 * @author luozq
 * @date 2020/2/10 13:34
 */
public enum CharmDynamoDbEnum {

    /**
     * like 数量
     */
    LIKE_NUM("likeNum", ActionType.ACTION_LIKE.getType(), 1),

    /**
     * superLike 数量
     */
    SUPER_LIKE_NUM("superLikeNum", ActionType.ACTION_SUPER_LIKE.getType(), 10),

    /**
     * face pk 数量
     */
    FACE_PK_NUM("facePkNum", "facePk", 0),

    /**
     * 收到的礼物数量
     */
    REC_GIFT_NUM("recGiftNum", "gift", 0),

    /**
     * 魅力值数量
     */
    CHARM_NUM("charmNum", "charm", 0);

    private String fieldName;

    private String action;

    private Integer price;

    CharmDynamoDbEnum(String fieldName, String action, Integer price) {
        this.fieldName = fieldName;
        this.action = action;
        this.price = price;
    }

    public String getFieldName() {
        return fieldName;
    }

    public void setFieldName(String fieldName) {
        this.fieldName = fieldName;
    }

    public String getAction() {
        return action;
    }

    public void setAction(String action) {
        this.action = action;
    }

    public Integer getPrice() {
        return price;
    }

    public void setPrice(Integer price) {
        this.price = price;
    }
}
