package com.ufoto.account.util.constant;

/**
 * @author luozq
 * @date 2020/2/10 16:27
 */
public class DynamoDbConstant {

    /**
     * charm table
     */
    public static final String CHARM_TABLE = "ufoto_user_charms_";
}
