package com.ufoto.account.dto.quota;

import lombok.Builder;
import lombok.Data;

import java.math.BigDecimal;

/**
 * @author luozq
 * @date 2020/2/10 14:48
 */
@Data
@Builder
public class GoodsTransactionDto {

    private Long id;

    private Long uid;

    private String goodsNo;

    private String goodsDesc;

    private Integer goodsType;

    private Integer transactionType;

    private BigDecimal price;

    private Integer createTime;

    private Integer updateTime;

    private String common;
}
