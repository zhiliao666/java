package com.ufoto.account.util.tool;

/**
 * <p>
 * Author     : Chan
 * CreateDate : 2019-01-21 16:23
 * Description:
 * </p>
 */
public interface GiftGoodsLogger {
    void log(String msg);
}
