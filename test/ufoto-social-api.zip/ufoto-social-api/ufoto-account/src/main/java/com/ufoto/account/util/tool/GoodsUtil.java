//package com.ufoto.account.util.tool;
//
//
//import com.ufoto.account.dto.UfotoGoodsTransaction;
//import com.ufoto.account.util.constant.EGoodsList;
//import com.ufoto.account.util.constant.EGoodsType;
//import com.ufoto.account.util.constant.ETransactionType;
//import com.ufoto.common.util.tool.DateUtil;
//
//import java.math.BigDecimal;
//
//
///**
// *
// * @author luozq
// * @date 2020/2/6
// */
//public class GoodsUtil {
//
//    public static UfotoGoodsTransaction getTransaction(long uid, BigDecimal price, EGoodsList goods) {
//        UfotoGoodsTransaction transaction = new UfotoGoodsTransaction();
//        transaction.setTransactionType(price.doubleValue() > 0 ? ETransactionType.REFUND.getType() : ETransactionType.EXPENSE.getType());
//        transaction.setGoodsNo(goods.getGoodsNo());
//        transaction.setGoodsDesc(goods.getDesc());
//        transaction.setGoodsType(EGoodsType.GOODS.getType());
//        transaction.setPrice(price);
//        transaction.setUid(uid);
//        transaction.setUpdateTime(DateUtil.getCurrentSecondIntValue());
//        transaction.setCreateTime(DateUtil.getCurrentSecondIntValue());
//        return transaction;
//    }
//
//    public static String handlePlaceholder(String desc, String num) {
//        if (desc.contains("%s")) {
//            return String.format(desc, num);
//        }
//        return desc;
//    }
//
//}
