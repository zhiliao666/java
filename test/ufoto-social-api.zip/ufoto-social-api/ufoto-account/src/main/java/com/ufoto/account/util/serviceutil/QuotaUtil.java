package com.ufoto.account.util.serviceutil;

import com.ufoto.common.utils.SpringContextUtil;
import com.ufoto.redis.service.RedisService;
import lombok.extern.slf4j.Slf4j;
import org.springframework.core.env.Environment;

import static com.ufoto.account.util.constant.RedisKeyEnum.*;
import static com.ufoto.account.util.constant.RedisKeyEnum.USER_PAID_SUPER_LIKE_REMAIN_ZSET_KEY;

/**
 * @author luozq
 * @date 2020/2/10 10:00
 */
@Slf4j
public class QuotaUtil {

    private QuotaUtil () {

    }

    public static boolean checkSubUser(Long uid) {
        RedisService redisService = SpringContextUtil.getBean(RedisService.class);
        return redisService.isMember(SUBSCRIPTION_USER_SET.toString(), uid + "");
    }

    public static boolean checkSuperLikeRemain(Long uid) {
        if (uid == null) {
            return false;
        }
        // 机器人定律一:机器人永不花钱！
        if (SnsUtil.checkIfRobot(uid)) {
            return true;
        }
        RedisService redisService = SpringContextUtil.getBean(RedisService.class);
        Environment env = SpringContextUtil.getBean(Environment.class);

        Double freeUsed = redisService.zscore(FREE_SUPERLIKE_USED_ZSET_KEY.toString(), uid + "");
        if (freeUsed == null) {
            freeUsed = 0d;
        }
        Double paidRemain = redisService.zscore(USER_PAID_SUPER_LIKE_REMAIN_ZSET_KEY.toString(), uid + "");
        if (paidRemain == null) {
            paidRemain = 0d;
        }
        if (checkSubUser(uid)) {
            Integer property = env.getProperty("vip.free.superLike", Integer.class, 5);
            return env.getProperty("superlike.free.limit", Integer.class, 1) + property - freeUsed > 0
                    || paidRemain > 0;
        }
        return env.getProperty("superlike.free.limit", Integer.class, 1) - freeUsed > 0
                || paidRemain > 0;
    }

    /**
     * 检查剩余的like次数是否足够
     *
     * @param uid 用户id
     * @return true for enough
     */
    public static boolean checkLikeRemain(Long uid) {
        if (uid == null) {
            return false;
        }

        RedisService redisService = SpringContextUtil.getBean(RedisService.class);
        Environment env = SpringContextUtil.getBean(Environment.class);

        Double freeUsed = redisService.zscore(FREE_LIKE_USED_ZSET_KEY.toString(), uid + "");
        if (freeUsed == null) {
            freeUsed = 0d;
        }
        return env.getProperty("like.free.limit", Integer.class, 50) - freeUsed > 0;
    }

    /**
     * 获取剩余like次数
     *
     * @param uid uid
     * @param costFlag 为True时消耗1次
     * @return 免费 like 数量
     */
    public static Integer getFreeLikeRemain(Long uid, boolean costFlag) {
        if (uid == null) {
            return -1;
        }
        Double used;
        RedisService redisService = SpringContextUtil.getBean(RedisService.class);
        Environment env = SpringContextUtil.getBean(Environment.class);
        if (costFlag && !checkSubUser(uid)) {
            used = redisService.zincrementScore(FREE_LIKE_USED_ZSET_KEY.toString(), uid + "", 1);
        } else {
            used = redisService.zscore(FREE_SUPERLIKE_USED_ZSET_KEY.toString(), uid + "");
        }
        if (used == null) {
            used = 0d;
        }
        return env.getProperty("like.free.limit", Integer.class, 50) - used.intValue();
    }

    /**
     * 获取免费 superLike
     * @param uid uid
     * @param costFlag costFlag true 消耗 免费superLike, false: 获取 免费superLike
     * @return 免费 superLike 数量
     */
    public static Integer getFreeSuperLikeRemain(Long uid, boolean costFlag) {
        if (uid == null) {
            return -1;
        }
        Double freeUsed;
        RedisService redisService = SpringContextUtil.getBean(RedisService.class);
        Environment env = SpringContextUtil.getBean(Environment.class);
        if (costFlag) {
            // 消费 free superLike
            freeUsed = redisService.zincrementScore(FREE_SUPERLIKE_USED_ZSET_KEY.toString(), uid + "",
                    1);
        } else {
            // 获取 free superLike
            freeUsed = redisService.zscore(FREE_SUPERLIKE_USED_ZSET_KEY.toString(), uid + "");
        }
        if (freeUsed == null) {
            freeUsed = 0d;
        }
        if (checkSubUser(uid)) {
            Integer property = env.getProperty("vip.free.superLike", Integer.class, 5);
            return (env.getProperty("superlike.free.limit", Integer.class, 1) + property - freeUsed
                    .intValue());
        }
        return (env.getProperty("superlike.free.limit", Integer.class, 1) - freeUsed.intValue());
    }

    /**
     * 获取付费 superLike 数量
     * @param uid uid
     * @param costFlag true 消耗 付费superLike, false: 获取 付费superLike
     * @return 付费 superLike
     */
    public static Integer getPaidSuperLikeRemain(Long uid, boolean costFlag) {
        Double paidRemainDouble;
        RedisService redisService = SpringContextUtil.getBean(RedisService.class);
        if (costFlag) {
            // 消耗 superLike
            paidRemainDouble = redisService.zincrementScore(USER_PAID_SUPER_LIKE_REMAIN_ZSET_KEY.toString(), uid + "", -1);
        } else {
            // 获取 superLike
            paidRemainDouble = redisService.zscore(USER_PAID_SUPER_LIKE_REMAIN_ZSET_KEY.toString(), uid + "");
        }
        if (paidRemainDouble == null) {
            paidRemainDouble = 0d;
        }
        return paidRemainDouble.intValue();
    }
}
