package com.ufoto.account.util.constant;

/**
 * @author luozq
 * @date 2020/2/10 15:34
 */
public enum EMsgType {


    /**
     * 金币收入消息
     */
    COIN_TASK_INCOME(902, "金币收入消息"),

    /**
     *金币支出消息
     */
    COIN_TASK_EXPENSE(903, "金币支出消息");

    private Integer type;

    private String remark;

    EMsgType(Integer type, String remark) {
        this.type = type;
        this.remark = remark;
    }

    public Integer getType() {
        return type;
    }

    public void setType(Integer type) {
        this.type = type;
    }

    public String getRemark() {
        return remark;
    }

    public void setRemark(String remark) {
        this.remark = remark;
    }
}
