package com.ufoto.account.api;

import com.ufoto.account.dto.coin.SuperLikeCostDto;
import com.ufoto.account.dto.quota.GoodsTransactionDto;
import com.ufoto.account.dto.quota.UfotoGoodsList;
import com.ufoto.account.service.BenefitService;
import com.ufoto.account.util.manage.GoodsManage;
import com.ufoto.account.util.manage.RobotManage;
import com.ufoto.account.util.serviceutil.SnsUtil;
import com.ufoto.common.utils.ApiResult;
import com.ufoto.common.utils.DateUtil;
import com.ufoto.redis.service.RedisService;
import lombok.RequiredArgsConstructor;
import lombok.extern.slf4j.Slf4j;
import org.springframework.http.HttpStatus;
import org.springframework.stereotype.Component;

import java.math.BigDecimal;
import java.util.Objects;

import static com.ufoto.account.util.constant.GoodsConstant.ONE_SUPER_LIKE;
import static com.ufoto.account.util.constant.RedisKeyEnum.REDIS_USER_COIN_AMOUNT;
import static com.ufoto.account.util.constant.RedisKeyEnum.USER_PAID_SUPER_LIKE_REMAIN_ZSET_KEY;
import static com.ufoto.account.util.serviceutil.QuotaUtil.getFreeSuperLikeRemain;
import static com.ufoto.account.util.serviceutil.QuotaUtil.getPaidSuperLikeRemain;

/**
 * @author luozq
 * @date 2020/2/6 17:22
 */
@Slf4j
@Component
@RequiredArgsConstructor
public class AccountCoinQuotaManage {

    private final RedisService redisService;

    private final BenefitService benefitService;

    private final GoodsManage goodsManage;

    private final RobotManage robotManage;

    /**
     * 金币额度校验
     * @param uid uid
     * @param price price
     * @return 校验结果, true: 金币额度足够， false: 金币额度不够
     */
    public ApiResult<Boolean> checkCoinQuota(Long uid, Double price) {
        Double score = redisService.zscore(REDIS_USER_COIN_AMOUNT.toString(), uid + "");
        boolean flag = Objects.nonNull(score) && score >= price;
        return new ApiResult<Boolean>().setResult(flag);
    }

    /**
     * 校验 super like 金币兑换是否足够
     * @param uid uid
     * @param lang uid
     * @param cp cp
     * @return true: 足够, false: 不够
     */
    public ApiResult<Boolean> checkSuperLikeExchange(Long uid, String lang, String cp) {
        if (robotManage.ifRobot(uid)) {
            return new ApiResult<Boolean>().setResult(true);
        }
        UfotoGoodsList goods = goodsManage.getGoodsByParam(ONE_SUPER_LIKE, lang);
        if (Objects.isNull(goods)) {
            return new ApiResult<Boolean>().setError(1001, "one_super_like goods not exists");
        }
        Double price = goods.getPrice();
        Double score = redisService.zscore(REDIS_USER_COIN_AMOUNT.toString(), uid + "");
        score = Objects.isNull(score) ? 0.0 : score;
        if (score < price) {
            return new ApiResult<Boolean>().setError(1002, "coin not enough, coin: " + score + ", price: " + price);
        }
        return new ApiResult<Boolean>().setResult(true);
    }

    /**
     * 消耗superLike 对应数量的金币,
     * 增加 superLike 付费额度
     * @param uid uid
     * @param lang lang
     * @param cp cp
     * @return true: 金币消耗成功, false: 消费失败
     */
    public ApiResult<SuperLikeCostDto> consumeCoinForSuperLike(Long uid, String lang, String cp) {
        ApiResult<Boolean> result = checkSuperLikeExchange(uid, lang, cp);
        if (!Objects.equals(result.getC(), HttpStatus.OK.value())) {
            return new ApiResult<SuperLikeCostDto>().setError(result.getC(), result.getM());
        }
        //  插入交易记录
        UfotoGoodsList goods = goodsManage.getGoodsByParam(ONE_SUPER_LIKE, lang);
        Double price = goods.getPrice();
        BigDecimal priceData = new BigDecimal(String.valueOf(price))
                .multiply(new BigDecimal("-1"));
        Integer time = DateUtil.getCurrentSecondIntValue();
        GoodsTransactionDto transaction = GoodsTransactionDto.builder()
                .uid(uid)
                .price(priceData)
                .goodsNo(ONE_SUPER_LIKE)
                .transactionType(2)
                .goodsDesc(goods.getGoodsDesc())
                .goodsType(goods.getGoodsType())
                .createTime(time)
                .updateTime(time)
                .build();
        boolean flag = benefitService.saveGoodsTransaction(transaction);
        if (flag) {
            Double count = redisService.zincrementScore(REDIS_USER_COIN_AMOUNT.toString(),
                    transaction.getUid() + "", transaction.getPrice().doubleValue());
            return new ApiResult<SuperLikeCostDto>().setResult(SuperLikeCostDto
                    .builder()
                    .uid(uid)
                    .price(new BigDecimal(price))
                    .account(new BigDecimal(count))
                    .freeSuperLikeRemain(getFreeSuperLikeRemain(uid, false))
                    .paidSuperLikeRemain(getPaidSuperLikeRemain(uid, false))
                    .build());
        }
        return new ApiResult<SuperLikeCostDto>().setError(1003, "交易记录异常, 金币兑换失败");
    }

}
