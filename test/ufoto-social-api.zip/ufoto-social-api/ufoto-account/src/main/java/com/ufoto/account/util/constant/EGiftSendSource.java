package com.ufoto.account.util.constant;

 /**
  *
  * @author luozq
  * @date 2020/2/6
  */

public enum EGiftSendSource {
    CHAT(1),
    SLIDE_AND_PROFILE(2);

    private int source;

    EGiftSendSource(int source) {
        this.source = source;
    }

    public int getSource() {
        return source;
    }}
