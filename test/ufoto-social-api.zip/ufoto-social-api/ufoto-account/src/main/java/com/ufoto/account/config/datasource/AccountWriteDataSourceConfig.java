package com.ufoto.account.config.datasource;

import com.zaxxer.hikari.HikariDataSource;
import lombok.RequiredArgsConstructor;
import org.apache.ibatis.session.SqlSessionFactory;
import org.mybatis.spring.SqlSessionFactoryBean;
import org.mybatis.spring.SqlSessionTemplate;
import org.springframework.beans.BeanUtils;
import org.springframework.beans.factory.annotation.Qualifier;
import org.springframework.boot.context.properties.ConfigurationProperties;
import org.springframework.boot.jdbc.DataSourceBuilder;
import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;
import org.springframework.core.io.support.PathMatchingResourcePatternResolver;
import org.springframework.jdbc.datasource.DataSourceTransactionManager;
import tk.mybatis.spring.annotation.MapperScan;

import javax.sql.DataSource;

/**
 * 配置写数据源
 *
 * @author luozq
 * @date 2019/3/6/006
 */
@RequiredArgsConstructor
@Configuration
@MapperScan(basePackages = {"com.ufoto.account.mapper.write"}, sqlSessionTemplateRef = "accountWriteSqlSessionTemplate")
public class AccountWriteDataSourceConfig extends DataSourceConfig {

    private final AccountHikari accountHikari;

    @Bean(value = "accountWriteDataSource", destroyMethod = "shutdown")
    @ConfigurationProperties(prefix = "spring.datasource.write.account")
    public HikariDataSource accountWriteDataSource() {
        final HikariDataSource dataSource = DataSourceBuilder.create().type(HikariDataSource.class).build();
        // 配置Hikari的相关配置参数
        BeanUtils.copyProperties(accountHikari, dataSource);
        return dataSource;
    }

    @Bean
    public SqlSessionFactory accountWriteSqlSessionFactory(@Qualifier("accountWriteDataSource") DataSource dataSource) throws Exception {
        SqlSessionFactoryBean bean = new SqlSessionFactoryBean();
        // 设置mybatis配置文件路径
        bean.setMapperLocations(new PathMatchingResourcePatternResolver()
                .getResources("classpath*:mapper/account/write/**/*.xml"));

        bean.setDataSource(dataSource);
        return getSqlSessionFactory(dataSource, bean);
    }

    @Bean
    public DataSourceTransactionManager accountWriteTransactionManager(@Qualifier("accountWriteDataSource") DataSource dataSource) {
        return new DataSourceTransactionManager(dataSource);
    }

    @Bean
    public SqlSessionTemplate accountWriteSqlSessionTemplate(@Qualifier("accountWriteSqlSessionFactory") SqlSessionFactory sqlSessionFactory) {
        return new SqlSessionTemplate(sqlSessionFactory);
    }

}
