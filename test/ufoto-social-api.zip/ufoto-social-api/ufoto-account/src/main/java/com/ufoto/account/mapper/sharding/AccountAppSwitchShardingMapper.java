package com.ufoto.account.mapper.sharding;

import org.apache.ibatis.annotations.Mapper;
import org.springframework.stereotype.Repository;

import java.util.List;

/**
 * @author luozq
 * @date 2020/1/14 16:53
 */
@Mapper
@Repository
public interface AccountAppSwitchShardingMapper {

    List<Long> getIdList();
}
