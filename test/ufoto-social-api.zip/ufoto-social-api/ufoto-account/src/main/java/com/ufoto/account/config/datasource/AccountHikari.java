package com.ufoto.account.config.datasource;

import com.zaxxer.hikari.HikariConfig;
import org.springframework.boot.context.properties.ConfigurationProperties;
import org.springframework.context.annotation.Configuration;



/**
 *
 * @author luozq
 * @date 2020/2/13
 */
@ConfigurationProperties(prefix = "spring.datasource.hikari")
@Configuration
public class AccountHikari extends HikariConfig {

}
