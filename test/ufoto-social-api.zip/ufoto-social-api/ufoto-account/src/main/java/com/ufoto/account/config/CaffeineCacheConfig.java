package com.ufoto.account.config;

import com.github.benmanes.caffeine.cache.*;

import lombok.extern.slf4j.Slf4j;
import org.springframework.cache.CacheManager;
import org.springframework.cache.caffeine.CaffeineCache;
import org.springframework.cache.support.SimpleCacheManager;
import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;
import java.util.ArrayList;
import java.util.concurrent.TimeUnit;


/**
 * 应用内部缓存:Caffeine缓存方式
 * @author luozq
 * @date 2018/11/7/007
 */
@Slf4j
@Configuration
public class CaffeineCacheConfig {


    /**
     * 创建基于Caffeine的Cache Manager
     *
     * @return
     */
    @Bean("accountCaffeineManager")
    public CacheManager caffeineCacheManager() {
        SimpleCacheManager cacheManager = new SimpleCacheManager();
        ArrayList<CaffeineCache> caches = new ArrayList<>();
        for (CacheNames c : CacheNames.values()) {
            caches.add(new CaffeineCache(c.name(),
                    Caffeine.newBuilder().recordStats()
                            .expireAfterWrite(c.getTtl(), TimeUnit.MINUTES)
                            .maximumSize(c.getMaxSize())
                            .build())
            );
        }

        cacheManager.setCaches(caches);
        return cacheManager;
    }


}

