//package com.ufoto.account.util.factory;
//
//import com.ufoto.account.dto.ExchangeGiftResult;
//import com.ufoto.account.dto.GiftRecordRequest;
//import com.ufoto.account.dto.GoodsParam;
//import com.ufoto.account.util.exception.TransactionException;
//import com.ufoto.account.util.tool.CoinMsgUtil;
//import com.ufoto.account.util.tool.GiftGoodsLogger;
//import com.ufoto.common.service.common.RedisService;
//import com.ufoto.common.util.tool.JsonUtil;
//import com.ufoto.common.util.tool.MapUtil;
//import com.ufoto.common.util.tool.SpringContextUtil;
//import org.springframework.stereotype.Component;
//import org.springframework.util.CollectionUtils;
//
//import java.math.BigDecimal;
//import java.util.HashMap;
//import java.util.Map;
//
///**
// * <p>
// * Author     : Chan
// * CreateDate : 2019-01-21 13:06
// * Description:
// * </p>
// */
//@Component
//public class GiftGoodsFactory implements GoodsFactory {
//    private final RedisService redisService;
//    private final RabbitProducer rabbitProducer;
//
//    public GiftGoodsFactory(RedisService redisService,
//                            RabbitProducer rabbitProducer) {
//        this.redisService = redisService;
//        this.rabbitProducer = rabbitProducer;
//    }
//
//    @Override
//    public ExchangeGiftResult purchase(GoodsParam goodsParam) {
//        Long uid = goodsParam.getUid();
//        BigDecimal price = goodsParam.getPrice();
//        Map<String, Object> logMap = new HashMap<>();
//        ExchangeGiftResult giftResult = new ExchangeGiftResult();
//        final Integer timestamp = DateUtil.getCurrentSecondIntValue();
//        giftResult.setTime(timestamp);
//        giftResult.setGoodsNo(goodsParam.getGiftNo());
//        giftResult.setPrice(price);
//        try {
//            //记录收入交易
//            final UfotoGoodsTransactionService ufotoGoodsTransactionService = SpringContextUtil.getBean(UfotoGoodsTransactionService.class);
//            ufotoGoodsTransactionService.recordGiftTransactions(goodsParam,giftResult);
//            //发送礼物记录至推荐
//            GiftRecordRequest giftRecordRequest = new GiftRecordRequest();
//            giftRecordRequest.setUid(uid);
//            giftRecordRequest.setTargetUid(goodsParam.getTargetUid());
//            giftRecordRequest.setPrice(goodsParam.getPrice().abs());
//            rabbitProducer.produce(EExchange.SWEETCHAT_DIRECT_RECOMMEND, ERoutingKey.ROUTE_KEY_GIFT_RECORD, giftRecordRequest);
//            //发送mqtt消息通知用户
//            SpringContextUtil.getBean(CoinMsgUtil.class).sendNotify(redisService, uid, price, logMap, EMsgType.COIN_TASK_EXPENSE.getMsgType());
//            giftResult.setStatus(EExchangeGiftStatus.SUCCESS.getStatus());
//            return giftResult;
//        } catch (TransactionException e) {
//            logMap.put("execError", e.getMessage());
//            if (e.getCode() != null) {
//                giftResult.setStatus(e.getCode());
//            } else {
//                giftResult.setStatus(EExchangeGiftStatus.FAILURE.getStatus());
//            }
//            return giftResult;
//        } finally {
//            final GiftGoodsLogger giftGoodsLogger = SpringContextUtil.getBean(GiftGoodsLogger.class);
//            final Map<String, Object> objectMap = MapUtil.toMap(giftResult);
//            if (!CollectionUtils.isEmpty(objectMap)) {
//                logMap.putAll(objectMap);
//            }
//            final Map<String, Object> map = MapUtil.toMap(goodsParam);
//            if (!CollectionUtils.isEmpty(map)) {
//                logMap.putAll(map);
//            }
//            giftGoodsLogger.log(JsonUtil.toJson(logMap));
//        }
//    }
//}
