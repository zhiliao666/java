//package com.ufoto.account.util.factory;
//
//
//
//import com.ufoto.account.dto.ExchangeGiftResult;
//import com.ufoto.account.dto.GoodsParam;
//import com.ufoto.account.dto.UfotoGoodsTransaction;
//import com.ufoto.account.util.constant.EGoodsList;
//import com.ufoto.account.util.exception.TransactionException;
//import com.ufoto.account.util.serviceutil.CoinMsgUtil;
//import com.ufoto.account.util.tool.GoodsLogger;
//import com.ufoto.account.util.tool.GoodsUtil;
//import com.ufoto.common.utils.DateUtil;
//import com.ufoto.common.utils.SpringContextUtil;
//import com.ufoto.redis.service.RedisService;
//import org.springframework.util.CollectionUtils;
//
//import java.math.BigDecimal;
//import java.util.HashMap;
//import java.util.Map;
//
///**
// *
// * @author luozq
// * @date 2020/2/6
// */
//public interface GoodsFactory {
//
//    ExchangeGiftResult purchase(GoodsParam goodsParam);
//
//    default ExchangeGiftResult common(RedisService redisService, GoodsParam goodsParam) {
//        Long uid = goodsParam.getUid();
//        BigDecimal price = goodsParam.getPrice();
//        EGoodsList goods = goodsParam.getGoods();
//        Map<String, Object> logMap = new HashMap<>();
//        ExchangeGiftResult giftResult = new ExchangeGiftResult();
//        final Integer timestamp = DateUtil.getCurrentSecondIntValue();
//        giftResult.setTime(timestamp);
//        giftResult.setGoodsNo(goods.getGoodsNo());
//        giftResult.setPrice(price);
//        try {
//            //记录收入交易
//            final UfotoGoodsTransaction transaction = GoodsUtil.getTransaction(uid, price, goods);
//            final UfotoGoodsTransactionService ufotoGoodsTransactionService = SpringContextUtil.getBean(UfotoGoodsTransactionService.class);
//            ufotoGoodsTransactionService.recordTransaction(transaction);
//            //发送mqtt消息通知用户
//            SpringContextUtil.getBean(CoinMsgUtil.class).sendNotify(redisService, uid, price, logMap, EMsgType.COIN_TASK_EXPENSE.getMsgType());
//            giftResult.setStatus(EExchangeGiftStatus.SUCCESS.getStatus());
//            return giftResult;
//        } catch (TransactionException e) {
//            logMap.put("execError", e.getMessage());
//            if (e.getCode() != null) {
//                giftResult.setStatus(e.getCode());
//            } else {
//                giftResult.setStatus(EExchangeGiftStatus.FAILURE.getStatus());
//            }
//            return giftResult;
//        } finally {
//            final GoodsLogger goodsLogger = SpringContextUtil.getBean(GoodsLogger.class);
//            final Map<String, Object> objectMap = MapUtil.toMap(giftResult);
//            if (!CollectionUtils.isEmpty(objectMap)) {
//                logMap.putAll(objectMap);
//            }
//            logMap.put("uid", uid);
//            goodsLogger.log(JsonUtil.toJson(logMap));
//        }
//    }
//}
