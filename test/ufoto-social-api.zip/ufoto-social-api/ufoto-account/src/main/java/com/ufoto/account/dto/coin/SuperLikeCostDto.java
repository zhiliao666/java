package com.ufoto.account.dto.coin;

import lombok.Builder;
import lombok.Data;

import java.io.Serializable;
import java.math.BigDecimal;

/**
 * @author luozq
 * @date 2020/2/27 13:19
 */
@Data
@Builder
public class SuperLikeCostDto implements Serializable {

    private Long uid;

    /**
     * 价格
     */
    private BigDecimal price;

    /**
     * 剩余金币数量
     */
    private BigDecimal account;


    /**
     * 免费 superLIke 剩余次数
     */
    private Integer freeSuperLikeRemain;

    /**
     * 付费 superLike 剩余次数
     */
    private Integer paidSuperLikeRemain;
}
