//package com.ufoto.account.util.tool;
//
//import ch.qos.logback.classic.spi.ILoggingEvent;
//import com.ufoto.logging.kafka.KafkaAppenderConfig;
//import com.ufoto.logging.layout.KafkaLayout;
//import com.ufoto.logging.proxy.UfotoLogFactory;
//import com.ufoto.utils.logging.AppMdcEncoderLayout;
//import org.slf4j.Logger;
//import org.springframework.stereotype.Component;
//
///**
// * <p>
// * Author     : Chan
// * CreateDate : 2019-01-21 16:23
// * Description:
// * </p>
// */
//@Component
//public class GiftGoodsLoggerImpl implements GiftGoodsLogger {
//
//    private static Logger logger = UfotoLogFactory.getLogger("coin.gift")
//            .enableCustomStatus()
//            .withFileName("coin-goods/coin_gift")
//            .withLayout(new AppMdcEncoderLayout(null))
//            .enableKafkaAppender()
//            .withKafkaAppenderConfig(KafkaAppenderConfig.<ILoggingEvent>builder()
//                    .topic("coin_gift")
//                    .kafkaLayout(new KafkaLayout())
//                    .build())
//            .build();
//
//    @Override
//    public void log(String msg) {
//        logger.info(msg);
//    }
//}
