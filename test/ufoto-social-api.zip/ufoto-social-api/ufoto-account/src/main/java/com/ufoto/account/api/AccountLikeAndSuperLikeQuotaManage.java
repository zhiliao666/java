package com.ufoto.account.api;

import com.ufoto.account.dto.action.SuperLikeQuotaDto;
import com.ufoto.account.dto.coin.SuperLikeCostDto;
import com.ufoto.account.util.serviceutil.QuotaUtil;
import com.ufoto.common.utils.ApiResult;
import com.ufoto.redis.service.RedisService;
import lombok.RequiredArgsConstructor;
import lombok.extern.slf4j.Slf4j;
import org.springframework.core.env.Environment;
import org.springframework.stereotype.Component;

import java.math.BigDecimal;
import java.util.Objects;

import static com.ufoto.account.util.constant.RedisKeyEnum.*;
import static com.ufoto.account.util.serviceutil.QuotaUtil.checkLikeRemain;
import static com.ufoto.account.util.serviceutil.QuotaUtil.checkSubUser;
import static com.ufoto.account.util.serviceutil.QuotaUtil.checkSuperLikeRemain;
import static com.ufoto.account.util.serviceutil.QuotaUtil.getFreeSuperLikeRemain;
import static com.ufoto.account.util.serviceutil.QuotaUtil.getPaidSuperLikeRemain;

/**
 * @author luozq
 * @date 2020/2/6 17:07
 */
@Slf4j
@Component
@RequiredArgsConstructor
public class AccountLikeAndSuperLikeQuotaManage {

    private final RedisService redisService;

    private final Environment env;

    /**
     * like, superLike 额度校验
     *
     * @param uid uid
     * @return 校验结果, true: 额度足够， false: 额度不够
     */
    public ApiResult<Boolean> checkLikeQuota(Long uid) {
        return new ApiResult<Boolean>().setResult(checkSubUser(uid) || checkLikeRemain(uid));
    }

    /**
     * like, superLike 额度校验
     *
     * @param uid uid
     * @return 校验结果, true: 额度足够， false: 额度不够
     */
    public ApiResult<Boolean> checkSuperLikeQuota(Long uid) {
        return new ApiResult<Boolean>().setResult(checkSuperLikeRemain(uid));

    }

    /**
     * 消耗like, superLike 额度
     *
     * @param uid      uid
     * @param costFlag true: 消耗like 额度, false: 不消耗
     * @return 剩余 like 额度
     */
    public ApiResult<Integer> consumeLikeQuota(Long uid, boolean costFlag) {
        Integer defaultLimit = env.getProperty("like.free.limit", Integer.class, 50);
        if (checkSubUser(uid)) {
            return new ApiResult<Integer>().setResult(defaultLimit);
        }
        Double used;
        if (costFlag) {
            used = redisService.zincrementScore(FREE_LIKE_USED_ZSET_KEY.toString(), uid + "", 1);
        } else {
            used = redisService.zscore(FREE_LIKE_USED_ZSET_KEY.toString(), uid + "");
        }
        int remain = defaultLimit - used.intValue();
        return new ApiResult<Integer>().setResult(Math.max(remain, 0));
    }

    /**
     * 消耗 superLike 额度
     *
     * @param uid uid
     * @return true 消费成功, false 消费失败
     */
    public ApiResult<SuperLikeCostDto> consumeSuperLikeQuota(Long uid) {
        if (!checkSuperLikeRemain(uid)) {
            return new ApiResult<SuperLikeCostDto>().setError(1001, "super like quota not enough.");
        }
        // 消费 free superLike
        Double freeUsed = redisService.zscore(FREE_SUPERLIKE_USED_ZSET_KEY.toString(), uid + "");
        freeUsed = Objects.isNull(freeUsed) ? 0d : freeUsed;
        Integer property = 0;
        if (checkSubUser(uid)) {
             property = env.getProperty("vip.free.superLike", Integer.class, 5);
        }
        int freeRemain = env.getProperty("superlike.free.limit", Integer.class, 1) + property - freeUsed.intValue();
        // 如果 free superLike 不够, 则扣减付费 superLike
        Double paidRemainDouble;
        if (freeRemain > 0) {
            // 消耗免费superLike
            redisService.zincrementScore(FREE_SUPERLIKE_USED_ZSET_KEY.toString(), uid + "", 1);
            paidRemainDouble = redisService.zscore(USER_PAID_SUPER_LIKE_REMAIN_ZSET_KEY.toString(), uid + "");
            freeRemain -= 1;
        } else {
            // 消耗付费superLike
            paidRemainDouble = redisService.zincrementScore(USER_PAID_SUPER_LIKE_REMAIN_ZSET_KEY.toString(), uid + "", -1);
            freeRemain = 0;
        }
        Double coinCount = redisService.zscore(REDIS_USER_COIN_AMOUNT.toString(), uid + "");
        coinCount = Objects.nonNull(coinCount) ? coinCount : 0d;
        paidRemainDouble = Objects.isNull(paidRemainDouble) ? 0D : paidRemainDouble;
        return new ApiResult<SuperLikeCostDto>().setResult(SuperLikeCostDto.builder()
                .paidSuperLikeRemain(paidRemainDouble.intValue())
                .freeSuperLikeRemain(freeRemain)
                .account(new BigDecimal(coinCount.toString()))
                .price(BigDecimal.ZERO)
                .build());
    }


    /**
     * 获取免费的 like 剩余次数
     *
     * @param uid uid
     * @return like 剩余次数
     */
    public ApiResult<Integer> getFreeLikeRemain(Long uid) {
        Integer freeLikeRemain = QuotaUtil.getFreeLikeRemain(uid, false);
        return new ApiResult<Integer>().setResult(freeLikeRemain);
    }

    /**
     * 获取 superLike 的免费次数和付费次数
     *
     * @param uid uid
     * @return superLike 剩余次数
     */
    public ApiResult<SuperLikeQuotaDto> getSuperLikeRemain(Long uid) {
        Integer paidSuperLikeRemain = getPaidSuperLikeRemain(uid, false);
        Integer freeSuperLikeRemain = getFreeSuperLikeRemain(uid, false);
        return new ApiResult<SuperLikeQuotaDto>().setResult(SuperLikeQuotaDto.builder()
                .uid(uid)
                .freeSuperLikeRemain(freeSuperLikeRemain)
                .paidSuperLikeRemain(paidSuperLikeRemain)
                .build());
    }

    /**
     * 清空每日的 like 和 superLike 免费额度
     */
    public void resetLikeAndSuperLikeQuota() {
        redisService.del(FREE_LIKE_USED_ZSET_KEY.toString());
        redisService.del(FREE_SUPERLIKE_USED_ZSET_KEY.toString());
        redisService.del(FREE_CANCEL_USED_ZSET_KEY.toString());
        redisService.del(RANDOM_MATCH_USED.toString());
        redisService.del(RANDOM_VOICE_CHAT_USED.toString());
    }
}
