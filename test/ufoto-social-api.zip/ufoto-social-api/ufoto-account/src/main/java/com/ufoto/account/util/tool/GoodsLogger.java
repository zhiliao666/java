//package com.ufoto.account.util.tool;
//
//
///**
// *
// * @author luozq
// * @date 2020/2/6
// */
//public interface GoodsLogger {
//    void log(String msg);
//}
