package com.ufoto.account.util.factory;

import com.google.common.collect.Lists;
import com.ufoto.account.util.constant.MqActType;
import com.ufoto.account.util.serviceutil.CharmDynamoDbUtil;
import com.ufoto.rabbit.behavior.msg.SnsSlideMsg;
import lombok.RequiredArgsConstructor;
import org.apache.commons.lang3.StringUtils;

import java.util.ArrayList;
import java.util.EnumSet;
import java.util.List;

/**
 * @author luozq
 * @date 2020/2/25 11:24
 */
@RequiredArgsConstructor
public abstract class AbstractActFactory implements ActFactory {

    protected final CharmDynamoDbUtil charmDynamoDbUtil;

    private static List<String> charmActionList = Lists.newArrayList(MqActType.LIKE.getActionType(),
            MqActType.SUPER_LIKE.getActionType());

    /**
     * execute
     *
     * @param snsSlideMsg msg
     */
    @Override
    public void execute(SnsSlideMsg snsSlideMsg) {
        // 加魅力值
        incrementCharm(snsSlideMsg);
        // 每日任务

        doDailyTask(snsSlideMsg);
    }

    /**
     * deal daily task
     *
     * @param snsSlideMsg msg
     */
    protected abstract void doDailyTask(SnsSlideMsg snsSlideMsg);

    /**
     * 增加魅力值
     *
     * @param snsSlideMsg msg
     */
    private void incrementCharm(SnsSlideMsg snsSlideMsg) {
        charmActionList.stream()
                .filter(item -> StringUtils.equalsAnyIgnoreCase(item, snsSlideMsg.getAction()))
                .findAny()
                .ifPresent(item -> charmDynamoDbUtil.incrementCharm(snsSlideMsg.getTargetUid(), snsSlideMsg.getAction()));

    }

}
