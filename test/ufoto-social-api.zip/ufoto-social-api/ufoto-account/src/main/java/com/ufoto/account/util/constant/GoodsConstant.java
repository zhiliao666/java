package com.ufoto.account.util.constant;

/**
 * @author luozq
 * @date 2020/2/26 18:04
 */
public interface GoodsConstant {

    /**
     * 一次 superLike
     */
    String ONE_SUPER_LIKE = "one_super_like";
}
