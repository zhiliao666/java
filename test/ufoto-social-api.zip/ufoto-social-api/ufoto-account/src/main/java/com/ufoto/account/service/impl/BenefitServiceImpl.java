package com.ufoto.account.service.impl;

import com.ufoto.account.dto.quota.GoodsTransactionDto;
import com.ufoto.account.mapper.write.GoodsTransactionMapper;
import com.ufoto.account.service.BenefitService;
import com.ufoto.account.util.constant.MqActType;
import com.ufoto.common.utils.SpringContextUtil;
import com.ufoto.rabbit.behavior.msg.SnsSlideMsg;
import lombok.RequiredArgsConstructor;
import lombok.extern.slf4j.Slf4j;
import org.springframework.stereotype.Service;
import org.springframework.util.StringUtils;

import java.util.EnumSet;

/**
 * @author luozq
 * @date 2020/2/17 16:45
 */
@Slf4j
@Service
@RequiredArgsConstructor
public class BenefitServiceImpl implements BenefitService {


    private final GoodsTransactionMapper goodsTransactionMapper;

    @Override
    public void dealWithLikeAct(SnsSlideMsg msgDto) {
        // 处理魅力值
        EnumSet.allOf(MqActType.class).stream()
                .filter(item -> StringUtils.endsWithIgnoreCase(item.getActionType(), msgDto.getAction()))
                .findAny()
                .ifPresent(item -> SpringContextUtil.getBean(item.getFactoryClass()).execute(msgDto));
    }

    @Override
    public boolean saveGoodsTransaction(GoodsTransactionDto transaction) {
        return goodsTransactionMapper.saveTransaction(transaction) > 0;
    }
}
