package com.ufoto.account.mapper.write;

import com.ufoto.account.dto.quota.GoodsTransactionDto;
import org.apache.ibatis.annotations.Mapper;
import org.springframework.stereotype.Repository;

/**
 * @author luozq
 * @date 2020/2/10 14:52
 */
@Mapper
@Repository
public interface GoodsTransactionMapper {

    /**
     * save
     * @param goodsTransactionDto msg
     * @return save result
     */
    int saveTransaction(GoodsTransactionDto goodsTransactionDto);
}
