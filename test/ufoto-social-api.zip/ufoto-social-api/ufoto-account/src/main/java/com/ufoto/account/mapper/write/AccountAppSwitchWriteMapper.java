package com.ufoto.account.mapper.write;

import org.apache.ibatis.annotations.Mapper;
import org.springframework.stereotype.Repository;

import java.util.List;

/**
 * @author luozq
 * @date 2020/1/14 16:53
 */
@Mapper
@Repository
public interface AccountAppSwitchWriteMapper {

    List<Long> getIdList();
}
