package com.ufoto.account.dto.quota;

import lombok.Data;

import java.io.Serializable;

/**
 * (UfotoGoodsList)实体类
 *
 * @author makejava
 * @since 2020-02-26 11:05:36
 */
@Data
public class UfotoGoodsList implements Serializable {

    private Integer id;
    /**
     * 商品编号
     */
    private String goodsNo;
    /**
     * 商品描述
     */
    private String goodsDesc;
    /**
     * 商品类型 1任务 2商品  3 其他
     */
    private Integer goodsType;
    /**
     * 是否可用
     */
    private Integer isDelete;
    /**
     * 任务达到数量算完成
     */
    private Integer num;
    /**
     * 商品价格 1 3 为空
     */
    private Double price;
    /**
     * 语言
     */
    private String lang;
    /**
     * 跳转action
     */
    private String jump;
    /**
     * 商品首图
     */
    private String firstImg;
    /**
     * 0 不区分页面;1 滑动页面; 2 聊天页面
     */
    private Object page;
    /**
     * 排序字段 默认是0；按数字顺序排
     */
    private Object orderNum;
    /**
     * 0 无;1 hot; 2 new
     */
    private Object tag;
    /**
     * 创建时间
     */
    private Integer createTime;
    /**
     * 更新时间
     */
    private Integer updateTime;
    /**
     * 属性
     */
    private String properties;

}

