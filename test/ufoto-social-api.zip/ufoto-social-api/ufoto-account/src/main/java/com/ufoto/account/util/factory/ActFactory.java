package com.ufoto.account.util.factory;

import com.ufoto.rabbit.behavior.msg.SnsSlideMsg;

/**
 * @author luozq
 * @date 2020/2/17 16:55
 */
public interface ActFactory {

    /**
     * execute
     * @param snsSlideMsg msg
     */
    void execute(SnsSlideMsg snsSlideMsg);
}
