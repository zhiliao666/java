package com.ufoto.account.vo;

import lombok.Builder;
import lombok.Data;

/**
 * @author luozq
 * @date 2020/2/6 17:32
 */
@Data
@Builder
public class CoinConsumeVo {

    private Long uid;

//    private EGoodsList goods;

    private String lang;

    private String packageName;
}
