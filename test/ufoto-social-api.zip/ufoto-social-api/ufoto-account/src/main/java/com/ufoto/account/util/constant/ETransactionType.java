package com.ufoto.account.util.constant;


/**
 *
 * @author luozq
 * @date 2020/2/6
 */
public enum ETransactionType {
    INCOME(1),
    EXPENSE(2),
    REFUND(3);

    private int type;

    ETransactionType(int type) {
        this.type = type;
    }

    public int getType() {
        return type;
    }
}
