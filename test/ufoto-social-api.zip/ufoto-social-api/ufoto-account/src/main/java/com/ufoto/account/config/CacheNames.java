package com.ufoto.account.config;

/**
 * @author luozq
 * @date 2018/11/8/008
 */
public enum CacheNames {

    /**
     * load robot into local cache, 30 * 24 * 60 = 43200
     */
    robots(0, 43200, 10000),

    goods(1, 300, 1);


    CacheNames() {

    }

    CacheNames(int type) {
        this.type = type;
    }


    CacheNames(int ttl, int maxSize) {
        this.ttl = ttl;
        this.maxSize = maxSize;
    }

    CacheNames(int type, int ttl, int maxSize) {
        this.type = type;
        this.ttl = ttl;
        this.maxSize = maxSize;
    }

    /**
     * 最大數量
     */
    private int maxSize = 50000;
    /**
     * 过期时间（分）
     */
    private int ttl = 5;

    private int type;

    public int getMaxSize() {
        return maxSize;
    }

    void setMaxSize(int maxSize) {
        this.maxSize = maxSize;
    }

    public int getTtl() {
        return ttl;
    }

    void setTtl(int ttl) {
        this.ttl = ttl;
    }

    public int getType() {
        return type;
    }

    public void setType(int type) {
        this.type = type;
    }
}
