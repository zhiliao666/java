package com.ufoto.account.mapper.read;

import com.ufoto.account.dto.action.InitCharmDto;
import com.ufoto.account.dto.quota.UfotoGoodsList;
import org.apache.ibatis.annotations.Mapper;
import org.apache.ibatis.annotations.Param;
import org.springframework.cache.annotation.Cacheable;
import org.springframework.stereotype.Repository;

import java.util.List;

/**
 * @author luozq
 * @date 2020/1/14 16:53
 */
@Mapper
@Repository
public interface BenefitReadMapper {

    /**
     * get all goods from ufoto_goods_list
     * @return goods
     */
    @Cacheable(cacheManager = "accountCaffeineManager", value = "goods", key = "'goods_cache'", unless = "#result.size() == 0")
    List<UfotoGoodsList> getAllGoods();

    /**
     * get rec gift num
     * @param tUid tUid
     * @return
     */
    InitCharmDto getRecGiftNum(@Param("tUid") Long tUid);

    /**
     * get action num
     * @param tUid targetUid
     * @param index index
     * @param type 1 like, 3 superLike
     * @return
     */
    long getInitActionNum(@Param("tUid") Long tUid,
                          @Param("index") Integer index,
                          @Param("type") int type);

    /**
     * get facePk statics data
     * @param tUid tUid
     * @return face pk num
     */
    InitCharmDto getFacePkNum(@Param("tUid") Long tUid);
}
