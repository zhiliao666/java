package com.ufoto.account.util.factory;

import com.ufoto.account.util.serviceutil.CharmDynamoDbUtil;
import com.ufoto.rabbit.behavior.msg.SnsSlideMsg;
import lombok.extern.slf4j.Slf4j;
import org.springframework.stereotype.Component;

/**
 * @author luozq
 * @date 2020/2/17 16:58
 */
@Slf4j
@Component
public class DisLikeActFactoryImpl extends AbstractActFactory {


    public DisLikeActFactoryImpl(CharmDynamoDbUtil charmDynamoDbUtil) {
        super(charmDynamoDbUtil);
    }

    @Override
    protected void doDailyTask(SnsSlideMsg snsSlideMsg) {
        // view_lzq do nothing
    }
}
