package com.ufoto.account.mq;

import com.rabbitmq.client.Channel;
import com.ufoto.account.service.BenefitService;
import com.ufoto.common.utils.JsonUtil;
import com.ufoto.rabbit.behavior.constants.BehaviorExchange;
import com.ufoto.rabbit.behavior.msg.SnsSlideMsg;
import com.ufoto.rabbit.config.RabbitConsumerExecutor;
import lombok.RequiredArgsConstructor;
import lombok.extern.slf4j.Slf4j;
import org.springframework.amqp.core.ExchangeTypes;
import org.springframework.amqp.rabbit.annotation.*;
import org.springframework.amqp.support.AmqpHeaders;
import org.springframework.messaging.handler.annotation.Header;
import org.springframework.messaging.handler.annotation.Payload;
import org.springframework.stereotype.Component;

/**
 * @author luozq
 * @date 2020/2/10 13:11
 */
@Slf4j
@Component
@RequiredArgsConstructor
public class BenefitMsgConsume {

    private final BenefitService benefitService;

    /**
     *  处理 like ,superLike 行为带来的每日任务和魅力值额度修改
     * @param msgDto msgDto
     * @param channel channel
     * @param deliveryTag deliveryTag
     */
    @RabbitListener(bindings = {
            @QueueBinding(exchange = @Exchange(name = BehaviorExchange.EX_SOCIAL_SNS_SLIDE,
                    type = ExchangeTypes.FANOUT),
            value = @Queue(name = "QUEUE.ACCOUNT.BENEFIT", durable = "true", exclusive = "false"))

    })
    public void benefitConsume(@Payload SnsSlideMsg msgDto, Channel channel,
                               @Header(AmqpHeaders.DELIVERY_TAG) long deliveryTag) {

        log.debug("benefitConsume mq consume task log, msg:{}", JsonUtil.toJson(msgDto));
        // view_lzq 每日任务目前还在 app-api, 暂不需要处理
        RabbitConsumerExecutor.execute(channel, deliveryTag, () -> benefitService.dealWithLikeAct(msgDto));
    }

}
