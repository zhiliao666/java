package com.ufoto.account.util.serviceutil;

import lombok.Data;

import java.math.BigDecimal;


/**
 *
 * @author luozq
 * @date 2020/2/10
 */
@Data
public class CoinMsg {

    private BigDecimal coin;
    /**
     * 余额
     */
    private BigDecimal amount;
}
