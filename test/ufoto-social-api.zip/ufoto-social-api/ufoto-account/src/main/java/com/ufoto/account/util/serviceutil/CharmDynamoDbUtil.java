package com.ufoto.account.util.serviceutil;

import com.amazonaws.services.dynamodbv2.document.DynamoDB;
import com.amazonaws.services.dynamodbv2.document.Item;
import com.amazonaws.services.dynamodbv2.document.PrimaryKey;
import com.amazonaws.services.dynamodbv2.document.Table;
import com.amazonaws.services.dynamodbv2.document.spec.UpdateItemSpec;
import com.amazonaws.services.dynamodbv2.document.utils.ValueMap;
import com.amazonaws.services.dynamodbv2.model.ReturnValue;
import com.ufoto.account.dto.action.InitCharmDto;
import com.ufoto.account.dto.other.DynamoDbUserCharmDto;
import com.ufoto.account.mapper.read.BenefitReadMapper;
import com.ufoto.account.util.constant.CharmDynamoDbEnum;
import com.ufoto.common.utils.JsonUtil;
import com.ufoto.rabbit.behavior.constants.ActionType;
import lombok.RequiredArgsConstructor;
import lombok.extern.slf4j.Slf4j;
import org.springframework.core.env.Environment;
import org.springframework.stereotype.Component;
import org.springframework.util.StopWatch;
import org.springframework.util.StringUtils;

import java.util.EnumSet;
import java.util.Objects;
import java.util.Optional;

import static com.ufoto.account.util.constant.DynamoDbConstant.CHARM_TABLE;

/**
 * @author luozq
 * @date 2020/2/10 16:18
 */
@Slf4j
@Component
@RequiredArgsConstructor
public class CharmDynamoDbUtil {

    private final Environment env;

    private final DynamoDB dynamoDB;

    private final BenefitReadMapper benefitReadMapper;

    private String charmTable;

    /**
     * 增加魅力值
     * @param tUid tUid
     * @param action action
     */
    public void incrementCharm(Long tUid, String action) {
        StopWatch watch = new StopWatch();
        watch.start();
        try {
            Table table = dynamoDB.getTable(getCharTable());
            Item item = table.getItem(new PrimaryKey("uid", tUid));
            if (Objects.isNull(item)) {
                // 从数据库捞出来
                insertCharmFromSchema(tUid, action);
            } else {
                // 更新对应魅力值
                DynamoDbUserCharmDto charmDto = JsonUtil.toObject(item.toJSON(), DynamoDbUserCharmDto.class);
                updateCharmByAction(tUid, action, charmDto);
            }
        } catch (Exception e) {
            log.error("incrementCharm task occurs error, uid:{}, action:{}", tUid, action, e);
        } finally {
            watch.stop();
            log.warn("incrementCharm task statics, uid:{}, action:{}, cost:{}",
                    tUid, action, watch.getLastTaskTimeMillis());
        }
    }

    /**
     * 更新魅力值
     * @param tUid tUid
     * @param action action: like, superLike
     * @param charmDto dynamoDb 中的数据
     */
    private void updateCharmByAction(Long tUid, String action, DynamoDbUserCharmDto charmDto) {
        try {
            Optional<CharmDynamoDbEnum> opt = EnumSet.allOf(CharmDynamoDbEnum.class).stream()
                    .filter(item -> StringUtils.endsWithIgnoreCase(item.getAction(), action))
                    .findAny();
            CharmDynamoDbEnum charmEnum = opt.orElse(null);
            if (Objects.isNull(charmEnum)) {
                log.warn("updateCharmByAction task warn, uid:{}, action:{}, has no mapping dynamoDb field", tUid, action);
                return;
            }
            String actionNumField = charmEnum.getFieldName();
            String charmNumField = CharmDynamoDbEnum.CHARM_NUM.getFieldName();
            // dynamoDb 没有默认值, 需要注意 += 赋值操作
            String updateExpression;
            if (Objects.isNull(charmDto.getLikeNum())) {
                updateExpression  = "set " + actionNumField + " = :val1";
            } else {
                updateExpression = "set " + actionNumField + " = " + actionNumField + " + :val1";
            }

            if (Objects.isNull(charmDto.getCharmNum())) {
                updateExpression  +=  ", " + charmNumField + " = :val2";
            } else {
                updateExpression  +=  ", " + charmNumField + " = " + charmNumField + " + :val2";
            }

            log.debug("updateCharmByAction task expression as follows, uid:{}, action:{}, updateExpression:{}, charmDto:{}",
                    tUid, action, updateExpression, JsonUtil.toJson(charmDto));
            Table table = dynamoDB.getTable(getCharTable());
            UpdateItemSpec updateItemSpec = new UpdateItemSpec()
                    .withPrimaryKey("uid", tUid)
                    .withUpdateExpression(updateExpression)
                    .withValueMap(new ValueMap().withNumber(":val1", 1).withNumber(":val2", charmEnum.getPrice()))
                    .withReturnValues(ReturnValue.UPDATED_NEW);
            table.updateItem(updateItemSpec);
        } catch (Exception e) {
           log.error("updateCharmByAction task occurs error, uid:{}, action:{}, charmDto:{}", tUid, action,
                   JsonUtil.toJson(charmDto), e);
        }
    }

    /**
     * 新增魅力值
     * @param tUid tUid
     * @param action action: like, superLike
     */
    private void insertCharmFromSchema(Long tUid, String action) {
        DynamoDbUserCharmDto charmDto = null;
        try {
            // 从数据库加载
            Integer index = Math.toIntExact(tUid % 100);
            // 查询 ufoto_user_like_t_{index}, 统计被 Like, superLike 的次数
            long likeCount = benefitReadMapper.getInitActionNum(tUid, index, 1);
            long superLikeCount = benefitReadMapper.getInitActionNum(tUid, index, 3);
            // 查询 ufoto_gift_record 获取收礼次数 和魅力值
            InitCharmDto giftCharmDto = benefitReadMapper.getRecGiftNum(tUid);
            // 查询 ufoto_user_charm_record 获取 facePk 次数和对应的魅力值
            InitCharmDto facePkCharmDto = benefitReadMapper.getFacePkNum(tUid);
            log.debug("insertCharmFromSchema params as follows, likeCount:{}, superLikeCount:{}, giftCharmDto:{}, facePkCharmDto:{}",
                    likeCount, superLikeCount, JsonUtil.toJson(giftCharmDto), JsonUtil.toJson(facePkCharmDto));

            if (StringUtils.endsWithIgnoreCase(action, ActionType.ACTION_LIKE.getType())) {
                likeCount += 1;
            } else if (StringUtils.endsWithIgnoreCase(action, ActionType.ACTION_SUPER_LIKE.getType())){
                superLikeCount += 1;
            }
            charmDto = DynamoDbUserCharmDto.builder()
                    .likeNum(likeCount)
                    .superLikeNum(superLikeCount)
                    .facePkNum(0L)
                    .recGiftNum(0L)
                    .facePkNum(0L)
                    .charmNum(0L)
                    .uid(tUid)
                    .build();
            // 计算魅力值
            long totalCharm = likeCount + superLikeCount * 10;
            if (Objects.nonNull(giftCharmDto)) {
                charmDto.setRecGiftNum(giftCharmDto.getCount());
                totalCharm += giftCharmDto.getPrice().longValue();
            }
            if (Objects.nonNull(facePkCharmDto)) {
                charmDto.setFacePkNum(facePkCharmDto.getCount());
                totalCharm += facePkCharmDto.getPrice().longValue();
            }
            charmDto.setCharmNum(totalCharm);

            Item item = Item.fromJSON(JsonUtil.toJson(charmDto));
            dynamoDB.getTable(getCharTable()).putItem(item);
        } catch (Exception e) {
            log.error("insertCharmFromSchema task occurs error, uid:{}, action:{}, charm:{}"
                    , tUid, action, JsonUtil.toJson(charmDto), e);
        }

    }

    private String getCharTable() {
        if (StringUtils.isEmpty(charmTable)) {
            String profile = env.getProperty("spring.profiles.active");
            charmTable = CHARM_TABLE + profile;
        }
        return charmTable;
    }
}
