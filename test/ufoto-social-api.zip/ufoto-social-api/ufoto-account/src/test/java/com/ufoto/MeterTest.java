package com.ufoto;

import com.codahale.metrics.Histogram;
import com.codahale.metrics.MetricRegistry;
import com.codahale.metrics.Snapshot;
import lombok.extern.slf4j.Slf4j;
import org.apache.commons.lang3.RandomUtils;
import org.junit.Test;
import java.util.concurrent.TimeUnit;
import java.util.stream.Stream;


/**
 * @author luozq
 * @date 2020/1/15 18:01
 */
@Slf4j
public class MeterTest {
    private final MetricRegistry metrics = new MetricRegistry();

    private final Histogram responseSizes = metrics.histogram("response-time");


    @Test
    public void testMeter() throws InterruptedException {
        Stream.iterate(0, item -> RandomUtils.nextInt(0, 20))
                .peek(responseSizes::update).limit(1000)
                .forEach(System.out::println);
        Snapshot snapshot = responseSizes.getSnapshot();
        TimeUnit.SECONDS.sleep(2);
    }
}
