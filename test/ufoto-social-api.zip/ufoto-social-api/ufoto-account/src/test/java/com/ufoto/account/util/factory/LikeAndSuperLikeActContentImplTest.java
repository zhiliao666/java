package com.ufoto.account.util.factory;

import com.ufoto.BaseUnitTest;
import com.ufoto.rabbit.behavior.msg.SnsSlideMsg;
import lombok.extern.slf4j.Slf4j;
import org.junit.Test;
import org.springframework.beans.factory.annotation.Autowired;

import static org.junit.Assert.*;

/**
 * @author luozq
 * @date 2020/3/2 14:02
 */
@Slf4j
public class LikeAndSuperLikeActContentImplTest extends BaseUnitTest {

    @Autowired
    private LikeAndSuperLikeActContentImpl actContent;

    @Test
    public void test1() {
        actContent.execute(SnsSlideMsg.builder()
                .uid(100L)
                .targetUid(900L)
                .action("like")
                .build());
    }

}